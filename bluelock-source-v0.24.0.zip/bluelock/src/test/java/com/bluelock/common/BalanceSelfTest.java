package com.bluelock.common;

import com.bluelock.common.story.StoryBalance;

public final class BalanceSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    public static void main(String[] args) {
        check(StoryBalance.opponentRating(62, 50) == 54, "Team X is 54 for a fresh player");
        check(StoryBalance.opponentRating(75, 50) == 67, "Team V is 67 for a fresh player");
        check(StoryBalance.opponentRating(75, 90) == 87 - 2 || StoryBalance.opponentRating(75, 90) == 85, "opponents grow with the player and cap at 85");
        check(StoryBalance.opponentRating(10, 0) == 30, "opponents never fall below 30");
        check(StoryBalance.teammateRating(48, 0, 50) == 48, "Team Z starts at its listed rating");
        check(StoryBalance.teammateRating(48, 12, 50) == 60, "team training lifts Team Z");
        check(StoryBalance.addTeamTraining(22, 5) == StoryBalance.MAX_TEAM_TRAINING, "team training is capped");
        for (StoryBalance.Drill d : StoryBalance.Drill.values()) {
            check(StoryBalance.drillGrowth(d, 0) == 0 && StoryBalance.drillGrowth(d, d.targetScore) == 2
                    && StoryBalance.drillGrowth(d, d.targetScore * 2) == 3 && StoryBalance.Drill.parse(d.id) == d, "drill " + d.id + " scoring");
        }
        check(StoryBalance.drillXp(0) == 4 && StoryBalance.drillXp(100) == 60, "drill xp range");
        System.out.println(failures == 0 ? "ALL BALANCE TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
