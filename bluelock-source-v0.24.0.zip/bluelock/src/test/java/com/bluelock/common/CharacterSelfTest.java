package com.bluelock.common;

import com.bluelock.common.ai.*;
import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.team.TeamTactics;
import java.util.*;

/** Phase 5: Blue Lock characters, traits, sprint energy and speed. */
public final class CharacterSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    private static BotView view(Pos self, boolean hasBall, Pos ball, CharacterTraits t, Position pos, List<Pos> opp) {
        return new BotView(Side.HOME, pos, self, ball, hasBall, hasBall ? Side.HOME : null, hasBall ? self : null, 0, 60,
                TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED), new Pos(30, 18), List.of(new Pos(40, 10)), opp,
                PitchLayout.standard(), BallMotion.STILL, 0.2, 50, 50, t);
    }

    public static void main(String[] args) {
        roster();
        energy();
        speed();
        behaviour();
        looksAndSkills();
        statEffects();
        bodyAndBinds();
        canonAndVoices();
        canonSquads();
        story();
        rolls();
        ranking();
        System.out.println(failures == 0 ? "ALL CHARACTER TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }

    private static void roster() {
        check(Roster.all().size() >= 20, "roster has 20+ characters (" + Roster.all().size() + ")");
        Set<String> ids = new HashSet<>();
        boolean uniq = true;
        for (FootballCharacter c : Roster.all()) uniq &= ids.add(c.id());
        check(uniq, "character ids are unique");
        check(Roster.byId("isagi") != null && Roster.byId("isagi").teamId().equals("team_z"), "Isagi is on team Z");
        check(Roster.byId("chigiri").traits().speed() > Roster.byId("kunigami").traits().speed(), "Chigiri is faster than Kunigami");
        check(Roster.byId("baro").traits().ego() > Roster.byId("isagi").traits().ego(), "Baro has more ego than Isagi");
        Set<String> taken = new HashSet<>();
        FootballCharacter st = Roster.assign("team_z", Position.ST, taken);
        check(st != null && st.position() == Position.ST, "an ST slot gets the ST character");
        taken.add(st.id());
        FootballCharacter again = Roster.assign("team_z", Position.ST, taken);
        check(again == null || !again.id().equals(st.id()), "a character is not given out twice");
        check(Roster.assign("team_z", Position.GK, new HashSet<>()).position() == Position.GK, "a GK slot gets the keeper");
        check(Roster.assign("nope", Position.ST, new HashSet<>()) == null, "unknown team gives no character");
        FootballCharacter isagi = Roster.byId("isagi");
        int look = Roster.lookOf(isagi, 0);
        check(Roster.byLook(look) == isagi && Roster.hairForLook(look).equals(isagi.hair()), "look code leads back to the character and his hair");
        check(Roster.hairForLook(-5).equals(Roster.hairForLook(-5)) && Roster.byLook(-5) == null, "nameless bots get the same hair on every client");
        check(BotStats.forCharacter(60, Roster.byId("chigiri")).base(Stat.TOP_SPEED) > BotStats.forRating(60, Position.RW).base(Stat.TOP_SPEED), "fast characters get speed stats");
    }

    private static void energy() {
        BotEnergy e = new BotEnergy(10);
        check(e.percent() == 100 && !e.isTired(), "energy starts full");
        int ticks = 0;
        while (!e.isTired() && ticks < 1000) { e.update(true, 2); ticks += 2; }
        check(ticks >= 190 && ticks <= 210, "10 s of sprint empties it (" + ticks + " ticks)");
        check(!e.update(true, 2), "a tired bot cannot sprint");
        check(e.speedFactor() < 1.0, "a tired bot jogs slower");
        for (int i = 0; i < 400 && e.isTired(); i++) e.update(false, 2);
        check(!e.isTired() && e.percent() >= BotEnergy.RECOVER_FROM_TIRED, "rest brings it back");
        check(e.update(true, 2), "after resting it can sprint again");
        BotEnergy big = new BotEnergy(20), small = new BotEnergy(5);
        int bigTicks = 0, smallTicks = 0;
        while (!big.isTired() && bigTicks < 2000) { big.update(true, 2); bigTicks += 2; }
        while (!small.isTired() && smallTicks < 2000) { small.update(true, 2); smallTicks += 2; }
        check(smallTicks < bigTicks, "stamina decides how long a sprint lasts");
    }

    private static void speed() {
        double jog = BotSpeed.jog(60, BotDifficulty.NORMAL.speedFactor(), CharacterTraits.NEUTRAL);
        check(jog > 0.13, "a jogging bot is faster than a sprinting player (" + String.format("%.3f", jog) + ")");
        double mult = BotSpeed.sprintMultiplier(jog, CharacterTraits.NEUTRAL);
        check(jog * mult > jog * 1.2 && jog * mult <= BotSpeed.SPRINT_CAP + 1e-9, "sprint is much faster but capped");
        CharacterTraits chigiri = Roster.byId("chigiri").traits();
        double j2 = BotSpeed.jog(90, BotDifficulty.PRO.speedFactor(), chigiri);
        check(j2 * BotSpeed.sprintMultiplier(j2, chigiri) <= BotSpeed.SPRINT_CAP + 1e-9, "even the fastest bot respects the cap");
        check(j2 > jog, "a fast character on PRO outruns a normal bot");
        check(AnimLogicProbe.sprintShownOnlyWhenFast(), "bots show the sprint animation only at sprint speed");
    }

    private static void behaviour() {
        PitchLayout l = PitchLayout.standard();
        // chasing a far ball: sprint
        BotView chase = new BotView(Side.HOME, Position.CM, new Pos(10, 18), new Pos(30, 18), false, null, null, 0, 60,
                TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED), new Pos(20, 18), List.of(), List.of(), l);
        BotDecision d = BotBrain.decide(chase);
        check(d.intent() == Intent.CHASE_BALL && d.sprint(), "chasing a far ball means sprinting");
        BotView close = new BotView(Side.HOME, Position.CM, new Pos(29, 18), new Pos(30, 18), false, null, null, 0, 60,
                TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED), new Pos(20, 18), List.of(), List.of(), l);
        check(!BotBrain.decide(close).sprint(), "a close ball needs no sprint");
        // ego: same spot, only the traits differ
        CharacterTraits egoist = new CharacterTraits(1, 1.35, 10, 100, 50, 50, 50);
        CharacterTraits team = new CharacterTraits(1, 1.35, 10, 10, 50, 50, 50);
        Pos self = new Pos(34, 18);   // 27 from the goal at u = 61
        BotDecision a = BotBrain.decide(view(self, true, self, egoist, Position.ST, List.of()));
        BotDecision b = BotBrain.decide(view(self, true, self, team, Position.ST, List.of()));
        Pos nearShot = new Pos(45, 18);
        boolean egoShoots = BotBrain.decide(view(nearShot, true, nearShot, egoist, Position.ST, List.of())).intent() == Intent.SHOOT;
        check(a.intent() != Intent.SHOOT && b.intent() != Intent.SHOOT && egoShoots, "an egoist shoots from range (sanity)");
        Pos mid = new Pos(40, 18);   // 21 from goal: only the egoist is in range at rating 60
        boolean egoMid = BotBrain.decide(view(mid, true, mid, egoist, Position.ST, List.of())).intent() == Intent.SHOOT;
        boolean teamMid = BotBrain.decide(view(mid, true, mid, team, Position.ST, List.of())).intent() == Intent.SHOOT;
        check(egoMid && !teamMid, "high ego shoots from further out than low ego");
        // old constructors still work
        check(CharacterTraits.forPosition(Position.GK).speed() < CharacterTraits.forPosition(Position.RW).speed(), "wingers are faster than keepers");
        check(new CharacterTraits(9, 9, 99, 500, -5, 0, 0).speed() <= 1.3, "traits are clamped");
    }

    private static void looksAndSkills() {
        boolean allSkillsReal = true, allHair = true, jerseys = true, heights = true;
        java.util.Set<String> realSkills = new HashSet<>(List.of("advanced_field_vision", "awakening_direct_shot", "awareness", "burst_dribble",
                "chain_dribble", "composure_focus", "control", "direct_shot", "feint", "finishing", "interception_read", "passing_lane_read",
                "precision_direct_shot", "pressure_finisher", "shadow_marking", "shoulder_charge", "spatial_read", "sprint_burst", "through_pass",
                "dragon_drive", "curved_shot", "perfect_pass", "monster_dribble", "chameleon", "trap"));
        for (FootballCharacter c : Roster.all()) {
            allSkillsReal &= !c.skills().isEmpty() && realSkills.containsAll(c.skills());
            allHair &= c.hair() != null;
            jerseys &= c.jersey() >= 1 && c.jersey() <= 99 && !c.shirtName().isEmpty();
            heights &= c.heightScale() >= 0.92 && c.heightScale() <= 1.10;
        }
        check(allSkillsReal, "every character has skills, all of them skills that exist");
        check(allHair && jerseys && heights, "every character has hair, a shirt name and number and a sane height");
        Set<com.bluelock.common.appearance.HairDesign> hairs = new HashSet<>();
        for (FootballCharacter c : Roster.all()) hairs.add(c.hair());
        check(hairs.size() >= Roster.all().size() - 2, "characters look different from each other (" + hairs.size() + " different hairstyles)");
        check(Roster.byId("chigiri").hair().color() != Roster.byId("nagi").hair().color(), "Chigiri's and Nagi's hair colours differ");
        check(Roster.byId("rin").skills().contains("awakening_direct_shot") && Roster.byId("chigiri").skills().contains("sprint_burst"), "Rin has the awakening shot, Chigiri the sprint burst");
        check(Roster.byId("kaiser").heightCm() > Roster.byId("isagi").heightCm(), "Kaiser is taller than Isagi");
        BotSkillRules.ShotBoost none = BotSkillRules.shot(List.of());
        BotSkillRules.ShotBoost awaken = BotSkillRules.shot(List.of("awakening_direct_shot"));
        BotSkillRules.ShotBoost precise = BotSkillRules.shot(List.of("precision_direct_shot"));
        check(none.spreadMul() == 1.0 && none.powerMul() == 1.0 && none.anim() == null, "no skill: the shot is unchanged");
        check(awaken.powerMul() > precise.powerMul() && precise.spreadMul() < awaken.spreadMul(), "awakening shoots harder, precision shoots straighter");
        check("feint".equals(BotSkillRules.dribbleSkill(List.of("feint", "burst_dribble"), true, true)), "under pressure a bot feints");
        check("burst_dribble".equals(BotSkillRules.dribbleSkill(List.of("feint", "burst_dribble"), false, true)), "in open space a bot bursts");
        check(BotSkillRules.dribbleSkill(List.of(), true, true) == null, "no skills: no dribble skill");
        check(BotSkillRules.passLead(List.of("through_pass")) > BotSkillRules.passLead(List.of()), "through pass leads the runner further");
        com.bluelock.common.appearance.KitDesign blue = com.bluelock.common.appearance.KitDesign.forTeam(0x2F6BFF, 7, "chigiri");
        com.bluelock.common.appearance.KitDesign yellow = com.bluelock.common.appearance.KitDesign.forTeam(0xF4D03F, 7, "x");
        check(blue.shirt() == 0x2F6BFF && blue.name().equals("CHIGIRI") && blue.number() == 7, "kit has team colour, upper-case name and number");
        check(blue.trim() == 0xFFFFFF && yellow.trim() != 0xFFFFFF, "dark shirts get white trim, light shirts dark trim");
        check(com.bluelock.common.appearance.KitDesign.numberFor(Position.GK) == 1 && com.bluelock.common.appearance.KitDesign.numberFor(Position.ST) == 9, "position numbers: keeper 1, striker 9");
        check(new com.bluelock.common.appearance.KitDesign(0, 0, 0, 0, 500, "AVERYLONGNAMEINDEED").number() == 99
                && new com.bluelock.common.appearance.KitDesign(0, 0, 0, 0, 5, "AVERYLONGNAMEINDEED").name().length() <= 12, "kit number and name are limited");
    }

    private static void statEffects() {
        check(Math.abs(com.bluelock.common.stats.StatEffects.moveSpeed(50, 50) - 1.0) < 1e-9, "average stats run at normal speed");
        check(com.bluelock.common.stats.StatEffects.moveSpeed(90, 80) > com.bluelock.common.stats.StatEffects.moveSpeed(40, 40), "more Top Speed and Acceleration means faster");
        check(com.bluelock.common.stats.StatEffects.moveSpeed(100, 100) <= 1.2 && com.bluelock.common.stats.StatEffects.moveSpeed(0, 0) >= 0.8, "speed from stats stays in 80-120%");
        check(com.bluelock.common.stats.StatEffects.sprintLength(90) > com.bluelock.common.stats.StatEffects.sprintLength(30), "more stamina means longer sprints");
        check(com.bluelock.common.stats.StatEffects.jumpHeight(100) > com.bluelock.common.stats.StatEffects.jumpHeight(0), "more Jump means higher jumps");
        check(com.bluelock.common.stats.StatEffects.passReach(90) > com.bluelock.common.stats.StatEffects.passReach(20), "more Vision means a longer look for passes");
        double slow = BotSpeed.jog(60, 1.05, CharacterTraits.NEUTRAL, com.bluelock.common.stats.StatEffects.moveSpeed(20, 20));
        double fast = BotSpeed.jog(60, 1.05, CharacterTraits.NEUTRAL, com.bluelock.common.stats.StatEffects.moveSpeed(90, 90));
        check(fast > slow * 1.2, "a bot with high Top Speed is clearly faster than one with low");
        PitchLayout l = PitchLayout.standard();
        Pos self = new Pos(20, 18);
        Pos far = new Pos(44, 18);   // 24 blocks away: only a visionary sees it
        TeamTactics tt = TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED);
        BotView blind = new BotView(Side.HOME, Position.CM, self, self, true, Side.HOME, self, 0, 60, tt, new Pos(30, 18), List.of(far), List.of(), l,
                BallMotion.STILL, 0.2, 50, 50, CharacterTraits.NEUTRAL, 10);
        BotView seer = new BotView(Side.HOME, Position.CM, self, self, true, Side.HOME, self, 0, 60, tt, new Pos(30, 18), List.of(far), List.of(), l,
                BallMotion.STILL, 0.2, 50, 50, CharacterTraits.NEUTRAL, 95);
        check(BotBrain.decide(blind).intent() != Intent.PASS && BotBrain.decide(seer).intent() == Intent.PASS, "only a bot with good Vision plays the long pass");
    }

    private static void canonSquads() {
        check(Roster.ofTeam("team_z").size() == 11, "Team Z has its 11 First Selection players (" + Roster.ofTeam("team_z").size() + ")");
        check(Roster.byId("isagi").jersey() == 11 && Roster.byId("chigiri").jersey() == 4 && Roster.byId("gagamaru").jersey() == 6
                && Roster.byId("nagi").jersey() == 11 && Roster.byId("reo").jersey() == 9 && Roster.byId("baro").jersey() == 10, "First Selection jersey numbers");
        check(Roster.byId("nagi").teamId().equals("team_v") && Roster.byId("reo").teamId().equals("team_v") && Roster.byId("zantetsu").teamId().equals("team_v"), "Team V is Nagi, Reo and Zantetsu");
        check(Roster.byId("baro").teamId().equals("team_x") && Roster.byId("junichi").teamId().equals("team_w"), "Baro is Team X, Junichi is Team W");
        boolean keptOut = true;
        for (String id : new String[] {"rin", "shidou", "kaiser", "sae", "noa"}) {
            keptOut &= Roster.byId(id) != null && Roster.byId(id).teamId().isEmpty();
        }
        check(keptOut, "Rin, Shidou, Kaiser, Sae and Noa are in the roster but on no Season 1 team");
        java.util.Set<String> taken = new java.util.HashSet<>();
        boolean noStory = true;
        for (String team : new String[] {"team_z", "team_v", "team_w", "team_x", "team_y"}) {
            for (Position p : new Position[] {Position.ST, Position.CM, Position.CB, Position.GK, Position.LW}) {
                FootballCharacter c = Roster.assign(team, p, new java.util.HashSet<>());
                noStory &= c == null || !c.teamId().isEmpty();
            }
        }
        check(noStory, "squads never pick a character without a Season 1 team");
        check(Roster.byId("chigiri").traits().speed() >= Roster.byId("isagi").traits().speed(), "Chigiri is the fastest");
        com.bluelock.common.stats.StatBlock chigiri = BotStats.forCharacter(50, Roster.byId("chigiri"));
        com.bluelock.common.stats.StatBlock isagi = BotStats.forCharacter(50, Roster.byId("isagi"));
        check(chigiri.base(Stat.TOP_SPEED) > isagi.base(Stat.TOP_SPEED) + 10, "canon stat bias: Chigiri is much faster than Isagi");
        check(isagi.base(Stat.SPATIAL_AWARENESS) > chigiri.base(Stat.SPATIAL_AWARENESS), "canon stat bias: Isagi sees space better");
        String story = "";
        try (java.io.InputStream in = CharacterSelfTest.class.getResourceAsStream("/data/bluelock/story/characters.json")) {
            story = in == null ? "" : new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (java.io.IOException e) {
            story = "";
        }
        boolean allListed = !story.isEmpty();
        for (FootballCharacter c : Roster.all()) {
            allListed &= story.contains("\"id\": \"" + c.id() + "\"");
        }
        check(allListed, "every roster character is in the story data file");
    }

    private static void canonAndVoices() {
        check(Roster.byId("nagi").skills().contains("trap"), "Nagi has Trap");
        check(Roster.byId("bachira").skills().contains("monster_dribble"), "Bachira has Monster Dribble");
        check(Roster.byId("reo").skills().contains("chameleon"), "Reo has Chameleon");
        check(Roster.byId("sae").skills().contains("perfect_pass"), "Sae has Perfect Pass");
        check(Roster.byId("shidou").skills().contains("dragon_drive"), "Shidou has Dragon Drive");
        check(Roster.byId("rin").skills().contains("curved_shot"), "Rin has Curved Shot");
        boolean allVoiced = true;
        for (FootballCharacter c : Roster.all()) {
            int v = com.bluelock.common.audio.Voices.ofCharacter(c.id());
            allVoiced &= v >= 0 && v < com.bluelock.common.audio.Voices.TYPES.length;
        }
        check(allVoiced, "every character has a voice type");
        check(com.bluelock.common.audio.Voices.fromLook(90, 50, 2) < 2 && com.bluelock.common.audio.Voices.fromLook(10, 50, 2) >= 4, "tall sounds deeper than small");
        check(com.bluelock.common.audio.Voices.mayAct(0, 10, com.bluelock.common.audio.Voices.Event.SHOT) == false
                && com.bluelock.common.audio.Voices.mayAct(0, 100, com.bluelock.common.audio.Voices.Event.SHOT), "voice cooldown works");
        check(com.bluelock.common.audio.Voices.Event.GOAL.fileName(1).equals("voice_deep_fierce_goal"), "voice file names");
    }

    private static void bodyAndBinds() {
        com.bluelock.common.appearance.BodyDesign b = com.bluelock.common.appearance.BodyDesign.standard();
        check(b.heightScale() > 0.92 && b.heightScale() < 1.10 && b.buildScale() > 0.92 && b.buildScale() < 1.12, "standard body has a normal size");
        check(new com.bluelock.common.appearance.BodyDesign(0, 999, -5, 0, 99, 99, 99, 99).height() == 100
                && new com.bluelock.common.appearance.BodyDesign(0, 999, -5, 0, 99, 99, 99, 99).eyeStyle() == 5, "body values are clamped");
        check(com.bluelock.common.appearance.BodyDesign.fromInts(b.withSkin(0x123456).withMark(2).toInts()).equals(b.withSkin(0x123456).withMark(2)), "body survives ints round trip");
        check(com.bluelock.common.appearance.BodyDesign.fromMap(b.withEyeStyle(3).toMap()).eyeStyle() == 3, "body survives map round trip");
        check(com.bluelock.common.appearance.BodyDesign.fromInts(new int[] {1, 2}).equals(b), "short body data gives the standard body");
        check(Roster.byId("kaiser").body().heightScale() > Roster.byId("isagi").body().heightScale(), "Kaiser's body is taller than Isagi's");
        check(Roster.bodyForLook(-3).equals(Roster.bodyForLook(-3)) && Roster.bodyForLook(Roster.lookOf(Roster.byId("rin"), 0)).equals(Roster.byId("rin").body()), "look codes give the same body everywhere");

        com.bluelock.common.profile.PlayerProfile p = new com.bluelock.common.profile.PlayerProfile(UUID.randomUUID(), "Roy", "",
                com.bluelock.common.profile.DominantFoot.RIGHT, com.bluelock.common.profile.Archetype.STRIKER,
                com.bluelock.common.profile.Personality.CREATIVE, com.bluelock.common.stats.StatBlock.uniform(50));
        check(!p.bind(0, "trap"), "a skill you do not own cannot be bound");
        p.unlockSkill("trap");
        p.unlockSkill("curved_shot");
        check(p.bind(0, "trap") && p.bound(0).equals("trap") && p.slotOf("trap") == 0, "an owned skill binds to slot 1");
        check(p.bind(2, "trap") && p.bound(0) == null && p.bound(2).equals("trap"), "a skill sits on one slot only");
        check(p.bind(1, "curved_shot") && p.bind(1, null) && p.bound(1) == null && p.isUnlocked("curved_shot"), "unbinding keeps the skill owned");
        check(!p.bind(3, "trap") && !p.bind(-1, "trap"), "only three slots exist");
        p.setBody(b.withSkin(0xAA5533).withHeight(80));
        p.bind(1, "curved_shot");
        com.bluelock.common.profile.PlayerProfile q = com.bluelock.common.persistence.ProfileCodec.fromMap(com.bluelock.common.persistence.ProfileCodec.toMap(p));
        check(q.bound(1).equals("curved_shot") && q.bound(2).equals("trap") && q.body().skin() == 0xAA5533 && q.body().height() == 80, "bound skills and body survive saving");
        check(BotSkillRules.shot(List.of("dragon_drive")).powerMul() > BotSkillRules.shot(List.of("direct_shot")).powerMul(), "Dragon Drive shoots harder than a direct shot");
        check(BotSkillRules.shot(List.of("curved_shot")).curve() > 0 && BotSkillRules.shot(List.of()).curve() == 0, "Curved Shot curves the ball");
        check(BotSkillRules.passSpread(List.of("perfect_pass")) == 0.0 && BotSkillRules.passLead(List.of("perfect_pass")) > BotSkillRules.passLead(List.of("through_pass")), "Perfect Pass is exact and leads further");
        check(BotSkillRules.touchBonus(List.of("trap")) >= 100 && BotSkillRules.touchBonus(List.of()) == 0, "Trap gives perfect touch");
        check("monster_dribble".equals(BotSkillRules.dribbleSkill(List.of("monster_dribble", "feint"), true, false)), "Monster Dribble is used under pressure");
    }

    /** Small helper so the test does not need the anim package imports above. */
    private static final class AnimLogicProbe {
        static boolean sprintShownOnlyWhenFast() {
            return com.bluelock.common.anim.AnimLogic.botLocomotion(0.30, false, false).equals("run")
                    && com.bluelock.common.anim.AnimLogic.botLocomotion(0.45, false, false).equals("sprint")
                    && com.bluelock.common.anim.AnimLogic.botLocomotion(0.45, true, false).equals("dribble_sprint")
                    && com.bluelock.common.anim.AnimLogic.botLocomotion(0.10, false, false).equals("walk");
        }
    }

    private static void story() {
        var all = com.bluelock.common.story.StoryBook.all();
        check(all.size() == 16 && com.bluelock.common.story.StoryBook.isFinished(15) && !com.bluelock.common.story.StoryBook.isFinished(0), "chapter 1 has 16 beats ending in END");
        check(com.bluelock.common.story.StoryBook.beat(99).kind() == com.bluelock.common.story.StoryBook.Kind.END && com.bluelock.common.story.StoryBook.beat(-3).id().equals("arrival"), "beat index is clamped");
        check(com.bluelock.common.story.StoryBook.passed(com.bluelock.common.story.StoryBook.Objective.SCORE, 1, 5)
                && !com.bluelock.common.story.StoryBook.passed(com.bluelock.common.story.StoryBook.Objective.SCORE, 0, 0), "SCORE needs one goal");
        check(com.bluelock.common.story.StoryBook.passed(com.bluelock.common.story.StoryBook.Objective.NOT_LOSE, 1, 1)
                && !com.bluelock.common.story.StoryBook.passed(com.bluelock.common.story.StoryBook.Objective.NOT_LOSE, 0, 1), "NOT_LOSE allows a draw");
        check(!com.bluelock.common.story.StoryBook.passed(com.bluelock.common.story.StoryBook.Objective.WIN, 1, 1)
                && com.bluelock.common.story.StoryBook.passed(com.bluelock.common.story.StoryBook.Objective.WIN, 2, 1), "WIN needs more goals");
        boolean sceneOk = true;
        boolean speakersOk = true;
        for (var b : all) {
            if (b.kind() == com.bluelock.common.story.StoryBook.Kind.SCENE) {
                sceneOk &= !b.lines().isEmpty();
                for (var l : b.lines()) {
                    speakersOk &= l.speaker().equals("narrator") || l.speaker().equals("ego") || l.speaker().equals("player") || Roster.byId(l.speaker()) != null;
                }
            } else if (b.kind() == com.bluelock.common.story.StoryBook.Kind.TRIAL) {
                speakersOk &= b.length() >= 20 && b.place().equals("team_z_room");
            } else if (b.kind() == com.bluelock.common.story.StoryBook.Kind.MATCH) {
                speakersOk &= !Roster.ofTeam(b.opponent()).isEmpty() && b.length() > 0;
            }
        }
        check(sceneOk && speakersOk, "every scene has lines, every speaker is known and every opponent has a squad");
        check(com.bluelock.common.story.StoryBook.scene("rules") != null && com.bluelock.common.story.StoryBook.scene("x") == null, "scenes are found by id");
        var profile = new com.bluelock.common.profile.PlayerProfile(java.util.UUID.randomUUID(), "Tester", "", com.bluelock.common.profile.DominantFoot.RIGHT,
                com.bluelock.common.profile.Archetype.STRIKER, com.bluelock.common.profile.Personality.CREATIVE, com.bluelock.common.stats.StatBlock.uniform(50));
        profile.setStoryBeat(7);
        var back = com.bluelock.common.persistence.ProfileCodec.fromMap(com.bluelock.common.persistence.ProfileCodec.toMap(profile));
        check(back.storyBeat() == 7, "story progress survives saving");
    }

    private static void rolls() {
        java.util.Random random = new java.util.Random(7);
        int n = 200000;
        int[] count = new int[101];
        long sum = 0;
        int min = 100;
        int max = 0;
        for (int i = 0; i < n; i++) {
            int p = com.bluelock.common.profile.TalentRoll.roll(random::nextDouble);
            count[p]++;
            sum += p;
            min = Math.min(min, p);
            max = Math.max(max, p);
        }
        double mean = sum / (double) n;
        check(Math.abs(mean - 50) < 0.6, "the talent roll averages 50 (" + String.format("%.2f", mean) + ")");
        check(min >= 10 && max <= 100, "the talent roll stays within 10..100");
        check(count[50] > count[65] && count[65] > count[80] && count[80] > count[92], "rolls get rarer the further they are from 50, upwards");
        check(count[50] > count[35] && count[35] > count[20] && count[20] > count[12], "rolls get rarer the further they are from 50, downwards");
        check(count[88] > 0 && count[14] > 0, "far values are still possible");
        check(com.bluelock.common.profile.TalentRoll.chanceAtLeast(10) > 0.999 && com.bluelock.common.profile.TalentRoll.chanceAtLeast(90) < 0.02
                && com.bluelock.common.profile.TalentRoll.chanceOf(100) > 0, "the odds shown to the player are consistent");
        check(com.bluelock.common.profile.TalentRoll.talentOf(74) == com.bluelock.common.profile.Talent.NORMAL
                && com.bluelock.common.profile.TalentRoll.talentOf(75) == com.bluelock.common.profile.Talent.GENIUS, "75 and up is a Genius");
        check(Math.abs(com.bluelock.common.profile.TalentRoll.xpMultiplier(50) - 1.0) < 1e-9
                && com.bluelock.common.profile.TalentRoll.xpMultiplier(100) > com.bluelock.common.profile.TalentRoll.xpMultiplier(10), "talent changes XP gain, 50 is normal");
        var profile = new com.bluelock.common.profile.PlayerProfile(java.util.UUID.randomUUID(), "Tester", "", com.bluelock.common.profile.DominantFoot.RIGHT,
                com.bluelock.common.profile.Archetype.STRIKER, com.bluelock.common.profile.Personality.CREATIVE, com.bluelock.common.stats.StatBlock.uniform(50));
        profile.setTalentPercent(93);
        profile.setRankPoints(420);
        var back = com.bluelock.common.persistence.ProfileCodec.fromMap(com.bluelock.common.persistence.ProfileCodec.toMap(profile));
        check(back.talentPercent() == 93 && back.talent() == com.bluelock.common.profile.Talent.GENIUS && back.rankPoints() == 420, "talent percent and rank points survive saving");
    }

    private static void ranking() {
        var table = com.bluelock.common.rank.Ranking.table("Me", 0);
        check(table.size() == 300 && table.get(299).player() && table.get(299).rank() == 300, "the ranking has 300 rows and a new player is last");
        java.util.Set<String> names = new java.util.HashSet<>();
        for (var r : table) names.add(r.name());
        check(names.size() == 300, "all 300 names are different");
        check(com.bluelock.common.rank.Ranking.rankOf(5000) == 1 && com.bluelock.common.rank.Ranking.rankOf(0) == 300, "points move the player between first and last");
        check(com.bluelock.common.rank.Ranking.rankOf(500) < com.bluelock.common.rank.Ranking.rankOf(100), "more points means a better rank");
        boolean isagiLow = false;
        boolean rinHigh = false;
        for (var r : table) {
            if (r.characterId().equals("isagi") && r.rank() >= 289) isagiLow = true;
            if (r.characterId().equals("rin") && r.rank() <= 3) rinHigh = true;
        }
        check(isagiLow && rinHigh, "Team Z sits at the bottom and the stars at the top");
        check(com.bluelock.common.rank.Cafeteria.tierOf(1) == com.bluelock.common.rank.Cafeteria.Tier.S
                && com.bluelock.common.rank.Cafeteria.tierOf(300) == com.bluelock.common.rank.Cafeteria.Tier.D
                && com.bluelock.common.rank.Cafeteria.mealFor(1).food() > com.bluelock.common.rank.Cafeteria.mealFor(300).food(), "better rank, better meal");
        check(com.bluelock.common.rank.Ranking.pointsToNextRank(0) == 11 && com.bluelock.common.rank.Ranking.pointsToNextRank(5000) == 0, "points to the next place");
    }
}
