package com.bluelock.forge;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.AABB;

/**
 * "I have the ball" without looking down (client only). While the local player carries the ball a ring of ticks pulses
 * around the crosshair with a small BALL tag; when the ball is gained the ring flashes outward, and when it is lost it
 * flashes red. It reads the synchronised carrier id of the nearby BallEntity, so nothing is sent over the network.
 */
public final class ClientBallCue {
    private static boolean had;
    private static int ticks;
    private static int gainFlash;
    private static int loseFlash;
    private static int sinceGain;

    private ClientBallCue() {
    }

    public static boolean has() {
        return had;
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        boolean now = false;
        if (mc.player != null && mc.level != null) {
            AABB box = mc.player.getBoundingBox().inflate(6.0);
            for (BallEntity ball : mc.level.getEntitiesOfClass(BallEntity.class, box)) {
                if (ball.carrierId() == mc.player.getId()) {
                    now = true;
                    break;
                }
            }
        }
        if (now && !had) {
            gainFlash = 10;
            sinceGain = 0;
        } else if (!now && had) {
            loseFlash = 10;
        }
        if (now) {
            sinceGain++;
        }
        had = now;
        ticks++;
        if (gainFlash > 0) {
            gainFlash--;
        }
        if (loseFlash > 0) {
            loseFlash--;
        }
    }

    public static void draw(GuiGraphics g, Font font, int width, int height) {
        if (!had && gainFlash <= 0 && loseFlash <= 0) {
            return;
        }
        int cx = width / 2;
        int cy = height / 2;
        double pulse = 0.5 + 0.5 * Math.sin(ticks * 0.35);
        int radius = 13 + (int) Math.round(pulse * 2);
        int color = BlueUi.CYAN;
        int alpha = had ? 150 + (int) Math.round(pulse * 80) : 0;
        if (gainFlash > 0) {
            radius += (10 - gainFlash) * 2;
            alpha = 60 + gainFlash * 19;
            color = BlueUi.GOLD;
        } else if (loseFlash > 0) {
            radius += (10 - loseFlash);
            alpha = 40 + loseFlash * 20;
            color = BlueUi.RED;
        }
        int rgba = (Math.min(255, alpha) << 24) | (color & 0xFFFFFF);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8 + (had ? ticks * 0.02 : 0);
            int x = cx + (int) Math.round(Math.cos(a) * radius);
            int y = cy + (int) Math.round(Math.sin(a) * radius);
            g.fill(x - 1, y - 1, x + 2, y + 2, rgba);
        }
        if (had) {
            Component tag = Component.translatable("bluelock.hud.ball");
            g.drawCenteredString(font, tag, cx, cy + radius + 6, rgba);
            // a bar that fills as the carry goes on: shows how long you have held it
            int w = Math.min(30, sinceGain / 4);
            g.fill(cx - 15, cy + radius + 17, cx - 15 + w, cy + radius + 18, rgba);
        }
    }
}
