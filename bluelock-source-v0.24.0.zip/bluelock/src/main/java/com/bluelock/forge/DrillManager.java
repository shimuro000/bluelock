package com.bluelock.forge;

import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.story.StoryBalance;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Training mini-games for the training room (or anywhere): SPRINT between two markers, PASSING and SHOOTING at a target.
 * The score becomes permanent growth on the drill's stats (up to a ceiling, so the drills help a beginner but do not
 * replace development points) plus some XP, and every good drill also trains Team Z a little.
 * Start one with /bluelock drill <sprint|passing|shooting>; /bluelock drill stop ends it early.
 */
public final class DrillManager {
    private static final Map<UUID, Session> SESSIONS = new HashMap<>();
    private static final Random RANDOM = new Random();

    private DrillManager() {
    }

    private static final class Session {
        final StoryBalance.Drill drill;
        final ServerLevel level;
        final double ox;
        final double oy;
        final double oz;
        final double fx;   // forward unit vector
        final double fz;
        int ticksLeft;
        int score;
        int target;      // sprint: which end (0 or 1)
        double tx;
        double tz;
        BallEntity ball;
        int idle;
        int ticks;

        Session(StoryBalance.Drill drill, ServerPlayer p) {
            this.drill = drill;
            this.level = (ServerLevel) p.level();
            this.ox = p.getX();
            this.oy = p.getY();
            this.oz = p.getZ();
            Vec3 look = p.getLookAngle();
            double len = Math.max(1.0E-3, Math.sqrt(look.x * look.x + look.z * look.z));
            this.fx = look.x / len;
            this.fz = look.z / len;
            this.ticksLeft = drill.seconds * 20;
        }
    }

    public static boolean running(UUID id) {
        return SESSIONS.containsKey(id);
    }

    public static void start(ServerPlayer player, StoryBalance.Drill drill) {
        if (TrialManager.running()) {
            player.sendSystemMessage(Component.translatable("bluelock.drill.busy"));
            return;
        }
        stop(player, false);
        Session s = new Session(drill, player);
        SESSIONS.put(player.getUUID(), s);
        if (drill == StoryBalance.Drill.SPRINT) {
            moveSprintTarget(s);
        } else {
            s.ball = BallEntity.spawn(s.level, s.ox + s.fx * 1.2, s.oy + 0.2, s.oz + s.fz * 1.2);
            s.ball.takeBy(player);
            moveTarget(s);
        }
        Titles.show(player, Component.translatable("bluelock.drill." + drill.id).withStyle(ChatFormatting.AQUA),
                Component.translatable("bluelock.drill." + drill.id + ".how"), 5, 50, 10);
        Juice.sound(s.level, s.ox, s.oy, s.oz, ModSounds.WHISTLE, 0.8F, 1.2F);
    }

    public static void stop(ServerPlayer player, boolean announce) {
        Session s = SESSIONS.remove(player.getUUID());
        if (s != null) {
            if (s.ball != null) {
                s.ball.discard();
            }
            if (announce) {
                player.sendSystemMessage(Component.translatable("bluelock.drill.stopped"));
            }
        }
    }

    private static void moveSprintTarget(Session s) {
        double d = s.target == 0 ? 14 : -2;
        s.tx = s.ox + s.fx * d;
        s.tz = s.oz + s.fz * d;
    }

    private static void moveTarget(Session s) {
        double dist = s.drill == StoryBalance.Drill.PASSING ? 9 + RANDOM.nextInt(4) : 15 + RANDOM.nextInt(5);
        double side = (RANDOM.nextDouble() - 0.5) * (s.drill == StoryBalance.Drill.PASSING ? 8 : 10);
        s.tx = s.ox + s.fx * dist - s.fz * side;
        s.tz = s.oz + s.fz * dist + s.fx * side;
    }

    public static void tick(MinecraftServer server) {
        if (SESSIONS.isEmpty()) {
            return;
        }
        Iterator<Map.Entry<UUID, Session>> it = SESSIONS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Session> e = it.next();
            Session s = e.getValue();
            ServerPlayer p = server.getPlayerList().getPlayer(e.getKey());
            if (p == null || p.isDeadOrDying() || p.level() != s.level) {
                if (s.ball != null) {
                    s.ball.discard();
                }
                it.remove();
                continue;
            }
            s.ticks++;
            s.ticksLeft--;
            double dx = p.getX() - s.ox;
            double dz = p.getZ() - s.oz;
            if (dx * dx + dz * dz > 60 * 60) {
                if (s.ball != null) {
                    s.ball.discard();
                }
                it.remove();
                p.sendSystemMessage(Component.translatable("bluelock.drill.stopped"));
                continue;
            }
            if (s.drill == StoryBalance.Drill.SPRINT) {
                sprintTick(s, p);
            } else {
                targetTick(s, p);
            }
            drawTarget(s);
            if (s.ticks % 10 == 0) {
                p.displayClientMessage(Component.translatable("bluelock.drill.hud", s.ticksLeft / 20 + 1, s.score, s.drill.targetScore), true);
            }
            if (s.ticksLeft <= 0) {
                it.remove();
                finish(server, p, s);
            }
        }
    }

    private static void sprintTick(Session s, ServerPlayer p) {
        double dx = p.getX() - s.tx;
        double dz = p.getZ() - s.tz;
        if (dx * dx + dz * dz < 2.2 * 2.2) {
            s.score++;
            s.target = 1 - s.target;
            moveSprintTarget(s);
            Juice.sound(s.level, p.getX(), p.getY(), p.getZ(), ModSounds.TOUCH, 0.9F, 1.0F + Math.min(0.8F, s.score * 0.05F));
            Juice.particles(s.level, ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1, p.getZ(), 8, 0.4, 0.05);
        }
    }

    private static void targetTick(Session s, ServerPlayer p) {
        if (s.ball == null || !s.ball.isAlive()) {
            s.ball = BallEntity.spawn(s.level, p.getX(), p.getY() + 0.2, p.getZ());
            s.ball.takeBy(p);
        }
        double bx = s.ball.getX() - s.tx;
        double bz = s.ball.getZ() - s.tz;
        double by = s.ball.getY() - s.oy;
        boolean touchedByPlayer = p.getUUID().equals(s.ball.lastToucher());
        if (bx * bx + bz * bz < 1.6 * 1.6 && by < 3.5 && touchedByPlayer && s.ball.carrier() == null) {
            s.score++;
            Juice.sound(s.level, s.tx, s.oy + 1, s.tz, ModSounds.GOAL, 0.9F, 1.0F + Math.min(0.6F, s.score * 0.04F));
            Juice.particles(s.level, ParticleTypes.FIREWORK, s.tx, s.oy + 1.2, s.tz, 24, 0.5, 0.15);
            Titles.show(p, Component.literal("+1").withStyle(ChatFormatting.GOLD), null, 0, 8, 6);
            s.ball.release();
            s.ball.placeAt(p.getX() + s.fx * 1.0, s.oy + 0.2, p.getZ() + s.fz * 1.0);
            s.ball.takeBy(p);
            moveTarget(s);
            s.idle = 0;
            return;
        }
        // a ball that stopped or flew away comes back to the player
        boolean still = s.ball.carrier() == null && s.ball.getDeltaMovement().horizontalDistanceSqr() < 0.0004;
        s.idle = still ? s.idle + 1 : 0;
        double far = s.ball.distanceToSqr(p);
        if (s.idle > 50 || far > 45 * 45) {
            s.ball.placeAt(p.getX() + s.fx * 0.8, s.oy + 0.2, p.getZ() + s.fz * 0.8);
            s.ball.takeBy(p);
            s.idle = 0;
        }
    }

    private static void drawTarget(Session s) {
        if (s.ticks % 4 != 0) {
            return;
        }
        double y = s.oy;
        for (int i = 0; i < 10; i++) {
            double a = Math.PI * 2 * i / 10 + s.ticks * 0.05;
            Juice.particles(s.level, ParticleTypes.END_ROD, s.tx + Math.cos(a) * 1.3, y + 0.15, s.tz + Math.sin(a) * 1.3, 1, 0.0, 0.0);
        }
        for (int h = 1; h <= 4; h++) {
            Juice.particles(s.level, s.drill == StoryBalance.Drill.SPRINT ? ParticleTypes.GLOW : ParticleTypes.END_ROD, s.tx, y + h * 0.6, s.tz, 1, 0.0, 0.0);
        }
    }

    private static void finish(MinecraftServer server, ServerPlayer p, Session s) {
        if (s.ball != null) {
            s.ball.discard();
        }
        int growth = StoryBalance.drillGrowth(s.drill, s.score);
        Optional<PlayerProfile> found = ProfileSavedData.get(server).load(p.getUUID());
        int given = 0;
        if (found.isPresent()) {
            PlayerProfile profile = found.get();
            for (Stat stat : s.drill.stats) {
                int room = StoryBalance.DRILL_CEILING - profile.stats().permanent(stat);
                int add = Math.max(0, Math.min(growth, room));
                if (add > 0) {
                    profile.stats().setGrowth(stat, profile.stats().growth(stat) + add);
                    given += add;
                }
            }
            Progression.LevelUp up = Progression.award(profile, StoryBalance.drillXp(s.score));
            ProfileSavedData.get(server).save(profile);
            MenuServer.sendState(p);
            if (up.happened()) {
                p.sendSystemMessage(Component.translatable("bluelock.progress.levelup", up.newLevel(),
                        Progression.SKILL_POINTS_PER_LEVEL * up.levelsGained(), Progression.DEVELOPMENT_POINTS_PER_LEVEL * up.levelsGained()));
            }
        }
        StoryManager.drillDone(server, p.getUUID(), growth);
        Titles.show(p, Component.translatable("bluelock.drill.done").withStyle(growth > 0 ? ChatFormatting.GOLD : ChatFormatting.GRAY),
                Component.translatable("bluelock.drill.result", s.score, growth), 5, 50, 15);
        Juice.sound(s.level, p.getX(), p.getY(), p.getZ(), growth > 0 ? ModSounds.GOAL : ModSounds.WHISTLE, 0.8F, 1.0F);
        StringBuilder names = new StringBuilder();
        for (Stat stat : s.drill.stats) {
            names.append(stat.name().toLowerCase(java.util.Locale.ROOT).replace('_', ' ')).append(", ");
        }
        p.sendSystemMessage(Component.translatable(given > 0 ? "bluelock.drill.gain" : "bluelock.drill.nogain",
                s.score, names.substring(0, names.length() - 2), growth));
    }
}
