package com.bluelock.forge;

import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.content.QuestDefinition;
import com.bluelock.common.content.SkillDefinition;
import com.bluelock.common.persistence.ProfileCodec;
import com.bluelock.common.profile.CharacterRoll;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.stats.Stat;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerPlayer;

/** Server side of the menu: sends everything the screens need, and runs the menu's button presses as /bluelock commands. */
public final class MenuServer {
    /** Only these /bluelock commands may be sent from a menu button. */
    private static final Pattern ALLOWED = Pattern.compile(
            "^(pitch( [a-z]{1,10})?|ball|quests|profile|cheat (skillpoints|devpoints|xp) [0-9]{1,6}|cheat unlockall|cheat refill|match [a-z0-9_ ]{1,40}|team [a-z0-9_ ]{1,40}|story (continue|restart|status)|campus build|go [a-z_]{1,20}|roll|eat|drill (sprint|passing|shooting|stop)|skills|skills unlock [a-z0-9_]{1,40}|skills bind [1-3] [a-z0-9_]{1,40}|skills unbind [1-3]|train [a-z0-9_]{1,40}( up| [0-9]{1,3})?)$");

    private static final java.util.Map<java.util.UUID, HairDesign> PENDING_HAIR = new java.util.HashMap<>();

    private static final java.util.Map<java.util.UUID, com.bluelock.common.appearance.BodyDesign> PENDING_BODY = new java.util.HashMap<>();

    /** The body chosen on the creation screen, used once by the create command. */
    public static com.bluelock.common.appearance.BodyDesign takePendingBody(java.util.UUID player) {
        com.bluelock.common.appearance.BodyDesign body = PENDING_BODY.remove(player);
        return body == null ? com.bluelock.common.appearance.BodyDesign.standard() : body;
    }

    private MenuServer() {
    }

    public static void runMenuCommand(ServerPlayer player, String command) {
        if (command == null || !ALLOWED.matcher(command).matches()) {
            return;
        }
        run(player, command);
    }

    /** Character creation from the menu. The name is cleaned up; the command itself validates it again. */
    public static void create(ServerPlayer player, String archetype, String personality, String position, String name, HairDesign hair,
                              com.bluelock.common.appearance.BodyDesign body) {
        PENDING_BODY.put(player.getUUID(), body == null ? com.bluelock.common.appearance.BodyDesign.standard() : body);
        PENDING_HAIR.put(player.getUUID(), hair == null ? HairDesign.standard() : hair);
        String cleanName = name == null ? "" : name.replaceAll("[\\r\\n]", " ").trim();
        if (!archetype.matches("[a-z_]{1,20}") || !personality.matches("[a-z_]{1,20}") || !position.matches("[a-z]{1,4}")) {
            PENDING_HAIR.remove(player.getUUID());
            PENDING_BODY.remove(player.getUUID());
            return;
        }
        run(player, "create " + archetype + " " + personality + " " + position + " " + cleanName);
        PENDING_BODY.remove(player.getUUID());
        PENDING_HAIR.remove(player.getUUID());   // when the command refused (bad name), the hair is not kept
    }

    /** The hair chosen on the creation screen, used once by the create command; the standard hair when none was sent. */
    public static HairDesign takePendingHair(java.util.UUID player) {
        HairDesign hair = PENDING_HAIR.remove(player);
        return hair == null ? HairDesign.standard() : hair;
    }

    private static void run(ServerPlayer player, String command) {
        player.getServer().getCommands().performPrefixedCommand(player.createCommandSourceStack(), "bluelock " + command);
        sendState(player);
    }

    public static void sendState(ServerPlayer player) {
        CompoundTag t = new CompoundTag();
        Optional<PlayerProfile> profile = ProfileSavedData.get(player.getServer()).load(player.getUUID());
        t.putBoolean("hasProfile", profile.isPresent());
        if (profile.isPresent()) {
            t.put("profile", NbtMapConverter.toTag(ProfileCodec.toMap(profile.get())));
            t.putLong("xpNeeded", Progression.xpToNext(profile.get().level()));
        } else {
            CharacterRoll.Result roll = CreationRolls.peek(player.getUUID());
            t.putBoolean("rolled", roll != null);
            if (roll != null) {
                t.putString("rollFoot", roll.foot().name());
                t.putString("rollTalent", roll.talent().name());
                t.putInt("rollPercent", roll.talentPercent());
            }
        }

        ListTag skills = new ListTag();
        for (SkillDefinition s : BlueLockData.get().skills().values()) {
            CompoundTag c = new CompoundTag();
            c.putString("id", s.id());
            c.putString("category", s.category().name());
            c.putString("requires", String.join(",", s.requires()));
            c.putInt("cooldown", s.cooldownTicks());
            c.putInt("stamina", s.staminaCost());
            CompoundTag reqs = new CompoundTag();
            for (Map.Entry<Stat, Integer> e : s.requirements().entrySet()) {
                reqs.putInt(e.getKey().name(), e.getValue());
            }
            c.put("req", reqs);
            skills.add(c);
        }
        t.put("skills", skills);

        ListTag quests = new ListTag();
        for (QuestDefinition q : BlueLockData.get().quests().values()) {
            CompoundTag c = new CompoundTag();
            c.putString("id", q.id());
            c.putString("type", q.type().name());
            c.putInt("target", q.target());
            c.putInt("xp", q.rewardXp());
            c.putInt("sp", q.rewardSkillPoints());
            c.putInt("dp", q.rewardDevelopmentPoints());
            quests.add(c);
        }
        t.put("quests", quests);

        t.putString("mode", MatchManager.mode().label());
        t.putBoolean("bots", MatchManager.botsEnabled());
        t.putString("difficulty", MatchManager.difficulty().label());
        t.putBoolean("pitch", MatchManager.hasPitch());
        t.putBoolean("practice", MatchManager.practice());
        t.putString("wantedSize", MatchManager.wantedPitchSize().id());
        t.putString("pitchSize", MatchManager.currentPitchSize() == null ? "" : MatchManager.currentPitchSize().id());
        var session = MatchManager.session();
        t.putBoolean("active", session != null && session.isActive());
        t.putInt("home", session == null ? 0 : session.homeGoals());
        t.putInt("away", session == null ? 0 : session.awayGoals());
        var side = MatchManager.sideOf(player.getUUID());
        t.putInt("side", side == null ? -1 : side.ordinal());
        var homeTeam = MatchManager.teamDefinition(com.bluelock.common.match.Side.HOME);
        var awayTeam = MatchManager.teamDefinition(com.bluelock.common.match.Side.AWAY);
        t.putString("teamHome", homeTeam.map(d -> d.id()).orElse(""));
        t.putString("teamAway", awayTeam.map(d -> d.id()).orElse(""));
        BlueLockNetwork.sendToPlayer(player, new MenuStatePacket(t));
    }
}
