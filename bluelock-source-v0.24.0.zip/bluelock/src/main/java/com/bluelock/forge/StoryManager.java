package com.bluelock.forge;

import com.bluelock.common.match.Side;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.progression.SkillRules;
import com.bluelock.common.story.StoryBook;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Story mode on the server: opens the player's current beat (a scene is sent to the client, a match is started on the
 * pitch), judges the match result against the objective, pays the reward and moves on. The progress is one number on the
 * profile, so it survives restarts. Only one story match runs at a time.
 */
public final class StoryManager {
    private static final int NEXT_DELAY_TICKS = 100;
    private static final int REST_TICKS = 20 * 90;   // the gap after a match: 90 seconds to train
    private static final java.util.Set<UUID> RESTING = new java.util.HashSet<>();
    private static final String HOME_TEAM = "team_z";

    /** Players whose story match is running: player id to the beat index being played. */
    private static final Map<UUID, Integer> PLAYING = new HashMap<>();
    /** Players waiting for the next beat to open after a match: player id to ticks left. */
    private static final Map<UUID, Integer> WAITING = new HashMap<>();

    /** Where each player was last taken, so the place title shows only when they arrive somewhere new. */
    private static final Map<UUID, String> LAST_PLACE = new HashMap<>();

    private StoryManager() {
    }

    private static Optional<PlayerProfile> profile(MinecraftServer server, UUID id) {
        return ProfileSavedData.get(server).load(id);
    }

    /** Opens whatever the player's current beat is. */
    public static void open(ServerPlayer player) {
        RESTING.remove(player.getUUID());
        MinecraftServer server = player.getServer();
        Optional<PlayerProfile> found = profile(server, player.getUUID());
        if (found.isEmpty()) {
            player.sendSystemMessage(Component.translatable("bluelock.error.no_profile"));
            return;
        }
        PlayerProfile p = found.get();
        StoryBook.Beat beat = StoryBook.beat(p.storyBeat());
        if (CampusBuilder.built(server) && CampusBuilder.go(player, beat.place())) {
            announcePlace(player, beat.place());
        }
        switch (beat.kind()) {
            case SCENE -> {
                WAITING.remove(player.getUUID());
                BlueLockNetwork.sendToPlayer(player, new StoryScenePacket(beat.id()));
            }
            case MATCH -> startMatch(player, p, beat);
            case TRIAL -> TrialManager.start(player, p.storyBeat(), beat);
            case END -> player.sendSystemMessage(Component.translatable("bluelock.story_ui.finished"));
        }
    }

    private static void announcePlace(ServerPlayer player, String place) {
        if (place.equals(LAST_PLACE.put(player.getUUID(), place))) {
            return;
        }
        player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket(10, 50, 15));
        player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket(Component.translatable("bluelock.place.sub")));
        player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket(Component.translatable("bluelock.place." + place)));
    }

    private static void startMatch(ServerPlayer player, PlayerProfile p, StoryBook.Beat beat) {
        if (!MatchManager.hasPitch()) {
            player.sendSystemMessage(Component.translatable("bluelock.story_ui.need_pitch"));
            return;
        }
        if (!PLAYING.isEmpty() && !PLAYING.containsKey(player.getUUID())) {
            player.sendSystemMessage(Component.translatable("bluelock.story_ui.busy"));
            return;
        }
        MinecraftServer server = player.getServer();
        MatchManager.stopMatch();
        if (CampusBuilder.built(server)) {
            MatchManager.setMode(com.bluelock.common.team.MatchMode.ELEVEN_V_ELEVEN);   // the campus stadium is a full-size pitch
            MatchManager.setPractice(false);
        }
        MatchManager.setBotsEnabled(true);
        MatchManager.setTeam(Side.HOME, HOME_TEAM);
        MatchManager.setTeam(Side.AWAY, beat.opponent());
        MatchManager.join(player.getUUID(), Side.HOME, p.archetype());
        int overall = com.bluelock.common.stats.OverallRating.compute(p.stats(), com.bluelock.common.stats.StatModifiers.NONE,
                com.bluelock.common.stats.RoleWeights.forArchetype(p.archetype()));
        int own = MatchManager.teamRatingOf(HOME_TEAM);
        int foe = MatchManager.teamRatingOf(beat.opponent());
        MatchManager.setStoryBalance(com.bluelock.common.story.StoryBalance.teammateRating(own, p.teamTraining(), overall),
                com.bluelock.common.story.StoryBalance.opponentRating(foe, overall), com.bluelock.common.story.StoryBalance.speedFactor());
        MatchManager.startMatch(server, beat.length());
        PLAYING.put(player.getUUID(), p.storyBeat());
        player.sendSystemMessage(Component.translatable(StoryBook.beat(p.storyBeat()).briefKey()));
        player.sendSystemMessage(Component.translatable("bluelock.story_ui.objective",
                Component.translatable("bluelock.story.objective." + beat.objective().name().toLowerCase(java.util.Locale.ROOT))));
    }

    /** The client finished reading a scene: move to the next beat (only if it really is the current scene). */
    public static void advance(ServerPlayer player, String sceneId) {
        MinecraftServer server = player.getServer();
        Optional<PlayerProfile> found = profile(server, player.getUUID());
        if (found.isEmpty()) {
            return;
        }
        PlayerProfile p = found.get();
        StoryBook.Beat beat = StoryBook.beat(p.storyBeat());
        if (beat.kind() != StoryBook.Kind.SCENE || !beat.id().equals(sceneId)) {
            return;
        }
        p.setStoryBeat(p.storyBeat() + 1);
        ProfileSavedData.get(server).save(p);
        MenuServer.sendState(player);
        if (StoryBook.beat(p.storyBeat()).kind() == StoryBook.Kind.MATCH) {
            open(player);   // a scene that leads into a match goes straight to the pitch
        } else if (StoryBook.isFinished(p.storyBeat())) {
            open(player);
        }
    }

    public static void restart(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        profile(server, player.getUUID()).ifPresent(p -> {
            p.setStoryBeat(0);
            ProfileSavedData.get(server).save(p);
        });
        PLAYING.remove(player.getUUID());
        WAITING.remove(player.getUUID());
        AmbientNpcs.resetEliminated();
        MenuServer.sendState(player);
        player.sendSystemMessage(Component.translatable("bluelock.story_ui.restarted"));
    }

    /** Test command: skip the current mission without a reward. */
    public static void skip(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        profile(server, player.getUUID()).ifPresent(p -> {
            if (p.storyBeat() >= StoryBook.size() - 1) {
                player.sendSystemMessage(Component.translatable("bluelock.story_ui.skip_end"));
                return;
            }
            p.setStoryBeat(p.storyBeat() + 1);
            ProfileSavedData.get(server).save(p);
            PLAYING.remove(player.getUUID());
            WAITING.remove(player.getUUID());
            MenuServer.sendState(player);
            player.sendSystemMessage(Component.translatable("bluelock.story_ui.skipped", p.storyBeat() + 1));
        });
    }

    public static void status(ServerPlayer player) {
        profile(player.getServer(), player.getUUID()).ifPresent(p -> {
            int beat = p.storyBeat();
            player.sendSystemMessage(Component.translatable("bluelock.story_ui.progress", Math.min(beat + 1, StoryBook.size()), StoryBook.size()));
            player.sendSystemMessage(Component.translatable(StoryBook.beat(beat).titleKey()));
        });
    }

    /** Called when a match ends: judges every story player that was playing it. */
    public static void onFinished(MinecraftServer server, int homeGoals, int awayGoals) {
        Iterator<Map.Entry<UUID, Integer>> it = PLAYING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            it.remove();
            ServerPlayer player = server.getPlayerList().getPlayer(e.getKey());
            Optional<PlayerProfile> found = profile(server, e.getKey());
            if (player == null || found.isEmpty()) {
                continue;
            }
            PlayerProfile p = found.get();
            if (p.storyBeat() != e.getValue()) {
                continue;
            }
            StoryBook.Beat beat = StoryBook.beat(p.storyBeat());
            if (beat.kind() != StoryBook.Kind.MATCH) {
                continue;
            }
            if (StoryBook.passed(beat.objective(), homeGoals, awayGoals)) {
                passBeat(server, player, p, beat);
            } else {
                player.sendSystemMessage(Component.translatable("bluelock.story_ui.failed"));
                Titles.show(player, Component.translatable("bluelock.story_ui.try_again").withStyle(net.minecraft.ChatFormatting.RED), null, 5, 40, 15);
                Juice.sound(player.serverLevel(), player.getX(), player.getY(), player.getZ(), ModSounds.GASP, 0.8F, 0.9F);
            }
        }
    }

    /** Pays the reward of a beat, moves on and schedules the next beat to open. */
    private static void passBeat(MinecraftServer server, ServerPlayer player, PlayerProfile p, StoryBook.Beat beat) {
        int rankBefore = com.bluelock.common.rank.Ranking.rankOf(p.rankPoints());
        reward(player, p, beat);
        p.addRankPoints(beat.xp());
        p.setStoryBeat(p.storyBeat() + 1);
        ProfileSavedData.get(server).save(p);
        MenuServer.sendState(player);
        player.sendSystemMessage(Component.translatable("bluelock.story_ui.passed", beat.xp(), beat.skillPoints(), beat.devPoints()));
        Rewards.announceRank(player, rankBefore, com.bluelock.common.rank.Ranking.rankOf(p.rankPoints()));
        Titles.show(player, Component.translatable("bluelock.story_ui.complete").withStyle(net.minecraft.ChatFormatting.GOLD),
                Component.translatable(beat.titleKey()), 5, 50, 15);
        Juice.sound(player.serverLevel(), player.getX(), player.getY(), player.getZ(), ModSounds.GOAL, 0.8F, 1.1F);
        Juice.particles(player.serverLevel(), net.minecraft.core.particles.ParticleTypes.FIREWORK, player.getX(), player.getY() + 1.5, player.getZ(), 40, 0.8, 0.2);
        if (beat.kind() == StoryBook.Kind.MATCH && !StoryBook.isFinished(p.storyBeat())) {
            startRest(server, player, p);
        } else {
            WAITING.put(player.getUUID(), NEXT_DELAY_TICKS);
        }
    }

    /** The gap between matches: the player trains in the training room and Team Z trains too. */
    private static void startRest(MinecraftServer server, ServerPlayer player, PlayerProfile p) {
        p.setTeamTraining(com.bluelock.common.story.StoryBalance.addTeamTraining(p.teamTraining(), com.bluelock.common.story.StoryBalance.REST_GAIN));
        ProfileSavedData.get(server).save(p);
        WAITING.put(player.getUUID(), REST_TICKS);
        RESTING.add(player.getUUID());
        if (CampusBuilder.built(server)) {
            CampusBuilder.go(player, "training_room");
        }
        Titles.show(player, Component.translatable("bluelock.rest.title"), Component.translatable("bluelock.rest.sub"), 10, 60, 20);
        player.sendSystemMessage(Component.translatable("bluelock.rest.team", p.teamTraining()));
        player.sendSystemMessage(Component.translatable("bluelock.rest.drills"));
        for (BotEntity bot : AmbientNpcs.teamZ(server)) {
            Voice.say(bot, com.bluelock.common.audio.Voices.Event.CHEER, 0.8);
        }
    }

    /** A drill finished during the rest (or any time): Team Z picks up a point of training from it. */
    public static void drillDone(MinecraftServer server, UUID id, int growthGiven) {
        if (growthGiven <= 0) {
            return;
        }
        profile(server, id).ifPresent(p -> {
            p.setTeamTraining(com.bluelock.common.story.StoryBalance.addTeamTraining(p.teamTraining(), 1));
            ProfileSavedData.get(server).save(p);
        });
    }

    /** The touch trial ended: judge it like a match. */
    public static void onTrialFinished(MinecraftServer server, UUID id, int beatIndex, boolean passed) {
        ServerPlayer player = server.getPlayerList().getPlayer(id);
        Optional<PlayerProfile> found = profile(server, id);
        if (player == null || found.isEmpty()) {
            return;
        }
        PlayerProfile p = found.get();
        StoryBook.Beat beat = StoryBook.beat(p.storyBeat());
        if (p.storyBeat() != beatIndex || beat.kind() != StoryBook.Kind.TRIAL) {
            return;
        }
        if (passed) {
            passBeat(server, player, p, beat);
        } else {
            player.sendSystemMessage(Component.translatable("bluelock.story_ui.failed"));
        }
    }

    private static void reward(ServerPlayer player, PlayerProfile p, StoryBook.Beat beat) {
        Progression.LevelUp up = Progression.award(p, beat.xp());
        p.setProgression(p.level(), p.xp(), p.skillPoints() + beat.skillPoints(), p.developmentPoints() + beat.devPoints());
        SkillRules.autoUnlockRoots(p, BlueLockData.get());
        if (up.happened()) {
            player.sendSystemMessage(Component.translatable("bluelock.progress.levelup", up.newLevel(),
                    Progression.SKILL_POINTS_PER_LEVEL * up.levelsGained(), Progression.DEVELOPMENT_POINTS_PER_LEVEL * up.levelsGained()));
        }
    }

    /** A player left, or the match was stopped by hand: forget the running story match. */
    public static void forget(UUID player) {
        PLAYING.remove(player);
        WAITING.remove(player);
    }

    public static void tick(MinecraftServer server) {
        if (WAITING.isEmpty()) {
            return;
        }
        for (UUID id : RESTING) {
            Integer left = WAITING.get(id);
            ServerPlayer rp = left == null ? null : server.getPlayerList().getPlayer(id);
            if (rp != null && left % 20 == 0) {
                rp.displayClientMessage(Component.translatable("bluelock.rest.hud", left / 20), true);
            }
        }
        Iterator<Map.Entry<UUID, Integer>> it = WAITING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            if (e.setValue(e.getValue() - 1) <= 1) {
                it.remove();
                RESTING.remove(e.getKey());
                ServerPlayer player = server.getPlayerList().getPlayer(e.getKey());
                if (player != null) {
                    open(player);
                }
            }
        }
    }
}
