package com.bluelock.forge;

import com.bluelock.common.content.SkillCategory;
import com.bluelock.common.content.SkillDefinition;
import com.bluelock.common.content.QuestDefinition;
import com.bluelock.common.pitch.PitchSize;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.SkillRules;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatCategory;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** The Blue Lock menu (key M): Match, Stats, Skills and Quests (client only). */
public class MainMenuScreen extends Screen {
    private enum Tab { MATCH, STATS, SKILLS, QUESTS, STORY, RANK }

    private record Label(Component text, int x, int y, int color) {
    }

    private record Bar(int x, int y, int w, int h, int percent, int color) {
    }

    private static final List<String> MODES = List.of("1v1", "2v2", "3v3", "4v4", "5v5", "7v7", "11v11");
    private static final List<String> DIFFICULTIES = List.of("easy", "normal", "hard", "pro");
    private static final List<String> TEAMS = List.of("team_v", "team_w", "team_x", "team_y", "team_z");
    private static final int[] MINUTES = {3, 5, 10};
    private static final int ROW = 22;

    private static Tab tab = Tab.MATCH;
    private static int statCategory;
    private static int skillCategory;
    private static int questPage;
    private static int minutesIndex;

    private final List<Label> labels = new ArrayList<>();          // scrolling content
    private final List<Bar> bars = new ArrayList<>();              // scrolling content
    private final List<Label> fixedLabels = new ArrayList<>();     // always visible
    private final List<AbstractWidget> contentWidgets = new ArrayList<>();
    private final List<Integer> contentOrigY = new ArrayList<>();
    private int scroll;
    private int viewTop;
    private int viewBottom;
    private int contentBottom;
    private int lastVersion = -1;
    private int ticks;
    private int left;
    private int width0;
    private int top;

    public MainMenuScreen() {
        super(Component.translatable("bluelock.menu.title"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** A widget that scrolls with the content. */
    private <T extends AbstractWidget> T content(T widget) {
        contentWidgets.add(widget);
        contentOrigY.add(widget.getY());
        return addRenderableWidget(widget);
    }

    private int maxScroll() {
        return Math.max(0, contentBottom - viewBottom + 4);
    }

    /** Moves the scrolling widgets and hides those that are not completely inside the visible area. */
    private void applyScroll() {
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
        for (int i = 0; i < contentWidgets.size(); i++) {
            AbstractWidget w = contentWidgets.get(i);
            int y = contentOrigY.get(i) - scroll;
            w.setY(y);
            w.visible = y >= viewTop && y + w.getHeight() <= viewBottom;
        }
    }

    private void measureContent() {
        contentBottom = viewTop;
        for (int i = 0; i < contentWidgets.size(); i++) {
            contentBottom = Math.max(contentBottom, contentOrigY.get(i) + contentWidgets.get(i).getHeight());
        }
        for (Label l : labels) {
            contentBottom = Math.max(contentBottom, l.y() + 10);
        }
        for (Bar b : bars) {
            contentBottom = Math.max(contentBottom, b.y() + b.h());
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (maxScroll() > 0) {
            scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) (delta * 24)));
            applyScroll();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ClientKeys.MENU.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void tick() {
        ticks++;
        if (ticks % 20 == 0) {
            BlueLockNetwork.CHANNEL.sendToServer(new MenuRequestPacket());
        }
        if (lastVersion != ClientMenuState.version) {
            lastVersion = ClientMenuState.version;
            rebuildWidgets();
        }
    }

    private void send(String command) {
        BlueLockNetwork.CHANNEL.sendToServer(new MenuCommandPacket(command));
    }

    private static String next(List<String> list, String current) {
        int i = list.indexOf(current);
        return list.get((i + 1) % list.size());
    }

    @Override
    protected void init() {
        labels.clear();
        bars.clear();
        fixedLabels.clear();
        contentWidgets.clear();
        contentOrigY.clear();
        width0 = Math.min(width - 24, 460);
        left = (width - width0) / 2;
        top = 72;
        viewTop = top + 4;
        viewBottom = height - 34;
        Tab[] tabs = Tab.values();
        int tabWidth = width0 / tabs.length;
        for (int i = 0; i < tabs.length; i++) {
            Tab t = tabs[i];
            addRenderableWidget(new BlueButton(left + i * tabWidth, 46, tabWidth - 3, 20,
                    Component.translatable("bluelock.menu.tab." + t.name().toLowerCase(Locale.ROOT)),
                    b -> {
                        tab = t;
                        scroll = 0;
                        rebuildWidgets();
                    }, t == tab ? BlueUi.GOLD : BlueUi.CYAN));
        }
        addRenderableWidget(new BlueButton(left + width0 - 70, height - 26, 70, 18,
                Component.translatable("bluelock.menu.close"), b -> onClose(), BlueUi.RED));

        if (ClientMenuState.hasProfile && ClientMenuState.profile != null) {
            addRenderableWidget(new BlueButton(left, height - 26, 110, 18, Component.translatable("bluelock.menu.hair"),
                    b -> minecraft.setScreen(new HairMakerScreen(this, ClientMenuState.profile.hair(),
                            made -> BlueLockNetwork.CHANNEL.sendToServer(new HairUpdatePacket(made.toInts())))), BlueUi.GOLD));
            addRenderableWidget(new BlueButton(left + 114, height - 26, 120, 18, Component.translatable("bluelock.menu.body"),
                    b -> minecraft.setScreen(new BodyMakerScreen(this, ClientMenuState.profile.body(), ClientMenuState.profile.hair(),
                            (body, hair) -> {
                                BlueLockNetwork.CHANNEL.sendToServer(new BodyUpdatePacket(body.toInts()));
                                BlueLockNetwork.CHANNEL.sendToServer(new HairUpdatePacket(hair.toInts()));
                            })), BlueUi.GOLD));
        }
        if (!ClientMenuState.hasProfile || ClientMenuState.profile == null) {
            labels.add(new Label(Component.translatable("bluelock.menu.no_character"), left + 8, top + 10, BlueUi.GOLD));
            addRenderableWidget(new BlueButton(left + 8, top + 30, 180, 20,
                    Component.translatable("bluelock.menu.create_character"),
                    b -> minecraft.setScreen(new CharacterCreationScreen()), BlueUi.GOLD));
            return;
        }
        switch (tab) {
            case MATCH -> buildMatch();
            case STATS -> buildStats();
            case SKILLS -> buildSkills();
            case QUESTS -> buildQuests();
            case STORY -> buildStory();
            case RANK -> buildRank();
        }
        measureContent();
        applyScroll();
    }

    // ---------- MATCH ----------

    private void buildMatch() {
        int y = top + 8;
        int bw = 214;
        content(new BlueButton(left + 6, y, bw, 20, Component.translatable("bluelock.menu.match.pitch"),
                b -> send("pitch"), BlueUi.CYAN));
        y += ROW;
        content(new BlueButton(left + 6, y, bw, 20, Component.translatable("bluelock.menu.match.mode", ClientMenuState.mode),
                b -> send("match mode " + next(MODES, ClientMenuState.mode)), BlueUi.CYAN));
        y += ROW;
        content(new BlueButton(left + 6, y, bw, 20,
                Component.translatable("bluelock.menu.match.practice", Component.translatable(ClientMenuState.practice ? "bluelock.menu.on" : "bluelock.menu.off")),
                b -> send("match practice " + (ClientMenuState.practice ? "off" : "on")), ClientMenuState.practice ? BlueUi.GOLD : BlueUi.CYAN));
        y += ROW;
        content(new BlueButton(left + 6, y, bw, 20, Component.translatable("bluelock.menu.match.minutes", MINUTES[minutesIndex]),
                b -> {
                    minutesIndex = (minutesIndex + 1) % MINUTES.length;
                    rebuildWidgets();
                }, BlueUi.CYAN));
        y += ROW;
        content(new BlueButton(left + 6, y, bw, 20,
                Component.translatable("bluelock.menu.match.bots", Component.translatable(ClientMenuState.bots ? "bluelock.menu.on" : "bluelock.menu.off")),
                b -> send("match bots " + (ClientMenuState.bots ? "off" : "on")), BlueUi.CYAN));
        y += ROW;
        content(new BlueButton(left + 6, y, bw, 20,
                Component.translatable("bluelock.menu.match.difficulty", Component.translatable("bluelock.menu.difficulty." + ClientMenuState.difficulty)),
                b -> send("match difficulty " + next(DIFFICULTIES, ClientMenuState.difficulty)), BlueUi.CYAN));
        y += ROW;
        content(new BlueButton(left + 6, y, bw / 2 - 2, 20, Component.translatable("bluelock.menu.match.join_home"),
                b -> send("match join home"), ClientMenuState.side == 0 ? BlueUi.GOLD : BlueUi.BLUE));
        content(new BlueButton(left + 6 + bw / 2 + 2, y, bw / 2 - 2, 20, Component.translatable("bluelock.menu.match.join_away"),
                b -> send("match join away"), ClientMenuState.side == 1 ? BlueUi.GOLD : BlueUi.RED));
        y += ROW;
        content(new BlueButton(left + 6, y, bw, 20,
                Component.translatable("bluelock.menu.match.team_home", teamName(ClientMenuState.teamHome)),
                b -> send("team set home " + next(TEAMS, ClientMenuState.teamHome.isEmpty() ? TEAMS.get(TEAMS.size() - 1) : ClientMenuState.teamHome)), BlueUi.BLUE));
        y += ROW;
        content(new BlueButton(left + 6, y, bw, 20,
                Component.translatable("bluelock.menu.match.team_away", teamName(ClientMenuState.teamAway)),
                b -> send("team set away " + next(TEAMS, ClientMenuState.teamAway.isEmpty() ? TEAMS.get(TEAMS.size() - 1) : ClientMenuState.teamAway)), BlueUi.RED));

        int rx = left + bw + 22;
        content(new BlueButton(rx, top + 8, width0 - bw - 28, 30, Component.translatable("bluelock.menu.match.start"),
                b -> send("match start " + MINUTES[minutesIndex]), BlueUi.GREEN));
        content(new BlueButton(rx, top + 8 + 34, width0 - bw - 28, 20, Component.translatable("bluelock.menu.match.stop"),
                b -> send("match stop"), BlueUi.RED));
        labels.add(new Label(Component.translatable(ClientMenuState.pitch ? "bluelock.menu.match.pitch_yes" : "bluelock.menu.match.pitch_no"),
                rx, top + 72, ClientMenuState.pitch ? BlueUi.GREEN : BlueUi.GREY));
        labels.add(new Label(Component.translatable("bluelock.menu.match.next_pitch", pitchSizeName(ClientMenuState.wantedSize)),
                rx, top + 84, BlueUi.CYAN));
        labels.add(new Label(Component.translatable(ClientMenuState.matchActive ? "bluelock.menu.match.running" : "bluelock.menu.match.idle"),
                rx, top + 96, ClientMenuState.matchActive ? BlueUi.GOLD : BlueUi.GREY));
        if (ClientMenuState.matchActive) {
            labels.add(new Label(Component.literal(ClientMenuState.homeGoals + "  -  " + ClientMenuState.awayGoals), rx, top + 108, BlueUi.WHITE));
        }
        labels.add(new Label(Component.translatable("bluelock.menu.match.hint"), rx, top + 126, BlueUi.GREY));
    }

    private static Component pitchSizeName(String id) {
        PitchSize size = PitchSize.parse(id).orElse(PitchSize.STANDARD);
        return Component.translatable("bluelock.pitch.size." + size.id(), size.length(), size.width());
    }

    private static Component teamName(String id) {
        return id.isEmpty() ? Component.translatable("bluelock.team.custom") : Component.translatable("bluelock.team." + id + ".name");
    }

    // ---------- STATS ----------

    private void buildStats() {
        PlayerProfile p = ClientMenuState.profile;
        StatCategory[] cats = StatCategory.values();
        int cw = width0 / cats.length;
        for (int i = 0; i < cats.length; i++) {
            int index = i;
            addRenderableWidget(new BlueButton(left + i * cw, top + 4, cw - 3, 18,
                    Component.translatable("bluelock.menu.stats.cat." + cats[i].name().toLowerCase(Locale.ROOT)),
                    b -> {
                        statCategory = index;
                        scroll = 0;
                        rebuildWidgets();
                    }, i == statCategory ? BlueUi.GOLD : BlueUi.BLUE));
        }
        fixedLabels.add(new Label(Component.translatable("bluelock.menu.stats.points", p.developmentPoints()), left + 4, top + 31, BlueUi.GOLD));
        addRenderableWidget(new BlueButton(left + width0 - 150, top + 26, 150, 18, Component.translatable("bluelock.menu.test_dev"),
                b -> send("cheat devpoints 50"), BlueUi.RED));
        viewTop = top + 50;
        int y = viewTop + 2;
        for (Stat stat : Stat.values()) {
            if (stat.category() != cats[statCategory]) {
                continue;
            }
            int value = p.stats().permanent(stat);
            labels.add(new Label(Component.translatable(stat.langKey()), left + 6, y + 6, BlueUi.WHITE));
            bars.add(new Bar(left + 170, y + 7, 150, 6, value, value >= 70 ? BlueUi.CYAN : BlueUi.BLUE));
            labels.add(new Label(Component.literal(String.valueOf(value)), left + 326, y + 6, BlueUi.WHITE));
            int cap = p.growthCurve().softCap();
            int cost = p.growthCurve().costToRaise(value);
            BlueButton up = new BlueButton(left + 352, y, 80, 18, Component.translatable("bluelock.menu.stats.up", cost),
                    b -> send("train " + stat.name().toLowerCase(Locale.ROOT) + " up"), BlueUi.GREEN);
            up.active = value < cap && p.developmentPoints() >= cost;
            content(up);
            y += 19;
        }
    }

    // ---------- SKILLS ----------

    private void buildSkills() {
        PlayerProfile p = ClientMenuState.profile;
        List<SkillCategory> cats = new ArrayList<>();
        for (SkillCategory c : SkillCategory.values()) {
            for (SkillDefinition s : ClientMenuState.SKILLS) {
                if (s.category() == c) {
                    cats.add(c);
                    break;
                }
            }
        }
        if (cats.isEmpty()) {
            fixedLabels.add(new Label(Component.translatable("bluelock.menu.skills.none"), left + 6, top + 10, BlueUi.GREY));
            return;
        }
        skillCategory = Math.floorMod(skillCategory, cats.size());
        addRenderableWidget(new BlueButton(left, top + 4, 30, 18, Component.literal("<"), b -> {
            skillCategory--;
            scroll = 0;
            rebuildWidgets();
        }, BlueUi.CYAN));
        addRenderableWidget(new BlueButton(left + width0 - 30, top + 4, 30, 18, Component.literal(">"), b -> {
            skillCategory++;
            scroll = 0;
            rebuildWidgets();
        }, BlueUi.CYAN));
        SkillCategory category = cats.get(skillCategory);
        fixedLabels.add(new Label(Component.translatable("bluelock.menu.skills.cat." + category.name().toLowerCase(Locale.ROOT)),
                left + 40, top + 9, BlueUi.GOLD));
        fixedLabels.add(new Label(Component.translatable("bluelock.menu.skills.points", p.skillPoints()), left + 4, top + 31, BlueUi.GOLD));
        addRenderableWidget(new BlueButton(left + width0 - 150, top + 26, 150, 18, Component.translatable("bluelock.menu.test_skill"),
                b -> send("cheat skillpoints 5"), BlueUi.RED));
        viewTop = top + 50;
        int y = viewTop + 2;
        for (SkillDefinition skill : ClientMenuState.SKILLS) {
            if (skill.category() != category) {
                continue;
            }
            labels.add(new Label(Component.translatable(skill.nameKey()), left + 6, y + 2, BlueUi.WHITE));
            labels.add(new Label(Component.translatable(skill.descriptionKey()), left + 6, y + 13, BlueUi.GREY));
            String error = SkillRules.check(p, skill);
            Component status;
            int color;
            if (p.isUnlocked(skill.id())) {
                status = Component.translatable("bluelock.menu.skills.unlocked");
                color = BlueUi.GREEN;
            } else if (error == null) {
                status = Component.translatable("bluelock.menu.skills.ready");
                color = BlueUi.GOLD;
            } else {
                status = Component.translatable(error);
                color = BlueUi.RED;
            }
            labels.add(new Label(status, left + 250, y + 2, color));
            labels.add(new Label(requirementText(skill), left + 250, y + 13, BlueUi.GREY));
            if (p.isUnlocked(skill.id()) && ActionIds.actionOfSkill(skill.id()) >= 0) {
                int slot = p.slotOf(skill.id());
                Component label = Component.translatable("bluelock.menu.skills.bind",
                        slot < 0 ? Component.translatable("bluelock.menu.skills.bind_none") : Component.literal(String.valueOf(slot + 1)));
                content(new BlueButton(left + width0 - 90, y + 2, 90, 18, label,
                        b -> send(slot >= 2 ? "skills unbind 3" : "skills bind " + (slot + 2) + " " + skill.id()),
                        slot < 0 ? BlueUi.CYAN : BlueUi.GOLD));
                y += 30;
                continue;
            }
            BlueButton unlock = new BlueButton(left + width0 - 78, y + 2, 78, 18, Component.translatable("bluelock.menu.skills.unlock"),
                    b -> send("skills unlock " + skill.id()), BlueUi.GREEN);
            unlock.active = !p.isUnlocked(skill.id()) && error == null && !skill.requires().isEmpty();
            content(unlock);
            y += 30;
        }
    }

    private static Component requirementText(SkillDefinition skill) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Stat, Integer> e : skill.requirements().entrySet()) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(Component.translatable(e.getKey().langKey()).getString()).append(' ').append(e.getValue());
        }
        return Component.literal(sb.toString());
    }

    // ---------- QUESTS ----------

    private void buildQuests() {
        PlayerProfile p = ClientMenuState.profile;
        List<QuestDefinition> quests = ClientMenuState.QUESTS;
        fixedLabels.add(new Label(Component.translatable("bluelock.quests.header", com.bluelock.common.progression.Quests.doneCount(p, quests), quests.size()),
                left + 4, top + 9, BlueUi.GOLD));
        viewTop = top + 28;
        int y = viewTop + 2;
        for (QuestDefinition q : quests) {
            boolean done = p.isQuestDone(q.id());
            int progress = done ? q.target() : p.questProgress(q.id());
            labels.add(new Label(Component.translatable(q.nameKey()), left + 6, y, done ? BlueUi.GREEN : BlueUi.WHITE));
            labels.add(new Label(Component.translatable(q.descriptionKey()), left + 6, y + 11, BlueUi.GREY));
            bars.add(new Bar(left + 6, y + 24, 200, 5, progress * 100 / q.target(), done ? BlueUi.GREEN : BlueUi.CYAN));
            labels.add(new Label(Component.literal(progress + "/" + q.target()), left + 212, y + 22, BlueUi.WHITE));
            labels.add(new Label(Component.translatable("bluelock.menu.quests.reward", q.rewardXp(), q.rewardSkillPoints(), q.rewardDevelopmentPoints()),
                    left + 260, y + 11, BlueUi.GOLD));
            y += 38;
        }
    }

    // ---------- RANK ----------

    private void buildRank() {
        PlayerProfile p = ClientMenuState.profile;
        int rank = com.bluelock.common.rank.Ranking.rankOf(p.rankPoints());
        com.bluelock.common.rank.Cafeteria.Meal meal = com.bluelock.common.rank.Cafeteria.mealFor(rank);
        fixedLabels.add(new Label(Component.translatable("bluelock.rank.header", rank, com.bluelock.common.rank.Ranking.SIZE, p.rankPoints()),
                left + 4, top + 9, BlueUi.GOLD));
        viewTop = top + 28;
        int y = viewTop + 2;
        labels.add(new Label(Component.translatable("bluelock.rank.tier", Component.translatable(com.bluelock.common.rank.Cafeteria.tierKey(meal.tier())),
                Component.translatable(meal.nameKey())), left + 6, y, BlueUi.WHITE));
        y += 12;
        int next = com.bluelock.common.rank.Ranking.pointsToNextRank(p.rankPoints());
        labels.add(new Label(Component.translatable(next == 0 ? "bluelock.rank.first" : "bluelock.rank.next", next), left + 6, y, BlueUi.GREY));
        y += 14;
        content(new BlueButton(left + 6, y, 214, 20, Component.translatable("bluelock.rank.eat"), b -> send("eat"), BlueUi.GREEN));
        y += 28;
        for (com.bluelock.common.rank.Ranking.Row row : com.bluelock.common.rank.Ranking.table(p.name(), p.rankPoints())) {
            int color = row.player() ? BlueUi.GOLD : !row.characterId().isEmpty() ? BlueUi.CYAN : BlueUi.WHITE;
            labels.add(new Label(Component.literal("#" + row.rank() + "  " + row.name()), left + 6, y, color));
            labels.add(new Label(Component.literal(row.points() + " pts"), left + 300, y, row.player() ? BlueUi.GOLD : BlueUi.GREY));
            y += 11;
        }
    }

    // ---------- STORY ----------

    private void buildStory() {
        PlayerProfile p = ClientMenuState.profile;
        int beat = p.storyBeat();
        int total = com.bluelock.common.story.StoryBook.size();
        com.bluelock.common.story.StoryBook.Beat current = com.bluelock.common.story.StoryBook.beat(beat);
        boolean finished = com.bluelock.common.story.StoryBook.isFinished(beat);
        int y = top + 10;
        labels.add(new Label(Component.translatable("bluelock.story_ui.chapter"), left + 6, y, BlueUi.GOLD));
        y += 16;
        labels.add(new Label(Component.translatable("bluelock.story_ui.progress", Math.min(beat + 1, total), total), left + 6, y, BlueUi.WHITE));
        y += 12;
        bars.add(new Bar(left + 6, y, 220, 5, Math.min(100, beat * 100 / Math.max(1, total - 1)), BlueUi.CYAN));
        y += 14;
        if (finished) {
            labels.add(new Label(Component.translatable("bluelock.story_ui.finished"), left + 6, y, BlueUi.GREEN));
        } else {
            labels.add(new Label(Component.translatable("bluelock.story_ui.next", Component.translatable(current.titleKey())), left + 6, y, BlueUi.WHITE));
            y += 12;
            if (current.kind() == com.bluelock.common.story.StoryBook.Kind.MATCH) {
                labels.add(new Label(Component.translatable(current.briefKey()), left + 6, y, BlueUi.GREY));
                y += 12;
                labels.add(new Label(Component.translatable("bluelock.story_ui.objective", Component.translatable(
                        "bluelock.story.objective." + current.objective().name().toLowerCase(Locale.ROOT))), left + 6, y, BlueUi.GOLD));
            }
        }
        y += 22;
        if (!finished) {
            content(new BlueButton(left + 6, y, 214, 20, Component.translatable("bluelock.story_ui.continue"),
                    b -> {
                        send("story continue");
                        onClose();
                    }, BlueUi.GOLD));
            y += ROW;
        }
        content(new BlueButton(left + 6, y, 214, 20, Component.translatable("bluelock.story_ui.restart"),
                b -> send("story restart"), BlueUi.RED));
        y += ROW;
        content(new BlueButton(left + 6, y, 214, 20, Component.translatable("bluelock.story_ui.build"),
                b -> {
                    send("campus build");
                    onClose();
                }, BlueUi.CYAN));
        y += ROW;
        labels.add(new Label(Component.translatable("bluelock.story_ui.drills"), left + 6, y + 4, BlueUi.GOLD));
        y += 16;
        String[] drills = {"sprint", "passing", "shooting"};
        for (int i = 0; i < drills.length; i++) {
            String id = drills[i];
            content(new BlueButton(left + 6 + i * 73, y, 70, 18, Component.translatable("bluelock.drill.btn." + id),
                    b -> {
                        send("drill " + id);
                        onClose();
                    }, BlueUi.GREEN));
        }
        y += ROW;
        labels.add(new Label(Component.translatable("bluelock.story_ui.places"), left + 6, y + 4, BlueUi.GOLD));
        y += 16;
        int column = 0;
        for (com.bluelock.common.campus.CampusPlan.Place place : com.bluelock.common.campus.CampusPlan.places()) {
            content(new BlueButton(left + 6 + column * 112, y, 108, 18, Component.translatable("bluelock.place." + place.id()),
                    b -> {
                        send("go " + place.id());
                        onClose();
                    }, BlueUi.CYAN));
            column++;
            if (column == 2) {
                column = 0;
                y += 20;
            }
        }
    }

    // ---------- drawing ----------

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        BlueUi.background(g, width, height);
        BlueUi.title(g, font, left, 8, 2.0F, Component.translatable("bluelock.menu.logo"), BlueUi.WHITE);
        BlueUi.slogan(g, font, width / 2 + width0 / 4, 14, ticks);
        PlayerProfile p = ClientMenuState.hasProfile ? ClientMenuState.profile : null;
        if (p != null) {
            Component who = Component.literal(p.name() + "  " + p.talentPercent() + "% ").append(Component.translatable(com.bluelock.common.profile.TalentRoll.bandKey(p.talentPercent())));
            g.drawString(font, who, left, 30, p.talent() == com.bluelock.common.profile.Talent.GENIUS ? BlueUi.GOLD : BlueUi.WHITE, true);
            Component lvl = Component.translatable("bluelock.menu.level", p.level());
            g.drawString(font, lvl, left + width0 - font.width(lvl), 30, BlueUi.WHITE, true);
            BlueUi.bar(g, left + width0 - 140, 38, 100, 4, (int) (100 * p.xp() / Math.max(1, ClientMenuState.xpNeeded)), BlueUi.CYAN);
        }
        BlueUi.panel(g, left - 4, top - 2, width0 + 8, height - top - 30);
        for (Bar b : bars) {
            int y = b.y() - scroll;
            if (y >= viewTop && y + b.h() <= viewBottom) {
                BlueUi.bar(g, b.x(), y, b.w(), b.h(), b.percent(), b.color());
            }
        }
        for (Label l : labels) {
            int y = l.y() - scroll;
            if (y >= viewTop && y + 9 <= viewBottom) {
                g.drawString(font, l.text(), l.x(), y, l.color(), true);
            }
        }
        for (Label l : fixedLabels) {
            g.drawString(font, l.text(), l.x(), l.y(), l.color(), true);
        }
        if (maxScroll() > 0) {   // scrollbar
            int trackX = left + width0 - 2;
            int trackH = viewBottom - viewTop;
            int thumbH = Math.max(14, trackH * trackH / (trackH + maxScroll()));
            int thumbY = viewTop + (trackH - thumbH) * scroll / maxScroll();
            g.fill(trackX, viewTop, trackX + 3, viewBottom, 0x55000000);
            g.fill(trackX, thumbY, trackX + 3, thumbY + thumbH, BlueUi.CYAN);
            g.drawString(font, Component.translatable("bluelock.menu.scroll_hint"), left + 4, height - 24, BlueUi.GREY, false);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }
}
