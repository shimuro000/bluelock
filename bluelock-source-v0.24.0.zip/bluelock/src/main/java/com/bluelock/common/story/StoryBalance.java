package com.bluelock.common.story;

import com.bluelock.common.stats.Stat;

/**
 * Balance of the story (no Minecraft code). Story opponents are tuned to the player instead of the global difficulty:
 * a fresh player (overall about 50) meets teams a little under their listed rating, and every point of overall above 50
 * lifts them by half a point. Team Z's own bots gain "team training" earned in the rest periods and the drills.
 */
public final class StoryBalance {
    public static final int MAX_TEAM_TRAINING = 24;
    public static final int REST_GAIN = 3;

    private StoryBalance() {
    }

    public static int opponentRating(int teamRating, int playerOverall) {
        int r = teamRating - 8 + Math.round((playerOverall - 50) * 0.5F);
        return Math.max(30, Math.min(85, r));
    }

    /** Team Z's bots: their listed rating plus their training, and a small share of the player's own level. */
    public static int teammateRating(int teamRating, int teamTraining, int playerOverall) {
        int r = teamRating + Math.max(0, Math.min(MAX_TEAM_TRAINING, teamTraining)) + Math.round((playerOverall - 50) * 0.25F);
        return Math.max(30, Math.min(85, r));
    }

    /** Bots in story matches run at the player's pace (1.0) instead of the global difficulty factor. */
    public static double speedFactor() {
        return 1.0;
    }

    public static int addTeamTraining(int current, int amount) {
        return Math.max(0, Math.min(MAX_TEAM_TRAINING, current + amount));
    }

    /** Drills train stats only up to this value, so they help a beginner without replacing development points. */
    public static final int DRILL_CEILING = 70;

    public enum Drill {
        SPRINT("sprint", 12, 35, Stat.TOP_SPEED, Stat.ACCELERATION, Stat.STAMINA),
        PASSING("passing", 14, 35, Stat.PASSING, Stat.VISION, Stat.BALL_CONTROL),
        SHOOTING("shooting", 10, 35, Stat.SHOOTING, Stat.FINISHING, Stat.SHOT_POWER);

        public final String id;
        public final int targetScore;   // the score that earns one point of growth on each trained stat
        public final int seconds;
        public final Stat[] stats;

        Drill(String id, int targetScore, int seconds, Stat... stats) {
            this.id = id;
            this.targetScore = targetScore;
            this.seconds = seconds;
            this.stats = stats;
        }

        public static Drill parse(String s) {
            for (Drill d : values()) {
                if (d.id.equalsIgnoreCase(s)) {
                    return d;
                }
            }
            return null;
        }
    }

    /** Growth points a score earns on each stat of the drill: 0 below half the target, 1 up to the target, 2 above it. */
    public static int drillGrowth(Drill drill, int score) {
        if (score >= drill.targetScore * 2) {
            return 3;
        }
        if (score >= drill.targetScore) {
            return 2;
        }
        return score * 2 >= drill.targetScore ? 1 : 0;
    }

    public static int drillXp(int score) {
        return Math.min(60, 4 + score * 3);
    }
}
