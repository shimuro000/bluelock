# Architecture (Phase 0 decisions)

- Platform: Minecraft Java 1.20.1, Java 17, Forge 47.4.0 (latest recommended build for 1.20.1), official Mojang mappings, ForgeGradle 6.0.x, Gradle 8.8 via the included wrapper.
- Single Gradle module. The "common vs loader" rule from the spec is enforced by package, not by a second module: `com.bluelock.common` must never import `net.minecraftforge.*`. If a second loader is ever wanted, `common` can be split into its own Gradle module without rewriting it.
- Server authoritative: clients only send intents; goals, XP, stats, cooldowns and ball state are decided on the server.
- All UI text goes through language files (`assets/bluelock/lang/*.json`), never hardcoded.
- Loader choice: Forge only. Fabric/NeoForge are out of scope for the first playable version.

## Phase 2: common module (done)
All in `com.bluelock.common`, no Forge imports, verified by `src/test/java/.../CommonSelfTest.java`.
- `stats`: `Stat` (35 stats from spec section 8), `StatBlock` (base + permanent growth, server-owned), `StatModifiers` (equipment/skill/temporary/flow/context layers), `StatCalculator` (EffectiveStat formula, clamped 0-100), `GrowthCurve`/`DefaultGrowthCurve` (progression bands; soft cap 99, 100 only via milestone), `RoleWeights` + `OverallRating` (role-weighted, not a plain average).
- `profile`: `PlayerProfile`, `Archetype`, `Personality`, `DominantFoot`, name validation returning language keys.
- `persistence`: `ProfileCodec` (profile <-> plain Map, versioned, tolerant of missing/broken fields), `ProfileRepository` (interface; Forge implements storage later).
- `util`: `Result` (success or language-key error).
Next (Phase 3): registries and data-driven definitions (skills, teams, formations) loaded from `data/bluelock/`.

## Phase 3: registries and data-driven content (done)
- `common/registry/Registry`: id -> definition table, ids limited to a-z, 0-9, `_`; frozen after loading.
- `common/content`: `SkillDefinition` (stat requirements, skill-tree parents, cooldown, stamina/Ego cost, mastery), `FormationDefinition`, `TeamDefinition`, and `DefinitionPack`, which builds everything from raw data, skips bad files and reports them in `problems()`. Skill trees are checked for missing parents and loops; teams must name an existing formation.
- Data files: `src/main/resources/data/bluelock/definitions/{skills,formations,teams}/<id>.json` (19 skills, 5 formations, 5 teams). Names and descriptions are language keys, so Arabic and English both work.
- `forge/DefinitionReloadListener`: loads the files on world load and on `/reload`; `/bluelock data` prints counts.
- Tests: `ContentSelfTest` loads the real data files through the real parser and checks every language key exists in both languages.
- Note: data lives under `definitions/` (not directly under `data/bluelock/`) so one reload listener can read all content types at once.
Next (Phase 4): player profile storage on the Forge side and the character creation flow.

## Phase 4: player profile and character creation (done)
- `common/profile/CharacterCreator`: builds a new player on the server. Every stat starts at 35; the archetype and personality shifts (JSON in `definitions/archetypes` and `definitions/personalities`) are applied. All shifts add up to zero, so every one of the 42 combinations has the same total (1225 points) and every build starts with weak spots.
- Balance check (test): own-role overall rating of all 42 builds lies within 35..38, so no starting class is clearly best.
- `forge/ProfileSavedData`: stores all profiles in the world (`data/bluelock_profiles.dat`), saved by Minecraft with the world, never every tick. Unreadable entries are skipped.
- Temporary commands until the menus (Phase 18): `/bluelock create <archetype> <personality> <foot> <name>`, `/bluelock profile`, `/bluelock reset confirm`. Tab-completion lists the choices.
- Nickname, appearance and jersey come with the creation screen in Phase 18.
Next (Phase 5): the ball and the pitch.

## Phase 5: the ball and the pitch (done)
- `common/ball/BallPhysics`: gravity, drag, bounces, rolling friction, kicks and dribbling as pure math (units: blocks per tick). Server-authoritative: only the server moves the ball.
- `forge/BallEntity`: the ball entity. Run into it = dribble, right-click = pass, left-click = shot. Rendered as the football sprite, always facing the camera.
- `common/pitch/PitchLayout` + `forge/PitchBuilder`: lines, centre circle, penalty and goal areas, stripes, two goals with nets. Built with vanilla blocks (grass, moss, white concrete, iron bars), so no custom block assets are needed.
- Assets: `assets/bluelock/textures/item/football.png` (64x64, drawn procedurally), `models/item/football.json`.
- Commands: `/bluelock pitch`, `/bluelock ball`. `/bluelock pitch` needs op rights on a dedicated server; in singleplayer anyone can use it.
- Known limits: ball motion is shown at 20 updates per second (smoothing comes later); no goal detection or score yet (Phase 6 and match phases).
Next (Phase 6): goal detection, possession and the first match rules.

## Phase 6: match rules (done)
- `common/pitch/PitchPlacement`: world <-> pitch coordinates; the pitch builder and the match both use it, so they always agree on where the goals are.
- `common/match`: `GoalDetector` (in play / goal / out, with posts, crossbar and goal depth), `MatchSession` (phases, score, clock, teams, possession, own goals, restarts), `MatchEvent`, `MatchRules`. Pure logic, 32 tests.
- Rules: clock runs only while the ball is in play; first touch after a kick-off starts it; a goal pauses play for 3 s then resets the ball to the centre; a ball that leaves the pitch (including over the crossbar) is put back on the nearest line spot and play resumes on the next touch; full time ends the match (draw allowed). HOME defends the goal behind u = 0.
- `forge/MatchManager`: one active match per server session; reads the ball every server tick, feeds the session, announces events in chat, resets the ball. `BallEntity.touchCount()` tells it when someone touched the ball.
- Commands: `/bluelock match start [minutes]`, `stop`, `join home|away`, `status`.
- Known limits: the pitch position is remembered only until the server stops (build the pitch again after a restart); no throw-ins, corners or fouls yet; no goalkeeper rules.
Next (Phase 7): player actions with stats (shot power, pass accuracy and so on use the profile's stats).

## Phase 8: teams and formations (done)
- `common/team`: `MatchMode` (1v1 to 11v11), `TeamSetup` (formation + who stands in each slot; empty slots are for AI bots; rebuilt from candidates every time so results are deterministic), `PositionFit` (archetype vs position), `FormationSelector` (explicit choice, then the team's own formation, then 4-3-3 or the first one that fits), `KickoffPositions` (every slot starts in its own half, outside the centre circle, mirrored for AWAY), `TeamTactics` (defensive line, pressing, tempo from the playstyle).
- Team rating = average of every slot (human overall or bot rating), lowered up to 10% by poor chemistry (chemistry = average position fit of the humans).
- Data: 6 new formations for the small modes (solo, duo, trio, diamond, 1-2-1, 2-3-1) next to the five 11-player ones.
- `forge/MatchManager`: mode, per-side team and formation, seating, kick-off teleports at the start and after goals.
- Commands: `/bluelock match mode`, `/bluelock team set|formation|slot|show`.
- Not done yet (their own phases): AI bots filling empty slots (Phase 13), tactics actually changing behaviour, substitutions, saving teams between sessions.
- Numbering note: this follows the spec's roadmap (Phase 6 football controls, 7 match engine, 8 teams). Football controls with stat-driven shot power and pass accuracy are only partly done (basic dribble, pass and shot exist); the stat link comes with Stats + progression (Phase 9).

## Gameplay update (carry, tackles, skills, bots, HUD, sound)
- `common/ball/BallCarry`: the ball sticks in front of the carrier's feet and swings with each step; fast, low-skill runners can lose it; a fast pass can only be settled with a good first touch / ball control.
- `common/action`: `TackleResolver` (Tackling/Strength/Anticipation vs Dribbling/Close control/Balance; slide bonus; skills can protect the carrier), `StaminaPool`, `KickModel` (pass and shot speed and accuracy from Passing, Shooting, Finishing, Shot power; shot aim assist), `PassAssist` (auto-aim at the team-mate you look at).
- `common/progression`: `Progression` (XP, levels, 1 skill point + 3 development points per level, cap level 50) and `SkillRules` (root skills unlock by stats; others need parents, stats and a skill point).
- `common/ai`: `BotBrain` is a pure decision function (keeper, shoot, pass, dribble, clear, press, tackle, support, hold shape, chase), plus `BotStats` and `team/FormationSpots`. 40 tests cover it.
- Forge: `BallEntity` (carrier logic, kicks), `BotEntity` + `BotRenderer` (footballer in a home/away kit, driven by `MatchManager`, which asks the brain three times per second), `TackleActions`, `PlayerActions` (pass, shot, slide, five dribble skills), `PlayerStates` (stamina, cooldowns), `Rewards` (XP and level-ups), `BlueLockNetwork` with `ActionPacket` (key presses to server) and `HudPacket` (score, clock, possession, stamina, cooldowns, banner to client), `ClientHud`, `ClientKeys`, `ModSounds`.
- Assets: six generated sound effects (kick, shot, tackle, whistle, goal cheer, skill whoosh), two bot kit textures.
- Not done yet: a full career/character screen with buttons, goalkeeper dives and animations (GeckoLib is planned for animations, see below), fouls and set pieces, shot-type skills (direct shot etc.) changing shots, assists.
- Animation note: GeckoLib 4 for 1.20.1 can animate custom entities (bots, the ball, goal nets). It must be packaged inside the mod jar (Jar-in-Jar) to keep a single-file install; planned for the animation phase together with player kick animations.

## Versioning
Every delivery bumps the version (gradle.properties `mod_version` and `BlueLockConstants.VERSION`, checked by VersionSelfTest). The source zip is named `bluelock-source-v<version>.zip`, the workflow file `build-v<version>.yml`, the jar `bluelock-<version>.jar`, and `/bluelock` prints the version in game.

## 0.10.0: menu, creation roll, quests, keepers, faster bots
- `common/profile`: `Talent` (Normal/Genius), `CharacterRoll` (60/30/10 foot, 25% genius), `PlayerProfile` now stores talent, position, hair, quests. `stats/TalentGrowthCurve` scales growth cost and cap by talent.
- `common/action/FootModel`: weak-foot accuracy/power and move strength.
- `common/ai`: `BotDifficulty` (easy to pro, speed formula), `KeeperLogic` (stance, shot analysis, dive reach, save chance), `BotBrain` keeper and dive intent.
- `common/content` + `progression/Quests`: quest definitions (13 data files) and progress.
- Forge: `MenuServer` plus four packets (`MenuRequestPacket`, `MenuCommandPacket` (whitelisted /bluelock commands), `CreatePacket`, `MenuStatePacket`); client `MainMenuScreen`, `CharacterCreationScreen`, `BlueUi`, `BlueButton`, key M; `BotEntity` dives; `BallEntity.keeperSave`.
- Deferred to 0.11: GeckoLib animations (GeckoLib animates custom entities such as bots and goalkeepers; its download address could not be verified from the build sandbox, so it will be added with an automatic fallback build), 3D hair (needs a custom render layer and appearance sync).

## 0.11.0: animation libraries (fail-safe)
- `build.gradle` has a `with_libs` switch. With `-Pwith_libs=true` it adds GeckoLib and PlayerAnimator and compiles `src/anim/java`; without it those classes do not exist. The workflow builds with the libraries first and falls back to the basic build automatically.
- Main code never imports the libraries. `AnimationBridge` finds `GeoBotEntity` / `PlayerAnimClient` by name, so the mod runs with or without them.
- Bots: `GeoBotEntity` (two controllers: movement and one-shot actions), `GeoBotModel`, `GeoBotRenderer`; assets `geo/entity/bot.geo.json`, `animations/entity/bot.animation.json`.
- Players: `PlayerAnimClient` registers a PlayerAnimator layer; the server sends `PlayerAnimPacket` for one-shots; `ClientAnimBridge` starts the dribble loops for every player who carries the ball (the ball entity synchronises its carrier id).
- `common/anim/AnimLogic` decides which animation plays; `AnimationSelfTest` checks every animation name exists in the asset files.
- `tools/make_animations.py` generates all animation JSON files from one description (angles in Minecraft convention). If a pose looks mirrored in game, flip the sign there and re-run the script.

## 0.12.0
Fix: removed the geckolib/playeranimator entries from mods.toml. Without a versionRange Forge refused to load the mod ("only supports ..."). The mod finds the libraries by itself, so no declaration is needed.

## 0.13.0
- `common/pitch/PitchSize` names the four pitch sizes and decides which one a match needs; `PitchLayout` scales its markings with the size (goals keep the same size).
- `common/appearance/HairDesign` (the numbers of one hair: style, seven sliders, seed, colours) and `HairModel` (turns a design into tapered 3D "locks", no Minecraft code) are fully tested without Minecraft. `PlayerProfile` stores the design; `ProfileCodec` saves it (old saves get the matching preset).
- Forge side: `HairRenderLayer` draws the locks on the player model's head on a plain white texture with per-corner colours; `ClientHair` holds every player's design and the live preview; `HairSync`, `HairSyncPacket`, `HairUpdatePacket` carry designs (protocol "3"); `HairMakerScreen` is the editor. `PitchSavedData` remembers the pitch across restarts and `MatchManager.buildPitchAt` builds it.

## 0.14.0 - Phase 5: characters, sprint, hair on bots

- `common/ai/CharacterTraits`, `FootballCharacter`, `Roster`: who a bot plays as and how (speed, sprint, ego, creativity, aggression, work rate). `Roster.assign(team, position, taken)` hands out each character at most once per team; `lookOf`/`byLook`/`hairForLook` turn a character into one synced integer.
- `BotEnergy` (sprint energy) and `BotSpeed` (jog and sprint attribute values, capped). `BotDifficulty.movementAttribute` is about 6% higher than in 0.13.0.
- `BotBrain` reads `BotView.traits()` (shot range, pass or dribble under pressure, run-ahead distance, tackle reach, pressing) and sets `BotDecision.sprint`.
- `BotEntity.applySprint` runs on every brain decision and sets the real movement speed; `DATA_LOOK` is synced for the hair; the character name is the entity's custom name.
- Hair: `HairDraw` is the shared drawing code; `HairRenderLayer` (players), `BotHairLayer` (plain bot), `HairGeoLayer` (GeckoLib head bone, no `@Override` so a signature change cannot break the build).
- `AnimLogic.botLocomotion`: bots show "sprint" only at real sprint speed.

## 0.15.0

- `BotEntity` drives itself in `aiStep` (no vanilla MoveControl): speed = attribute x `BLOCKS_PER_ATTRIBUTE` x factor, with short boosts for skills.
- `FootballCharacter` gained shirt name, jersey, height and skills; `Roster` has per-character hair designs. `BotSkillRules` maps skills to shot, dribble, pass and tackle changes.
- Kits: `KitDesign` (common), `KitDraw` (boxes and back text), `KitRenderLayer` (players), `BotKitLayer` (plain bot), `KitGeoLayer` (GeckoLib bones). Players' kits are sent by `KitSync`/`KitSyncPacket` (network protocol "4"); bots sync colour and number through entity data.
- `HairGeoLayer` now mirrors x (GeckoLib model space is mirrored compared with the plain model).

## 0.16.0

- `StatEffects` (common): one place for what stats do (speed, sprint length, jump, pass reach). `StatMovement` applies speed and jump to players in a match; `BotEntity.configure` applies it to bots; `BotView.vision` feeds the pass search.
- `Juice` (sound, particles, shake helpers), `ShakePacket` and `ClientShake` (camera shake). Network protocol "5". `BallEntity.goalBlockHit` plays post and net sounds from the blocks the ball touches.

## 0.17.0

- `BodyDesign` (common) is the body and face; `PlayerProfile` stores it and the 3 skill bind slots (`ProfileCodec` saves both). `Roster` gives every character a body.
- Skills: `ActionIds` has signature actions and slot actions after the basic ones; `PlayerActions.signature/useBound/tickSignature` run them; `BallEntity.setCurve` bends the ball. Commands `skills bind/unbind` are allowed through `MenuServer.ALLOWED`.
- Body: `BodySync`, `BodySyncPacket`, `BodyUpdatePacket`, `ClientBody` mirror the hair classes; `BodyDraw` paints the skin coat and face; `KitLayerHelper`, `HairRenderLayer`, `BotHairLayer`, `HairGeoLayer` and `KitGeoLayer` call it. Players are scaled in `RenderPlayerEvent`, bots in their renderers. Network protocol "6".

## 0.18.0

- `Voices` (common): voice types, vocal events with cooldowns, character to voice table. `Voice` (forge) plays them on the vanilla VOICE sound category from `PlayerActions`, `MatchManager` (bots) and `TackleActions`. `ModSounds.VOICE[type][event]` registers 48 sound events; the files come from `tools/make_voices.py` (formant synthesiser).
- `Roster` skill lists now carry the canon technique bindings.

## 0.19.0

- The roster is generated: edit `tools/gen_roster.py` and run it. It rewrites the character block of `Roster.java`, `CanonStats.java` and `data/bluelock/story/characters.json` from one table, so the game and the story file cannot disagree.
- A character with an empty team id is on no Season 1 team: `Roster.ofTeam`/`assign` never pick him, `Roster.all()` still lists him (look codes are indexes into it, so only append).
- `CanonStats` adds each character's strengths and weaknesses in `BotStats.forCharacter`.

## 0.20.0

- Story: `common/story/StoryBook` (beats, objectives, pure Java) with `StoryChapter1` generated by `tools/gen_story.py` together with the `bluelock.story.*` text in en_us. Progress is one int on the profile (`storyBeat`, saved by `ProfileCodec`).
- `StoryManager` (forge) opens the current beat: scenes go to the client as `StoryScenePacket` (the id only; the client reads the lines from `StoryBook`), matches are started through `MatchManager`, and `MatchManager.handle` calls `StoryManager.onFinished` to judge the result. `StoryAdvancePacket` tells the server a scene was read. `DialogueScreen` draws the portraits. Network protocol "7".

## 0.21.0

- `common/campus/CampusPlan`: the campus as ~530 box fills in a local frame (x right, z forward), plus named `Place`s. Pure Java, tested by `CampusSelfTest` (voxel simulation and a walk-to flood fill).
- `CampusBuilder` (forge) places the fills 14000 blocks per tick, rotated to the player's facing, then builds the stadium pitch with `PitchBuilder` and hands it to `MatchManager.adoptPitch`. `CampusSavedData` remembers the origin so `/bluelock go` and the story can teleport. Story beats carry a `place` (generated by `tools/gen_story.py`).

## 0.22.0

- `TalentRoll` (common): talent 10..100 on a truncated bell curve (mean 50, spread 17); `PlayerProfile.talentPercent` drives XP gain and the Genius flag (75+). `CreationRolls` now rolls only when the client sends `roll`; the creation screen spins the reels client side while waiting for the state.
- `Ranking` and `Cafeteria` (common/rank): 299 fixed rivals plus the player, points to rank, tier and meal tables. `Rewards` adds rank points and announces climbs; `CafeteriaServer` serves meals.
- Story: `Kind.TRIAL` beats run through `TrialManager`; story matches are 11v11 on the campus stadium (`PitchSize.FULL`).
- `CampusPlan`: Selection Hall with 300 figures, dormitory annex, practice pitch, lettering; bounds grown to x -92..66, z -50..195.

## 0.23.0
Big-block campus with blue lettering, 46 ambient NPCs (AmbientNpcs), voices TALK/CHEER, team-room one-ball last-touch trial (TrialManager), test commands (debug talent/foot, story skip).

## 0.24.0
StoryBalance (common) tunes story bots; DrillManager mini-games; StoryManager rest periods; ClientBallCue HUD ring; canon match order X,Y,W,V.
