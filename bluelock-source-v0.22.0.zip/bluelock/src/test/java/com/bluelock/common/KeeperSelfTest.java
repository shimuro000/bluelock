package com.bluelock.common;

import com.bluelock.common.ai.*;
import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.team.TeamTactics;
import java.util.List;
import java.util.Random;

public final class KeeperSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    private static final PitchLayout L = PitchLayout.standard();
    private static final double CV = L.centreV() + 0.5;

    public static void main(String[] args) {
        // stance: on the line between goal and ball
        Pos far = KeeperLogic.stance(L, Side.HOME, new Pos(40, CV));
        Pos near = KeeperLogic.stance(L, Side.HOME, new Pos(8, CV));
        check(far.u() > near.u() - 0.01 && far.u() >= 1.0 && far.u() <= 6.0, "keeper stands further out when the ball is far (" + String.format("%.1f", far.u()) + " vs " + String.format("%.1f", near.u()) + ")");
        Pos left = KeeperLogic.stance(L, Side.HOME, new Pos(15, CV + 10));
        check(left.v() > CV && left.v() <= CV + 3.4, "keeper shades toward the ball but stays between the posts");
        Pos away = KeeperLogic.stance(L, Side.AWAY, new Pos(L.length() - 12, CV));
        check(away.u() > L.length() - 6.01 && away.u() < L.length() - 0.99, "AWAY keeper stands in front of the far goal");
        check(KeeperLogic.stance(L, Side.HOME, new Pos(10, CV - 30)).v() >= CV - 3.4, "the keeper never leaves the goal width");

        // shot analysis
        var onTarget = KeeperLogic.analyse(L, Side.HOME, new Pos(20, CV), 0.3, new BallMotion(-0.8, 0.05, 0.05));
        check(onTarget.onTarget() && Math.abs(onTarget.ticks() - 25) < 0.5 && onTarget.crossV() > CV, "a shot at the near goal is detected with its arrival time (" + String.format("%.0f", onTarget.ticks()) + " ticks)");
        check(!KeeperLogic.analyse(L, Side.HOME, new Pos(20, CV), 0.3, new BallMotion(-0.8, 0.8, 0)).onTarget(), "a shot that goes wide is not a threat");
        check(!KeeperLogic.analyse(L, Side.HOME, new Pos(10, CV), 0.3, new BallMotion(-0.8, 0, 0.6)).onTarget(), "a shot over the bar is not a threat");
        check(!KeeperLogic.analyse(L, Side.HOME, new Pos(20, CV), 0.3, new BallMotion(0.8, 0, 0)).onTarget(), "a ball going away from the goal is not a threat");
        check(!KeeperLogic.analyse(L, Side.HOME, new Pos(20, CV), 0.3, new BallMotion(-0.05, 0, 0)).onTarget(), "a slow ball is not a shot");
        check(KeeperLogic.analyse(L, Side.AWAY, new Pos(L.length() - 20, CV), 0.3, new BallMotion(0.8, 0, 0.05)).onTarget(), "the AWAY keeper sees shots too");
        check(!KeeperLogic.analyse(L, Side.AWAY, new Pos(L.length() - 20, CV), 0.3, new BallMotion(-0.8, 0, 0)).onTarget(), "and ignores shots at the other goal");

        // dive choices
        var shotRight = new KeeperLogic.ShotThreat(true, CV + 3, 1, 10, 0.9);
        check(KeeperLogic.diveDirection(shotRight, CV) == 1 && KeeperLogic.diveDirection(new KeeperLogic.ShotThreat(true, CV - 3, 1, 10, 0.9), CV) == -1, "the keeper dives toward the shot");
        check(KeeperLogic.diveDirection(new KeeperLogic.ShotThreat(true, CV + 0.4, 1, 10, 0.9), CV) == 0, "a shot right at the keeper needs no dive");
        check(KeeperLogic.diveReach(80, 80) > KeeperLogic.diveReach(30, 30), "better keepers reach further");

        // save probability
        double good = KeeperLogic.saveChance(85, 80, 80, 0.7, 1.5), bad = KeeperLogic.saveChance(30, 30, 30, 0.7, 1.5);
        check(good > bad && good <= 0.92 && bad >= 0.03, "better keepers save more (" + String.format("%.2f", good) + " vs " + String.format("%.2f", bad) + ")");
        check(KeeperLogic.saveChance(60, 60, 60, 1.2, 1.0) < KeeperLogic.saveChance(60, 60, 60, 0.4, 1.0), "harder shots are harder to save");
        check(KeeperLogic.saveChance(60, 60, 60, 0.7, 0.2) > KeeperLogic.saveChance(60, 60, 60, 0.7, 3.0), "shots far from the keeper are harder to save");
        check(KeeperLogic.saveChance(60, 60, 60, 0.7, 10.0) == 0.0, "out of reach means no save");
        check(KeeperLogic.resolveSave(0.0, () -> 0.0) == KeeperLogic.SaveOutcome.BEATEN, "zero chance: beaten");
        check(KeeperLogic.resolveSave(0.8, () -> 0.1) == KeeperLogic.SaveOutcome.CATCH && KeeperLogic.resolveSave(0.8, () -> 0.6) == KeeperLogic.SaveOutcome.PARRY && KeeperLogic.resolveSave(0.8, () -> 0.95) == KeeperLogic.SaveOutcome.BEATEN, "low roll catches, middle roll parries, high roll beats the keeper");
        Random r = new Random(3);
        int saved = 0;
        for (int i = 0; i < 20_000; i++) if (KeeperLogic.resolveSave(KeeperLogic.saveChance(60, 60, 60, 0.8, 1.5), r::nextDouble) != KeeperLogic.SaveOutcome.BEATEN) saved++;
        check(saved > 5000 && saved < 14000, "an average keeper stops a decent share of average shots (" + saved / 200 + "%)");

        // the brain
        TeamTactics tt = TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED);
        var dive = BotBrain.decide(new BotView(Side.HOME, Position.GK, new Pos(2, CV), new Pos(10, CV), false, Side.AWAY, new Pos(10, CV), 3, 60, tt, new Pos(3, CV), List.of(), List.of(), L,
                new BallMotion(-0.9, 0.12, 0.05), 0.3, 60, 60));
        check(dive.intent() == Intent.DIVE && dive.passIndex() == 1, "the brain orders a dive toward a shot on the right");
        var diveLeft = BotBrain.decide(new BotView(Side.HOME, Position.GK, new Pos(2, CV), new Pos(10, CV), false, Side.AWAY, new Pos(10, CV), 3, 60, tt, new Pos(3, CV), List.of(), List.of(), L,
                new BallMotion(-0.9, -0.12, 0.05), 0.3, 60, 60));
        check(diveLeft.intent() == Intent.DIVE && diveLeft.passIndex() == -1, "and toward a shot on the left");
        var farShot = BotBrain.decide(new BotView(Side.HOME, Position.GK, new Pos(2, CV), new Pos(60, CV), false, Side.AWAY, new Pos(60, CV), 3, 60, tt, new Pos(3, CV), List.of(), List.of(), L,
                new BallMotion(-0.9, 0, 0.05), 0.3, 60, 60));
        check(farShot.intent() != Intent.DIVE, "no dive while the shot is still far away");
        var step = BotBrain.decide(new BotView(Side.HOME, Position.GK, new Pos(2, CV), new Pos(11, CV + 3), false, Side.AWAY, new Pos(11, CV + 3), 3, 60, tt, new Pos(3, CV), List.of(), List.of(), L,
                BallMotion.STILL, 0.2, 60, 60));
        var stand = KeeperLogic.stance(L, Side.HOME, new Pos(11, CV + 3));
        check(step.intent() == Intent.MOVE && step.target().u() > stand.u(), "a keeper steps out to narrow the angle when an attacker runs at goal");

        System.out.println(failures == 0 ? "ALL KEEPER TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
