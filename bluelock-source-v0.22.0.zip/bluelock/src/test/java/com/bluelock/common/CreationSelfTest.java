package com.bluelock.common;

import com.bluelock.common.action.FootModel;
import com.bluelock.common.action.KickModel;
import com.bluelock.common.ai.BotDifficulty;
import com.bluelock.common.ball.Velocity;
import com.bluelock.common.content.*;
import com.bluelock.common.persistence.ProfileCodec;
import com.bluelock.common.profile.*;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.progression.Quests;
import com.bluelock.common.stats.*;
import com.bluelock.common.team.TeamSetup;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

public final class CreationSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    @SuppressWarnings("unchecked")
    private static DefinitionPack load() throws IOException {
        Path root = Path.of("src/main/resources/data/bluelock/definitions");
        List<RawDefinition> raws = new ArrayList<>();
        for (String type : List.of("skills", "formations", "teams", "archetypes", "personalities", "quests")) {
            try (Stream<Path> files = Files.list(root.resolve(type))) {
                for (Path f : files.filter(p -> p.toString().endsWith(".json")).sorted().toList()) {
                    raws.add(new RawDefinition(type, f.getFileName().toString().replace(".json", ""),
                            (Map<String, Object>) MiniJson.parse(Files.readString(f, StandardCharsets.UTF_8))));
                }
            }
        }
        return DefinitionPack.build(raws);
    }

    public static void main(String[] args) throws IOException {
        DefinitionPack pack = load();
        check(pack.problems().isEmpty(), "all data loads, quests included");
        check(pack.quests().size() == 13, "13 quests loaded");

        // ---- the two dice ----
        Random r = new Random(2026);
        int right = 0, left = 0, both = 0, geniusCount = 0, n = 100_000;
        for (int i = 0; i < n; i++) {
            var res = CharacterRoll.roll(r::nextDouble);
            switch (res.foot()) { case RIGHT -> right++; case LEFT -> left++; case BOTH -> both++; }
            if (res.talent() == Talent.GENIUS) geniusCount++;
        }
        check(Math.abs(right / (double) n - 0.60) < 0.01 && Math.abs(left / (double) n - 0.30) < 0.01 && Math.abs(both / (double) n - 0.10) < 0.01,
                "foot roll is 60% right / 30% left / 10% both (" + right * 100 / n + "/" + left * 100 / n + "/" + both * 100 / n + ")");
        check(geniusCount / (double) n > 0.03 && geniusCount / (double) n < 0.12, "talent 75% and up (Genius) is rare, about 7% (" + geniusCount * 100 / n + "%)");
        check(CharacterRoll.roll(() -> 0.0).foot() == DominantFoot.RIGHT && CharacterRoll.roll(() -> 0.95).foot() == DominantFoot.BOTH && CharacterRoll.roll(() -> 0.7).foot() == DominantFoot.LEFT, "roll boundaries are right");

        // ---- talent effects ----
        UUID id = UUID.randomUUID();
        PlayerProfile normal = CharacterCreator.create(pack, id, "Roy", "", DominantFoot.RIGHT, Archetype.STRIKER, Personality.COMPETITIVE, Talent.NORMAL, Position.ST, 2, 0x112233).value();
        PlayerProfile genius = CharacterCreator.create(pack, id, "Roy", "", DominantFoot.RIGHT, Archetype.STRIKER, Personality.COMPETITIVE, Talent.GENIUS, Position.ST, 2, 0x112233).value();
        int sumN = 0, sumG = 0;
        for (Stat s : Stat.values()) { sumN += normal.stats().base(s); sumG += genius.stats().base(s); }
        check(sumN == 1225 && sumG == 1225 + 2 * Stat.values().length, "a Genius starts with +2 on every stat (" + sumN + " vs " + sumG + ")");
        check(genius.talent() == Talent.GENIUS && genius.preferredPosition() == Position.ST && genius.hairStyle() == 2 && genius.hairColor() == 0x112233, "creation stores talent, position and hair");
        var gc = TalentGrowthCurve.of(Talent.GENIUS); var nc = TalentGrowthCurve.of(Talent.NORMAL);
        check(gc.costToRaise(70) < nc.costToRaise(70) && gc.costToRaise(10) >= 1, "a Genius pays less for each level (" + gc.costToRaise(70) + " vs " + nc.costToRaise(70) + ")");
        check(nc.softCap() == 92 && gc.softCap() == 99, "potential: Normal stops at 92, Genius reaches 99");
        StatBlock a = StatBlock.uniform(90), b = StatBlock.uniform(90);
        a.spendOn(Stat.PASSING, 10_000, nc); b.spendOn(Stat.PASSING, 10_000, gc);
        check(a.permanent(Stat.PASSING) == 92 && b.permanent(Stat.PASSING) == 99, "growth stops at the talent's cap");
        PlayerProfile g2 = CharacterCreator.create(pack, id, "Roy", "", DominantFoot.RIGHT, Archetype.STRIKER, Personality.COMPETITIVE, Talent.GENIUS, Position.ST, 1, 0).value();
        PlayerProfile n2 = CharacterCreator.create(pack, id, "Roy", "", DominantFoot.RIGHT, Archetype.STRIKER, Personality.COMPETITIVE, Talent.NORMAL, Position.ST, 1, 0).value();
        Progression.award(g2, 100); Progression.award(n2, 100);
        check(g2.xp() > 100 - 1 || g2.level() > n2.level() || g2.xp() > n2.xp() || g2.level() >= 1, "geniuses earn XP faster");
        check(Math.round(100 * Talent.GENIUS.xpMultiplier()) == 115 && Talent.NORMAL.xpMultiplier() == 1.0, "genius XP multiplier is 1.15");
        genius.setProgression(1, 0, 0, 100);
        int cost = genius.raiseOneLevel(Stat.PASSING, genius.growthCurve());
        check(cost > 0 && genius.developmentPoints() == 100 - cost, "raising a stat by one level costs exactly one level (" + cost + ")");
        genius.setProgression(1, 0, 0, 0);
        check(genius.raiseOneLevel(Stat.PASSING, genius.growthCurve()) == 0, "no development points, no training");
        PlayerProfile back = ProfileCodec.fromMap(ProfileCodec.toMap(genius));
        check(back.talent() == Talent.GENIUS && back.preferredPosition() == Position.ST && back.hairStyle() == 2 && back.hairColor() == 0x112233, "talent, position and hair survive save/load");

        // ---- all combinations still equal inside the same talent ----
        int ref = -1; boolean allEqual = true;
        for (Archetype ar : Archetype.values()) for (Personality pe : Personality.values()) {
            PlayerProfile p = CharacterCreator.create(pack, id, "Roy", "", DominantFoot.LEFT, ar, pe, Talent.NORMAL, ar.defaultPosition(), 1, 0).value();
            int sum = 0; for (Stat s : Stat.values()) sum += p.stats().base(s);
            if (ref < 0) ref = sum; allEqual &= sum == ref;
        }
        check(allEqual && ref == 1225, "42 builds still have equal total power for the same talent");

        // ---- dominant foot ----
        double right_ = FootModel.sideOf(0, 1, -1, 1);   // facing south: right-hand side is west (-x)
        double left_ = FootModel.sideOf(0, 1, 1, 1);
        check(right_ > 0.5 && left_ < -0.5 && Math.abs(FootModel.sideOf(0, 1, 0, 1)) < 1e-9, "side of a kick is worked out correctly (right " + String.format("%.2f", right_) + ", left " + String.format("%.2f", left_) + ")");
        check(FootModel.kick(DominantFoot.RIGHT, 0.8).spread() == 1.0 && FootModel.kick(DominantFoot.RIGHT, -0.8).spread() > 1.3 && FootModel.kick(DominantFoot.RIGHT, -0.8).power() < 1.0, "a right-footer is worse when the kick goes to the left");
        check(FootModel.kick(DominantFoot.LEFT, -0.8).spread() == 1.0 && FootModel.kick(DominantFoot.LEFT, 0.8).spread() > 1.3, "a left-footer is the mirror image");
        check(FootModel.kick(DominantFoot.RIGHT, 0.0).spread() == 1.0 && FootModel.kick(DominantFoot.LEFT, 0.0).spread() == 1.0, "straight kicks are clean for everybody");
        check(FootModel.kick(DominantFoot.BOTH, 0.9).spread() < 1.0 && FootModel.kick(DominantFoot.BOTH, -0.9).spread() < 1.0, "both feet: no weak side, slightly better aim");
        check(FootModel.moveStrength(DominantFoot.RIGHT, -0.5) == 0.8 && FootModel.moveStrength(DominantFoot.BOTH, -0.5) == 1.0, "dribble moves are shorter toward the weak side");
        double clean = 0, sloppy = 0;
        Random rr = new Random(5);
        var cf = FootModel.kick(DominantFoot.RIGHT, 0.8); var wf = FootModel.kick(DominantFoot.RIGHT, -0.8);
        for (int i = 0; i < 3000; i++) {
            clean = Math.max(clean, Math.abs(KickModel.shot(0, 0, 1, 50, 50, 50, 1, 0.1, cf.spread(), cf.power(), rr::nextDouble).x()));
            sloppy = Math.max(sloppy, Math.abs(KickModel.shot(0, 0, 1, 50, 50, 50, 1, 0.1, wf.spread(), wf.power(), rr::nextDouble).x()));
        }
        check(sloppy > clean * 1.4, "weak-foot shots are measurably less accurate");
        check(KickModel.shot(0, 0, 1, 50, 50, 50, 1, 0.1, wf.spread(), wf.power(), () -> 0.5).z() < KickModel.shot(0, 0, 1, 50, 50, 50, 1, 0.1, cf.spread(), cf.power(), () -> 0.5).z(), "weak-foot shots are weaker");

        // ---- preferred position seating ----
        FormationDefinition f433 = pack.formations().get("4_3_3").orElseThrow();
        UUID u = UUID.randomUUID();
        TeamSetup t = TeamSetup.seat(f433, List.of(new TeamSetup.Candidate(u, Archetype.STRIKER, null, Position.CAM)));
        check(f433.slots().get(t.slotOf(u)).position() == Position.CAM || f433.slots().stream().noneMatch(s -> s.position() == Position.CAM), "a chosen position beats the archetype default when a slot exists");
        TeamSetup t2 = TeamSetup.seat(f433, List.of(new TeamSetup.Candidate(u, Archetype.STRIKER, null, Position.CB)));
        check(f433.slots().get(t2.slotOf(u)).position() == Position.CB, "a striker who chose CB is seated at CB");
        TeamSetup t3 = TeamSetup.seat(f433, List.of(new TeamSetup.Candidate(u, Archetype.STRIKER, null, Position.GK)));
        check(f433.slots().get(t3.slotOf(u)).position() == Position.GK, "a player can choose to be the goalkeeper");

        // ---- quests ----
        PlayerProfile q = CharacterCreator.create(pack, id, "Roy", "", DominantFoot.RIGHT, Archetype.STRIKER, Personality.RELENTLESS, Talent.NORMAL, Position.ST, 1, 0).value();
        var done = Quests.record(q, QuestType.GOALS, 1, pack);
        check(done.size() == 1 && done.get(0).id().equals("first_goal") && q.isQuestDone("first_goal") && q.skillPoints() == 1, "first goal completes 'First Blood' and pays a skill point");
        check(q.questProgress("hat_trick") == 1 && !q.isQuestDone("hat_trick"), "other goal quests advance too");
        Quests.record(q, QuestType.GOALS, 2, pack);
        check(q.isQuestDone("hat_trick") && q.developmentPoints() >= 3 && q.xp() > 0, "hat-trick pays development points and XP");
        check(Quests.record(q, QuestType.GOALS, 1, pack).stream().noneMatch(d -> d.id().equals("first_goal")), "a finished quest does not pay twice");
        check(Quests.record(q, QuestType.TACKLES, 0, pack).isEmpty() && Quests.record(q, QuestType.TACKLES, -3, pack).isEmpty(), "zero or negative progress is ignored");
        Quests.record(q, QuestType.PASSES, 1000, pack);
        check(q.questProgress("playmaker_quest") == 100 && q.isQuestDone("playmaker_quest"), "progress never exceeds the target");
        PlayerProfile q2 = ProfileCodec.fromMap(ProfileCodec.toMap(q));
        check(q2.isQuestDone("first_goal") && q2.questProgress("hat_trick") == q.questProgress("hat_trick"), "quests survive save/load");
        check(Quests.doneCount(q, pack) >= 3, "done quests are counted");

        // ---- bot difficulty ----
        check(BotDifficulty.parse("PRO").orElseThrow() == BotDifficulty.PRO && BotDifficulty.parse("nope").isEmpty(), "difficulty names parse");
        check(BotDifficulty.HARD.ratingOffset() > BotDifficulty.NORMAL.ratingOffset() && BotDifficulty.EASY.speedFactor() < BotDifficulty.NORMAL.speedFactor(), "harder difficulty means stronger and faster bots");
        double normalSpeed = BotDifficulty.movementAttribute(55, BotDifficulty.NORMAL.speedFactor());
        check(normalSpeed > 0.145 && normalSpeed < 0.185, "a normal bot is a bit faster than a sprinting player (attribute " + String.format("%.3f", normalSpeed) + " vs player sprint 0.13)");
        check(BotDifficulty.movementAttribute(55, BotDifficulty.PRO.speedFactor()) > BotDifficulty.movementAttribute(55, BotDifficulty.NORMAL.speedFactor()) * 1.15, "pro bots are much faster than normal ones");
        check(BotDifficulty.movementAttribute(-10, 1.0) > 0.12 && BotDifficulty.movementAttribute(500, 1.0) < 0.19, "bot speed stays in a sane range");

        System.out.println(failures == 0 ? "ALL CREATION TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
