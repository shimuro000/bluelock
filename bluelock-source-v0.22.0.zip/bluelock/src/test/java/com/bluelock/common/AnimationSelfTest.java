package com.bluelock.common;

import com.bluelock.common.anim.AnimLogic;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Checks the animation logic and that every animation the game can ask for exists in the asset files. */
public final class AnimationSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> json(String path) throws IOException {
        return (Map<String, Object>) MiniJson.parse(Files.readString(Path.of(path), StandardCharsets.UTF_8));
    }

    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws IOException {
        String base = "src/main/resources/assets/bluelock/";

        // ---- which animation plays ----
        check(AnimLogic.locomotion(0, false, false).equals("idle") && AnimLogic.locomotion(0, true, false).equals("idle_ball"), "standing still: idle, or idle with the ball");
        check(AnimLogic.locomotion(0.08, false, false).equals("walk") && AnimLogic.locomotion(0.08, true, false).equals("dribble_walk"), "walking speed");
        check(AnimLogic.locomotion(0.20, false, false).equals("run") && AnimLogic.locomotion(0.20, true, false).equals("dribble_run"), "running speed (a walking Minecraft player moves 0.22 per tick)");
        check(AnimLogic.locomotion(0.3, false, false).equals("sprint") && AnimLogic.locomotion(0.3, true, false).equals("dribble_sprint"), "sprinting speed");
        check(AnimLogic.locomotion(0.3, false, true).equals("jump") && AnimLogic.locomotion(0.0, true, true).equals("dribble_jump"), "being in the air always means jump");
        check("sprint".equals(AnimLogic.playerLocomotion(0.3, false, false)) && "jump".equals(AnimLogic.playerLocomotion(0.0, false, true)) && "idle".equals(AnimLogic.playerLocomotion(0.0, false, false)),
                "players get idle, walk, run, sprint and jump even without the ball");
        check(AnimLogic.playerLocomotion(0.3, true, false).equals("dribble_sprint"), "players with the ball use the dribbling animations");
        check("feint_right".equals(AnimLogic.forSkill("feint", 1)) && "feint_left".equals(AnimLogic.forSkill("feint", -1)), "feint animation follows the side");
        check("burst".equals(AnimLogic.forSkill("burst_dribble", 1)) && "chain_spin".equals(AnimLogic.forSkill("chain_dribble", 1))
                && "sprint_burst".equals(AnimLogic.forSkill("sprint_burst", 1)) && "shoulder".equals(AnimLogic.forSkill("shoulder_charge", 1)), "every animated skill has its animation");
        check("direct_shot".equals(AnimLogic.forSkill("direct_shot", 1)) && "direct_shot".equals(AnimLogic.forSkill("precision_direct_shot", 1))
                && "awakening_shot".equals(AnimLogic.forSkill("awakening_direct_shot", 1)) && "through_pass".equals(AnimLogic.forSkill("through_pass", 1))
                && "read_scan".equals(AnimLogic.forSkill("passing_lane_read", 1)) && "read_scan".equals(AnimLogic.forSkill("spatial_read", 1))
                && "vision_open".equals(AnimLogic.forSkill("advanced_field_vision", 1)) && "intercept_step".equals(AnimLogic.forSkill("interception_read", 1))
                && "shadow_step".equals(AnimLogic.forSkill("shadow_marking", 1)) && "focus_breath".equals(AnimLogic.forSkill("composure_focus", 1)),
                "every active skill has its animation");
        check(AnimLogic.forSkill("control", 1) == null && AnimLogic.forSkill("finishing", 1) == null && AnimLogic.forSkill(null, 1) == null, "passive skills and null have no animation");
        // every skill definition that is not passive must map to an animation that exists for players
        for (String skill : List.of("feint", "burst_dribble", "chain_dribble", "sprint_burst", "shoulder_charge", "direct_shot", "precision_direct_shot",
                "awakening_direct_shot", "through_pass", "passing_lane_read", "spatial_read", "advanced_field_vision", "interception_read", "shadow_marking", "composure_focus")) {
            String anim = AnimLogic.forSkill(skill, 1);
            check(anim != null && AnimLogic.PLAYER_ANIMATIONS.contains(anim) && AnimLogic.durationTicks(anim) > 0, "skill '" + skill + "' plays a real player animation with a duration");
        }
        for (String n : AnimLogic.PLAYER_ANIMATIONS) {
            if (!AnimLogic.LOOPING.contains(n) && !n.equals("dribble_jump") && !n.equals("jump")) check(AnimLogic.durationTicks(n) > 0, "one-shot '" + n + "' has a duration");
        }

        // ---- bot animations (GeckoLib) ----
        Map<String, Object> botFile = json(base + "animations/entity/bot.animation.json");
        Map<String, Object> bot = (Map<String, Object>) botFile.get("animations");
        check(bot.keySet().containsAll(AnimLogic.BOT_ANIMATIONS) && bot.size() == AnimLogic.BOT_ANIMATIONS.size(), "bot animation file has exactly the " + AnimLogic.BOT_ANIMATIONS.size() + " animations the game uses");
        Map<String, Object> geo = json(base + "geo/entity/bot.geo.json");
        List<Object> geometries = (List<Object>) geo.get("minecraft:geometry");
        List<Object> bones = (List<Object>) ((Map<String, Object>) geometries.get(0)).get("bones");
        Set<String> boneNames = new java.util.HashSet<>();
        for (Object b : bones) boneNames.add((String) ((Map<String, Object>) b).get("name"));
        check(boneNames.containsAll(Set.of("root", "waist", "body", "head", "right_arm", "left_arm", "right_leg", "left_leg")), "bot model has all bones");
        boolean bonesKnown = true, loopsMatch = true, lengths = true, loopsClosed = true;
        for (Map.Entry<String, Object> e : bot.entrySet()) {
            Map<String, Object> a = (Map<String, Object>) e.getValue();
            Map<String, Object> animBones = (Map<String, Object>) a.get("bones");
            for (String bn : animBones.keySet()) bonesKnown &= boneNames.contains(bn);
            loopsMatch &= Boolean.TRUE.equals(a.get("loop")) == AnimLogic.LOOPING.contains(e.getKey());
            double len = ((Number) a.get("animation_length")).doubleValue();
            lengths &= len > 0.2 && len < 3;
            if (Boolean.TRUE.equals(a.get("loop"))) {
                for (Object boneAnim : animBones.values()) {
                    Map<String, Object> ba = (Map<String, Object>) boneAnim;
                    Map<String, Object> rot = (Map<String, Object>) ba.get("rotation");
                    if (rot == null) continue;
                    java.util.List<String> keys = new java.util.ArrayList<>(rot.keySet());
                    keys.sort(java.util.Comparator.comparingDouble(Double::parseDouble));
                    loopsClosed &= rot.get(keys.get(0)).equals(rot.get(keys.get(keys.size() - 1)));
                }
            }
        }
        check(bonesKnown, "every animated bone exists in the bot model");
        check(loopsMatch, "looping flags match the animation list (walk/run/idle loop, kicks do not)");
        check(lengths, "all bot animations have a sensible length");
        check(loopsClosed, "looping animations end where they begin (no jump when they repeat)");

        check(!Files.exists(Path.of(base + "player_animations")), "the old (wrong) 'player_animations' folder is gone: PlayerAnimator only reads 'player_animation'");
        // ---- player animations (PlayerAnimator) ----
        boolean playerOk = true, parts = true;
        for (String n : AnimLogic.PLAYER_ANIMATIONS) {
            Path f = Path.of(base + "player_animation/" + n + ".json");
            if (!Files.exists(f)) { playerOk = false; System.out.println("  missing player animation " + n); continue; }
            Map<String, Object> p = json(f.toString());
            Map<String, Object> emote = (Map<String, Object>) p.get("emote");
            List<Object> moves = (List<Object>) emote.get("moves");
            playerOk &= ((Number) p.get("version")).intValue() == 3 && !moves.isEmpty() && ((Number) emote.get("endTick")).intValue() > 0;
            playerOk &= Boolean.TRUE.equals(emote.get("isLoop")) == AnimLogic.LOOPING.contains(n);
            for (Object m : moves) {
                for (String key : ((Map<String, Object>) m).keySet()) {
                    parts &= Set.of("tick", "easing", "turn", "head", "torso", "rightArm", "leftArm", "rightLeg", "leftLeg").contains(key);
                }
            }
        }
        check(playerOk, "all " + AnimLogic.PLAYER_ANIMATIONS.size() + " player animation files exist and are well-formed");
        check(parts, "player animations only use known body parts");
        long extra = Files.list(Path.of(base + "player_animation")).count();
        check(extra == AnimLogic.PLAYER_ANIMATIONS.size(), "no stray player animation files (" + extra + ")");

        System.out.println(failures == 0 ? "ALL ANIMATION TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
