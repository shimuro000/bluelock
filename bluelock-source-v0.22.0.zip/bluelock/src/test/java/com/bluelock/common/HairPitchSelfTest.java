package com.bluelock.common;

import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.appearance.HairModel;
import com.bluelock.common.persistence.ProfileCodec;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.pitch.PitchSize;
import com.bluelock.common.profile.*;
import com.bluelock.common.stats.StatBlock;
import com.bluelock.common.team.MatchMode;
import java.util.*;

/** Phase 4: the four pitch sizes and the 3D hair design. */
public final class HairPitchSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    public static void main(String[] args) {
        pitches();
        hair();
        System.out.println(failures == 0 ? "ALL HAIR/PITCH TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }

    private static void pitches() {
        for (PitchSize s : PitchSize.values()) {
            PitchLayout l = s.layout();
            check(l.length() == s.length() && l.width() == s.width() && PitchSize.of(l) == s, "size " + s + " builds and is recognised");
            int lines = 0;
            for (int u = 0; u < l.length(); u++) for (int v = 0; v < l.width(); v++) if (l.surfaceAt(u, v) == PitchLayout.Surface.LINE) lines++;
            check(lines > 100 && l.surfaceAt(l.centreU(), l.centreV()) == PitchLayout.Surface.LINE, s + " has lines and a centre spot");
        }
        PitchLayout full = PitchSize.FULL.layout();
        check(full.penaltyDepth() == 16 && full.penaltyHalfWidth() == 20, "full pitch has a real-size penalty area");
        check(PitchSize.STANDARD.layout().penaltyDepth() == 9, "standard pitch markings unchanged");
        check(full.penaltyHalfWidth() < full.width() / 2, "penalty area fits inside the full pitch");
        check(PitchSize.forMatch(MatchMode.ELEVEN_V_ELEVEN, true) == PitchSize.FULL && PitchSize.forMatch(MatchMode.ELEVEN_V_ELEVEN, false) == PitchSize.FULL, "11v11 always uses the full pitch");
        check(PitchSize.forMatch(MatchMode.ONE_V_ONE, true) == PitchSize.PRACTICE, "practice 1v1 uses the small pitch");
        check(PitchSize.forMatch(MatchMode.FIVE_V_FIVE, true) == PitchSize.STANDARD && PitchSize.forMatch(MatchMode.FIVE_V_FIVE, false) == PitchSize.LARGE, "5v5: practice standard, real match large");
        check(PitchSize.forMatch(MatchMode.SEVEN_V_SEVEN, false) == PitchSize.LARGE, "7v7 uses the large pitch");
        check(PitchSize.parse("Full").isPresent() && PitchSize.parse("nope").isEmpty(), "pitch size parsing");
        int goalCells = full.goalCells(false).size();
        check(goalCells == PitchSize.STANDARD.layout().goalCells(false).size(), "goal size is the same on every pitch");
    }

    private static void hair() {
        Set<Integer> signatures = new HashSet<>();
        for (int style = 0; style < HairDesign.STYLE_COUNT; style++) {
            HairDesign d = HairDesign.preset(style, 0x336699);
            List<HairModel.Quad> quads = HairModel.build(d);
            boolean finite = true, inside = true;
            for (HairModel.Quad q : quads) {
                for (int i = 0; i < 4; i++) {
                    finite &= Float.isFinite(q.x[i]) && Float.isFinite(q.y[i]) && Float.isFinite(q.z[i]) && q.t[i] >= 0 && q.t[i] <= 1;
                    inside &= Math.abs(q.x[i]) < 12 && q.y[i] > -22 && q.y[i] < 20 && Math.abs(q.z[i]) < 16;
                }
                finite &= Math.abs(q.nx * q.nx + q.ny * q.ny + q.nz * q.nz - 1) < 0.01;
            }
            check(quads.size() >= 10 && finite && inside, "style " + HairDesign.STYLE_NAMES[style] + ": " + quads.size() + " faces, finite and near the head");
            signatures.add(quads.size() * 31 + Arrays.hashCode(quads.get(quads.size() / 2).x));
        }
        check(signatures.size() >= 10, "the styles look different from each other");
        HairDesign a = HairDesign.preset(3, 0x112233);
        check(HairModel.build(a).size() == HairModel.build(a).size() && Arrays.equals(HairModel.build(a).get(5).x, HairModel.build(a).get(5).x), "same design gives the same mesh");
        check(!Arrays.equals(HairModel.build(a).get(HairModel.build(a).size() - 1).x, HairModel.build(a.withSeed(77)).get(HairModel.build(a.withSeed(77)).size() - 1).x)
                || HairModel.build(a).size() != HairModel.build(a.withSeed(77)).size(), "a different seed changes the locks");
        check(HairModel.build(HairDesign.preset(0, 0)).size() < HairModel.build(HairDesign.preset(11, 0)).size(), "buzz cut has fewer faces than big volume");
        check(HairModel.build(HairDesign.preset(7, 0).withSliders(50, 50, 50, 100, 0, 0, 0)).stream().anyMatch(q -> q.y[0] > 4 || q.y[2] > 4), "long back hair hangs below the chin");

        HairDesign weird = new HairDesign(99, -5, 500, 7, 7, 7, 7, 7, -3, 0xFFFFFFFF, 0x1000000, 900);
        check(weird.style() == 11 && weird.top() == 0 && weird.front() == 100 && weird.seed() == 0 && weird.color() == 0xFFFFFF && weird.tipColor() == 0 && weird.tipAmount() == 100, "values are clamped");
        check(HairDesign.fromInts(new int[] {1, 2}).equals(HairDesign.standard()) && HairDesign.fromInts(null).equals(HairDesign.standard()), "bad packet data gives the standard hair");
        HairDesign r = HairDesign.random(new Random(5));
        check(HairDesign.fromInts(r.toInts()).equals(r), "design survives the int array (network)");
        check(HairDesign.fromMap(r.toMap()).equals(r), "design survives the map (save file)");
        check(HairDesign.fromMap(Map.of("style", 4, "color", 0xABCDEF)).equals(HairDesign.preset(4, 0xABCDEF)), "old-style map becomes the preset");
        check(HairDesign.preset(14, 1).style() == 2 && HairDesign.preset(-1, 1).style() == 11, "preset numbers wrap around");
        check(HairDesign.preset(3, 5).withStyle(8).tail() > 0 && HairDesign.preset(3, 5).withStyle(8).color() == 5, "changing style keeps colours and applies the preset");

        HairDesign none = HairDesign.preset(1, 0x204060);
        HairDesign tip = none.withColors(0x204060, 0xFF0000, 60);
        check(HairModel.colorAt(none, 1f) == 0x204060, "no tips: always the main colour");
        check(HairModel.colorAt(tip, 0f) == 0x204060 && HairModel.colorAt(tip, 1f) == 0xFF0000, "tips: root is main colour, end is tip colour");
        int prev = -1; boolean mono = true;
        for (int i = 0; i <= 10; i++) { int red = (HairModel.colorAt(tip, i / 10f) >> 16) & 255; mono &= red >= prev; prev = red; }
        check(mono, "tip colour grows smoothly toward the tip");

        PlayerProfile p = new PlayerProfile(UUID.randomUUID(), "Roy", "", DominantFoot.RIGHT, Archetype.STRIKER, Personality.COMPETITIVE, StatBlock.uniform(35));
        p.setHair(r);
        PlayerProfile back = ProfileCodec.fromMap(ProfileCodec.toMap(p));
        check(back.hair().equals(r), "designed hair survives profile save/load");
        Map<String, Object> old = ProfileCodec.toMap(p);
        old.remove("hair");
        old.put("hairStyle", 6);
        old.put("hairColor", 0x778899);
        PlayerProfile legacy = ProfileCodec.fromMap(old);
        check(legacy.hair().equals(HairDesign.preset(6, 0x778899)), "a 0.12 save without a hair design gets the matching preset");
    }
}
