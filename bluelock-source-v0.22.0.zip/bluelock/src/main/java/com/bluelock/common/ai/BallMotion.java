package com.bluelock.common.ai;

/** Ball velocity in pitch coordinates, blocks per tick: u along the pitch, v across it, h up. */
public record BallMotion(double u, double v, double h) {
    public static final BallMotion STILL = new BallMotion(0, 0, 0);

    public double speed() {
        return Math.sqrt(u * u + v * v + h * h);
    }
}
