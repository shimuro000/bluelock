package com.bluelock.common.pitch;

import com.bluelock.common.team.MatchMode;
import java.util.Locale;
import java.util.Optional;

/**
 * The four pitch sizes. PRACTICE is the small pitch for training; FULL is close to a real 105 x 68 m pitch for 11v11.
 * Which one a match uses depends on the mode and on whether it is practice or a real match.
 */
public enum PitchSize {
    PRACTICE(41, 25),
    STANDARD(61, 37),
    LARGE(81, 49),
    FULL(105, 69);

    private final int length;
    private final int width;

    PitchSize(int length, int width) {
        this.length = length;
        this.width = width;
    }

    public int length() { return length; }
    public int width() { return width; }

    public PitchLayout layout() {
        return new PitchLayout(length, width);
    }

    public String id() {
        return name().toLowerCase(Locale.ROOT);
    }

    /** Practice uses the smallest pitch that still fits the team size; a real match uses a bigger one. */
    public static PitchSize forMatch(MatchMode mode, boolean practice) {
        int n = mode.size();
        if (n >= 11) return FULL;
        if (n >= 7) return LARGE;
        if (practice) return n <= 3 ? PRACTICE : STANDARD;
        return n <= 3 ? STANDARD : LARGE;
    }

    public static Optional<PitchSize> parse(String text) {
        if (text == null) return Optional.empty();
        String t = text.trim().toLowerCase(Locale.ROOT);
        for (PitchSize s : values()) {
            if (s.id().equals(t)) return Optional.of(s);
        }
        return Optional.empty();
    }

    /** The size whose dimensions equal this layout, or null for a custom layout. */
    public static PitchSize of(PitchLayout layout) {
        for (PitchSize s : values()) {
            if (s.length == layout.length() && s.width == layout.width()) return s;
        }
        return null;
    }
}
