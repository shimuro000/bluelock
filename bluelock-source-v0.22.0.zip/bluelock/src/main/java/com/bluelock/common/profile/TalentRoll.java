package com.bluelock.common.profile;

import java.util.function.DoubleSupplier;

/**
 * Talent as a percentage from 10 to 100. The average is 50 and the chance falls away smoothly in both directions
 * (a bell curve), so 90 is much rarer than 60 and 100 or 10 are very rare, but every value stays possible.
 */
public final class TalentRoll {
    public static final int MIN = 10;
    public static final int MAX = 100;
    public static final int MEAN = 50;
    public static final double SPREAD = 17.0;
    /** From this percentage up a character counts as a Genius (faster growth, higher cap). */
    public static final int GENIUS_FROM = 75;

    private TalentRoll() {
    }

    /** rng returns numbers in [0, 1). */
    public static int roll(DoubleSupplier rng) {
        for (int i = 0; i < 50; i++) {
            double u1 = Math.max(1e-12, rng.getAsDouble());
            double u2 = rng.getAsDouble();
            double z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
            long value = Math.round(MEAN + SPREAD * z);
            if (value >= MIN && value <= MAX) {
                return (int) value;
            }
        }
        return MEAN;
    }

    private static double weight(int p) {
        double d = (p - MEAN) / SPREAD;
        return Math.exp(-0.5 * d * d);
    }

    private static final double TOTAL;

    static {
        double sum = 0;
        for (int p = MIN; p <= MAX; p++) {
            sum += weight(p);
        }
        TOTAL = sum;
    }

    /** The chance (0..1) of rolling exactly this percentage. */
    public static double chanceOf(int percent) {
        return percent < MIN || percent > MAX ? 0 : weight(percent) / TOTAL;
    }

    /** The chance (0..1) of rolling this percentage or better. */
    public static double chanceAtLeast(int percent) {
        double sum = 0;
        for (int p = Math.max(MIN, percent); p <= MAX; p++) {
            sum += weight(p);
        }
        return sum / TOTAL;
    }

    /** The chance (0..1) of rolling this percentage or worse. */
    public static double chanceAtMost(int percent) {
        double sum = 0;
        for (int p = MIN; p <= Math.min(MAX, percent); p++) {
            sum += weight(p);
        }
        return sum / TOTAL;
    }

    public static Talent talentOf(int percent) {
        return percent >= GENIUS_FROM ? Talent.GENIUS : Talent.NORMAL;
    }

    /** 50% gives x1.00, 10% x0.84, 100% x1.20. */
    public static double xpMultiplier(int percent) {
        return 0.80 + clamp(percent) * 0.004;
    }

    public static int clamp(int percent) {
        return Math.max(MIN, Math.min(MAX, percent));
    }

    /** Language key of the band the percentage falls in. */
    public static String bandKey(int percent) {
        String band = percent < 25 ? "late" : percent < 45 ? "below" : percent <= 55 ? "average" : percent < GENIUS_FROM ? "gifted" : "genius";
        return "bluelock.talent_band." + band;
    }
}
