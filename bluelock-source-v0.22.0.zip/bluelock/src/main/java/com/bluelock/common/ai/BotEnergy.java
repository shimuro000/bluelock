package com.bluelock.common.ai;

/**
 * A bot's sprint energy (no Minecraft code). Sprinting drains it, jogging and standing refill it. At zero the bot
 * is tired: it cannot sprint until it has recovered a part of the bar, and jogs a little slower meanwhile.
 */
public final class BotEnergy {
    public static final double RECOVER_FROM_TIRED = 30.0;
    public static final double TIRED_SPEED_FACTOR = 0.92;
    private static final double RECOVER_SECONDS = 10.0;

    public enum State { FRESH, SPRINTING, TIRED }

    private final double drainPerTick;
    private final double regenPerTick;
    private double energy = 100.0;
    private boolean tired;
    private boolean sprinting;

    public BotEnergy(double sprintSeconds) {
        double s = Math.max(1.0, sprintSeconds);
        this.drainPerTick = 100.0 / (s * 20.0);
        this.regenPerTick = 100.0 / (RECOVER_SECONDS * 20.0);
    }

    /**
     * Advances the bar by some ticks. wantSprint says whether the brain asked for a sprint.
     * Returns true when the bot really sprints during these ticks.
     */
    public boolean update(boolean wantSprint, int ticks) {
        int n = Math.max(0, ticks);
        if (tired && energy >= RECOVER_FROM_TIRED) {
            tired = false;
        }
        sprinting = wantSprint && !tired && energy > 0.0;
        if (sprinting) {
            energy -= drainPerTick * n;
            if (energy <= 0.0) {
                energy = 0.0;
                tired = true;
            }
        } else {
            energy = Math.min(100.0, energy + regenPerTick * n * (tired ? 0.8 : 1.0));
            if (tired && energy >= RECOVER_FROM_TIRED) {
                tired = false;
            }
        }
        return sprinting;
    }

    public double percent() { return energy; }
    public boolean isTired() { return tired; }
    public boolean isSprinting() { return sprinting; }

    public State state() {
        return tired ? State.TIRED : sprinting ? State.SPRINTING : State.FRESH;
    }

    /** Speed factor from the state: tired bots jog slower. */
    public double speedFactor() {
        return tired ? TIRED_SPEED_FACTOR : 1.0;
    }

    public void refill() {
        energy = 100.0;
        tired = false;
    }
}
