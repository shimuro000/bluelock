package com.bluelock.common.action;

import java.util.List;

/** Passing-lane maths for the vision skills and the through pass. Positions are {x, z} pairs in blocks. */
public final class PassLanes {
    /** A lane is blocked when an opponent stands closer than this to the line of the pass. */
    public static final double LANE_WIDTH = 1.7;

    private PassLanes() {
    }

    /** Shortest distance from point (px, pz) to the segment (ax, az)-(bx, bz). */
    public static double distanceToSegment(double px, double pz, double ax, double az, double bx, double bz) {
        double abx = bx - ax, abz = bz - az;
        double len2 = abx * abx + abz * abz;
        double t = len2 < 1.0E-9 ? 0 : ((px - ax) * abx + (pz - az) * abz) / len2;
        t = Math.max(0, Math.min(1, t));
        double cx = ax + abx * t, cz = az + abz * t;
        return Math.hypot(px - cx, pz - cz);
    }

    /** True if no opponent is on the line from the passer to the receiver. */
    public static boolean laneOpen(double[] passer, double[] receiver, List<double[]> opponents) {
        for (double[] o : opponents) {
            if (distanceToSegment(o[0], o[1], passer[0], passer[1], receiver[0], receiver[1]) < LANE_WIDTH) return false;
        }
        return true;
    }

    /** True if the receiver has no opponent within {@code radius} blocks (he is free to receive). */
    public static boolean unmarked(double[] receiver, List<double[]> opponents, double radius) {
        for (double[] o : opponents) {
            if (Math.hypot(o[0] - receiver[0], o[1] - receiver[1]) < radius) return false;
        }
        return true;
    }

    /**
     * Where a through pass should go: ahead of the runner. A moving team-mate gets the ball where he will be in
     * {@code leadTicks}; a standing one gets it {@code standingLead} blocks toward the goal (goalDirX, goalDirZ).
     */
    public static double[] throughTarget(double mateX, double mateZ, double mateVx, double mateVz,
                                         double goalDirX, double goalDirZ, double leadTicks, double standingLead) {
        double speed = Math.hypot(mateVx, mateVz);
        if (speed > 0.05) {
            return new double[] {mateX + mateVx * leadTicks, mateZ + mateVz * leadTicks};
        }
        double len = Math.hypot(goalDirX, goalDirZ);
        double gx = len < 1.0E-6 ? 0 : goalDirX / len;
        double gz = len < 1.0E-6 ? 1 : goalDirZ / len;
        return new double[] {mateX + gx * standingLead, mateZ + gz * standingLead};
    }
}
