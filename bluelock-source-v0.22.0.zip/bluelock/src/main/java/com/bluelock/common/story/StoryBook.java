package com.bluelock.common.story;

import java.util.List;

/**
 * The story (no Minecraft code): a chapter is a list of beats. A scene is a few lines of dialogue, a match is a game
 * against a First Selection team with an objective, the end marks the chapter as complete. The player's progress is
 * just the index of the current beat. Text lives in the language files under bluelock.story.*.
 */
public final class StoryBook {
    public enum Kind { SCENE, MATCH, TRIAL, END }

    /** What the player must do in a match beat to move on. */
    public enum Objective { SCORE, NOT_LOSE, WIN }

    /** One line of dialogue. speaker: "narrator", "ego", "player" or a roster character id. */
    public record Line(String speaker, String key) {
    }

    public record Beat(Kind kind, String id, List<Line> lines, String opponent, int length, Objective objective,
                       int xp, int skillPoints, int devPoints, String place) {
        public String titleKey() {
            return "bluelock.story." + id + ".title";
        }

        public String briefKey() {
            return "bluelock.story." + id + ".brief";
        }
    }

    private static final List<Beat> CHAPTER = StoryChapter1.build();

    private StoryBook() {
    }

    static Beat scene(String id, String place, List<Line> lines) {
        return new Beat(Kind.SCENE, id, lines, "", 0, Objective.SCORE, 0, 0, 0, place);
    }

    static Beat match(String id, String place, String opponent, int minutes, Objective objective, int xp, int sp, int dp) {
        return new Beat(Kind.MATCH, id, List.of(), opponent, minutes, objective, xp, sp, dp, place);
    }

    /** The touch trial: length is in seconds. */
    static Beat trial(String id, String place, int seconds, int xp, int sp, int dp) {
        return new Beat(Kind.TRIAL, id, List.of(), "", seconds, Objective.WIN, xp, sp, dp, place);
    }

    static Beat end(String id) {
        return new Beat(Kind.END, id, List.of(), "", 0, Objective.SCORE, 0, 0, 0, "rank_wall");
    }

    public static int size() {
        return CHAPTER.size();
    }

    public static List<Beat> all() {
        return CHAPTER;
    }

    /** The beat at an index; indexes past the end stay on the last beat (the end of the chapter). */
    public static Beat beat(int index) {
        return CHAPTER.get(Math.max(0, Math.min(CHAPTER.size() - 1, index)));
    }

    public static boolean isFinished(int index) {
        return beat(index).kind() == Kind.END;
    }

    /** Finds a scene by id, or null. */
    public static Beat scene(String id) {
        for (Beat b : CHAPTER) {
            if (b.kind() == Kind.SCENE && b.id().equals(id)) {
                return b;
            }
        }
        return null;
    }

    /** Did the player meet the objective? mine and theirs are the final scores of the player's side and the opponent. */
    public static boolean passed(Objective objective, int mine, int theirs) {
        return switch (objective) {
            case SCORE -> mine >= 1;
            case NOT_LOSE -> mine >= theirs;
            case WIN -> mine > theirs;
        };
    }
}
