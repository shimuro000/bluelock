package com.bluelock.common.stats;

/**
 * What stats do on the pitch, for players and bots alike (no Minecraft code). Every multiplier is 1.0 at the
 * baseline of 50, so an average footballer plays like the plain game.
 */
public final class StatEffects {
    private StatEffects() {
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Running speed: Top Speed matters most, Acceleration a little. 0.85 to 1.17 over the whole range. */
    public static double moveSpeed(int topSpeed, int acceleration) {
        double m = 0.85 + 0.30 * clamp(topSpeed, 0, 100) / 100.0 + (clamp(acceleration, 0, 100) - 50) * 0.0006;
        return clamp(m, 0.80, 1.20);
    }

    /** How long a bot can sprint compared with its character: 0.6 at stamina 0, 1.0 at 50, 1.4 at 100. */
    public static double sprintLength(int stamina) {
        return 0.6 + 0.8 * clamp(stamina, 0, 100) / 100.0;
    }

    /** Jump height: 0.90 at jump 0, 1.025 at 50, 1.15 at 100. */
    public static double jumpHeight(int jump) {
        return 0.90 + 0.25 * clamp(jump, 0, 100) / 100.0;
    }

    /** How far a bot looks for a pass (blocks): 16 at vision 0, 22 at 50, 28 at 100. */
    public static double passReach(int vision) {
        return 16.0 + 12.0 * clamp(vision, 0, 100) / 100.0;
    }

    /** Power of a heavy impact such as a shoulder charge, from Strength: 0.8 to 1.2. */
    public static double strengthPush(int strength) {
        return 0.8 + 0.4 * clamp(strength, 0, 100) / 100.0;
    }
}
