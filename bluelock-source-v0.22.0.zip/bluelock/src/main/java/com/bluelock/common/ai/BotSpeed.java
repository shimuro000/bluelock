package com.bluelock.common.ai;

/**
 * Running speed of a bot as Minecraft movement-speed attribute values (no Minecraft code). A walking player has
 * 0.10 and a sprinting player about 0.13. A bot jogs faster than a sprinting player and sprints much faster.
 */
public final class BotSpeed {
    /** No bot ever runs faster than this (about 11 blocks per second). */
    public static final double SPRINT_CAP = 0.26;
    private static final double JOG_CAP = 0.21;

    private BotSpeed() {
    }

    /** The attribute value for a jog: grows with rating, difficulty and the character's own speed. */
    public static double jog(int rating, double difficultySpeedFactor, CharacterTraits traits) {
        return jog(rating, difficultySpeedFactor, traits, 1.0);
    }

    /** statMultiplier comes from StatEffects.moveSpeed (the bot's Top Speed and Acceleration). */
    public static double jog(int rating, double difficultySpeedFactor, CharacterTraits traits, double statMultiplier) {
        return Math.min(JOG_CAP, BotDifficulty.movementAttribute(rating, difficultySpeedFactor) * traits.speed() * statMultiplier);
    }

    /** How much faster than the jog a sprint is, limited so the sprint never goes above the cap. */
    public static double sprintMultiplier(double jogAttribute, CharacterTraits traits) {
        return Math.min(traits.sprintBoost(), SPRINT_CAP / Math.max(0.01, jogAttribute));
    }
}
