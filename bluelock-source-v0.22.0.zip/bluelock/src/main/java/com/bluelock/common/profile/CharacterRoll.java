package com.bluelock.common.profile;

import java.util.function.DoubleSupplier;

/** The two rolls made when a character is created: dominant foot (60% right, 30% left, 10% both) and talent (10 to 100%, average 50, see {@link TalentRoll}). */
public final class CharacterRoll {
    public static final double RIGHT_CHANCE = 0.60;
    public static final double LEFT_CHANCE = 0.30;   // the remaining 10% play with both feet
    public static final double GENIUS_CHANCE = 0.25;

    public record Result(DominantFoot foot, Talent talent, int talentPercent) {
    }

    private CharacterRoll() {
    }

    /** rng returns numbers in [0, 1). */
    public static Result roll(DoubleSupplier rng) {
        double f = rng.getAsDouble();
        DominantFoot foot = f < RIGHT_CHANCE ? DominantFoot.RIGHT : f < RIGHT_CHANCE + LEFT_CHANCE ? DominantFoot.LEFT : DominantFoot.BOTH;
        int percent = TalentRoll.roll(rng);
        return new Result(foot, TalentRoll.talentOf(percent), percent);
    }
}
