package com.bluelock.common.ai;

import java.util.Locale;
import java.util.Optional;

/** How strong and how fast the bots are. The rating offset is added to the team rating; speedFactor scales running speed. */
public enum BotDifficulty {
    EASY(-10, 0.90), NORMAL(8, 1.05), HARD(18, 1.15), PRO(28, 1.25);

    private final int ratingOffset;
    private final double speedFactor;

    BotDifficulty(int ratingOffset, double speedFactor) {
        this.ratingOffset = ratingOffset;
        this.speedFactor = speedFactor;
    }

    public int ratingOffset() { return ratingOffset; }
    public double speedFactor() { return speedFactor; }

    public String label() { return name().toLowerCase(Locale.ROOT); }

    public static Optional<BotDifficulty> parse(String text) {
        if (text == null) return Optional.empty();
        for (BotDifficulty d : values()) {
            if (d.label().equals(text.trim().toLowerCase(Locale.ROOT))) return Optional.of(d);
        }
        return Optional.empty();
    }

    /** Minecraft movement-speed attribute for a bot's jog. A player walks at 0.10 and sprints at about 0.13. */
    public static double movementAttribute(int rating, double speedFactor) {
        double r = Math.max(20, Math.min(100, rating));
        return (0.115 + r * 0.0006) * speedFactor * 1.06;
    }
}
