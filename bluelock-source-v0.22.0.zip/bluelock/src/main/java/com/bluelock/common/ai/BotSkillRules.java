package com.bluelock.common.ai;

import java.util.List;

/**
 * How a bot's skills change what it does (no Minecraft code). Skill ids are the ones in
 * data/bluelock/definitions/skills. Skills the bot does not own change nothing.
 */
public final class BotSkillRules {
    public static final int DRIBBLE_SKILL_COOLDOWN = 140;

    /** Shot changes: spreadMul below 1 is more accurate, powerMul above 1 is harder. anim may be null. */
    public record ShotBoost(double spreadMul, double powerMul, String anim, double curve) {
        public ShotBoost(double spreadMul, double powerMul, String anim) {
            this(spreadMul, powerMul, anim, 0.0);
        }
    }

    private BotSkillRules() {
    }

    public static ShotBoost shot(List<String> skills) {
        double spread = 1.0;
        double power = 1.0;
        String anim = null;
        double curve = 0.0;
        if (skills.contains("dragon_drive")) {
            spread = 0.6; power = 1.5; anim = "awakening_shot";
        } else if (skills.contains("awakening_direct_shot")) {
            spread = 0.5; power = 1.45; anim = "awakening_shot";
        } else if (skills.contains("precision_direct_shot")) {
            spread = 0.3; power = 1.1; anim = "direct_shot";
        } else if (skills.contains("direct_shot")) {
            spread = 0.75; power = 1.2; anim = "direct_shot";
        }
        if (skills.contains("curved_shot")) {
            curve = 0.035;
            spread *= 0.8;
            if (anim == null) anim = "direct_shot";
        }
        if (skills.contains("finishing")) spread *= 0.85;
        return new ShotBoost(spread, power, anim, curve);
    }

    /** The dribble skill to use now, or null. Under pressure: feints. With open space: bursts. */
    public static String dribbleSkill(List<String> skills, boolean pressured, boolean openSpace) {
        if (pressured) {
            if (skills.contains("monster_dribble")) return "monster_dribble";
            if (skills.contains("chameleon")) return "chameleon";
            if (skills.contains("chain_dribble")) return "chain_dribble";
            if (skills.contains("feint")) return "feint";
        }
        if (openSpace) {
            if (skills.contains("burst_dribble")) return "burst_dribble";
            if (skills.contains("sprint_burst")) return "sprint_burst";
        }
        return null;
    }

    /** How far ahead of a running team-mate a pass is aimed: 1.0 normal, longer with Through Pass. */
    public static double passLead(List<String> skills) {
        if (skills.contains("perfect_pass")) return 1.8;
        return skills.contains("through_pass") ? 1.6 : 1.0;
    }

    /** A bot with Perfect Pass never misplaces a pass. */
    public static double passSpread(List<String> skills) {
        return skills.contains("perfect_pass") ? 0.0 : 1.0;
    }

    /** Extra first touch for a bot that has Trap: it controls any ball. */
    public static int touchBonus(List<String> skills) {
        return skills.contains("trap") ? 100 : 0;
    }

    public static boolean hasShoulderCharge(List<String> skills) {
        return skills.contains("shoulder_charge");
    }
}
