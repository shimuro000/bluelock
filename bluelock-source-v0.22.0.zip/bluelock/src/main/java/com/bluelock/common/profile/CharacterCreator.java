package com.bluelock.common.profile;

import com.bluelock.common.content.BuildDefinition;
import com.bluelock.common.content.DefinitionPack;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import com.bluelock.common.util.Result;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Builds a brand-new player from the creation choices. Every stat starts at BASELINE, then the archetype and
 * personality shifts are applied. Because all shifts add up to zero, every build has the same total power.
 * Runs on the server; the client only sends the choices.
 */
public final class CharacterCreator {
    public static final int BASELINE = 35;

    private CharacterCreator() {
    }

    public static Result<PlayerProfile> create(DefinitionPack pack, UUID id, String name, String nickname,
                                               DominantFoot foot, Archetype archetype, Personality personality) {
        return create(pack, id, name, nickname, foot, archetype, personality, Talent.NORMAL, archetype.defaultPosition(), 1, 0x3B2A1E);
    }

    /** Full creation: the foot and talent come from {@link CharacterRoll}, the rest from the player's choices. */
    public static Result<PlayerProfile> create(DefinitionPack pack, UUID id, String name, String nickname,
                                               DominantFoot foot, Archetype archetype, Personality personality,
                                               Talent talent, com.bluelock.common.content.Position position,
                                               int hairStyle, int hairColor) {
        return create(pack, id, name, nickname, foot, archetype, personality, talent, position,
                com.bluelock.common.appearance.HairDesign.preset(hairStyle, hairColor));
    }

    /** Full creation with a hair designed in the hair maker. */
    public static Result<PlayerProfile> create(DefinitionPack pack, UUID id, String name, String nickname,
                                               DominantFoot foot, Archetype archetype, Personality personality,
                                               Talent talent, com.bluelock.common.content.Position position,
                                               com.bluelock.common.appearance.HairDesign hair) {
        String nameError = PlayerProfile.validateName(name);
        if (nameError != null) return Result.fail(nameError);
        String nick = nickname == null ? "" : nickname.trim();
        if (!nick.isEmpty() && PlayerProfile.validateName(nick) != null) return Result.fail("bluelock.error.nickname_invalid");

        var a = pack.archetypes().get(archetype.name().toLowerCase(Locale.ROOT));
        var p = pack.personalities().get(personality.name().toLowerCase(Locale.ROOT));
        if (a.isEmpty() || p.isEmpty()) return Result.fail("bluelock.error.content_missing");

        StatBlock stats = StatBlock.uniform(BASELINE);
        apply(stats, a.get());
        apply(stats, p.get());
        for (Stat s : Stat.values()) {
            stats.setBase(s, stats.base(s) + talent.startingBonus());
        }
        PlayerProfile profile = new PlayerProfile(id, name.trim(), nick, foot, archetype, personality, stats);
        profile.setCreationExtras(talent, position, hair);
        return Result.ok(profile);
    }

    private static void apply(StatBlock stats, BuildDefinition build) {
        for (Map.Entry<Stat, Integer> e : build.statDeltas().entrySet()) {
            stats.setBase(e.getKey(), stats.base(e.getKey()) + e.getValue());
        }
    }
}
