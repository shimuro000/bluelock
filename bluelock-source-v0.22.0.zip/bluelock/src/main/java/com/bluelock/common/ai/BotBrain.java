package com.bluelock.common.ai;

import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;

/**
 * Decision making of a football bot. Pure and deterministic: the same view always gives the same decision,
 * so it can be tested without Minecraft. The Forge entity turns the decision into movement and kicks.
 */
public final class BotBrain {
    public static final double TACKLE_RANGE = 1.8;
    private static final double PRESSURE_DISTANCE = 3.0;

    private BotBrain() {
    }

    public static BotDecision decide(BotView v) {
        BotDecision d;
        if (v.position() == Position.GK) d = keeper(v);
        else if (v.selfHasBall()) d = withBall(v);
        else if (v.possession() == v.side()) d = support(v);
        else if (v.possession() != null) d = defend(v);
        else d = looseBall(v);
        return d.withSprint(wantsSprint(v, d));
    }

    /** Sprint when it matters: chasing, pressing, breaking forward with the ball, or making a run to be open. */
    private static boolean wantsSprint(BotView v, BotDecision d) {
        double dist = v.self().dist(d.target());
        switch (d.intent()) {
            case CHASE_BALL, PRESS, TACKLE:
                return dist > 3.0;
            case DRIBBLE:
                // with room in front, run; with an opponent close, keep control
                return nearestDistance(v.self(), v.opponents()) > PRESSURE_DISTANCE + 1.0
                        && v.traits().creativity() < 85;
            case MOVE:
                return dist > 12.0 && v.possession() == v.side() && v.traits().workRate() >= 40;
            case HOLD:
                return dist > 16.0;
            default:
                return false;
        }
    }

    // ---------- helpers ----------

    private static boolean attacksFar(BotView v) {
        return v.side() == Side.HOME;
    }

    private static double dir(BotView v) {
        return attacksFar(v) ? 1.0 : -1.0;
    }

    private static Pos goal(BotView v) {
        PitchLayout l = v.layout();
        return new Pos(attacksFar(v) ? l.length() : 0, l.centreV() + 0.5);
    }

    private static boolean isForward(Position p) {
        return switch (p) {
            case ST, CF, LW, RW, CAM, LM, RM -> true;
            default -> false;
        };
    }

    private static Pos clamp(PitchLayout l, double u, double v) {
        return new Pos(Math.max(2, Math.min(l.length() - 2, u)), Math.max(2, Math.min(l.width() - 2, v)));
    }

    private static double nearestDistance(Pos p, java.util.List<Pos> others) {
        double best = Double.MAX_VALUE;
        for (Pos o : others) best = Math.min(best, p.dist(o));
        return best;
    }

    /** Where this bot stands when it has nothing special to do: its formation spot, moved with the ball. */
    private static Pos shape(BotView v) {
        PitchLayout l = v.layout();
        double cu = l.centreU() + 0.5;
        double cv = l.centreV() + 0.5;
        double k = 0.30 + 0.30 * v.tactics().defensiveLine() / 100.0;
        return clamp(l, v.baseSpot().u() + (v.ball().u() - cu) * k, v.baseSpot().v() + (v.ball().v() - cv) * 0.25);
    }

    // ---------- roles ----------

    private static BotDecision keeper(BotView v) {
        PitchLayout l = v.layout();
        double fromOwnGoal = attacksFar(v) ? v.ball().u() : l.length() - v.ball().u();

        if (v.selfHasBall()) {
            int pass = bestPass(v, true);
            if (pass >= 0) return new BotDecision(Intent.PASS, v.mates().get(pass), 1.0, pass);
            return BotDecision.of(Intent.CLEAR, new Pos(l.centreU() + 0.5, v.self().v()), 1.0);
        }
        // a shot is on its way: dive (or just stand and reach)
        KeeperLogic.ShotThreat threat = KeeperLogic.analyse(l, v.side(), v.ball(), v.ballHeight(), v.ballMotion());
        if (threat.onTarget() && threat.ticks() <= 14) {
            int dir = KeeperLogic.diveDirection(threat, v.self().v());
            double goalU = attacksFar(v) ? 1.0 : l.length() - 1.0;
            return new BotDecision(Intent.DIVE, new Pos(goalU, threat.crossV()), 1.0, dir);
        }
        // a loose ball in or near the box: come out and claim it
        if (v.possession() == null && fromOwnGoal < 14 && v.self().dist(v.ball()) < 7.5 && v.ballMotion().speed() < 0.25) {
            return BotDecision.of(Intent.CHASE_BALL, v.ball(), 1.0);
        }
        // an opponent running at goal: narrow the angle by stepping out
        if (v.carrier() != null && v.possession() != v.side() && fromOwnGoal < 16) {
            Pos stance = KeeperLogic.stance(l, v.side(), v.carrier());
            double stepOut = attacksFar(v) ? 1.5 : -1.5;
            return BotDecision.of(Intent.MOVE, new Pos(stance.u() + stepOut, stance.v()), 1.0);
        }
        return BotDecision.of(Intent.MOVE, KeeperLogic.stance(l, v.side(), v.ball()), 0.95);
    }

    private static BotDecision withBall(BotView v) {
        PitchLayout l = v.layout();
        Pos goal = goal(v);
        double dGoal = v.self().dist(goal);
        double nearest = nearestDistance(v.self(), v.opponents());
        boolean pressured = nearest < PRESSURE_DISTANCE;
        double depth = attacksFar(v) ? v.self().u() : l.length() - v.self().u();
        double shootRange = (14 + 10 * v.rating() / 100.0) * v.traits().shotRangeMultiplier();

        if (dGoal <= shootRange) {
            // aim at the far corner from the goalkeeper (the opponent closest to the goal)
            double keeperV = l.centreV() + 0.5;
            double bestKeeperDist = Double.MAX_VALUE;
            for (Pos o : v.opponents()) {
                double d = o.dist(goal);
                if (d < bestKeeperDist) {
                    bestKeeperDist = d;
                    keeperV = o.v();
                }
            }
            double aimV = l.centreV() + 0.5 + (keeperV >= l.centreV() + 0.5 ? -2.4 : 2.4);
            return BotDecision.of(Intent.SHOOT, new Pos(goal.u(), aimV), 1.0);
        }
        if (depth < 10 && pressured) {
            return BotDecision.of(Intent.CLEAR, new Pos(l.centreU() + 0.5, v.self().v()), 1.0);
        }
        int pass = bestPass(v, false);
        if (pass >= 0 && (pressured || !isForward(v.position()))
                && !(pressured && v.traits().creativity() >= 85 && nearest > 1.6)
                && !(v.traits().ego() >= 90 && dGoal < shootRange * 1.5 && !pressured)) {
            return new BotDecision(Intent.PASS, v.mates().get(pass), 1.0, pass);
        }
        // dribble toward goal, sidestepping the closest opponent that is in front
        double stepV = v.self().v();
        for (Pos o : v.opponents()) {
            boolean inFront = (o.u() - v.self().u()) * dir(v) > 0 && o.dist(v.self()) < 6.0;
            if (inFront) {
                stepV += o.v() >= v.self().v() ? -4.0 : 4.0;
                break;
            }
        }
        return BotDecision.of(Intent.DRIBBLE, clamp(l, v.self().u() + dir(v) * 7.0, stepV), 1.0);
    }

    private static BotDecision support(BotView v) {
        PitchLayout l = v.layout();
        double ahead = dir(v);
        Position pos = v.position();
        boolean forward = pos == Position.ST || pos == Position.CF || pos == Position.LW || pos == Position.RW;
        boolean mid = pos == Position.CAM || pos == Position.CM || pos == Position.CDM || pos == Position.LM || pos == Position.RM;
        if (forward) {
            Pos base = v.baseSpot();
            return BotDecision.of(Intent.MOVE, clamp(l, v.ball().u() + ahead * (9.0 + v.traits().runAheadBonus()), base.v()), 0.95);
        }
        if (mid) {
            Pos base = v.baseSpot();
            return BotDecision.of(Intent.MOVE, clamp(l, v.ball().u() + ahead * 2.5, base.v()), 0.95);
        }
        return BotDecision.of(Intent.MOVE, shape(v), 0.9);
    }

    private static BotDecision defend(BotView v) {
        if (v.carrier() != null && (v.chaseRank() == 0
                || (v.chaseRank() == 1 && (v.tactics().pressing() >= 60 || v.traits().aggression() >= 80)))) {
            double d = v.self().dist(v.carrier());
            if (v.chaseRank() == 0 && d <= TACKLE_RANGE + v.traits().tackleReachBonus()) {
                return BotDecision.of(Intent.TACKLE, v.carrier(), 1.0);
            }
            return BotDecision.of(Intent.PRESS, v.carrier(), v.chaseRank() == 0 ? 1.0 : 0.9);
        }
        return BotDecision.of(Intent.HOLD, shape(v), 0.85);
    }

    private static BotDecision looseBall(BotView v) {
        if (v.chaseRank() == 0) return BotDecision.of(Intent.CHASE_BALL, v.ball(), 1.0);
        return BotDecision.of(Intent.MOVE, shape(v), 0.9);
    }

    // ---------- passing ----------

    /** Index of the best open teammate ahead of the ball carrier, or -1. */
    private static int bestPass(BotView v, boolean allowBackwards) {
        int best = -1;
        double bestScore = -Double.MAX_VALUE;
        for (int i = 0; i < v.mates().size(); i++) {
            Pos m = v.mates().get(i);
            double dist = v.self().dist(m);
            double progress = (m.u() - v.self().u()) * dir(v);
            if (dist < 4 || dist > com.bluelock.common.stats.StatEffects.passReach(v.vision())) continue;
            if (!allowBackwards && progress < 2) continue;
            if (nearestDistance(m, v.opponents()) < 2.5) continue;
            if (laneBlocked(v.self(), m, v.opponents())) continue;
            double score = progress - dist * 0.1;
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        return best;
    }

    private static boolean laneBlocked(Pos from, Pos to, java.util.List<Pos> opponents) {
        double dx = to.u() - from.u(), dv = to.v() - from.v();
        double len2 = dx * dx + dv * dv;
        for (Pos o : opponents) {
            double t = len2 == 0 ? 0 : ((o.u() - from.u()) * dx + (o.v() - from.v()) * dv) / len2;
            if (t <= 0 || t >= 1) continue;
            double px = from.u() + t * dx, pv = from.v() + t * dv;
            if (Math.hypot(o.u() - px, o.v() - pv) < 2.2) return true;
        }
        return false;
    }
}
