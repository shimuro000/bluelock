package com.bluelock.common.profile;

import com.bluelock.common.content.Position;

/** Football background (spec section 5, stage C). Modifies starting tendencies, never locks the build. */
public enum Archetype {
    STRIKER(Position.ST), SPEEDSTER(Position.RW), DRIBBLER(Position.LW), PLAYMAKER(Position.CAM),
    FINISHER(Position.CF), DEFENDER(Position.CB), ALL_ROUNDER(Position.CM);

    private final Position defaultPosition;

    Archetype(Position defaultPosition) {
        this.defaultPosition = defaultPosition;
    }

    public Position defaultPosition() {
        return defaultPosition;
    }
}
