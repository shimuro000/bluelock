package com.bluelock.common.rank;

import com.bluelock.common.ai.FootballCharacter;
import com.bluelock.common.ai.Roster;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The ranking of the 300 (no Minecraft code). 299 others have fixed points; the player starts at 300th with 0 points and
 * climbs by earning points (matches, goals, wins, the trial). Rank 1 has 2990 points, rank 299 has 10, in steps of 10.
 * Named characters stand at fixed places (Team Z at the bottom, the stars at the top); everybody else gets a generated name.
 * The places of the named characters are my own approximation, not the series' official list.
 */
public final class Ranking {
    public static final int SIZE = 300;
    public static final int STEP = 10;

    public record Row(int rank, String name, String characterId, int points, boolean player) {
    }

    private static final String[] SURNAMES = {"Aoki", "Baba", "Chiba", "Doi", "Endo", "Fujii", "Goto", "Hara", "Ishii", "Jono", "Kato", "Maeda",
            "Nakano", "Ogawa", "Saito", "Tanabe", "Ueda", "Wada", "Yamada", "Abe", "Eto", "Fukuda", "Hirano", "Inoue", "Kubo", "Matsuda",
            "Noguchi", "Okada", "Sakai", "Takagi", "Ushio", "Yano", "Arai", "Hayashi", "Ito", "Kimura", "Mori", "Nishi", "Ono", "Shimizu"};
    private static final String[] GIVEN = {"Akira", "Daiki", "Eiji", "Fumio", "Gaku", "Haruki", "Itsuki", "Jun", "Kaito", "Kenta", "Makoto",
            "Naoki", "Osamu", "Ryota", "Shota", "Takumi", "Ukyo", "Yuto", "Asahi", "Bunta", "Haru", "Issei", "Kosei", "Masato", "Noboru",
            "Reiji", "Sora", "Tatsuya", "Yamato", "Zen", "Hinata", "Jin", "Kazuki", "Minato", "Riku", "Soma", "Toma", "Yusei", "Ren", "Shun"};

    /** Fixed places of named characters (rank 300 is the player). Team Z is the last block of eleven. */
    private static final Map<String, Integer> ANCHORS = new HashMap<>();

    static {
        String[] stars = {"rin", "shidou", "kaiser", "sae", "noa", "otoya", "tokimitsu", "aiku", "hiori", "aryu", "nanase"};
        for (int i = 0; i < stars.length; i++) {
            ANCHORS.put(stars[i], i + 1);
        }
        ANCHORS.put("nagi", 14);
        ANCHORS.put("reo", 15);
        ANCHORS.put("zantetsu", 60);
        ANCHORS.put("baro", 40);
        String[] teamZ = {"kuon", "igarashi", "naruhaya", "iemon", "imamura", "gagamaru", "raichi", "kunigami", "chigiri", "bachira", "isagi"};
        for (int i = 0; i < teamZ.length; i++) {
            ANCHORS.put(teamZ[i], 289 + i);
        }
    }

    private static final List<Row> OTHERS = buildOthers();

    private Ranking() {
    }

    private static int pointsOfRank(int rank) {
        return (SIZE - rank) * STEP;
    }

    private static List<Row> buildOthers() {
        String[] names = new String[SIZE];
        String[] ids = new String[SIZE];
        Set<String> used = new HashSet<>();
        for (FootballCharacter c : Roster.all()) {
            used.add(c.displayName());
            Integer rank = ANCHORS.get(c.id());
            if (rank != null && names[rank] == null) {
                names[rank] = c.displayName();
                ids[rank] = c.id();
            }
        }
        int k = 0;
        for (int rank = 1; rank < SIZE; rank++) {
            if (names[rank] != null) {
                continue;
            }
            String name;
            do {
                name = SURNAMES[(k * 7 + 3) % SURNAMES.length] + " " + GIVEN[(k * 11 + k / 7) % GIVEN.length];
                k++;
            } while (!used.add(name));
            names[rank] = name;
            ids[rank] = "";
        }
        List<Row> rows = new ArrayList<>();
        for (int rank = 1; rank < SIZE; rank++) {
            rows.add(new Row(rank, names[rank], ids[rank], pointsOfRank(rank), false));
        }
        return rows;
    }

    /** The player's rank (1..300) for these points: one place behind everybody with more points. */
    public static int rankOf(int points) {
        int ahead = 0;
        for (Row r : OTHERS) {
            if (r.points() > points) {
                ahead++;
            }
        }
        return ahead + 1;
    }

    /** All 300 rows in order with the player inserted at their place. */
    public static List<Row> table(String playerName, int points) {
        int rank = rankOf(points);
        List<Row> out = new ArrayList<>(SIZE);
        int next = 1;
        for (Row r : OTHERS) {
            if (next == rank) {
                out.add(new Row(next++, playerName, "", points, true));
            }
            out.add(new Row(next++, r.name(), r.characterId(), r.points(), false));
        }
        if (out.size() < SIZE) {
            out.add(new Row(next, playerName, "", points, true));
        }
        return out;
    }

    /** Points needed to take the place just above the current one (0 when already first). */
    public static int pointsToNextRank(int points) {
        int best = Integer.MAX_VALUE;
        for (Row r : OTHERS) {
            if (r.points() > points) {
                best = Math.min(best, r.points() - points + 1);
            }
        }
        return best == Integer.MAX_VALUE ? 0 : best;
    }

    /** What an action earns. Story matches add their own bonus on top. */
    public static int pointsFor(com.bluelock.common.progression.Progression.XpAction action) {
        return switch (action) {
            case GOAL -> 15;
            case MATCH_PLAYED -> 5;
            case MATCH_WON -> 40;
            default -> 0;
        };
    }

    public static List<Row> others() {
        return OTHERS;
    }
}
