package com.bluelock.common.ai;

import com.bluelock.common.content.Position;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;

/** Stats for a bot from its rating (a team rating plus the difficulty), shaped by its position. */
public final class BotStats {
    private BotStats() {
    }

    public static StatBlock forRating(int rating, Position position) {
        int base = Math.max(20, Math.min(95, rating));
        StatBlock b = StatBlock.uniform(base);
        switch (position) {
            case GK -> boost(b, 12, Stat.REACTION, Stat.JUMP, Stat.POSITIONING, Stat.BALANCE);
            case CB, LB, RB, LWB, RWB, CDM -> boost(b, 10, Stat.TACKLING, Stat.MARKING, Stat.INTERCEPTION, Stat.STRENGTH);
            case CM, CAM, LM, RM -> boost(b, 8, Stat.PASSING, Stat.VISION, Stat.STAMINA, Stat.DRIBBLING);
            case LW, RW, ST, CF -> boost(b, 10, Stat.SHOOTING, Stat.FINISHING, Stat.SHOT_POWER, Stat.ACCELERATION);
        }
        return b;
    }

    /** Stats of a named character: his team rating plus his bonus, shaped by his position and his play style. */
    public static StatBlock forCharacter(int teamRating, FootballCharacter c) {
        StatBlock b = forRating(teamRating + c.ratingBonus(), c.position());
        CharacterTraits t = c.traits();
        if (t.speed() >= 1.05) boost(b, 8, Stat.TOP_SPEED, Stat.ACCELERATION);
        if (t.ego() >= 75) boost(b, 6, Stat.SHOOTING, Stat.SHOT_POWER);
        if (t.creativity() >= 75) boost(b, 6, Stat.DRIBBLING, Stat.VISION);
        if (t.aggression() >= 75) boost(b, 6, Stat.TACKLING, Stat.STRENGTH);
        if (t.workRate() >= 80) boost(b, 6, Stat.STAMINA);
        CanonStats.apply(c.id(), b);
        return b;
    }

    private static void boost(StatBlock b, int amount, Stat... stats) {
        for (Stat s : stats) {
            b.setBase(s, b.base(s) + amount);
        }
    }
}
