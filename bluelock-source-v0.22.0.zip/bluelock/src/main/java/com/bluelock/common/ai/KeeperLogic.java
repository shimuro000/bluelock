package com.bluelock.common.ai;

import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;
import java.util.function.DoubleSupplier;

/** Goalkeeper brain parts: where to stand, whether a shot is coming, whether to dive, and whether the save works. */
public final class KeeperLogic {
    public enum SaveOutcome { CATCH, PARRY, BEATEN }

    /** A shot that will cross the goal line. crossV/crossHeight are where it crosses, ticks is the time left. */
    public record ShotThreat(boolean onTarget, double crossV, double crossHeight, double ticks, double speed) {
        public static final ShotThreat NONE = new ShotThreat(false, 0, 0, 0, 0);
    }

    private static final double GRAVITY = 0.03;
    private static final double MIN_APPROACH_SPEED = 0.18;

    private KeeperLogic() {
    }

    /** Where the keeper of {@code side} stands: on the line between the goal centre and the ball, close in when the ball is far. */
    public static Pos stance(PitchLayout layout, Side side, Pos ball) {
        double cv = layout.centreV() + 0.5;
        Pos goal = new Pos(side == Side.HOME ? 0.5 : layout.length() - 0.5, cv);
        double d = Math.max(1.0, goal.dist(ball));
        double out = Math.max(1.2, Math.min(4.5, 0.12 * d));
        double u = goal.u() + (ball.u() - goal.u()) / d * out;
        double v = goal.v() + (ball.v() - goal.v()) / d * out;
        v = Math.max(cv - 3.4, Math.min(cv + 3.4, v));
        double minU = side == Side.HOME ? 1.0 : layout.length() - 6.0;
        double maxU = side == Side.HOME ? 6.0 : layout.length() - 1.0;
        return new Pos(Math.max(minU, Math.min(maxU, u)), v);
    }

    /** Looks at the ball's motion and works out whether it will cross this keeper's goal line between the posts. */
    public static ShotThreat analyse(PitchLayout layout, Side side, Pos ball, double ballHeight, BallMotion m) {
        boolean toward = side == Side.HOME ? m.u() < -MIN_APPROACH_SPEED * 0.3 : m.u() > MIN_APPROACH_SPEED * 0.3;
        if (!toward || m.speed() < MIN_APPROACH_SPEED) return ShotThreat.NONE;
        double planeU = side == Side.HOME ? 0.0 : layout.length();
        double t = (planeU - ball.u()) / m.u();
        if (t <= 0 || t > 40) return ShotThreat.NONE;
        double crossV = ball.v() + m.v() * t;
        // the ball cannot go below the grass: a shot rolling along the ground still arrives at height 0
        double crossH = Math.max(0.0, ballHeight + m.h() * t - 0.5 * GRAVITY * t * t);
        double cv = layout.centreV() + 0.5;
        boolean inFrame = Math.abs(crossV - cv) <= 3.6 && crossH >= -0.2 && crossH <= 3.0;
        return new ShotThreat(inFrame, crossV, crossH, t, m.speed());
    }

    /** How far sideways a keeper can reach by diving, in blocks. */
    public static double diveReach(int reaction, int jump) {
        return 2.0 + 0.016 * jump + 0.008 * reaction;
    }

    /** Dive direction: -1 toward lower v, +1 toward higher v, 0 when the ball comes straight at the keeper (just stand). */
    public static int diveDirection(ShotThreat threat, double keeperV) {
        double lateral = threat.crossV() - keeperV;
        if (Math.abs(lateral) <= 0.9) return 0;
        return lateral < 0 ? -1 : 1;
    }

    /** Probability that a save works (catch or parry), 0.03..0.92. lateral is how far the ball passes from the keeper. */
    public static double saveChance(int reaction, int positioning, int jump, double ballSpeed, double lateral) {
        double reach = diveReach(reaction, jump);
        if (Math.abs(lateral) > reach) return 0.0;
        double chance = 0.45 + 0.004 * reaction + 0.002 * positioning - ballSpeed * 0.30 - (Math.abs(lateral) / reach) * 0.30;
        return Math.max(0.03, Math.min(0.92, chance));
    }

    /** Low rolls catch the ball, middle rolls push it away, high rolls beat the keeper. */
    public static SaveOutcome resolveSave(double chance, DoubleSupplier rng) {
        if (chance <= 0) return SaveOutcome.BEATEN;
        double r = rng.getAsDouble();
        if (r < chance * 0.55) return SaveOutcome.CATCH;
        if (r < chance) return SaveOutcome.PARRY;
        return SaveOutcome.BEATEN;
    }
}
