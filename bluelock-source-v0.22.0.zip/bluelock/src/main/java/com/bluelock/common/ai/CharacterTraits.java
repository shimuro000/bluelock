package com.bluelock.common.ai;

import com.bluelock.common.content.Position;

/**
 * How one footballer plays, as numbers (no Minecraft code). The bot brain and the sprint system read these, so two
 * bots in the same situation can act differently. {@link #NEUTRAL} is the plain, average player; every modifier is
 * built so that the neutral values change nothing.
 *
 * <ul>
 *   <li>{@code speed}: multiplies running speed (1.0 average, 1.2 very fast).</li>
 *   <li>{@code sprintBoost}: how much faster a sprint is than a jog (1.3 to 1.5).</li>
 *   <li>{@code sprintSeconds}: how long he can sprint before he is tired.</li>
 *   <li>{@code ego} 0..100: high means he shoots from further away and passes less.</li>
 *   <li>{@code creativity} 0..100: high means he keeps dribbling under pressure and looks for risky passes.</li>
 *   <li>{@code aggression} 0..100: high means he presses and tackles more.</li>
 *   <li>{@code workRate} 0..100: high means longer runs off the ball; low means he stays put.</li>
 * </ul>
 */
public record CharacterTraits(double speed, double sprintBoost, double sprintSeconds,
                              int ego, int creativity, int aggression, int workRate) {

    public static final CharacterTraits NEUTRAL = new CharacterTraits(1.0, 1.35, 10.0, 50, 50, 50, 50);

    public CharacterTraits {
        speed = Math.max(0.8, Math.min(1.3, speed));
        sprintBoost = Math.max(1.15, Math.min(1.55, sprintBoost));
        sprintSeconds = Math.max(4.0, Math.min(20.0, sprintSeconds));
        ego = clamp(ego);
        creativity = clamp(creativity);
        aggression = clamp(aggression);
        workRate = clamp(workRate);
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(100, v));
    }

    /** Small, position-based differences for bots that are not a named character. */
    public static CharacterTraits forPosition(Position p) {
        return switch (p) {
            case GK -> new CharacterTraits(0.95, 1.25, 8.0, 20, 20, 40, 50);
            case CB, LB, RB, LWB, RWB, CDM -> new CharacterTraits(0.99, 1.33, 11.0, 30, 30, 65, 70);
            case CM, CAM, LM, RM -> new CharacterTraits(1.0, 1.35, 12.0, 50, 55, 50, 70);
            case LW, RW -> new CharacterTraits(1.04, 1.40, 9.0, 60, 60, 40, 60);
            case ST, CF -> new CharacterTraits(1.02, 1.38, 9.0, 70, 50, 50, 55);
        };
    }

    /** Shooting range multiplier from ego: 1.0 for ego 50, 1.3 for 100, about 0.82 for 20. */
    public double shotRangeMultiplier() {
        return 1.0 + (ego - 50) * 0.006;
    }

    /** How many blocks further than the standard 9 a forward runs ahead of the ball: 0 for work rate 50. */
    public double runAheadBonus() {
        return (workRate - 50) * 0.08;
    }

    /** Extra reach for a tackle (blocks): 0 for aggression 50. */
    public double tackleReachBonus() {
        return (aggression - 50) * 0.006;
    }
}
