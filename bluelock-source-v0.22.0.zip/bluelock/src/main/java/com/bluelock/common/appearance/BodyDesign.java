package com.bluelock.common.appearance;

import java.util.HashMap;
import java.util.Map;

/**
 * The body and face of a character, as numbers (no Minecraft code): skin tone, height, build, eye colour and
 * style, eyebrows, mouth and a face mark. Every value is clamped, so a bad packet or save cannot break anything.
 */
public record BodyDesign(int skin, int height, int build, int eyeColor, int eyeStyle, int brow, int mouth, int mark) {
    public static final int INT_COUNT = 8;
    public static final int SLIDER_MAX = 100;
    public static final int EYE_STYLES = 6;
    public static final int BROWS = 4;
    public static final int MOUTHS = 4;
    public static final int MARKS = 5;

    public static final int[] SKIN_TONES = {
            0xFFE0C8, 0xF6CDA8, 0xE8B58C, 0xD39B6E, 0xB57A4E, 0x93603A, 0x6E4528, 0x4A2E1A, 0xFAD7D0, 0xDDE6F0};
    public static final int[] EYE_COLORS = {
            0x1B1B1F, 0x4A2E1A, 0x8B5E3C, 0x2F6BFF, 0x1FA89A, 0x34B34A, 0xD9B45A, 0xB3261E, 0x7B3FBF, 0xE86AA6, 0x8A8F98, 0xF28C28};
    public static final String[] MARK_NAMES = {"none", "freckles", "scar", "mole", "blush"};

    public BodyDesign {
        skin &= 0xFFFFFF;
        eyeColor &= 0xFFFFFF;
        height = clamp(height, 0, SLIDER_MAX);
        build = clamp(build, 0, SLIDER_MAX);
        eyeStyle = clamp(eyeStyle, 0, EYE_STYLES - 1);
        brow = clamp(brow, 0, BROWS - 1);
        mouth = clamp(mouth, 0, MOUTHS - 1);
        mark = clamp(mark, 0, MARKS - 1);
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    public static BodyDesign standard() {
        return new BodyDesign(SKIN_TONES[1], 50, 50, EYE_COLORS[1], 0, 1, 0, 0);
    }

    /** Model height: 0.92 (shortest) to 1.10 (tallest); 50 is 1.01 (about 180 cm). */
    public double heightScale() {
        return 0.92 + 0.18 * height / SLIDER_MAX;
    }

    /** Width of the body: 0.92 (slim) to 1.12 (broad). */
    public double buildScale() {
        return 0.92 + 0.20 * build / SLIDER_MAX;
    }

    /** A body from a real height in centimetres (the build stays average). */
    public static BodyDesign forHeightCm(int cm, int skin, int eyeColor, int eyeStyle, int brow, int mouth, int mark, int build) {
        double scale = Math.max(0.92, Math.min(1.10, cm / 178.0));
        int height = (int) Math.round((scale - 0.92) / 0.18 * SLIDER_MAX);
        return new BodyDesign(skin, height, build, eyeColor, eyeStyle, brow, mouth, mark);
    }

    public BodyDesign withSkin(int rgb) { return new BodyDesign(rgb, height, build, eyeColor, eyeStyle, brow, mouth, mark); }
    public BodyDesign withHeight(int v) { return new BodyDesign(skin, v, build, eyeColor, eyeStyle, brow, mouth, mark); }
    public BodyDesign withBuild(int v) { return new BodyDesign(skin, height, v, eyeColor, eyeStyle, brow, mouth, mark); }
    public BodyDesign withEyeColor(int rgb) { return new BodyDesign(skin, height, build, rgb, eyeStyle, brow, mouth, mark); }
    public BodyDesign withEyeStyle(int v) { return new BodyDesign(skin, height, build, eyeColor, v, brow, mouth, mark); }
    public BodyDesign withBrow(int v) { return new BodyDesign(skin, height, build, eyeColor, eyeStyle, v, mouth, mark); }
    public BodyDesign withMouth(int v) { return new BodyDesign(skin, height, build, eyeColor, eyeStyle, brow, v, mark); }
    public BodyDesign withMark(int v) { return new BodyDesign(skin, height, build, eyeColor, eyeStyle, brow, mouth, v); }

    public static BodyDesign random(java.util.Random r) {
        return new BodyDesign(SKIN_TONES[r.nextInt(SKIN_TONES.length)], 20 + r.nextInt(61), 20 + r.nextInt(61),
                EYE_COLORS[r.nextInt(EYE_COLORS.length)], r.nextInt(EYE_STYLES), r.nextInt(BROWS), r.nextInt(MOUTHS),
                r.nextInt(4) == 0 ? 1 + r.nextInt(MARKS - 1) : 0);
    }

    public int[] toInts() {
        return new int[] {skin, height, build, eyeColor, eyeStyle, brow, mouth, mark};
    }

    public static BodyDesign fromInts(int[] v) {
        if (v == null || v.length < INT_COUNT) return standard();
        return new BodyDesign(v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7]);
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = new HashMap<>();
        int[] v = toInts();
        String[] keys = {"skin", "height", "build", "eyeColor", "eyeStyle", "brow", "mouth", "mark"};
        for (int i = 0; i < keys.length; i++) m.put(keys[i], v[i]);
        return m;
    }

    public static BodyDesign fromMap(Map<?, ?> m) {
        String[] keys = {"skin", "height", "build", "eyeColor", "eyeStyle", "brow", "mouth", "mark"};
        int[] v = standard().toInts();
        for (int i = 0; i < keys.length; i++) {
            if (m.get(keys[i]) instanceof Number n) v[i] = n.intValue();
        }
        return fromInts(v);
    }
}
