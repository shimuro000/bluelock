package com.bluelock.common.action;

/** Ego energy of one player: the fuel of the big skills. It refills slowly on its own. */
public final class EgoPool {
    private double current;
    private double max;

    public EgoPool(int egoAffinityStat) {
        this.max = maxFor(egoAffinityStat);
        this.current = max;
    }

    public static double maxFor(int egoAffinityStat) {
        return 60 + 0.5 * egoAffinityStat;
    }

    public void refreshMax(int egoAffinityStat) {
        double ratio = max <= 0 ? 1 : current / max;
        max = maxFor(egoAffinityStat);
        current = max * ratio;
    }

    public boolean spend(double cost) {
        if (cost <= 0) return true;
        if (current < cost) return false;
        current -= cost;
        return true;
    }

    /** Call once per tick. About 100 ego per minute at affinity 50. */
    public void tick(int egoAffinityStat) {
        current = Math.min(max, current + 0.025 + 0.0005 * egoAffinityStat);
    }

    public double current() { return current; }
    public double max() { return max; }
    public int percent() { return (int) Math.round(100.0 * current / max); }
    public void fill() { current = max; }
}
