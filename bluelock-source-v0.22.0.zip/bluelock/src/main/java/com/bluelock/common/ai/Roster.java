package com.bluelock.common.ai;

import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.content.Position;
import java.util.ArrayList;
import java.util.List;

/**
 * The Blue Lock characters bots can play as, grouped by team (team_v, team_w, team_x, team_y, team_z).
 * Pure data and a small assignment rule, so it can be tested without Minecraft.
 */
public final class Roster {
    private static final List<FootballCharacter> ALL = new ArrayList<>();

    private static final java.util.Map<String, int[]> BODY_TABLE = new java.util.HashMap<>();
    static {
        BODY_TABLE.put("isagi", new int[] {1, 0x1F3FA0, 1, 1, 0, 45});
        BODY_TABLE.put("bachira", new int[] {1, 0xF2C230, 5, 0, 1, 40});
        BODY_TABLE.put("kunigami", new int[] {2, 0xC8641E, 1, 3, 0, 70});
        BODY_TABLE.put("chigiri", new int[] {0, 0xC03070, 0, 0, 0, 35});
        BODY_TABLE.put("raichi", new int[] {2, 0xD9A02A, 4, 2, 3, 65});
        BODY_TABLE.put("gagamaru", new int[] {3, 0x14110E, 2, 3, 1, 90});
        BODY_TABLE.put("kuon", new int[] {1, 0x4A2E1A, 0, 1, 0, 50});
        BODY_TABLE.put("igarashi", new int[] {3, 0x4A2E1A, 1, 3, 0, 85});
        BODY_TABLE.put("naruhaya", new int[] {1, 0x4A2E1A, 0, 1, 0, 50});
        BODY_TABLE.put("iemon", new int[] {1, 0x4A2E1A, 0, 1, 0, 55});
        BODY_TABLE.put("imamura", new int[] {1, 0x4A2E1A, 0, 1, 0, 50});
        BODY_TABLE.put("nagi", new int[] {0, 0x1FA89A, 3, 0, 0, 40});
        BODY_TABLE.put("reo", new int[] {0, 0x7B3FBF, 0, 1, 1, 50});
        BODY_TABLE.put("zantetsu", new int[] {2, 0x1B1B1F, 1, 2, 0, 65});
        BODY_TABLE.put("junichi", new int[] {1, 0x4A2E1A, 1, 2, 0, 55});
        BODY_TABLE.put("keisuke", new int[] {1, 0x4A2E1A, 1, 1, 1, 50});
        BODY_TABLE.put("baro", new int[] {2, 0xB02020, 4, 2, 2, 70});
        BODY_TABLE.put("meiji", new int[] {1, 0x4A2E1A, 0, 1, 0, 50});
        BODY_TABLE.put("sanga", new int[] {1, 0x4A2E1A, 0, 1, 0, 50});
        BODY_TABLE.put("banku", new int[] {2, 0x4A2E1A, 1, 3, 0, 70});
        BODY_TABLE.put("ikki", new int[] {1, 0x8A8F98, 1, 3, 0, 80});
        BODY_TABLE.put("okawa", new int[] {1, 0x4A2E1A, 0, 1, 0, 50});
        BODY_TABLE.put("rin", new int[] {0, 0x1FA89A, 1, 2, 0, 55});
        BODY_TABLE.put("shidou", new int[] {0, 0xE060A0, 1, 2, 2, 60});
        BODY_TABLE.put("kaiser", new int[] {0, 0x2F6BFF, 1, 1, 2, 60});
        BODY_TABLE.put("sae", new int[] {0, 0x2FA070, 1, 2, 0, 55});
        BODY_TABLE.put("noa", new int[] {0, 0xD9B45A, 1, 3, 0, 75});
        BODY_TABLE.put("otoya", new int[] {1, 0x1B1B1F, 2, 0, 1, 45});
        BODY_TABLE.put("tokimitsu", new int[] {1, 0x34B34A, 4, 1, 0, 85});
        BODY_TABLE.put("aiku", new int[] {1, 0x34B34A, 3, 1, 0, 60});
        BODY_TABLE.put("hiori", new int[] {1, 0x9FE0E8, 1, 1, 0, 50});
        BODY_TABLE.put("aryu", new int[] {1, 0x14110E, 1, 1, 0, 75});
        BODY_TABLE.put("nanase", new int[] {1, 0x4A2E1A, 2, 0, 1, 60});
    }

    private static BodyDesign bodyFor(String id, int cm) {
        int[] b = BODY_TABLE.getOrDefault(id, new int[] {1, 0x4A2E1A, 0, 1, 0, 50});
        return BodyDesign.forHeightCm(cm, BodyDesign.SKIN_TONES[b[0]], b[1], b[2], b[3], b[4], 0, b[5]);
    }

    private static CharacterTraits t(double speed, double boost, double secs, int ego, int cre, int agg, int work) {
        return new CharacterTraits(speed, boost, secs, ego, cre, agg, work);
    }

    /** A hair design from a preset: style, colour, tip colour and amount, seed, optional sliders (top, front, sides, back, spikes, fluff, tail). */
    private static HairDesign hair(int style, int color, int tip, int tipAmount, int seed, int[] s) {
        HairDesign d = HairDesign.preset(style, color);
        if (s != null) d = d.withSliders(s[0], s[1], s[2], s[3], s[4], s[5], s[6]);
        return d.withColors(color, tip, tipAmount).withSeed(seed);
    }

    private static void add(String id, String name, String shirt, String team, Position pos, int bonus, CharacterTraits tr,
                            int jersey, int cm, List<String> skills, HairDesign hair) {
        ALL.add(new FootballCharacter(id, name, shirt, team, pos, bonus, tr, hair, bodyFor(id, cm), jersey, cm, skills));
    }

    static {
        add("isagi", "Yoichi Isagi", "ISAGI", "team_z", Position.CF, 6, t(1.00, 1.38, 12, 55, 70, 50, 85), 11, 175, List.of("spatial_read", "advanced_field_vision", "direct_shot", "passing_lane_read", "awareness"), hair(6, 0x16224F, 0x16224F, 0, 11, null));
        add("bachira", "Meguru Bachira", "BACHIRA", "team_z", Position.LW, 8, t(1.06, 1.40, 10, 55, 100, 35, 55), 8, 175, List.of("feint", "chain_dribble", "burst_dribble", "control", "monster_dribble"), hair(3, 0x14110E, 0xD9A82A, 40, 21, new int[] {70, 40, 40, 45, 20, 60, 0}));
        add("kunigami", "Rensuke Kunigami", "KUNIGAMI", "team_z", Position.ST, 6, t(1.03, 1.38, 12, 50, 35, 70, 70), 9, 187, List.of("shoulder_charge", "direct_shot", "pressure_finisher"), hair(2, 0xB8581F, 0xB8581F, 0, 31, null));
        add("chigiri", "Hyoma Chigiri", "CHIGIRI", "team_z", Position.RW, 8, t(1.25, 1.55, 8, 40, 45, 35, 65), 4, 178, List.of("sprint_burst", "burst_dribble"), hair(8, 0xD9506A, 0xE8789C, 35, 41, null));
        add("raichi", "Jingo Raichi", "RAICHI", "team_z", Position.CF, 3, t(1.00, 1.36, 9, 80, 30, 60, 50), 99, 186, List.of("direct_shot", "finishing", "pressure_finisher"), hair(2, 0xE8DCA0, 0xE8DCA0, 0, 51, null));
        add("gagamaru", "Gin Gagamaru", "GAGAMARU", "team_z", Position.GK, 5, t(0.97, 1.28, 8, 25, 15, 45, 40), 6, 198, List.of("composure_focus", "awareness"), hair(1, 0x14110E, 0xC9CED6, 40, 61, null));
        add("kuon", "Wataru Kuon", "KUON", "team_z", Position.ST, 3, t(1.00, 1.34, 14, 30, 35, 60, 80), 17, 185, List.of("finishing", "awareness", "direct_shot"), hair(1, 0x3B2A1E, 0x3B2A1E, 0, 71, null));
        add("igarashi", "Gurimu Igarashi", "IGARASHI", "team_z", Position.CB, 2, t(0.98, 1.32, 12, 25, 25, 75, 70), 4, 185, List.of("shoulder_charge", "interception_read"), hair(0, 0x3B2A1E, 0x3B2A1E, 0, 81, null));
        add("naruhaya", "Asahi Naruhaya", "NARUHAYA", "team_z", Position.CM, 1, t(1.00, 1.34, 11, 35, 40, 50, 70), 14, 176, List.of("passing_lane_read"), hair(1, 0x5A3B24, 0x5A3B24, 0, 91, null));
        add("iemon", "Okuhito Iemon", "IEMON", "team_z", Position.GK, 1, t(0.97, 1.28, 8, 25, 15, 45, 40), 12, 184, List.of("awareness"), hair(0, 0x14110E, 0x14110E, 0, 101, null));
        add("imamura", "Yudai Imamura", "IMAMURA", "team_z", Position.LB, 1, t(1.00, 1.34, 12, 30, 30, 60, 70), 3, 177, List.of("interception_read"), hair(1, 0x3B2A1E, 0x3B2A1E, 0, 111, null));
        add("nagi", "Seishiro Nagi", "NAGI", "team_v", Position.CF, 10, t(1.02, 1.38, 8, 60, 90, 20, 25), 11, 190, List.of("control", "direct_shot", "finishing", "trap"), hair(5, 0xF4F4F4, 0xC9CED6, 40, 101, null));
        add("reo", "Reo Mikage", "REO", "team_v", Position.CM, 9, t(1.02, 1.38, 11, 55, 75, 45, 80), 9, 180, List.of("through_pass", "passing_lane_read", "feint", "chameleon"), hair(8, 0x7B3FBF, 0xB28CE0, 25, 111, null));
        add("zantetsu", "Zantetsu Tsurugi", "TSURUGI", "team_v", Position.LW, 4, t(1.04, 1.38, 11, 40, 40, 55, 70), 6, 181, List.of("sprint_burst", "direct_shot"), hair(2, 0x14110E, 0x14110E, 0, 241, null));
        add("junichi", "Junichi Wanima", "J. WANIMA", "team_w", Position.ST, 4, t(1.02, 1.36, 11, 55, 45, 55, 70), 9, 180, List.of("finishing", "direct_shot"), hair(2, 0x1B1B1F, 0x1B1B1F, 0, 301, null));
        add("keisuke", "Keisuke Wanima", "K. WANIMA", "team_w", Position.CAM, 3, t(1.00, 1.36, 11, 45, 55, 50, 70), 10, 180, List.of("through_pass"), hair(2, 0x1B1B1F, 0x1B1B1F, 0, 311, null));
        add("baro", "Shoei Baro", "BARO", "team_x", Position.ST, 9, t(1.10, 1.45, 11, 100, 40, 85, 65), 10, 187, List.of("precision_direct_shot", "finishing", "shoulder_charge"), hair(2, 0x14110E, 0xB3261E, 20, 91, new int[] {75, 45, 30, 40, 90, 40, 0}));
        add("meiji", "Haato Meiji", "MEIJI", "team_x", Position.CM, 2, t(1.00, 1.34, 12, 35, 45, 50, 70), 8, 176, List.of("passing_lane_read"), hair(1, 0x5A3B24, 0x5A3B24, 0, 321, null));
        add("sanga", "Rian Sanga", "SANGA", "team_x", Position.LB, 2, t(1.00, 1.34, 12, 30, 30, 60, 70), 3, 178, List.of("interception_read"), hair(1, 0x1B1B1F, 0x1B1B1F, 0, 331, null));
        add("banku", "Yawara Banku", "BANKU", "team_x", Position.CB, 2, t(0.98, 1.32, 12, 25, 25, 70, 70), 5, 183, List.of("shoulder_charge"), hair(0, 0x3B2A1E, 0x3B2A1E, 0, 341, null));
        add("ikki", "Niko Ikki", "IKKI", "team_y", Position.CB, 6, t(1.00, 1.36, 13, 35, 45, 85, 75), 5, 185, List.of("shoulder_charge", "shadow_marking"), hair(2, 0x8A8F98, 0x1B1B1F, 30, 231, null));
        add("okawa", "Hibiki Okawa", "OKAWA", "team_y", Position.CM, 3, t(1.00, 1.34, 12, 35, 45, 50, 70), 7, 178, List.of("passing_lane_read", "spatial_read"), hair(1, 0x3B2A1E, 0x3B2A1E, 0, 351, null));
        add("rin", "Rin Itoshi", "RIN", "", Position.CM, 12, t(1.05, 1.42, 13, 85, 85, 65, 75), 10, 182, List.of("direct_shot", "advanced_field_vision", "through_pass", "awakening_direct_shot", "chain_dribble", "curved_shot"), hair(6, 0x14181C, 0x14181C, 0, 151, null));
        add("shidou", "Ryusei Shidou", "SHIDOU", "", Position.ST, 10, t(1.10, 1.45, 10, 80, 100, 55, 60), 13, 182, List.of("burst_dribble", "feint", "awakening_direct_shot", "sprint_burst", "dragon_drive"), hair(2, 0xE8C84A, 0xE8C84A, 0, 161, null));
        add("kaiser", "Michael Kaiser", "KAISER", "", Position.CF, 12, t(1.04, 1.40, 10, 95, 75, 50, 55), 9, 187, List.of("precision_direct_shot", "advanced_field_vision", "chain_dribble", "finishing", "curved_shot"), hair(7, 0xE8C84A, 0x2F6BFF, 40, 171, null));
        add("sae", "Sae Itoshi", "SAE", "", Position.CAM, 14, t(1.06, 1.42, 12, 75, 90, 55, 80), 10, 185, List.of("through_pass", "advanced_field_vision", "precision_direct_shot", "composure_focus", "perfect_pass"), hair(6, 0x6B3B30, 0x6B3B30, 0, 181, null));
        add("noa", "Noel Noa", "NOA", "", Position.CF, 14, t(1.06, 1.42, 15, 55, 80, 70, 95), 9, 190, List.of("awareness", "spatial_read", "control", "shoulder_charge", "direct_shot", "finishing"), hair(6, 0xF4F4F4, 0xF4F4F4, 0, 191, null));
        add("otoya", "Eita Otoya", "OTOYA", "", Position.RW, 4, t(1.05, 1.40, 14, 40, 55, 50, 85), 33, 177, List.of("sprint_burst", "burst_dribble"), hair(1, 0xF4F4F4, 0x1F6B3A, 40, 201, null));
        add("tokimitsu", "Aoshi Tokimitsu", "TOKIMITSU", "", Position.ST, 4, t(1.00, 1.36, 14, 30, 50, 55, 85), 3, 184, List.of("shoulder_charge", "sprint_burst"), hair(1, 0x14110E, 0x14110E, 0, 211, null));
        add("aiku", "Oliver Aiku", "AIKU", "", Position.CB, 5, t(1.00, 1.36, 13, 30, 40, 65, 80), 2, 186, List.of("shadow_marking", "interception_read", "awareness"), hair(3, 0x5A3B24, 0x34B34A, 40, 221, null));
        add("hiori", "Yo Hiori", "HIORI", "", Position.CM, 6, t(1.00, 1.36, 12, 35, 55, 50, 85), 27, 183, List.of("passing_lane_read", "spatial_read", "control", "through_pass"), hair(1, 0x2FD0E8, 0x2FD0E8, 0, 121, null));
        add("aryu", "Jyubei Aryu", "ARYU", "", Position.CB, 6, t(0.98, 1.34, 11, 70, 60, 50, 70), 2, 195, List.of("awareness", "shoulder_charge"), hair(7, 0x14110E, 0x14110E, 0, 131, null));
        add("nanase", "Nijiro Nanase", "NANASE", "", Position.LW, 5, t(1.03, 1.40, 10, 50, 60, 40, 65), 99, 178, List.of("burst_dribble", "sprint_burst"), hair(3, 0xD9B45A, 0xF28C28, 30, 141, null));
    }

    private Roster() {
    }

    public static List<FootballCharacter> all() {
        return List.copyOf(ALL);
    }

    public static List<FootballCharacter> ofTeam(String teamId) {
        List<FootballCharacter> out = new ArrayList<>();
        for (FootballCharacter c : ALL) {
            if (c.teamId().equals(teamId)) out.add(c);
        }
        return out;
    }

    public static FootballCharacter byId(String id) {
        for (FootballCharacter c : ALL) {
            if (c.id().equals(id)) return c;
        }
        return null;
    }

    /**
     * Picks the character for one slot of a team. Characters are used at most once ({@code taken} holds the ids
     * already given out). A character who plays exactly this position goes first, then one in the same line
     * (goal, defence, midfield, attack). Returns null when the team has nobody fitting: the bot is then a nameless
     * player with traits from its position.
     */
    public static FootballCharacter assign(String teamId, Position slotPosition, java.util.Set<String> taken) {
        List<FootballCharacter> team = ofTeam(teamId);
        for (FootballCharacter c : team) {
            if (!taken.contains(c.id()) && c.position() == slotPosition) return c;
        }
        for (FootballCharacter c : team) {
            if (!taken.contains(c.id()) && line(c.position()) == line(slotPosition)) return c;
        }
        return null;
    }

    /** Look codes are synced to clients as one number: 0 or more = index in the roster, negative = a nameless bot. */
    public static int lookOf(FootballCharacter c, int fallbackSeed) {
        if (c == null) return -1 - Math.abs(fallbackSeed % 100000);
        return ALL.indexOf(c);
    }

    public static FootballCharacter byLook(int look) {
        return look >= 0 && look < ALL.size() ? ALL.get(look) : null;
    }

    /** The hair of a look: the character's own, or a made-up one from the seed (the same on every client). */
    public static HairDesign hairForLook(int look) {
        FootballCharacter c = byLook(look);
        if (c != null) return c.hair();
        return HairDesign.random(new java.util.Random(look * 7919L + 13));
    }

    /** The body of a look: the character's own, or a made-up one from the seed (the same on every client). */
    public static BodyDesign bodyForLook(int look) {
        FootballCharacter c = byLook(look);
        if (c != null) return c.body();
        return BodyDesign.random(new java.util.Random(look * 104729L + 7));
    }

    private static int line(Position p) {
        return switch (p) {
            case GK -> 0;
            case CB, LB, RB, LWB, RWB, CDM -> 1;
            case CM, CAM, LM, RM -> 2;
            case LW, RW, ST, CF -> 3;
        };
    }
}
