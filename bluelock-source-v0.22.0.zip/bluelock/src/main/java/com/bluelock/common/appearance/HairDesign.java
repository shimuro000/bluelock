package com.bluelock.common.appearance;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * A player's 3D hair, described by numbers only (no Minecraft code, so it can be tested and sent over the network).
 * The hair maker screen edits these values and {@link HairModel} turns them into 3D pieces.
 *
 * <ul>
 *   <li>{@code style}: one of the {@link #STYLE_COUNT} presets; choosing a preset sets all the sliders below.</li>
 *   <li>{@code top, front, sides, back, spikes, fluff, tail}: sliders from 0 to 100 (volume on top, fringe length,
 *       side length, back length, number and size of spikes, messiness, ponytail length).</li>
 *   <li>{@code seed}: changes the random look of locks and tufts without changing the sliders.</li>
 *   <li>{@code color, tipColor, tipAmount}: main colour (RGB), colour of the tips (RGB) and how much of each lock is tipped, 0 to 100.</li>
 * </ul>
 * Every value is clamped by the constructor, so a design is always valid, even when it arrives from a client.
 */
public record HairDesign(int style, int top, int front, int sides, int back, int spikes, int fluff, int tail,
                         int seed, int color, int tipColor, int tipAmount) {

    public static final int STYLE_COUNT = 12;
    public static final int DEFAULT_COLOR = 0x3B2A1E;
    public static final int SLIDER_MAX = 100;
    public static final int SEED_MAX = 9999;
    /** Number of values in {@link #toInts()}. */
    public static final int INT_COUNT = 12;

    /** Slider defaults per style: top, front, sides, back, spikes, fluff, tail. */
    private static final int[][] PRESETS = {
            {8, 4, 6, 6, 0, 0, 0},        // 0 buzz cut
            {30, 35, 22, 20, 0, 10, 0},   // 1 short
            {45, 30, 20, 20, 75, 25, 0},  // 2 spiky
            {40, 55, 35, 38, 30, 55, 0},  // 3 messy
            {70, 45, 45, 40, 15, 90, 0},  // 4 fluffy curls
            {45, 70, 40, 45, 10, 60, 0},  // 5 lazy
            {35, 8, 25, 35, 0, 5, 0},     // 6 swept back
            {40, 40, 70, 85, 0, 20, 0},   // 7 long
            {35, 30, 30, 40, 0, 15, 85},  // 8 ponytail
            {60, 10, 4, 10, 90, 20, 0},   // 9 mohawk
            {30, 80, 55, 45, 0, 5, 0},    // 10 bowl
            {95, 60, 70, 60, 0, 85, 0},   // 11 big volume
    };

    /** Language key suffixes of the presets: bluelock.hair.style.NAME */
    public static final String[] STYLE_NAMES = {
            "buzz", "short", "spiky", "messy", "fluffy", "lazy", "swept", "long", "ponytail", "mohawk", "bowl", "volume"};

    /** Colour swatches shown in the hair maker. */
    public static final int[] SWATCHES = {
            0x1B1B1F, 0x3B2A1E, 0x5A3B24, 0x8B5E3C, 0xD9B45A, 0xF0E8C8, 0xB5532A, 0xB3261E,
            0xE86AA6, 0xC2188C, 0x7B3FBF, 0x5E3BE0, 0x1F2D6B, 0x2F6BFF, 0x2FD0E8, 0x1FA89A,
            0x34B34A, 0xA6D93A, 0xF4F4F4, 0x8A8F98, 0xC9CED6, 0xF28C28, 0x5C1A2B, 0x101A40};

    public HairDesign {
        style = clamp(style, 0, STYLE_COUNT - 1);
        top = clamp(top, 0, SLIDER_MAX);
        front = clamp(front, 0, SLIDER_MAX);
        sides = clamp(sides, 0, SLIDER_MAX);
        back = clamp(back, 0, SLIDER_MAX);
        spikes = clamp(spikes, 0, SLIDER_MAX);
        fluff = clamp(fluff, 0, SLIDER_MAX);
        tail = clamp(tail, 0, SLIDER_MAX);
        seed = clamp(seed, 0, SEED_MAX);
        color &= 0xFFFFFF;
        tipColor &= 0xFFFFFF;
        tipAmount = clamp(tipAmount, 0, SLIDER_MAX);
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** A style with its default sliders, no tips, in the given colour. Style numbers outside the range wrap around. */
    public static HairDesign preset(int style, int color) {
        int s = Math.floorMod(style, STYLE_COUNT);
        int[] p = PRESETS[s];
        return new HairDesign(s, p[0], p[1], p[2], p[3], p[4], p[5], p[6], 0, color, color, 0);
    }

    public static HairDesign standard() {
        return preset(1, DEFAULT_COLOR);
    }

    /** The same design after picking another preset: sliders reset to the preset, colours and seed are kept. */
    public HairDesign withStyle(int newStyle) {
        HairDesign p = preset(newStyle, color);
        return new HairDesign(p.style, p.top, p.front, p.sides, p.back, p.spikes, p.fluff, p.tail, seed, color, tipColor, tipAmount);
    }

    public HairDesign withSliders(int top, int front, int sides, int back, int spikes, int fluff, int tail) {
        return new HairDesign(style, top, front, sides, back, spikes, fluff, tail, seed, color, tipColor, tipAmount);
    }

    public HairDesign withColors(int color, int tipColor, int tipAmount) {
        return new HairDesign(style, top, front, sides, back, spikes, fluff, tail, seed, color, tipColor, tipAmount);
    }

    public HairDesign withSeed(int newSeed) {
        return new HairDesign(style, top, front, sides, back, spikes, fluff, tail, newSeed, color, tipColor, tipAmount);
    }

    /** A random style with sliders near its preset, a random colour and sometimes coloured tips. */
    public static HairDesign random(Random random) {
        HairDesign base = preset(random.nextInt(STYLE_COUNT), SWATCHES[random.nextInt(SWATCHES.length)]);
        boolean tips = random.nextInt(3) == 0;
        return new HairDesign(base.style,
                jitter(base.top, random), jitter(base.front, random), jitter(base.sides, random), jitter(base.back, random),
                jitter(base.spikes, random), jitter(base.fluff, random), base.tail == 0 ? 0 : jitter(base.tail, random),
                random.nextInt(SEED_MAX + 1), base.color,
                tips ? SWATCHES[random.nextInt(SWATCHES.length)] : base.color, tips ? 20 + random.nextInt(40) : 0);
    }

    private static int jitter(int value, Random random) {
        return clamp(value + random.nextInt(21) - 10, 0, SLIDER_MAX);
    }

    // ---------- network and save format ----------

    /** All values in a fixed order, for packets. */
    public int[] toInts() {
        return new int[] {style, top, front, sides, back, spikes, fluff, tail, seed, color, tipColor, tipAmount};
    }

    /** Reads {@link #toInts()}; too-short or null input gives the standard design, values are clamped. */
    public static HairDesign fromInts(int[] v) {
        if (v == null || v.length < INT_COUNT) return standard();
        return new HairDesign(v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9], v[10], v[11]);
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = new HashMap<>();
        m.put("style", style);
        m.put("top", top);
        m.put("front", front);
        m.put("sides", sides);
        m.put("back", back);
        m.put("spikes", spikes);
        m.put("fluff", fluff);
        m.put("tail", tail);
        m.put("seed", seed);
        m.put("color", color);
        m.put("tipColor", tipColor);
        m.put("tipAmount", tipAmount);
        return m;
    }

    /** Reads {@link #toMap()}; missing fields fall back to the style preset (or the standard design if even the style is missing). */
    public static HairDesign fromMap(Map<?, ?> m) {
        if (m == null) return standard();
        HairDesign p = preset(num(m.get("style"), 1), num(m.get("color"), DEFAULT_COLOR));
        return new HairDesign(p.style,
                num(m.get("top"), p.top), num(m.get("front"), p.front), num(m.get("sides"), p.sides), num(m.get("back"), p.back),
                num(m.get("spikes"), p.spikes), num(m.get("fluff"), p.fluff), num(m.get("tail"), p.tail),
                num(m.get("seed"), 0), p.color, num(m.get("tipColor"), p.color), num(m.get("tipAmount"), 0));
    }

    private static int num(Object o, int def) {
        return o instanceof Number n ? n.intValue() : def;
    }
}
