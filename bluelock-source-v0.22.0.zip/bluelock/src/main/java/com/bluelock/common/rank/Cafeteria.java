package com.bluelock.common.rank;

/**
 * The cafeteria serves by rank, like the school it is: the better the rank, the better the meal. A meal fills hunger and
 * gives a short boost (speed, regeneration, resistance). No Minecraft code; the Forge side turns it into effects.
 */
public final class Cafeteria {
    public static final int COOLDOWN_TICKS = 3600;
    public static final int RANGE_BLOCKS = 18;

    public enum Tier { S, A, B, C, D }

    public record Meal(Tier tier, String id, int food, int speedLevel, int speedSeconds, int regenSeconds, int resistSeconds) {
        public String nameKey() {
            return "bluelock.meal." + id;
        }
    }

    private Cafeteria() {
    }

    public static Tier tierOf(int rank) {
        if (rank <= 10) return Tier.S;
        if (rank <= 50) return Tier.A;
        if (rank <= 120) return Tier.B;
        if (rank <= 200) return Tier.C;
        return Tier.D;
    }

    public static String tierKey(Tier tier) {
        return "bluelock.tier." + tier.name().toLowerCase(java.util.Locale.ROOT);
    }

    public static Meal mealFor(int rank) {
        return switch (tierOf(rank)) {
            case S -> new Meal(Tier.S, "course", 20, 1, 180, 20, 120);
            case A -> new Meal(Tier.A, "steak", 18, 1, 120, 10, 0);
            case B -> new Meal(Tier.B, "curry", 14, 0, 120, 0, 0);
            case C -> new Meal(Tier.C, "fish", 10, 0, 60, 0, 0);
            case D -> new Meal(Tier.D, "riceball", 6, -1, 0, 0, 0);
        };
    }
}
