package com.bluelock.common.appearance;

import com.bluelock.common.content.Position;

/**
 * A football kit (no Minecraft code): shirt, trim (collar, cuffs, socks tops, number), shorts, socks, the number
 * on the back and the name above it. Colours come from the team colour, so teammates always match.
 */
public record KitDesign(int shirt, int trim, int shorts, int socks, int number, String name) {
    public static final int MAX_NAME = 12;

    public KitDesign {
        shirt &= 0xFFFFFF;
        trim &= 0xFFFFFF;
        shorts &= 0xFFFFFF;
        socks &= 0xFFFFFF;
        number = Math.max(0, Math.min(99, number));
        String n = name == null ? "" : name.trim().toUpperCase(java.util.Locale.ROOT);
        name = n.length() > MAX_NAME ? n.substring(0, MAX_NAME) : n;
    }

    /** The kit of a team: shirt and socks in the team colour, shorts darker, white or black trim for contrast. */
    public static KitDesign forTeam(int teamColor, int number, String name) {
        int c = teamColor & 0xFFFFFF;
        int trim = luminance(c) > 150 ? 0x14141C : 0xFFFFFF;
        return new KitDesign(c, trim, scale(c, 0.55), c, number, name);
    }

    public static int luminance(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        return (int) Math.round(0.299 * r + 0.587 * g + 0.114 * b);
    }

    private static int scale(int rgb, double f) {
        int r = (int) Math.round(((rgb >> 16) & 255) * f);
        int g = (int) Math.round(((rgb >> 8) & 255) * f);
        int b = (int) Math.round((rgb & 255) * f);
        return (r << 16) | (g << 8) | b;
    }

    /** The usual shirt number of a position (1 keeper, 9 striker, 10 playmaker...). */
    public static int numberFor(Position p) {
        return switch (p) {
            case GK -> 1;
            case RB -> 2;
            case LB -> 3;
            case CB -> 4;
            case RWB -> 12;
            case LWB -> 13;
            case CDM -> 6;
            case CM -> 8;
            case CAM -> 10;
            case RM -> 7;
            case LM -> 11;
            case RW -> 7;
            case LW -> 11;
            case CF -> 9;
            case ST -> 9;
        };
    }
}
