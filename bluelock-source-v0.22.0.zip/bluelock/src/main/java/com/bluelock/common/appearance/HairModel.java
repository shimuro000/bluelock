package com.bluelock.common.appearance;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Turns a {@link HairDesign} into 3D pieces (no Minecraft code). Everything is built from "locks": tapered four-sided
 * prisms from a base point to a tip point. A cap, sides, back, fringe, spikes, tufts and a ponytail are just locks
 * placed by the design's sliders, so one small generator makes every style.
 *
 * Coordinates are the head model's own, in 1/16 block pixels: the head is 8 wide, 8 tall and 8 deep, x runs to the
 * right, y runs DOWN (the top of the head is y = -8, the chin is y = 0) and the face looks toward -z.
 * The result is the same every time for the same design.
 */
public final class HairModel {

    /** One four-cornered face. t is how far along its lock a corner is (0 root, 1 tip), used for tip colours. */
    public static final class Quad {
        public final float[] x = new float[4];
        public final float[] y = new float[4];
        public final float[] z = new float[4];
        public final float[] t = new float[4];
        public float nx;
        public float ny;
        public float nz;
        /** Small brightness difference per face (about 0.88 to 1.0) so the hair does not look flat. */
        public float shade = 1.0F;
    }

    private final List<Quad> quads = new ArrayList<>();
    private final Random random;

    private HairModel(long seed) {
        random = new Random(seed);
    }

    public static List<Quad> build(HairDesign d) {
        HairModel m = new HairModel(d.seed() * 7919L + d.style() * 104729L + 17L);
        m.generate(d);
        return m.quads;
    }

    // ---------- the colour of a point on the hair ----------

    /** Mixes the main colour into the tip colour. t = 0 is the root, 1 the tip; tipAmount 0 means no tips at all. */
    public static int colorAt(HairDesign d, float t) {
        if (d.tipAmount() <= 0) return d.color();
        float k = d.tipAmount() / 100.0F;
        float start = 1.0F - 0.85F * k;
        float f = Math.max(0.0F, Math.min(1.0F, (t - start) / Math.max(0.0001F, 1.0F - start)));
        f = f * f * (3.0F - 2.0F * f);
        return mix(d.color(), d.tipColor(), f);
    }

    private static int mix(int a, int b, float f) {
        int r = Math.round(((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = Math.round(((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = Math.round((a & 255) * (1 - f) + (b & 255) * f);
        return (r << 16) | (g << 8) | bl;
    }

    // ---------- generation (h = height above the chin, so y = -h) ----------

    private void generate(HairDesign d) {
        double top = d.top() / 100.0;
        double front = d.front() / 100.0;
        double sides = d.sides() / 100.0;
        double back = d.back() / 100.0;
        double spikes = d.spikes() / 100.0;
        double fluff = d.fluff() / 100.0;
        double tail = d.tail() / 100.0;
        double spread = fluff * 0.5 + top * 0.45;            // how much wider than the head the hair gets
        double halfWidth = 4.55 + spread;
        double capTop = 8.55 + top * 5.0;

        // cap over the top of the head (no tip colour: it is the root of everything)
        lock(0, 6.4, 0, 0, capTop, 0, 1, 0, 0, halfWidth, halfWidth, 0.88, 0, 0);

        // back of the head, down to the neck and below it for long hair
        double backLow = 4.6 - back * 10.1;
        double backDepth = 0.55 + back * 0.6 + fluff * 0.5 + top * 0.3;
        lock(0, 7.8, 4.45 + backDepth * 0.4, 0, backLow, Math.max(2.9, 4.5 - Math.max(0, -backLow) * 0.12) + backDepth * 0.4,
                1, 0, 0, halfWidth - 0.05, backDepth, 0.96, 0.0, 1.0);

        // the two sides, from the ears backwards
        double sideLow = 6.0 - sides * 7.0;
        double sideThick = 0.55 + fluff * 0.4 + top * 0.25;
        for (int s = -1; s <= 1; s += 2) {
            lock(s * (4.45 + sideThick * 0.4), 7.8, 0.9, s * (4.5 + sideThick * 0.4), sideLow, 1.0,
                    0, 0, 1, 3.1, sideThick, 0.95, 0.0, 1.0);
        }

        // fringe across the forehead
        if (front > 0.05) {
            int locks = 7;
            for (int i = 0; i < locks; i++) {
                double x = -4.2 + 8.4 * i / (locks - 1);
                double length = (0.4 + front * 5.5) * (0.75 + 0.5 * random.nextDouble());
                double sway = (random.nextDouble() - 0.5) * (0.4 + fluff * 3.0) + (i - locks / 2.0) * front * 0.08;
                lock(x, 8.1, -4.3, x + sway, 8.1 - length, -4.75 - front * 0.2,
                        1, 0, 0, 0.72, 0.5, 0.7, 0.0, 1.0);
            }
        }

        // spikes: scattered over the top, or in one row for a mohawk
        int spikeCount = (int) Math.round(spikes * 10.0);
        boolean mohawk = d.spikes() > 60 && d.sides() < 15;
        for (int i = 0; i < spikeCount; i++) {
            double px;
            double pz;
            if (mohawk) {
                px = (random.nextDouble() - 0.5) * 0.8;
                pz = -3.6 + 7.2 * i / Math.max(1, spikeCount - 1);
            } else {
                double angle = random.nextDouble() * Math.PI * 2;
                double radius = Math.sqrt(random.nextDouble()) * 3.6;
                px = Math.cos(angle) * radius;
                pz = Math.sin(angle) * radius;
            }
            double length = 2.2 + spikes * 5.5 * (0.7 + 0.5 * random.nextDouble());
            double dx = px * 0.3 + (random.nextDouble() - 0.5) * 0.8;
            double dz = pz * 0.3 + (random.nextDouble() - 0.5) * 0.8;
            double norm = Math.sqrt(dx * dx + 1.0 + dz * dz);
            lock(px, capTop - 0.5, pz, px + dx / norm * length, capTop - 0.5 + length / norm, pz + dz / norm * length,
                    1, 0, 0, 0.85 + spikes * 0.4, 0.85 + spikes * 0.4, 0.08, 0.0, 1.0);
        }

        // loose tufts around the head
        int tufts = (int) Math.round(fluff * 14.0);
        for (int i = 0; i < tufts; i++) {
            double azimuth = random.nextDouble() * Math.PI * 2;
            double elevation = 0.15 + random.nextDouble() * 1.3;
            double px = Math.cos(elevation) * Math.sin(azimuth) * halfWidth;
            double ph = 3.9 + Math.sin(elevation) * (capTop - 3.9) * 0.95;
            double pz = Math.cos(elevation) * Math.cos(azimuth) * halfWidth;
            if (pz < -3.2 && ph < 7.2) {
                continue;                                   // keep the face clear
            }
            double dx = px + (random.nextDouble() - 0.5) * 2.0;
            double dh = (ph - 3.9) * 0.8 + random.nextDouble();
            double dz = pz + (random.nextDouble() - 0.5) * 2.0;
            double norm = Math.sqrt(dx * dx + dh * dh + dz * dz);
            double length = 1.3 + random.nextDouble() * (1.2 + fluff * 1.6);
            lock(px, ph, pz, px + dx / norm * length, ph + dh / norm * length, pz + dz / norm * length,
                    0, 1, 0, 0.95, 0.95, 0.3, 0.1, 1.0);
        }

        // ponytail in two parts, bending down
        if (tail > 0.05) {
            double length = 3.0 + tail * 11.0;
            double midH = 6.3 - length * 0.35;
            double midZ = 5.6 + tail * 1.2;
            lock(0, 6.4, 4.7, 0, midH, midZ, 1, 0, 0, 1.15, 1.05, 0.95, 0.0, 0.45);
            lock(0, midH, midZ, 0, midH - length * 0.65, midZ + 0.2, 1, 0, 0, 1.1, 1.0, 0.45, 0.45, 1.0);
        }
    }

    // ---------- one lock ----------

    private void lock(double bx, double bh, double bz, double tx, double th, double tz,
                      double ux, double uy, double uz, double a, double b, double taper, double tRoot, double tTip) {
        double wx = tx - bx;
        double wy = th - bh;
        double wz = tz - bz;
        double length = Math.sqrt(wx * wx + wy * wy + wz * wz);
        if (length < 1e-6) {
            return;
        }
        wx /= length;
        wy /= length;
        wz /= length;
        // u: the hint made perpendicular to the lock's axis
        double dot = ux * wx + uy * wy + uz * wz;
        double px = ux - dot * wx;
        double py = uy - dot * wy;
        double pz = uz - dot * wz;
        double pl = Math.sqrt(px * px + py * py + pz * pz);
        if (pl < 1e-6) {
            px = wy;
            py = -wx;
            pz = 0;
            pl = Math.sqrt(px * px + py * py);
            if (pl < 1e-6) {
                px = 1;
                py = 0;
                pz = 0;
                pl = 1;
            }
        }
        px /= pl;
        py /= pl;
        pz /= pl;
        // v = w x u
        double vx = wy * pz - wz * py;
        double vy = wz * px - wx * pz;
        double vz = wx * py - wy * px;

        double[][] corner = new double[8][];
        int[][] signs = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
        for (int k = 0; k < 4; k++) {
            double su = signs[k][0] * a;
            double sv = signs[k][1] * b;
            corner[k] = new double[] {bx + px * su + vx * sv, bh + py * su + vy * sv, bz + pz * su + vz * sv};
            corner[k + 4] = new double[] {tx + px * su * taper + vx * sv * taper,
                    th + py * su * taper + vy * sv * taper, tz + pz * su * taper + vz * sv * taper};
        }
        double cx = (bx + tx) / 2;
        double ch = (bh + th) / 2;
        double cz = (bz + tz) / 2;
        for (int k = 0; k < 4; k++) {
            int n = (k + 1) % 4;
            addQuad(new double[][] {corner[k], corner[n], corner[n + 4], corner[k + 4]},
                    new double[] {tRoot, tRoot, tTip, tTip}, cx, ch, cz);
        }
        addQuad(new double[][] {corner[4], corner[5], corner[6], corner[7]},
                new double[] {tTip, tTip, tTip, tTip}, cx, ch, cz);
    }

    private void addQuad(double[][] c, double[] t, double cx, double ch, double cz) {
        Quad q = new Quad();
        double fx = 0;
        double fh = 0;
        double fz = 0;
        for (int i = 0; i < 4; i++) {
            q.x[i] = (float) c[i][0];
            q.y[i] = (float) -c[i][1];
            q.z[i] = (float) c[i][2];
            q.t[i] = (float) t[i];
            fx += c[i][0] / 4;
            fh += c[i][1] / 4;
            fz += c[i][2] / 4;
        }
        // normal from the two diagonals, flipped to point away from the lock's centre
        double d1x = c[2][0] - c[0][0];
        double d1h = c[2][1] - c[0][1];
        double d1z = c[2][2] - c[0][2];
        double d2x = c[3][0] - c[1][0];
        double d2h = c[3][1] - c[1][1];
        double d2z = c[3][2] - c[1][2];
        double nx = d1h * d2z - d1z * d2h;
        double nh = d1z * d2x - d1x * d2z;
        double nz = d1x * d2h - d1h * d2x;
        double nl = Math.sqrt(nx * nx + nh * nh + nz * nz);
        if (nl < 1e-9) {
            return;                                           // a flat, zero-area face: skip it
        }
        nx /= nl;
        nh /= nl;
        nz /= nl;
        if (nx * (fx - cx) + nh * (fh - ch) + nz * (fz - cz) < 0) {
            nx = -nx;
            nh = -nh;
            nz = -nz;
        }
        q.nx = (float) nx;
        q.ny = (float) -nh;
        q.nz = (float) nz;
        q.shade = 0.88F + 0.12F * random.nextFloat();
        quads.add(q);
    }
}
