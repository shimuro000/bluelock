package com.bluelock.common.action;

import com.bluelock.common.profile.DominantFoot;

/**
 * How the dominant foot changes kicks and moves. Kicks that go to the player's strong side (or straight ahead) are
 * clean; kicks across the body onto the weak foot are less accurate and weaker. Players who use both feet have no weak side.
 */
public final class FootModel {
    private static final double STRAIGHT = 0.15;

    /** spread multiplies the random aiming error; power multiplies the ball speed. */
    public record Factors(double spread, double power) {
    }

    private FootModel() {
    }

    /**
     * sideSign: positive when the kick goes to the player's right of where they are facing, negative to the left
     * (see {@link #sideOf}).
     */
    public static Factors kick(DominantFoot foot, double sideSign) {
        if (foot == DominantFoot.BOTH) return new Factors(0.9, 1.0);
        return isStrongSide(foot, sideSign) ? new Factors(1.0, 1.0) : new Factors(1.6, 0.9);
    }

    /** 1.0 for sidesteps toward the strong side, 0.8 toward the weak side. */
    public static double moveStrength(DominantFoot foot, double sideSign) {
        if (foot == DominantFoot.BOTH) return 1.0;
        return isStrongSide(foot, sideSign) ? 1.0 : 0.8;
    }

    private static boolean isStrongSide(DominantFoot foot, double sideSign) {
        return foot == DominantFoot.RIGHT ? sideSign >= -STRAIGHT : sideSign <= STRAIGHT;
    }

    /**
     * Which side a direction (dx, dz) lies on, seen from someone facing (hx, hz). Minecraft: +x east, +z south.
     * Returns a value in -1..1: positive = right-hand side, negative = left-hand side.
     */
    public static double sideOf(double hx, double hz, double dx, double dz) {
        double hl = Math.sqrt(hx * hx + hz * hz);
        double dl = Math.sqrt(dx * dx + dz * dz);
        if (hl < 1.0E-9 || dl < 1.0E-9) return 0;
        return (-dx * hz + dz * hx) / (hl * dl);
    }
}
