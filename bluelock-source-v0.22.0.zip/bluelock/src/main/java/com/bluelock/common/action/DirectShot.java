package com.bluelock.common.action;

import java.util.function.Predicate;

/**
 * The direct shot family: hitting a loose ball first time, with no setup touch.
 * Three tiers, each a skill of its own: normal, precision and awakening. The numbers here decide how each
 * tier behaves; the player's stats move them up or down (composure steadies the shot, shooting adds power,
 * awakening potential and ego affinity fuel the awakened version).
 * Pure logic: the Forge side only finds the ball and applies the result.
 */
public final class DirectShot {
    /** The crosshair radius: a loose ball this close (blocks) to the player can be hit with a direct shot. */
    public static final double REACH = 2.0;
    /** The ball must be no higher than this above the player's feet (a volley, not a header). */
    public static final double MAX_BALL_HEIGHT = 2.3;
    /** Below this height the ball counts as lying on the ground. */
    public static final double GROUND_HEIGHT = 0.45;

    public enum Tier {
        NORMAL("direct_shot"),
        PRECISION("precision_direct_shot"),
        AWAKENING("awakening_direct_shot");

        private final String skillId;

        Tier(String skillId) {
            this.skillId = skillId;
        }

        public String skillId() {
            return skillId;
        }

        public static Tier ofSkill(String skillId) {
            for (Tier t : values()) {
                if (t.skillId.equals(skillId)) return t;
            }
            return null;
        }
    }

    /**
     * How one shot is hit. spreadMul scales the random aiming error (smaller is more accurate), powerMul the
     * ball speed, aimBlend how strongly the shot is pulled toward the target (0..1) when the player looks within
     * aimAngleDegrees of it, and cornerAim whether the target is a goal corner instead of the goal centre.
     */
    public record Params(Tier tier, double powerMul, double spreadMul, double aimBlend, double aimAngleDegrees,
                         boolean cornerAim) {
    }

    private DirectShot() {
    }

    public static Params params(Tier tier, int shooting, int finishing, int composure, int awakeningPotential) {
        double steady = 1.25 - 0.5 * clamp01(composure / 100.0);          // composure 100 -> 0.75, 0 -> 1.25
        double craft = 1.0 - 0.15 * clamp01((shooting + finishing) / 200.0);
        return switch (tier) {
            case NORMAL -> new Params(tier, 0.95 + 0.15 * clamp01(shooting / 100.0), 0.85 * steady * craft, 0.35, 20.0, false);
            case PRECISION -> new Params(tier, 0.90 + 0.10 * clamp01(shooting / 100.0), 0.35 * steady * craft, 0.85, 34.0, true);
            case AWAKENING -> new Params(tier, 1.15 + 0.40 * clamp01(awakeningPotential / 100.0), 0.12 * steady, 0.95, 48.0, true);
        };
    }

    /** True when a ball at this offset from the player can be hit: close enough, low enough and nobody carries it. */
    public static boolean canStrike(double horizontalDistance, double heightAboveFeet, boolean carried) {
        return !carried && horizontalDistance <= REACH && heightAboveFeet >= -0.6 && heightAboveFeet <= MAX_BALL_HEIGHT;
    }

    public static boolean onGround(double heightAboveFeet) {
        return heightAboveFeet <= GROUND_HEIGHT;
    }

    /**
     * The tier to use when the key is pressed: the best one the player owns and can use right now
     * (awakening, then precision, then normal).
     */
    public static Tier best(Predicate<String> owns, Predicate<Tier> usableNow) {
        Tier[] order = {Tier.AWAKENING, Tier.PRECISION, Tier.NORMAL};
        for (Tier t : order) {
            if (owns.test(t.skillId()) && usableNow.test(t)) return t;
        }
        return null;
    }

    /** True if the player owns any direct shot skill (the crosshair only shows for them). */
    public static boolean ownsAny(Predicate<String> owns) {
        for (Tier t : Tier.values()) {
            if (owns.test(t.skillId())) return true;
        }
        return false;
    }

    private static double clamp01(double v) {
        return Math.max(0, Math.min(1, v));
    }
}
