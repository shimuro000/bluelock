package com.bluelock.forge;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

/** The football key bindings (client only). Players can change them in Options > Controls > Blue Lock. */
public final class ClientKeys {
    private static final String CATEGORY = "key.categories.bluelock";

    public static final KeyMapping PASS = new KeyMapping("key.bluelock.pass", InputConstants.KEY_R, CATEGORY);
    public static final KeyMapping SHOT = new KeyMapping("key.bluelock.shot", InputConstants.KEY_F, CATEGORY);
    public static final KeyMapping SLIDE = new KeyMapping("key.bluelock.slide", InputConstants.KEY_V, CATEGORY);
    public static final KeyMapping FEINT = new KeyMapping("key.bluelock.feint", InputConstants.KEY_Z, CATEGORY);
    public static final KeyMapping BURST = new KeyMapping("key.bluelock.burst", InputConstants.KEY_X, CATEGORY);
    public static final KeyMapping CHAIN = new KeyMapping("key.bluelock.chain", InputConstants.KEY_C, CATEGORY);
    public static final KeyMapping SPRINT = new KeyMapping("key.bluelock.sprint", InputConstants.KEY_B, CATEGORY);
    public static final KeyMapping SHOULDER = new KeyMapping("key.bluelock.shoulder", InputConstants.KEY_G, CATEGORY);

    public static final KeyMapping DIRECT = new KeyMapping("key.bluelock.direct", InputConstants.KEY_H, CATEGORY);
    public static final KeyMapping THROUGH = new KeyMapping("key.bluelock.through", InputConstants.KEY_Y, CATEGORY);
    public static final KeyMapping DIVE = new KeyMapping("key.bluelock.dive", InputConstants.KEY_N, CATEGORY);
    public static final KeyMapping LANE = new KeyMapping("key.bluelock.lane", InputConstants.KEY_J, CATEGORY);
    public static final KeyMapping SPATIAL = new KeyMapping("key.bluelock.spatial", InputConstants.KEY_K, CATEGORY);
    public static final KeyMapping VISION = new KeyMapping("key.bluelock.vision", InputConstants.KEY_I, CATEGORY);
    public static final KeyMapping INTERCEPT = new KeyMapping("key.bluelock.intercept", InputConstants.KEY_O, CATEGORY);
    public static final KeyMapping SHADOW = new KeyMapping("key.bluelock.shadow", InputConstants.KEY_U, CATEGORY);
    public static final KeyMapping COMPOSURE = new KeyMapping("key.bluelock.composure", InputConstants.KEY_COMMA, CATEGORY);

    /** Opens the Blue Lock menu. */
    public static final KeyMapping MENU = new KeyMapping("key.bluelock.menu", InputConstants.KEY_M, CATEGORY);

    /** Bind slots: each fires the skill the player bound to it in the menu. */
    public static final KeyMapping[] SLOTS = {
            new KeyMapping("key.bluelock.slot1", InputConstants.KEY_LBRACKET, CATEGORY),
            new KeyMapping("key.bluelock.slot2", InputConstants.KEY_RBRACKET, CATEGORY),
            new KeyMapping("key.bluelock.slot3", InputConstants.KEY_BACKSLASH, CATEGORY)};

    /** Index = action id (see ActionIds). */
    public static final KeyMapping[] BY_ACTION = {PASS, SHOT, SLIDE, FEINT, BURST, CHAIN, SPRINT, SHOULDER,
            DIRECT, THROUGH, DIVE, LANE, SPATIAL, VISION, INTERCEPT, SHADOW, COMPOSURE};

    private ClientKeys() {
    }
}
