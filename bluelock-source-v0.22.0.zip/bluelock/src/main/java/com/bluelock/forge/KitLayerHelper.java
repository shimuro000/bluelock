package com.bluelock.forge;

import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.appearance.KitDesign;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;

/** Draws a kit on a humanoid model's parts (shared by the player and the plain bot layer). */
final class KitLayerHelper {
    private KitLayerHelper() {
    }

    /**
     * Draws the skin coat of the body design (when there is one) and then the kit (when there is one) on every part.
     * With a body but no match kit the character wears the plain training kit and no number.
     */
    static void draw(PoseStack ps, MultiBufferSource buffer, BodyDesign look, KitDesign matchKit, int light,
                     ModelPart body, ModelPart rightArm, ModelPart leftArm, ModelPart rightLeg, ModelPart leftLeg) {
        KitDesign kit = matchKit != null ? matchKit : look != null ? BodyDraw.TRAINING : null;
        part(ps, buffer, look, kit, light, body, KitDraw.Part.BODY);
        part(ps, buffer, look, kit, light, rightArm, KitDraw.Part.RIGHT_ARM);
        part(ps, buffer, look, kit, light, leftArm, KitDraw.Part.LEFT_ARM);
        part(ps, buffer, look, kit, light, rightLeg, KitDraw.Part.RIGHT_LEG);
        part(ps, buffer, look, kit, light, leftLeg, KitDraw.Part.LEFT_LEG);
        if (matchKit == null) {
            return;
        }
        ps.pushPose();
        body.translateAndRotate(ps);
        ps.scale(1.0F / 16.0F, 1.0F / 16.0F, 1.0F / 16.0F);
        KitDraw.backText(ps, buffer, kit, true, light);
        ps.popPose();
    }

    private static void part(PoseStack ps, MultiBufferSource buffer, BodyDesign look, KitDesign kit, int light, ModelPart part, KitDraw.Part which) {
        ps.pushPose();
        part.translateAndRotate(ps);
        ps.scale(1.0F / 16.0F, 1.0F / 16.0F, 1.0F / 16.0F);
        if (look != null) {
            BodyDraw.limb(ps, buffer, look, which, true, light);
        }
        if (kit != null) {
            KitDraw.part(ps, buffer, kit, which, true, light);
        }
        ps.popPose();
    }
}
