package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Client to server: the player pressed a football key. */
public record ActionPacket(int action) {

    public static void encode(ActionPacket message, FriendlyByteBuf buffer) {
        buffer.writeVarInt(message.action());
    }

    public static ActionPacket decode(FriendlyByteBuf buffer) {
        return new ActionPacket(buffer.readVarInt());
    }

    public static void handle(ActionPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null && message.action() >= 0 && message.action() < ActionIds.TOTAL) {
                int action = message.action();
                if (action >= ActionIds.SLOT_BASE) {
                    PlayerActions.useBound(player, action - ActionIds.SLOT_BASE);
                } else if (action >= ActionIds.SIG_BASE) {
                    PlayerActions.signature(player, action - ActionIds.SIG_BASE);
                } else {
                    PlayerActions.handle(player, action);
                }
            }
        });
        context.setPacketHandled(true);
    }
}
