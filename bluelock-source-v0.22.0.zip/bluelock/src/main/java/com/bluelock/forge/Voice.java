package com.bluelock.forge;

import com.bluelock.common.ai.FootballCharacter;
import com.bluelock.common.ai.Roster;
import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.audio.Voices;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;

/**
 * Plays the voice of a player or bot (server side). Sounds are on the vanilla "Voice/Speech" volume slider, so every
 * player can turn them down or off in Options > Music & Sounds. A speaker stays quiet for a moment after each sound.
 */
public final class Voice {
    private static final Map<Integer, Long> LAST = new HashMap<>();

    private Voice() {
    }

    /** The voice type of this speaker. */
    public static int typeOf(LivingEntity who) {
        if (who instanceof BotEntity bot) {
            FootballCharacter c = Roster.byLook(bot.look());
            int own = c == null ? -1 : Voices.ofCharacter(c.id());
            if (own >= 0) {
                return own;
            }
            BodyDesign body = Roster.bodyForLook(bot.look());
            return Voices.fromLook(body.height(), body.build(), bot.look());
        }
        if (who instanceof ServerPlayer player) {
            BodyDesign body = ProfileSavedData.get(player.getServer()).load(player.getUUID()).map(p -> p.body()).orElse(BodyDesign.standard());
            return Voices.fromLook(body.height(), body.build(), player.getUUID().hashCode());
        }
        return 2;
    }

    /** Makes the speaker voice the event, unless they spoke too recently. chance 0..1 thins out frequent sounds. */
    public static void say(LivingEntity who, Voices.Event event, double chance) {
        if (who == null || who.level().isClientSide || ThreadLocalRandom.current().nextDouble() > chance) {
            return;
        }
        long now = who.level().getGameTime();
        Long last = LAST.get(who.getId());
        if (last != null && !Voices.mayAct(last, now, event)) {
            return;
        }
        LAST.put(who.getId(), now);
        if (LAST.size() > 400) {
            LAST.values().removeIf(t -> now - t > 600);
        }
        int type = typeOf(who);
        SoundEvent sound = ModSounds.VOICE.get(type).get(event.ordinal()).get();
        who.level().playSound(null, who.getX(), who.getY() + 1.4, who.getZ(), sound, SoundSource.VOICE,
                event.volume, Voices.pitch(type, ThreadLocalRandom.current().nextDouble()));
    }

    public static void say(LivingEntity who, Voices.Event event) {
        say(who, event, 1.0);
    }
}
