package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Server to client: this player (by entity id) plays a one-shot animation. */
public record PlayerAnimPacket(int entityId, String name) {
    public static void encode(PlayerAnimPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.entityId());
        buf.writeUtf(m.name(), 40);
    }

    public static PlayerAnimPacket decode(FriendlyByteBuf buf) {
        return new PlayerAnimPacket(buf.readVarInt(), buf.readUtf(40));
    }

    public static void handle(PlayerAnimPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientAnimBridge.playFromServer(m.entityId(), m.name())));
        context.setPacketHandled(true);
    }
}
