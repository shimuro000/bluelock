package com.bluelock.forge;

import com.bluelock.common.ai.FootballCharacter;
import com.bluelock.common.ai.Roster;
import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.appearance.HairDesign;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.BiConsumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;

/**
 * The body and features screen (client only), next to the hair maker: skin tone, eye colour and shape, eyebrows,
 * mouth, a mark (freckles, scar...), height and build. "Look like" copies the body and hair of one of the characters,
 * so a player can play as their favourite. Everything is previewed live on your own character.
 */
public class BodyMakerScreen extends Screen {
    private final Screen parent;
    private final BiConsumer<BodyDesign, HairDesign> onDone;
    private BodyDesign design;
    private HairDesign hair;
    private int copyIndex;
    private int scroll;
    private int contentBottom;
    private final List<AbstractWidget> scrolling = new ArrayList<>();
    private final List<Integer> originalY = new ArrayList<>();
    private int ticks;

    public BodyMakerScreen(Screen parent, BodyDesign start, HairDesign hair, BiConsumer<BodyDesign, HairDesign> onDone) {
        super(Component.translatable("bluelock.body.title"));
        this.parent = parent;
        this.design = start == null ? BodyDesign.standard() : start;
        this.hair = hair == null ? HairDesign.standard() : hair;
        this.onDone = onDone;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        ticks++;
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public void removed() {
        ClientBody.preview = null;
        ClientHair.preview = null;
        ClientHair.previewSpin = 0.0F;
    }

    private <T extends AbstractWidget> T scrolled(T widget) {
        scrolling.add(widget);
        originalY.add(widget.getY());
        return addRenderableWidget(widget);
    }

    private int viewTop() {
        return 56;
    }

    private int viewBottom() {
        return height - 30;
    }

    private int maxScroll() {
        return Math.max(0, contentBottom - viewBottom() + 6);
    }

    private void applyScroll() {
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
        for (int i = 0; i < scrolling.size(); i++) {
            AbstractWidget w = scrolling.get(i);
            int y = originalY.get(i) - scroll;
            w.setY(y);
            w.visible = y >= viewTop() && y + w.getHeight() <= viewBottom();
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (maxScroll() > 0 && mouseX > width / 2.0) {
            scroll -= (int) (delta * 24);
            applyScroll();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (button == 0 && mouseX < width / 2.0 && mouseY > viewTop() && mouseY < height - 30) {
            ClientHair.previewSpin += (float) dragX * 1.6F;
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    private void change(BodyDesign next) {
        design = next;
        ClientBody.preview = design;
    }

    @Override
    protected void init() {
        scrolling.clear();
        originalY.clear();
        ClientBody.preview = design;
        ClientHair.preview = hair;
        int rightX = width / 2 + 10;
        int w = Math.min(width / 2 - 30, 230);
        int y = viewTop() + 4;

        // look like a character
        List<FootballCharacter> all = Roster.all();
        FootballCharacter pick = all.get(Math.floorMod(copyIndex, all.size()));
        scrolled(new BlueButton(rightX, y, 24, 20, Component.literal("<"), b -> {
            copyIndex--;
            rebuildWidgets();
        }, BlueUi.CYAN));
        scrolled(new BlueButton(rightX + 26, y, w - 52, 20, Component.translatable("bluelock.body.copy", pick.name()), b -> {
            copyIndex++;
            rebuildWidgets();
        }, BlueUi.GOLD));
        scrolled(new BlueButton(rightX + w - 24, y, 24, 20, Component.literal(">"), b -> {
            copyIndex++;
            rebuildWidgets();
        }, BlueUi.CYAN));
        y += 24;
        scrolled(new BlueButton(rightX, y, w, 20, Component.translatable("bluelock.body.apply"), b -> {
            design = pick.body();
            hair = pick.hair();
            rebuildWidgets();
        }, BlueUi.GREEN));
        y += 28;

        // skin tone
        int columns = 5;
        int cell = Math.min(26, w / columns);
        for (int i = 0; i < BodyDesign.SKIN_TONES.length; i++) {
            int rgb = BodyDesign.SKIN_TONES[i];
            scrolled(new HairMakerScreen.Swatch(rightX + (i % columns) * cell, y + (i / columns) * cell, cell - 2, rgb, rgb == design.skin(), () -> {
                change(design.withSkin(rgb));
                rebuildWidgets();
            }));
        }
        y += ((BodyDesign.SKIN_TONES.length + columns - 1) / columns) * cell + 6;

        // eye colour
        columns = 6;
        cell = Math.min(26, w / columns);
        for (int i = 0; i < BodyDesign.EYE_COLORS.length; i++) {
            int rgb = BodyDesign.EYE_COLORS[i];
            scrolled(new HairMakerScreen.Swatch(rightX + (i % columns) * cell, y + (i / columns) * cell, cell - 2, rgb, rgb == design.eyeColor(), () -> {
                change(design.withEyeColor(rgb));
                rebuildWidgets();
            }));
        }
        y += ((BodyDesign.EYE_COLORS.length + columns - 1) / columns) * cell + 6;

        // cycling feature buttons
        scrolled(cycler(rightX, y, w, "bluelock.body.eye_style", design.eyeStyle(), BodyDesign.EYE_STYLES, v -> change(design.withEyeStyle(v))));
        y += 22;
        scrolled(cycler(rightX, y, w, "bluelock.body.brow", design.brow(), BodyDesign.BROWS, v -> change(design.withBrow(v))));
        y += 22;
        scrolled(cycler(rightX, y, w, "bluelock.body.mouth", design.mouth(), BodyDesign.MOUTHS, v -> change(design.withMouth(v))));
        y += 22;
        scrolled(cycler(rightX, y, w, "bluelock.body.mark", design.mark(), BodyDesign.MARKS, v -> change(design.withMark(v))));
        y += 26;
        scrolled(new HairMakerScreen.ValueSlider(rightX, y, w, "bluelock.body.height", design.height(), 100, v -> change(design.withHeight(v))));
        y += 21;
        scrolled(new HairMakerScreen.ValueSlider(rightX, y, w, "bluelock.body.build", design.build(), 100, v -> change(design.withBuild(v))));
        y += 26;
        int half = (w - 2) / 2;
        scrolled(new BlueButton(rightX, y, half, 18, Component.translatable("bluelock.body.random"), b -> {
            change(BodyDesign.random(new Random()));
            rebuildWidgets();
        }, BlueUi.CYAN));
        scrolled(new BlueButton(rightX + half + 2, y, half, 18, Component.translatable("bluelock.body.reset"), b -> {
            change(BodyDesign.standard());
            rebuildWidgets();
        }, BlueUi.RED));
        y += 24;
        contentBottom = y;
        applyScroll();

        addRenderableWidget(new BlueButton(rightX, height - 24, w / 2 - 2, 18, Component.translatable("bluelock.body.done"), b -> {
            onDone.accept(design, hair);
            minecraft.setScreen(parent);
        }, BlueUi.GREEN));
        addRenderableWidget(new BlueButton(rightX + w / 2 + 2, height - 24, w / 2 - 2, 18, Component.translatable("bluelock.body.cancel"),
                b -> minecraft.setScreen(parent), BlueUi.RED));
        int px = width / 4;
        addRenderableWidget(new BlueButton(px - 66, height - 24, 40, 18, Component.translatable("bluelock.hair.view_front"),
                b -> ClientHair.previewSpin = 0.0F, BlueUi.BLUE));
        addRenderableWidget(new BlueButton(px - 20, height - 24, 40, 18, Component.translatable("bluelock.hair.view_side"),
                b -> ClientHair.previewSpin = 90.0F, BlueUi.BLUE));
        addRenderableWidget(new BlueButton(px + 26, height - 24, 40, 18, Component.translatable("bluelock.hair.view_back"),
                b -> ClientHair.previewSpin = 180.0F, BlueUi.BLUE));
    }

    /** A button that shows "Label: current name" and moves to the next choice when clicked. */
    private BlueButton cycler(int x, int y, int w, String key, int current, int count, java.util.function.IntConsumer set) {
        return new BlueButton(x, y, w, 20,
                Component.translatable(key, Component.translatable(key + "." + current)),
                b -> {
                    set.accept((current + 1) % count);
                    rebuildWidgets();
                }, BlueUi.CYAN);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        BlueUi.background(g, width, height);
        BlueUi.title(g, font, width / 2 - 70, 12, 2.5F, Component.translatable("bluelock.body.title"), BlueUi.WHITE);
        BlueUi.slogan(g, font, width / 2, 40, ticks);
        BlueUi.panel(g, 20, 52, width / 2 - 30, height - 82);
        int px = width / 4;
        if (minecraft != null && minecraft.player != null) {
            int scale = Math.max(30, Math.min(70, (height - 140) / 2));
            g.pose().pushPose();
            g.pose().translate(px, 0.0F, 50.0F);
            g.pose().mulPose(Axis.YP.rotationDegrees(ClientHair.previewSpin));
            g.pose().translate(-px, 0.0F, -50.0F);
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, px, height - 52, scale, 0.0F, 0.0F, minecraft.player);
            g.pose().popPose();
        }
        g.drawCenteredString(font, Component.translatable("bluelock.hair.drag_hint"), px, 60, BlueUi.GREY);
        if (maxScroll() > 0) {
            int trackH = viewBottom() - viewTop();
            int thumbH = Math.max(14, trackH * trackH / (trackH + maxScroll()));
            int thumbY = viewTop() + (trackH - thumbH) * scroll / maxScroll();
            g.fill(width - 8, viewTop(), width - 5, viewBottom(), 0x55000000);
            g.fill(width - 8, thumbY, width - 5, thumbY + thumbH, BlueUi.CYAN);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }
}
