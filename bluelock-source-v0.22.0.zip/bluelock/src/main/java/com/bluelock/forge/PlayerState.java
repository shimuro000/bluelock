package com.bluelock.forge;

import com.bluelock.common.action.EgoPool;
import com.bluelock.common.action.StaminaPool;

/** Short-lived, server-side state of one player: stamina, ego, cooldowns and move effects. Not saved. */
final class PlayerState {
    final StaminaPool stamina;
    final EgoPool ego;
    final long[] readyAt = new long[ActionIds.COUNT];
    final int[] cooldownLength = new int[ActionIds.COUNT];
    long tackleReadyAt;
    long immuneUntil;
    long noLossUntil;
    long slideUntil;
    double slideX;
    double slideZ;
    int feintSide = 1;

    /** Skill effects that last a while (game ticks; 0 = off). */
    long composedUntil;      // composure_focus: steadier passes and shots, ball does not slip away
    long lanesUntil;         // passing_lane_read / advanced_field_vision: wider pass aim, better accuracy
    long visionUntil;        // advanced_field_vision: the strongest version
    long interceptUntil;     // interception_read: a much bigger reach for loose balls
    long diveUntil;          // dive: arms out, bigger reach for the ball
    long shadowUntil;        // shadow_marking: marking sprint
    long pressureReadyAt;    // pressure_finisher fires by itself on shots: its own cooldown

    /** Signature techniques: effects that last a while and each one's own cooldown. */
    long trapUntil;
    long monsterUntil;
    long monsterNext;
    final long[] sigReadyAt = new long[ActionIds.SIGNATURE.length];
    final int[] sigLength = new int[ActionIds.SIGNATURE.length];

    /** The three direct shot tiers each have their own cooldown (index = DirectShot.Tier ordinal). */
    final long[] directReadyAt = new long[3];
    final int[] directCooldownLength = new int[3];

    void startCooldown(int action, long now, int ticks) {
        readyAt[action] = now + ticks;
        cooldownLength[action] = Math.max(1, ticks);
    }

    PlayerState(int staminaStat, int egoStat) {
        this.stamina = new StaminaPool(staminaStat);
        this.ego = new EgoPool(egoStat);
    }
}
