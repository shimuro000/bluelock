package com.bluelock.forge;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Where the Blue Lock campus stands (saved with the world, file data/bluelock_campus.dat), so places can be found again. */
public final class CampusSavedData extends SavedData {
    public static final String NAME = "bluelock_campus";

    private boolean present;
    private int originX;
    private int floorY;
    private int originZ;
    private int facing;      // Direction.get2DDataValue of the forward direction
    private String dimension = "";

    public static CampusSavedData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(CampusSavedData::loadFromTag, CampusSavedData::new, NAME);
    }

    public static CampusSavedData loadFromTag(CompoundTag t) {
        CampusSavedData d = new CampusSavedData();
        d.present = t.getBoolean("present");
        d.originX = t.getInt("x");
        d.floorY = t.getInt("y");
        d.originZ = t.getInt("z");
        d.facing = t.getInt("facing");
        d.dimension = t.getString("dimension");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putBoolean("present", present);
        t.putInt("x", originX);
        t.putInt("y", floorY);
        t.putInt("z", originZ);
        t.putInt("facing", facing);
        t.putString("dimension", dimension);
        return t;
    }

    public void remember(int x, int y, int z, int facing2d, String dimensionId) {
        present = true;
        originX = x;
        floorY = y;
        originZ = z;
        facing = facing2d;
        dimension = dimensionId;
        setDirty();
    }

    public boolean present() { return present; }
    public int originX() { return originX; }
    public int floorY() { return floorY; }
    public int originZ() { return originZ; }
    public int facing() { return facing; }
    public String dimension() { return dimension; }
}
