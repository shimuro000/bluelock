package com.bluelock.forge;

import com.bluelock.common.action.DirectShot;
import com.bluelock.common.profile.PlayerProfile;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;

/**
 * What the client highlights on screen: the direct-shot crosshair on a loose ball within two blocks, and the
 * markers placed by the vision skills. This class only decides WHAT to show; ClientRender draws it. Client only.
 */
public final class ClientFx {
    public static final int KIND_OPEN_MATE = 0;
    public static final int KIND_OPPONENT = 1;
    public static final int KIND_BALL = 2;
    public static final int KIND_MARKED = 3;

    private record Mark(int kind, long until) {
    }

    /** One thing to draw: an entity marker. */
    public record Marker(Entity entity, int kind) {
    }

    private static final Map<Integer, Mark> MARKS = new HashMap<>();

    private ClientFx() {
    }

    /** Called from SkillFxPacket. */
    public static void mark(int kind, int[] ids, int ticks) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return;
        }
        long until = minecraft.level.getGameTime() + ticks;
        for (int id : ids) {
            MARKS.put(id, new Mark(kind, until));
        }
    }

    /** Once per client tick: forget marks that ran out or whose entity is gone. */
    public static void tick() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            MARKS.clear();
            return;
        }
        long now = minecraft.level.getGameTime();
        MARKS.entrySet().removeIf(e -> now >= e.getValue().until() || minecraft.level.getEntity(e.getKey()) == null);
    }

    public static List<Marker> markers() {
        List<Marker> list = new ArrayList<>();
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return list;
        }
        for (Map.Entry<Integer, Mark> e : MARKS.entrySet()) {
            Entity entity = minecraft.level.getEntity(e.getKey());
            if (entity != null) {
                list.add(new Marker(entity, e.getValue().kind()));
            }
        }
        return list;
    }

    /** The tier the direct-shot key would use right now (0 normal, 1 precision, 2 awakening), or -1 if the player owns none. */
    public static int bestOwnedTier() {
        PlayerProfile profile = ClientMenuState.profile;
        if (profile == null) {
            return -1;
        }
        if (profile.isUnlocked(DirectShot.Tier.AWAKENING.skillId())) {
            return 2;
        }
        if (profile.isUnlocked(DirectShot.Tier.PRECISION.skillId())) {
            return 1;
        }
        return profile.isUnlocked(DirectShot.Tier.NORMAL.skillId()) ? 0 : -1;
    }

    /**
     * The loose ball the direct-shot crosshair should sit on: the player owns a direct shot skill and a ball
     * that nobody carries is within two blocks (on the ground or in the air). Null when there is none.
     */
    public static BallEntity crosshairBall() {
        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (minecraft.level == null || player == null || player.isSpectator() || bestOwnedTier() < 0) {
            return null;
        }
        BallEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (BallEntity ball : minecraft.level.getEntitiesOfClass(BallEntity.class,
                player.getBoundingBox().inflate(DirectShot.REACH + 1.0, 3.0, DirectShot.REACH + 1.0))) {
            double horizontal = Math.hypot(ball.getX() - player.getX(), ball.getZ() - player.getZ());
            if (DirectShot.canStrike(horizontal, ball.getY() - player.getY(), ball.carrierId() >= 0) && horizontal < bestDist) {
                bestDist = horizontal;
                best = ball;
            }
        }
        return best;
    }
}
