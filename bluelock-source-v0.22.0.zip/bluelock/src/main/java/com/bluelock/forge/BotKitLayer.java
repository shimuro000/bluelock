package com.bluelock.forge;

import com.bluelock.common.ai.Roster;
import com.bluelock.common.appearance.KitDesign;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;

/** The football kit on the plain (non-animated) bot (client only). */
public final class BotKitLayer extends RenderLayer<BotEntity, HumanoidModel<BotEntity>> {
    public BotKitLayer(RenderLayerParent<BotEntity, HumanoidModel<BotEntity>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffer, int light, BotEntity bot,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (bot.isInvisible()) {
            return;
        }
        KitDesign kit = bot.kit();
        HumanoidModel<BotEntity> m = getParentModel();
        KitLayerHelper.draw(ps, buffer, Roster.bodyForLook(bot.look()), kit, light, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg);
    }
}
