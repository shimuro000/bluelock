package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Draws the direct-shot crosshair on the ball and the skill markers on players, as simple coloured lines in the
 * world. Client only.
 */
@Mod.EventBusSubscriber(modid = BlueLockConstants.MOD_ID, value = Dist.CLIENT)
public final class ClientRender {
    private static final int[][] TIER_COLORS = {{120, 220, 255}, {255, 215, 60}, {255, 80, 40}};
    private static final int[][] KIND_COLORS = {{80, 255, 120}, {255, 70, 70}, {255, 215, 60}, {255, 150, 40}};

    private ClientRender() {
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null) {
            return;
        }
        BallEntity ball = ClientFx.crosshairBall();
        java.util.List<ClientFx.Marker> markers = ClientFx.markers();
        if (ball == null && markers.isEmpty()) {
            return;
        }
        float partial = event.getPartialTick();
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        Vector3f left = camera.getLeftVector();
        Vector3f up = camera.getUpVector();
        PoseStack pose = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = minecraft.renderBuffers().bufferSource();
        VertexConsumer lines = buffers.getBuffer(RenderType.lines());
        pose.pushPose();
        PoseStack.Pose last = pose.last();
        Matrix4f matrix = last.pose();
        Matrix3f normal = last.normal();
        float time = (minecraft.level.getGameTime() + partial);

        if (ball != null) {
            Vec3 p = ball.getPosition(partial).add(0, 0.2, 0).subtract(cam);
            int[] c = TIER_COLORS[Math.max(0, ClientFx.bestOwnedTier())];
            float pulse = 0.55F + 0.06F * (float) Math.sin(time * 0.5F);
            billboardRing(lines, matrix, normal, p, left, up, pulse, 28, c);
            billboardRing(lines, matrix, normal, p, left, up, pulse * 0.45F, 16, c);
            for (int i = 0; i < 4; i++) {
                double a = i * Math.PI / 2 + 0.0;
                float cx = (float) Math.cos(a);
                float cy = (float) Math.sin(a);
                float x0 = (float) p.x + (left.x() * cx + up.x() * cy) * (pulse * 0.7F);
                float y0 = (float) p.y + (left.y() * cx + up.y() * cy) * (pulse * 0.7F);
                float z0 = (float) p.z + (left.z() * cx + up.z() * cy) * (pulse * 0.7F);
                float x1 = (float) p.x + (left.x() * cx + up.x() * cy) * (pulse * 1.35F);
                float y1 = (float) p.y + (left.y() * cx + up.y() * cy) * (pulse * 1.35F);
                float z1 = (float) p.z + (left.z() * cx + up.z() * cy) * (pulse * 1.35F);
                line(lines, matrix, normal, x0, y0, z0, x1, y1, z1, c);
            }
        }

        for (ClientFx.Marker marker : markers) {
            Vec3 feet = marker.entity().getPosition(partial).subtract(cam);
            int[] c = KIND_COLORS[Math.max(0, Math.min(KIND_COLORS.length - 1, marker.kind()))];
            if (marker.kind() == ClientFx.KIND_BALL) {
                billboardRing(lines, matrix, normal, feet.add(0, 0.2, 0), left, up, 0.7F, 24, c);
            } else {
                groundRing(lines, matrix, normal, feet.add(0, 0.06, 0), 0.8F + 0.08F * (float) Math.sin(time * 0.4F), 24, c);
                Vec3 head = feet.add(0, marker.entity().getBbHeight() + 0.55, 0);
                billboardRing(lines, matrix, normal, head, left, up, 0.22F, 4, c);
            }
        }
        pose.popPose();
        buffers.endBatch(RenderType.lines());
    }

    private static void billboardRing(VertexConsumer vc, Matrix4f m, Matrix3f n, Vec3 centre, Vector3f left, Vector3f up,
                                      float radius, int segments, int[] c) {
        for (int i = 0; i < segments; i++) {
            double a0 = 2 * Math.PI * i / segments;
            double a1 = 2 * Math.PI * (i + 1) / segments;
            float c0 = (float) Math.cos(a0) * radius;
            float s0 = (float) Math.sin(a0) * radius;
            float c1 = (float) Math.cos(a1) * radius;
            float s1 = (float) Math.sin(a1) * radius;
            line(vc, m, n,
                    (float) centre.x + left.x() * c0 + up.x() * s0, (float) centre.y + left.y() * c0 + up.y() * s0, (float) centre.z + left.z() * c0 + up.z() * s0,
                    (float) centre.x + left.x() * c1 + up.x() * s1, (float) centre.y + left.y() * c1 + up.y() * s1, (float) centre.z + left.z() * c1 + up.z() * s1,
                    c);
        }
    }

    private static void groundRing(VertexConsumer vc, Matrix4f m, Matrix3f n, Vec3 centre, float radius, int segments, int[] c) {
        for (int i = 0; i < segments; i++) {
            double a0 = 2 * Math.PI * i / segments;
            double a1 = 2 * Math.PI * (i + 1) / segments;
            line(vc, m, n,
                    (float) (centre.x + Math.cos(a0) * radius), (float) centre.y, (float) (centre.z + Math.sin(a0) * radius),
                    (float) (centre.x + Math.cos(a1) * radius), (float) centre.y, (float) (centre.z + Math.sin(a1) * radius),
                    c);
        }
    }

    private static void line(VertexConsumer vc, Matrix4f m, Matrix3f n, float x0, float y0, float z0, float x1, float y1, float z1, int[] c) {
        float dx = x1 - x0;
        float dy = y1 - y0;
        float dz = z1 - z0;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-6F) {
            return;
        }
        dx /= len;
        dy /= len;
        dz /= len;
        vc.vertex(m, x0, y0, z0).color(c[0], c[1], c[2], 255).normal(n, dx, dy, dz).endVertex();
        vc.vertex(m, x1, y1, z1).color(c[0], c[1], c[2], 255).normal(n, dx, dy, dz).endVertex();
    }
}
