package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Client to server: the player has read this scene; go on to the next beat. */
public record StoryAdvancePacket(String sceneId) {
    public static void encode(StoryAdvancePacket m, FriendlyByteBuf buf) {
        buf.writeUtf(m.sceneId(), 40);
    }

    public static StoryAdvancePacket decode(FriendlyByteBuf buf) {
        return new StoryAdvancePacket(buf.readUtf(40));
    }

    public static void handle(StoryAdvancePacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        ServerPlayer player = context.getSender();
        context.enqueueWork(() -> {
            if (player != null) {
                StoryManager.advance(player, m.sceneId());
            }
        });
        context.setPacketHandled(true);
    }
}
