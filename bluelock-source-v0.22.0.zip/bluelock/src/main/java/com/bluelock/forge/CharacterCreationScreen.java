package com.bluelock.forge;

import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.content.Position;
import com.bluelock.common.profile.Archetype;
import com.bluelock.common.profile.CharacterRoll;
import com.bluelock.common.profile.Personality;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;

/**
 * "Enter Blue Lock": name, favourite position, football background and personality are chosen here;
 * the dominant foot (60% right, 30% left, 10% both) and the talent (25% Genius) are rolled by the server (client only).
 */
public class CharacterCreationScreen extends Screen {
    private static final Position[] POSITIONS = Position.values();
    private static final Archetype[] ARCHETYPES = Archetype.values();
    private static final Personality[] PERSONALITIES = Personality.values();

    private EditBox nameBox;
    private int positionIndex = java.util.Arrays.asList(POSITIONS).indexOf(Position.ST);
    private int archetypeIndex;
    private int personalityIndex;
    private HairDesign hair = HairDesign.standard();
    private BodyDesign body = BodyDesign.standard();
    private String error = "";
    private int scroll;
    private int contentBottom;
    private final java.util.List<AbstractWidget> scrolling = new java.util.ArrayList<>();
    private final java.util.List<Integer> originalY = new java.util.ArrayList<>();
    private int ticks;
    private int lastVersion = -1;
    private static final int DESTINY_HEIGHT = 112;
    private int destinyY;
    private boolean spinning;
    private int spinTicks;

    public CharacterCreationScreen() {
        super(Component.translatable("bluelock.create.title"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private void rollPressed() {
        if (ClientMenuState.rolled || spinning) {
            return;
        }
        spinning = true;
        spinTicks = 0;
        BlueLockNetwork.CHANNEL.sendToServer(new MenuCommandPacket("roll"));
        rebuildWidgets();
    }

    @Override
    public void tick() {
        ticks++;
        if (spinning) {
            spinTicks++;
            if ((spinTicks >= 70 && ClientMenuState.rolled) || spinTicks > 240) {
                spinning = false;
                rebuildWidgets();
            }
        }
        if (ticks == 1 || ticks % 40 == 0) {
            BlueLockNetwork.CHANNEL.sendToServer(new MenuRequestPacket());
        }
        if (lastVersion != ClientMenuState.version) {
            lastVersion = ClientMenuState.version;
            if (ClientMenuState.hasProfile) {
                onClose();   // the character exists now
            }
        }
    }

    private <T extends AbstractWidget> T scrolled(T widget) {
        scrolling.add(widget);
        originalY.add(widget.getY());
        return addRenderableWidget(widget);
    }

    private int viewTop() {
        return 62;
    }

    private int viewBottom() {
        return height - 30;
    }

    private int maxScroll() {
        return Math.max(0, contentBottom - viewBottom() + 6);
    }

    private void applyScroll() {
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
        for (int i = 0; i < scrolling.size(); i++) {
            AbstractWidget w = scrolling.get(i);
            int y = originalY.get(i) - scroll;
            w.setY(y);
            w.visible = y >= viewTop() && y + w.getHeight() <= viewBottom();
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (maxScroll() > 0) {
            scroll -= (int) (delta * 24);
            applyScroll();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    /** The hair on the preview is the one being made here; it is cleared again when the screen goes away. */
    @Override
    public void removed() {
        ClientHair.preview = null;
        ClientBody.preview = null;
    }

    @Override
    protected void init() {
        ClientHair.preview = hair;
        ClientBody.preview = body;
        scrolling.clear();
        originalY.clear();
        int rightX = width / 2 + 10;
        int w = Math.min(width / 2 - 30, 210);
        int y = 70;
        String previous = nameBox == null ? "" : nameBox.getValue();
        nameBox = new EditBox(font, rightX, y, w, 20, Component.translatable("bluelock.create.name"));
        nameBox.setMaxLength(16);
        nameBox.setValue(previous);
        nameBox.setHint(Component.translatable("bluelock.create.name_hint"));
        scrolled(nameBox);
        setInitialFocus(nameBox);
        y += 26;
        scrolled(new BlueButton(rightX, y, w, 20, Component.translatable("bluelock.create.position", POSITIONS[positionIndex].name()),
                b -> {
                    positionIndex = (positionIndex + 1) % POSITIONS.length;
                    rebuildWidgets();
                }, BlueUi.CYAN));
        y += 24;
        scrolled(new BlueButton(rightX, y, w, 20,
                Component.translatable("bluelock.create.archetype", Component.translatable("bluelock.archetype." + ARCHETYPES[archetypeIndex].name().toLowerCase(Locale.ROOT))),
                b -> {
                    archetypeIndex = (archetypeIndex + 1) % ARCHETYPES.length;
                    rebuildWidgets();
                }, BlueUi.CYAN));
        y += 24;
        scrolled(new BlueButton(rightX, y, w, 20,
                Component.translatable("bluelock.create.personality", Component.translatable("bluelock.personality." + PERSONALITIES[personalityIndex].name().toLowerCase(Locale.ROOT))),
                b -> {
                    personalityIndex = (personalityIndex + 1) % PERSONALITIES.length;
                    rebuildWidgets();
                }, BlueUi.CYAN));
        y += 24;
        scrolled(new BlueButton(rightX, y, w, 20, Component.translatable("bluelock.create.hair"),
                b -> minecraft.setScreen(new HairMakerScreen(this, hair, made -> hair = made)), BlueUi.GOLD));
        y += 24;
        scrolled(new BlueButton(rightX, y, w, 20, Component.translatable("bluelock.create.body"),
                b -> minecraft.setScreen(new BodyMakerScreen(this, body, hair, (madeBody, madeHair) -> {
                    body = madeBody;
                    hair = madeHair;
                })), BlueUi.GOLD));
        y += 28;
        destinyY = y;
        BlueButton roll = scrolled(new BlueButton(rightX + w - 96, y + 6, 90, 18, Component.translatable("bluelock.create.roll"), b -> rollPressed(), BlueUi.GOLD));
        roll.active = !ClientMenuState.rolled && !spinning;
        y += DESTINY_HEIGHT + 8;
        BlueButton confirmButton = scrolled(new BlueButton(rightX, y, w, 24, Component.translatable("bluelock.create.confirm"), b -> confirm(), BlueUi.GREEN));
        confirmButton.active = ClientMenuState.rolled && !spinning;
        contentBottom = y + 24;
        applyScroll();
        addRenderableWidget(new BlueButton(width - 70, height - 24, 60, 16, Component.translatable("bluelock.menu.close"), b -> onClose(), BlueUi.RED));
    }

    private void confirm() {
        String name = nameBox.getValue().trim();
        if (name.length() < 2) {
            error = Component.translatable("bluelock.error.name_too_short").getString();
            return;
        }
        BlueLockNetwork.CHANNEL.sendToServer(new CreatePacket(name,
                ARCHETYPES[archetypeIndex].name().toLowerCase(Locale.ROOT),
                PERSONALITIES[personalityIndex].name().toLowerCase(Locale.ROOT),
                POSITIONS[positionIndex].name().toLowerCase(Locale.ROOT), hair.toInts(), body.toInts()));
        error = "";
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        BlueUi.background(g, width, height);
        BlueUi.title(g, font, width / 2 - 100, 12, 2.5F, Component.translatable("bluelock.create.title"), BlueUi.WHITE);
        BlueUi.slogan(g, font, width / 2, 40, ticks);

        int previewX = width / 4;
        BlueUi.panel(g, 20, 56, width / 2 - 30, height - 90);
        if (minecraft != null && minecraft.player != null) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, previewX, height - 70, 60, previewX - mouseX, height - 160 - mouseY, minecraft.player);
        }

        // the destiny panel: the foot and talent rolls, spinning when Roll is pressed
        int rightX = width / 2 + 10;
        int w = Math.min(width / 2 - 30, 210);
        int y = destinyY - scroll;
        if (y >= viewTop() && y + DESTINY_HEIGHT <= viewBottom()) {
            renderDestiny(g, rightX, y, w);
        }
        if (!error.isEmpty()) {
            g.drawString(font, error, rightX, height - 24, BlueUi.RED, true);
        }
        if (maxScroll() > 0) {
            int trackH = viewBottom() - viewTop();
            int thumbH = Math.max(14, trackH * trackH / (trackH + maxScroll()));
            int thumbY = viewTop() + (trackH - thumbH) * scroll / maxScroll();
            g.fill(width - 8, viewTop(), width - 5, viewBottom(), 0x55000000);
            g.fill(width - 8, thumbY, width - 5, thumbY + thumbH, BlueUi.CYAN);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    private static final String[] FOOT_NAMES = {"RIGHT", "LEFT", "BOTH"};

    private void renderDestiny(GuiGraphics g, int rightX, int y, int w) {
        BlueUi.panel(g, rightX, y, w, DESTINY_HEIGHT);
        g.drawString(font, Component.translatable("bluelock.create.destiny"), rightX + 6, y + 8, BlueUi.CYAN, true);
        boolean rolled = ClientMenuState.rolled;
        boolean footLocked = rolled && (!spinning || spinTicks >= 38);
        boolean talentLocked = rolled && (!spinning || spinTicks >= 62);
        // the foot reel
        String footName;
        if (footLocked) {
            footName = ClientMenuState.rollFoot;
        } else if (spinning) {
            footName = FOOT_NAMES[(spinTicks / 3) % FOOT_NAMES.length];
        } else {
            footName = null;
        }
        Component foot = footName == null ? Component.translatable("bluelock.create.unrolled")
                : Component.translatable("bluelock.foot." + footName.toLowerCase(Locale.ROOT));
        g.drawString(font, Component.translatable("bluelock.create.foot", foot), rightX + 6, y + 24, footLocked ? BlueUi.WHITE : BlueUi.GREY, true);
        // the talent reel: random numbers that slow down, then the real one
        int shown = ClientMenuState.rollPercent;
        if (!talentLocked) {
            int slow = Math.max(1, spinTicks / 10);
            int seed = (spinning ? spinTicks / slow : 0) * 7919 + 13;
            shown = spinning ? 10 + Math.floorMod(seed * 31 + seed / 3, 91) : 0;
        }
        boolean genius = talentLocked && shown >= com.bluelock.common.profile.TalentRoll.GENIUS_FROM;
        int color = !talentLocked ? BlueUi.GREY : genius ? BlueUi.GOLD : BlueUi.WHITE;
        g.drawString(font, Component.translatable("bluelock.create.talent_label"), rightX + 6, y + 40, BlueUi.WHITE, true);
        Component number = talentLocked || spinning ? Component.literal(shown + "%") : Component.literal("--%");
        BlueUi.title(g, font, rightX + 6, y + 52, 2.0F, number, color);
        int barX = rightX + 66;
        BlueUi.bar(g, barX, y + 56, w - 78, 6, talentLocked || spinning ? shown : 0, genius ? BlueUi.GOLD : BlueUi.CYAN);
        if (talentLocked) {
            g.drawString(font, Component.translatable(com.bluelock.common.profile.TalentRoll.bandKey(shown)), rightX + 6, y + 72,
                    genius ? BlueUi.GOLD : BlueUi.WHITE, true);
            double atLeast = com.bluelock.common.profile.TalentRoll.chanceAtLeast(shown) * 100;
            g.drawString(font, Component.translatable("bluelock.create.rarity", String.format(Locale.ROOT, "%.1f", atLeast)),
                    rightX + 6, y + 84, BlueUi.GREY, false);
        } else {
            g.drawString(font, Component.translatable(spinning ? "bluelock.create.rolling" : "bluelock.create.press_roll"), rightX + 6, y + 72, BlueUi.GREY, true);
        }
        g.drawString(font, Component.translatable("bluelock.create.odds_new"), rightX + 6, y + 98, BlueUi.GREY, false);
    }
}
