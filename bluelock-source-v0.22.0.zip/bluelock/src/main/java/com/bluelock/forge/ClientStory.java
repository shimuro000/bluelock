package com.bluelock.forge;

/** The scene the server wants the client to show; ClientEvents opens the dialogue screen when it sees one. Plain data. */
public final class ClientStory {
    public static String pending;

    private ClientStory() {
    }

    public static String take() {
        String id = pending;
        pending = null;
        return id;
    }
}
