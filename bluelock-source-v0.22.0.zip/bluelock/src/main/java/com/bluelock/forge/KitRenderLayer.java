package com.bluelock.forge;

import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.appearance.KitDesign;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;

/** The football kit on players who are in a match (client only). */
public final class KitRenderLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public KitRenderLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffer, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (player.isInvisible() || player.isSpectator()) {
            return;
        }
        KitDesign kit = ClientKit.get(player.getUUID());
        BodyDesign look = ClientBody.designFor(player.getUUID());
        if (kit == null && look == null) {
            return;
        }
        PlayerModel<AbstractClientPlayer> m = getParentModel();
        KitLayerHelper.draw(ps, buffer, look, kit, light, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg);
    }
}
