package com.bluelock.forge;

import com.bluelock.common.appearance.HairDesign;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.world.entity.EquipmentSlot;

/**
 * Draws the 3D hair on a player's head (client only). The hair is a set of small tapered blocks made by
 * {@link HairModel}; they are drawn on a plain white texture and coloured per corner, so tips can fade into a
 * second colour. The layer follows the head of the player model, so it moves with every animation.
 */
public final class HairRenderLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {

    public HairRenderLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    /** The hair to draw on this player: the preview for the local player while a screen edits it, else what the server sent. */
    private static HairDesign designFor(AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        boolean local = mc.player != null && player.getUUID().equals(mc.player.getUUID());
        if (local && ClientHair.preview != null) {
            return ClientHair.preview;
        }
        HairDesign design = ClientHair.get(player.getUUID());
        if (design == null && local && ClientMenuState.profile != null) {
            design = ClientMenuState.profile.hair();
        }
        return design;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (player.isInvisible() || player.isSpectator() || !player.getItemBySlot(EquipmentSlot.HEAD).isEmpty()) {
            return;
        }
        HairDesign design = designFor(player);
        com.bluelock.common.appearance.BodyDesign look = ClientBody.designFor(player.getUUID());
        if (design == null && look == null) {
            return;
        }
        poseStack.pushPose();
        getParentModel().head.translateAndRotate(poseStack);
        poseStack.scale(1.0F / 16.0F, 1.0F / 16.0F, 1.0F / 16.0F);
        if (look != null) {
            BodyDraw.head(poseStack, buffer, look, packedLight);
        }
        if (design != null) {
            HairDraw.draw(poseStack, buffer, design, packedLight);
        }
        poseStack.popPose();
    }
}
