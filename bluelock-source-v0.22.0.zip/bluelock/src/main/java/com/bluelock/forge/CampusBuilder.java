package com.bluelock.forge;

import com.bluelock.common.campus.CampusPlan;
import com.bluelock.common.pitch.PitchPlacement;
import com.bluelock.common.pitch.PitchSize;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Builds the Blue Lock campus from {@link CampusPlan} a few thousand blocks per tick (so the game does not freeze),
 * builds the stadium pitch at the end and remembers where everything is, so {@link #go} can take players to any place.
 * The plan's frame (x right, z forward) is turned to face the way the player was looking.
 */
public final class CampusBuilder {
    private static final int BLOCKS_PER_TICK = 24000;
    private static final Direction[] HORIZONTAL = {Direction.SOUTH, Direction.WEST, Direction.NORTH, Direction.EAST};

    private static Job job;

    private CampusBuilder() {
    }

    private static final class Job {
        final ServerLevel level;
        final int originX;
        final int floorY;
        final int originZ;
        final Direction forward;
        final UUID owner;
        final long total;
        int fill;
        long cell;
        long done;
        int lastReport;

        Job(ServerLevel level, int originX, int floorY, int originZ, Direction forward, UUID owner) {
            this.level = level;
            this.originX = originX;
            this.floorY = floorY;
            this.originZ = originZ;
            this.forward = forward;
            this.owner = owner;
            this.total = CampusPlan.totalVolume();
        }
    }

    public static boolean busy() {
        return job != null;
    }

    public static boolean built(MinecraftServer server) {
        return CampusSavedData.get(server).present();
    }

    /** Starts building so that the front door is 5 blocks ahead of the player, in the direction they look. */
    public static boolean start(ServerPlayer player) {
        if (job != null) {
            return false;
        }
        Direction forward = player.getDirection();
        if (forward.getAxis() == Direction.Axis.Y) {
            forward = Direction.NORTH;
        }
        BlockPos feet = player.blockPosition();
        int ox = feet.getX() + forward.getStepX() * 5;
        int oz = feet.getZ() + forward.getStepZ() * 5;
        job = new Job((ServerLevel) player.level(), ox, feet.getY() - 1, oz, forward, player.getUUID());
        return true;
    }

    private static int worldX(Job j, int x, int z) {
        Direction right = j.forward.getClockWise();
        return j.originX + j.forward.getStepX() * z + right.getStepX() * x;
    }

    private static int worldZ(Job j, int x, int z) {
        Direction right = j.forward.getClockWise();
        return j.originZ + j.forward.getStepZ() * z + right.getStepZ() * x;
    }

    private static BlockState state(CampusPlan.Mat mat) {
        return switch (mat) {
            case AIR -> Blocks.AIR.defaultBlockState();
            case FOUND -> Blocks.DIRT.defaultBlockState();
            case PAVE -> Blocks.STONE_BRICKS.defaultBlockState();
            case BLACK -> Blocks.BLACK_CONCRETE.defaultBlockState();
            case GRAY -> Blocks.GRAY_CONCRETE.defaultBlockState();
            case GRAY_LIGHT -> Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState();
            case FLOOR -> Blocks.POLISHED_ANDESITE.defaultBlockState();
            case FLOOR_DARK -> Blocks.DEEPSLATE_TILES.defaultBlockState();
            case GLASS -> Blocks.GLASS.defaultBlockState();
            case LIGHT -> Blocks.SEA_LANTERN.defaultBlockState();
            case BLUE -> Blocks.BLUE_CONCRETE.defaultBlockState();
            case CYAN -> Blocks.LIGHT_BLUE_CONCRETE.defaultBlockState();
            case WHITE -> Blocks.WHITE_CONCRETE.defaultBlockState();
            case RED -> Blocks.RED_CONCRETE.defaultBlockState();
            case GOLD -> Blocks.GOLD_BLOCK.defaultBlockState();
            case ORANGE -> Blocks.ORANGE_CONCRETE.defaultBlockState();
            case WOOD -> Blocks.SPRUCE_PLANKS.defaultBlockState();
            case SLAB -> Blocks.SMOOTH_STONE_SLAB.defaultBlockState();
            case BARS -> Blocks.IRON_BARS.defaultBlockState();
            case IRON -> Blocks.IRON_BLOCK.defaultBlockState();
            case WOOL_BLUE -> Blocks.BLUE_WOOL.defaultBlockState();
            case WOOL_WHITE -> Blocks.WHITE_WOOL.defaultBlockState();
            case SKIN -> Blocks.TERRACOTTA.defaultBlockState();
        };
    }

    public static void tick(MinecraftServer server) {
        if (job == null) {
            return;
        }
        Job j = job;
        List<CampusPlan.Fill> fills = CampusPlan.fills();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int budget = BLOCKS_PER_TICK;
        while (budget > 0 && j.fill < fills.size()) {
            CampusPlan.Fill f = fills.get(j.fill);
            long volume = f.volume();
            if (j.cell >= volume) {
                j.fill++;
                j.cell = 0;
                continue;
            }
            int sx = f.x1() - f.x0() + 1;
            int sy = f.y1() - f.y0() + 1;
            int x = f.x0() + (int) (j.cell % sx);
            int y = f.y0() + (int) ((j.cell / sx) % sy);
            int z = f.z0() + (int) (j.cell / ((long) sx * sy));
            j.cell++;
            j.done++;
            pos.set(worldX(j, x, z), j.floorY + y, worldZ(j, x, z));
            BlockState current = j.level.getBlockState(pos);
            switch (f.mat()) {
                case AIR -> {
                    if (!current.isAir()) {
                        j.level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                    }
                    budget--;
                }
                case FOUND -> {
                    if (current.isAir() || !current.getFluidState().isEmpty() || current.canBeReplaced()) {
                        j.level.setBlock(pos, state(f.mat()), Block.UPDATE_CLIENTS);
                    }
                    budget--;
                }
                case BARS -> {
                    j.level.setBlock(pos, state(f.mat()), Block.UPDATE_ALL);
                    budget -= 2;
                }
                default -> {
                    j.level.setBlock(pos, state(f.mat()), Block.UPDATE_CLIENTS);
                    budget -= 2;
                }
            }
        }
        int percent = (int) (j.done * 100 / Math.max(1, j.total));
        if (percent / 25 > j.lastReport / 25 && percent < 100) {
            tell(server, j, Component.translatable("bluelock.campus.progress", percent / 25 * 25));
        }
        j.lastReport = percent;
        if (j.fill >= fills.size()) {
            finish(server, j);
            job = null;
        }
    }

    private static void finish(MinecraftServer server, Job j) {
        // the stadium pitch, centred on the plan's pitch spot, running away from the tunnel
        int cx = worldX(j, 0, CampusPlan.PITCH_CENTRE_Z);
        int cz = worldZ(j, 0, CampusPlan.PITCH_CENTRE_Z);
        PitchPlacement placement = PitchBuilder.build(j.level, new BlockPos(cx, j.floorY + 1, cz), j.forward, PitchSize.FULL.layout());
        MatchManager.adoptPitch(j.level, placement);
        // a small practice pitch in front of the building, running across it (it is for free play, not for matches)
        int px = worldX(j, 0, CampusPlan.PRACTICE_CENTRE_Z);
        int pz = worldZ(j, 0, CampusPlan.PRACTICE_CENTRE_Z);
        PitchBuilder.build(j.level, new BlockPos(px, j.floorY + 1, pz), j.forward.getClockWise(), PitchSize.PRACTICE.layout());
        CampusSavedData.get(server).remember(j.originX, j.floorY, j.originZ, j.forward.get2DDataValue(), j.level.dimension().location().toString());
        tell(server, j, Component.translatable("bluelock.campus.done"));
    }

    private static void tell(MinecraftServer server, Job j, Component message) {
        ServerPlayer player = server.getPlayerList().getPlayer(j.owner);
        if (player != null) {
            player.sendSystemMessage(message);
        }
    }

    /** Distance in blocks from the player to a campus place, or -1 when there is no campus (or it is in another dimension). */
    public static double distanceTo(ServerPlayer player, String placeId) {
        CampusSavedData data = CampusSavedData.get(player.getServer());
        CampusPlan.Place place = CampusPlan.place(placeId);
        if (!data.present() || place == null || !player.level().dimension().location().toString().equals(data.dimension())) {
            return -1;
        }
        Direction forward = Direction.from2DDataValue(data.facing());
        Direction right = forward.getClockWise();
        double x = data.originX() + forward.getStepX() * place.z() + right.getStepX() * place.x() + 0.5;
        double z = data.originZ() + forward.getStepZ() * place.z() + right.getStepZ() * place.x() + 0.5;
        return Math.sqrt((player.getX() - x) * (player.getX() - x) + (player.getZ() - z) * (player.getZ() - z));
    }

    /** Takes the player to a place of the campus. Returns false when there is no campus or no such place. */
    public static boolean go(ServerPlayer player, String placeId) {
        MinecraftServer server = player.getServer();
        CampusSavedData data = CampusSavedData.get(server);
        CampusPlan.Place place = CampusPlan.place(placeId);
        if (!data.present() || place == null) {
            return false;
        }
        ServerLevel level = null;
        for (ServerLevel candidate : server.getAllLevels()) {
            if (candidate.dimension().location().toString().equals(data.dimension())) {
                level = candidate;
            }
        }
        if (level == null) {
            return false;
        }
        Direction forward = Direction.from2DDataValue(data.facing());
        Direction right = forward.getClockWise();
        double x = data.originX() + forward.getStepX() * place.z() + right.getStepX() * place.x() + 0.5;
        double z = data.originZ() + forward.getStepZ() * place.z() + right.getStepZ() * place.x() + 0.5;
        double y = data.floorY() + place.y();
        Direction look = forward;
        for (int i = 0; i < place.turn(); i++) {
            look = look.getClockWise();
        }
        player.teleportTo(level, x, y, z, look.toYRot(), 0.0F);
        return true;
    }
}
