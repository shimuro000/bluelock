package com.bluelock.forge;

import com.bluelock.common.appearance.BodyDesign;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * What the client knows about body: the design of every player (sent by the server), and the design that the body
 * maker is showing right now on the local player (the preview). Plain data, no client-only classes.
 */
public final class ClientBody {
    private static final Map<UUID, BodyDesign> DESIGNS = new HashMap<>();
    /** Set while the body maker or the creation screen is open; the local player is drawn with this body. */
    public static BodyDesign preview;
    /** How far the preview is turned, in degrees (dragging in the body maker). */
    public static float previewSpin;

    private ClientBody() {
    }

    public static void set(UUID player, BodyDesign design) {
        DESIGNS.put(player, design);
    }

    public static BodyDesign get(UUID player) {
        return DESIGNS.get(player);
    }

    /** The body to draw on this player: the preview for the local player while a screen edits it, else what the server sent. */
    public static BodyDesign designFor(UUID player) {
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
        boolean local = mc.player != null && player.equals(mc.player.getUUID());
        if (local && preview != null) {
            return preview;
        }
        BodyDesign design = DESIGNS.get(player);
        if (design == null && local && ClientMenuState.profile != null) {
            design = ClientMenuState.profile.body();
        }
        return design;
    }

    public static void clear() {
        DESIGNS.clear();
    }
}
