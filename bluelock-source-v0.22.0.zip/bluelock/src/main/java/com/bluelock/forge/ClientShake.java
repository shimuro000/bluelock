package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** A short camera shake (goals, power shots, heavy tackles). Client only. */
@Mod.EventBusSubscriber(modid = BlueLockConstants.MOD_ID, value = Dist.CLIENT)
public final class ClientShake {
    private static long startNanos;
    private static long durationNanos;
    private static float strength;

    private ClientShake() {
    }

    public static void start(float newStrength, int ticks) {
        // a new shake only replaces a weaker one that is still running
        if (System.nanoTime() < startNanos + durationNanos && newStrength < strength * 0.6F) {
            return;
        }
        startNanos = System.nanoTime();
        durationNanos = ticks * 50_000_000L;
        strength = Math.max(0.0F, Math.min(1.5F, newStrength));
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        long elapsed = System.nanoTime() - startNanos;
        if (elapsed < 0 || elapsed >= durationNanos || durationNanos <= 0) {
            return;
        }
        double fade = 1.0 - (double) elapsed / durationNanos;
        double t = elapsed / 1.0E8;
        float amount = (float) (strength * fade);
        event.setYaw(event.getYaw() + (float) Math.sin(t * 9.0) * amount * 1.6F);
        event.setPitch(event.getPitch() + (float) Math.sin(t * 11.0 + 1.3) * amount * 1.2F);
        event.setRoll(event.getRoll() + (float) Math.sin(t * 7.0 + 2.1) * amount * 1.0F);
    }
}
