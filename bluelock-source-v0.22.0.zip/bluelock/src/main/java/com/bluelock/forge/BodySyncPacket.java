package com.bluelock.forge;

import com.bluelock.common.appearance.BodyDesign;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Server to client: the body of one player. */
public record BodySyncPacket(UUID player, int[] body) {
    public static void encode(BodySyncPacket m, FriendlyByteBuf buf) {
        buf.writeUUID(m.player());
        for (int i = 0; i < BodyDesign.INT_COUNT; i++) {
            buf.writeInt(i < m.body().length ? m.body()[i] : 0);
        }
    }

    public static BodySyncPacket decode(FriendlyByteBuf buf) {
        UUID id = buf.readUUID();
        int[] body = new int[BodyDesign.INT_COUNT];
        for (int i = 0; i < body.length; i++) {
            body[i] = buf.readInt();
        }
        return new BodySyncPacket(id, body);
    }

    public static void handle(BodySyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> ClientBody.set(m.player(), BodyDesign.fromInts(m.body())));
        context.setPacketHandled(true);
    }
}
