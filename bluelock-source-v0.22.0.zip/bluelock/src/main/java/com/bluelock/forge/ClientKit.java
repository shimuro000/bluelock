package com.bluelock.forge;

import com.bluelock.common.appearance.KitDesign;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** The kit every player wears right now (sent by the server while a match is on). Plain data. */
public final class ClientKit {
    private static final Map<UUID, KitDesign> KITS = new HashMap<>();

    private ClientKit() {
    }

    public static void set(UUID player, KitDesign kit) {
        if (kit == null) {
            KITS.remove(player);
        } else {
            KITS.put(player, kit);
        }
    }

    public static KitDesign get(UUID player) {
        return KITS.get(player);
    }

    public static void clear() {
        KITS.clear();
    }
}
