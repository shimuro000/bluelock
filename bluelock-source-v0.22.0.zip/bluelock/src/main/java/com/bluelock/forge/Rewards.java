package com.bluelock.forge;

import com.bluelock.common.content.QuestDefinition;
import com.bluelock.common.content.QuestType;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.progression.Quests;
import com.bluelock.common.progression.SkillRules;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/** Gives XP for football actions, handles level-ups and newly unlocked skills, and saves the profile. */
public final class Rewards {
    private Rewards() {
    }

    private static QuestType questFor(Progression.XpAction action) {
        return switch (action) {
            case PASS -> QuestType.PASSES;
            case SHOT -> QuestType.SHOTS;
            case TACKLE_WON -> QuestType.TACKLES;
            case GOAL -> QuestType.GOALS;
            case DRIBBLE_MOVE, SKILL_USED -> QuestType.SKILL_MOVES;
            case MATCH_PLAYED -> QuestType.MATCHES;
            case MATCH_WON -> QuestType.WINS;
        };
    }

    /** Tells the player when they climbed the ranking, and when the climb opened a better cafeteria meal. */
    public static void announceRank(ServerPlayer player, int before, int after) {
        if (after >= before) {
            return;
        }
        player.sendSystemMessage(Component.translatable("bluelock.rank.up", after, before - after));
        com.bluelock.common.rank.Cafeteria.Tier was = com.bluelock.common.rank.Cafeteria.tierOf(before);
        com.bluelock.common.rank.Cafeteria.Tier now = com.bluelock.common.rank.Cafeteria.tierOf(after);
        if (was != now) {
            player.sendSystemMessage(Component.translatable("bluelock.rank.tier_up",
                    Component.translatable(com.bluelock.common.rank.Cafeteria.tierKey(now)),
                    Component.translatable(com.bluelock.common.rank.Cafeteria.mealFor(after).nameKey())));
        }
    }

    public static void give(MinecraftServer server, UUID playerId, Progression.XpAction action) {
        ProfileSavedData store = ProfileSavedData.get(server);
        Optional<PlayerProfile> found = store.load(playerId);
        if (found.isEmpty()) {
            return;
        }
        PlayerProfile profile = found.get();
        int rankBefore = com.bluelock.common.rank.Ranking.rankOf(profile.rankPoints());
        profile.addRankPoints(com.bluelock.common.rank.Ranking.pointsFor(action));
        Progression.LevelUp levelUp = Progression.award(profile, action);
        if (action == Progression.XpAction.GOAL) {
            profile.addGoal();
        }
        QuestType questType = questFor(action);
        List<QuestDefinition> finished = questType == null ? List.of() : Quests.record(profile, questType, 1, BlueLockData.get());
        List<String> unlocked = SkillRules.autoUnlockRoots(profile, BlueLockData.get());
        store.save(profile);

        ServerPlayer player = server.getPlayerList().getPlayer(playerId);
        if (player != null) {
            announceRank(player, rankBefore, com.bluelock.common.rank.Ranking.rankOf(profile.rankPoints()));
            for (QuestDefinition quest : finished) {
                player.sendSystemMessage(Component.translatable("bluelock.quest.completed", Component.translatable(quest.nameKey()),
                        quest.rewardXp(), quest.rewardSkillPoints(), quest.rewardDevelopmentPoints()));
            }
        }
        if (player != null && levelUp.happened()) {
            player.sendSystemMessage(Component.translatable("bluelock.progress.levelup", levelUp.newLevel(),
                    Progression.SKILL_POINTS_PER_LEVEL * levelUp.levelsGained(),
                    Progression.DEVELOPMENT_POINTS_PER_LEVEL * levelUp.levelsGained()));
            for (String skill : unlocked) {
                player.sendSystemMessage(Component.translatable("bluelock.progress.skill_unlocked",
                        Component.translatable("bluelock.skill." + skill + ".name")));
            }
        }
    }
}
