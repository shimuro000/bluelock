package com.bluelock.forge;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.RegistryObject;

/** Small helpers for sound, particles and screen shake on the server, so the game feels good ("juice"). */
public final class Juice {
    private Juice() {
    }

    public static void sound(Level level, double x, double y, double z, RegistryObject<SoundEvent> sound, float volume, float pitch) {
        if (level != null && !level.isClientSide) {
            level.playSound(null, x, y, z, sound.get(), SoundSource.PLAYERS, volume, pitch);
        }
    }

    public static void particles(Level level, ParticleOptions type, double x, double y, double z, int count, double spread, double speed) {
        if (level instanceof ServerLevel server) {
            server.sendParticles(type, x, y, z, count, spread, spread, spread, speed);
        }
    }

    /** Shakes the camera of every player within radius blocks. strength about 0.3 (small) to 1.0 (big). */
    public static void shake(Level level, double x, double y, double z, double radius, float strength, int ticks) {
        if (level instanceof ServerLevel server) {
            for (ServerPlayer player : server.players()) {
                if (player.distanceToSqr(x, y, z) < radius * radius) {
                    BlueLockNetwork.sendToPlayer(player, new ShakePacket(strength, ticks));
                }
            }
        }
    }
}
