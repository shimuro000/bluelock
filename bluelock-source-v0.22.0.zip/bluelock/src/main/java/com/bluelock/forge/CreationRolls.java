package com.bluelock.forge;

import com.bluelock.common.profile.CharacterRoll;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * The foot and talent dice of players who have not created a character yet. Each player is rolled once and keeps
 * that result until the character is created, so closing and reopening the menu cannot be used to re-roll.
 */
public final class CreationRolls {
    private static final Map<UUID, CharacterRoll.Result> ROLLS = new HashMap<>();

    private CreationRolls() {
    }

    /** The roll this player has made, or null when they have not pressed Roll yet. */
    public static CharacterRoll.Result peek(UUID player) {
        return ROLLS.get(player);
    }

    public static CharacterRoll.Result get(UUID player) {
        return ROLLS.computeIfAbsent(player, id -> CharacterRoll.roll(ThreadLocalRandom.current()::nextDouble));
    }

    public static void clear(UUID player) {
        ROLLS.remove(player);
    }
}
