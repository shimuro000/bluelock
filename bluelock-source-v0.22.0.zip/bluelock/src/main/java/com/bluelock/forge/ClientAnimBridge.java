package com.bluelock.forge;

import com.bluelock.common.anim.AnimLogic;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/**
 * Client side of the player animations: plays the one-shot animations the server announces, and runs a small
 * state machine that keeps the right idle / walk / run / sprint loop going (with or without the ball) for every
 * player who is taking part in football: in a match, carrying the ball, or close to a ball. Everybody else keeps
 * the normal Minecraft animations. Client only.
 */
public final class ClientAnimBridge {
    /** A player this close (blocks) to any ball counts as playing football. */
    private static final double BALL_INTEREST = 24.0;

    private static final Map<Integer, String> LOOP = new HashMap<>();
    private static final Map<Integer, Long> BUSY_UNTIL = new HashMap<>();

    private ClientAnimBridge() {
    }

    public static void playFromServer(int entityId, String name) {
        Minecraft minecraft = Minecraft.getInstance();
        PlayerAnimBackend backend = AnimationBridge.playerBackend();
        if (minecraft.level == null || backend == null) {
            return;
        }
        Entity entity = minecraft.level.getEntity(entityId);
        if (entity instanceof Player player) {
            backend.play(player, name);
            BUSY_UNTIL.put(entityId, minecraft.level.getGameTime() + AnimLogic.durationTicks(name));
            LOOP.remove(entityId);
        }
    }

    /** Players doing something that the football animations would look wrong on (swimming, riding, sleeping...). */
    private static boolean normalMovementOnly(AbstractClientPlayer player) {
        return player.isPassenger() || player.isSleeping() || player.isSwimming() || player.isFallFlying()
                || player.isCrouching() || player.isInWater() || player.isSpectator() || player.onClimbable();
    }

    /** Once per client tick. */
    public static void tick() {
        Minecraft minecraft = Minecraft.getInstance();
        PlayerAnimBackend backend = AnimationBridge.playerBackend();
        if (minecraft.level == null || backend == null) {
            LOOP.clear();
            BUSY_UNTIL.clear();
            return;
        }
        long now = minecraft.level.getGameTime();
        Set<Integer> carriers = new HashSet<>();
        java.util.List<BallEntity> balls = new java.util.ArrayList<>();
        for (Entity entity : minecraft.level.entitiesForRendering()) {
            if (entity instanceof BallEntity ball) {
                balls.add(ball);
                if (ball.carrierId() >= 0) {
                    carriers.add(ball.carrierId());
                }
            }
        }
        Set<Integer> seen = new HashSet<>();
        for (AbstractClientPlayer player : minecraft.level.players()) {
            int id = player.getId();
            seen.add(id);
            if (now < BUSY_UNTIL.getOrDefault(id, 0L)) {
                continue;
            }
            boolean carrying = carriers.contains(id);
            boolean playing = ClientHudState.active || carrying;
            if (!playing) {
                for (BallEntity ball : balls) {
                    if (ball.distanceToSqr(player) < BALL_INTEREST * BALL_INTEREST) {
                        playing = true;
                        break;
                    }
                }
            }
            String wanted = null;
            if (playing && !normalMovementOnly(player)) {
                double speed = Math.hypot(player.getX() - player.xo, player.getZ() - player.zo);
                boolean airborne = Math.abs(player.getY() - player.yo) > 0.08;
                wanted = AnimLogic.playerLocomotion(speed, carrying, airborne);
            }
            if (!Objects.equals(wanted, LOOP.get(id))) {
                if (wanted == null) {
                    backend.stop(player);
                    LOOP.remove(id);
                } else {
                    backend.play(player, wanted);
                    LOOP.put(id, wanted);
                }
            }
        }
        LOOP.keySet().retainAll(seen);
        BUSY_UNTIL.keySet().retainAll(seen);
    }
}
