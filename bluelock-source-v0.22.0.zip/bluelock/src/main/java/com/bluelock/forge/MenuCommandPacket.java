package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Client to server: a menu button that runs a /bluelock command (only whitelisted commands are accepted). */
public record MenuCommandPacket(String command) {
    public static void encode(MenuCommandPacket m, FriendlyByteBuf buf) {
        buf.writeUtf(m.command(), 120);
    }

    public static MenuCommandPacket decode(FriendlyByteBuf buf) {
        return new MenuCommandPacket(buf.readUtf(120));
    }

    public static void handle(MenuCommandPacket m, Supplier<NetworkEvent.Context> ctx) {
        MenuPackets.serverSide(ctx, player -> MenuServer.runMenuCommand(player, m.command()));
    }
}
