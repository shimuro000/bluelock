package com.bluelock.forge;

import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.profile.PlayerProfile;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

/** Server side of the hair: saves a changed hair and tells every client, so other players see it too. */
public final class HairSync {
    private HairSync() {
    }

    /** A player changed their hair in the menu. Only players with a character can have one. */
    public static void update(ServerPlayer player, HairDesign design) {
        ProfileSavedData store = ProfileSavedData.get(player.getServer());
        Optional<PlayerProfile> profile = store.load(player.getUUID());
        if (profile.isEmpty()) {
            return;
        }
        profile.get().setHair(design);
        store.save(profile.get());
        broadcast(player.getUUID(), design);
        MenuServer.sendState(player);
    }

    /** Sends one player's hair to everybody. */
    public static void broadcast(UUID id, HairDesign design) {
        BlueLockNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), new HairSyncPacket(id, design.toInts()));
    }

    /** A player joined: they learn everybody's hair, and everybody learns theirs. */
    public static void onLogin(ServerPlayer joiner) {
        ProfileSavedData store = ProfileSavedData.get(joiner.getServer());
        for (ServerPlayer other : joiner.getServer().getPlayerList().getPlayers()) {
            store.load(other.getUUID()).ifPresent(p ->
                    BlueLockNetwork.sendToPlayer(joiner, new HairSyncPacket(other.getUUID(), p.hair().toInts())));
        }
        store.load(joiner.getUUID()).ifPresent(p -> broadcast(joiner.getUUID(), p.hair()));
    }
}
