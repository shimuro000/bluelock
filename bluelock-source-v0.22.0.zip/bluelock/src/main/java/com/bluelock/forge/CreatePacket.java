package com.bluelock.forge;

import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.appearance.HairDesign;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/**
 * Client to server: create my character, with the hair made in the hair maker. The foot and talent are rolled by the
 * server, never chosen by the client, and the hair numbers are clamped by the server.
 */
public record CreatePacket(String name, String archetype, String personality, String position, int[] hair, int[] body) {
    public static void encode(CreatePacket m, FriendlyByteBuf buf) {
        buf.writeUtf(m.name(), 40);
        buf.writeUtf(m.archetype(), 24);
        buf.writeUtf(m.personality(), 24);
        buf.writeUtf(m.position(), 8);
        for (int i = 0; i < HairDesign.INT_COUNT; i++) {
            buf.writeInt(m.hair() != null && i < m.hair().length ? m.hair()[i] : 0);
        }
        for (int i = 0; i < BodyDesign.INT_COUNT; i++) {
            buf.writeInt(m.body() != null && i < m.body().length ? m.body()[i] : 0);
        }
    }

    public static CreatePacket decode(FriendlyByteBuf buf) {
        String name = buf.readUtf(40);
        String archetype = buf.readUtf(24);
        String personality = buf.readUtf(24);
        String position = buf.readUtf(8);
        int[] hair = new int[HairDesign.INT_COUNT];
        for (int i = 0; i < hair.length; i++) {
            hair[i] = buf.readInt();
        }
        int[] body = new int[BodyDesign.INT_COUNT];
        for (int i = 0; i < body.length; i++) {
            body[i] = buf.readInt();
        }
        return new CreatePacket(name, archetype, personality, position, hair, body);
    }

    public static void handle(CreatePacket m, Supplier<NetworkEvent.Context> ctx) {
        MenuPackets.serverSide(ctx, player -> MenuServer.create(player, m.archetype(), m.personality(), m.position(), m.name(),
                HairDesign.fromInts(m.hair()), BodyDesign.fromInts(m.body())));
    }
}
