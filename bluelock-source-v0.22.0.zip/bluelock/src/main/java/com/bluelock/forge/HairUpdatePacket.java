package com.bluelock.forge;

import com.bluelock.common.appearance.HairDesign;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Client to server: "this is my new hair" (from the hair maker opened in the menu). The server clamps every value. */
public record HairUpdatePacket(int[] hair) {
    public static void encode(HairUpdatePacket m, FriendlyByteBuf buf) {
        for (int i = 0; i < HairDesign.INT_COUNT; i++) {
            buf.writeInt(i < m.hair().length ? m.hair()[i] : 0);
        }
    }

    public static HairUpdatePacket decode(FriendlyByteBuf buf) {
        int[] hair = new int[HairDesign.INT_COUNT];
        for (int i = 0; i < hair.length; i++) {
            hair[i] = buf.readInt();
        }
        return new HairUpdatePacket(hair);
    }

    public static void handle(HairUpdatePacket m, Supplier<NetworkEvent.Context> ctx) {
        MenuPackets.serverSide(ctx, player -> HairSync.update(player, HairDesign.fromInts(m.hair())));
    }
}
