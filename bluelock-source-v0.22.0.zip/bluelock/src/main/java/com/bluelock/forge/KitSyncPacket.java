package com.bluelock.forge;

import com.bluelock.common.appearance.KitDesign;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Server to client: the kit of one player. wearing false means the player has no kit (no match). */
public record KitSyncPacket(UUID player, boolean wearing, int shirt, int trim, int shorts, int socks, int number, String name) {
    public static KitSyncPacket of(UUID player, KitDesign k) {
        return new KitSyncPacket(player, true, k.shirt(), k.trim(), k.shorts(), k.socks(), k.number(), k.name());
    }

    public static KitSyncPacket none(UUID player) {
        return new KitSyncPacket(player, false, 0, 0, 0, 0, 0, "");
    }

    public static void encode(KitSyncPacket m, FriendlyByteBuf buf) {
        buf.writeUUID(m.player());
        buf.writeBoolean(m.wearing());
        buf.writeInt(m.shirt());
        buf.writeInt(m.trim());
        buf.writeInt(m.shorts());
        buf.writeInt(m.socks());
        buf.writeInt(m.number());
        buf.writeUtf(m.name(), 32);
    }

    public static KitSyncPacket decode(FriendlyByteBuf buf) {
        return new KitSyncPacket(buf.readUUID(), buf.readBoolean(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt(),
                buf.readInt(), buf.readUtf(32));
    }

    public static void handle(KitSyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> ClientKit.set(m.player(),
                m.wearing() ? new KitDesign(m.shirt(), m.trim(), m.shorts(), m.socks(), m.number(), m.name()) : null));
        context.setPacketHandled(true);
    }
}
