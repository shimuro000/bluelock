package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Server to client: show this story scene (the lines come from the shared StoryBook, so only the id is sent). */
public record StoryScenePacket(String sceneId) {
    public static void encode(StoryScenePacket m, FriendlyByteBuf buf) {
        buf.writeUtf(m.sceneId(), 40);
    }

    public static StoryScenePacket decode(FriendlyByteBuf buf) {
        return new StoryScenePacket(buf.readUtf(40));
    }

    public static void handle(StoryScenePacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> ClientStory.pending = m.sceneId());
        context.setPacketHandled(true);
    }
}
