package com.bluelock.forge;

import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.pitch.PitchPlacement;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Builds a pitch from a PitchLayout: striped grass (grass block + moss), white concrete lines, and two goals
 * with iron-bar nets. The area above the pitch is cleared. Surface blocks use a cheap update flag; only the
 * nets use full updates so the bars connect to each other. Holes under the pitch are filled with dirt so a big pitch
 * does not float over valleys or water. Returns the placement so matches know where it is.
 */
public final class PitchBuilder {
    private static final int CLEAR_HEIGHT = 10;
    private static final int FOUNDATION_DEPTH = 8;

    private PitchBuilder() {
    }

    public static PitchPlacement build(ServerLevel level, BlockPos centre, Direction facing, PitchLayout layout) {
        boolean alongX = facing.getAxis() == Direction.Axis.X;
        int floorY = centre.getY() - 1;
        PitchPlacement placement = new PitchPlacement(centre.getX(), floorY, centre.getZ(), alongX, layout);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        // clear the space above the pitch and behind both goals
        for (int u = -PitchLayout.GOAL_DEPTH - 1; u <= layout.length() + PitchLayout.GOAL_DEPTH; u++) {
            for (int v = -1; v <= layout.width(); v++) {
                for (int dy = 1; dy <= CLEAR_HEIGHT; dy++) {
                    pos.set(placement.blockX(u, v), floorY + dy, placement.blockZ(u, v));
                    if (!level.getBlockState(pos).isAir()) {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                    }
                }
            }
        }

        // surface, and dirt under it wherever the ground below is a hole, water or plants (a big pitch crosses uneven land)
        for (int u = 0; u < layout.length(); u++) {
            for (int v = 0; v < layout.width(); v++) {
                int x = placement.blockX(u, v);
                int z = placement.blockZ(u, v);
                pos.set(x, floorY, z);
                level.setBlock(pos, surfaceState(layout.surfaceAt(u, v)), Block.UPDATE_CLIENTS);
                for (int below = 1; below <= FOUNDATION_DEPTH; below++) {
                    pos.set(x, floorY - below, z);
                    BlockState state = level.getBlockState(pos);
                    if (state.isAir() || !state.getFluidState().isEmpty() || state.canBeReplaced()) {
                        level.setBlock(pos, Blocks.DIRT.defaultBlockState(), Block.UPDATE_CLIENTS);
                    } else {
                        break;
                    }
                }
            }
        }

        // goals
        for (boolean farEnd : new boolean[] {false, true}) {
            for (PitchLayout.GoalCell cell : layout.goalCells(farEnd)) {
                pos.set(placement.blockX(cell.u(), cell.v()), floorY + cell.dy(), placement.blockZ(cell.u(), cell.v()));
                if (cell.part() == PitchLayout.GoalPart.NET) {
                    level.setBlock(pos, Blocks.IRON_BARS.defaultBlockState(), Block.UPDATE_ALL);
                } else {
                    level.setBlock(pos, Blocks.WHITE_CONCRETE.defaultBlockState(), Block.UPDATE_CLIENTS);
                }
            }
        }
        return placement;
    }

    private static BlockState surfaceState(PitchLayout.Surface surface) {
        return switch (surface) {
            case LIGHT_GRASS -> Blocks.GRASS_BLOCK.defaultBlockState();
            case DARK_GRASS -> Blocks.MOSS_BLOCK.defaultBlockState();
            case LINE -> Blocks.WHITE_CONCRETE.defaultBlockState();
        };
    }
}
