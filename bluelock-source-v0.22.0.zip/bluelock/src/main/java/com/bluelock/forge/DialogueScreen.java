package com.bluelock.forge;

import com.bluelock.common.ai.FootballCharacter;
import com.bluelock.common.ai.Roster;
import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.story.StoryBook;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

/**
 * The story dialogue (client only): a portrait of whoever speaks, their name, and the line typed out. The portraits are
 * drawn from the character's own hair and body data, so there is no artwork to ship. Click, Space or Enter completes the
 * line and then moves on; Escape closes (the scene stays where it was and can be resumed from the STORY tab).
 */
public class DialogueScreen extends Screen {
    private static final int CPS = 2;   // characters per tick

    private final StoryBook.Beat scene;
    private int index;
    private int shown;
    private int ticks;
    private boolean sent;
    private int slide;

    public DialogueScreen(StoryBook.Beat scene) {
        super(Component.translatable(scene.titleKey()));
        this.scene = scene;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private StoryBook.Line line() {
        return scene.lines().get(Math.min(index, scene.lines().size() - 1));
    }

    private String text() {
        PlayerProfile p = ClientMenuState.profile;
        return Component.translatable(line().key(), p == null ? "" : p.name()).getString();
    }

    @Override
    public void tick() {
        ticks++;
        slide++;
        if (shown < text().length()) {
            shown += CPS;
        }
    }

    private void next() {
        if (shown < text().length()) {
            shown = text().length();
            return;
        }
        if (index + 1 < scene.lines().size()) {
            index++;
            shown = 0;
            slide = 0;
            return;
        }
        if (!sent) {
            sent = true;
            BlueLockNetwork.CHANNEL.sendToServer(new StoryAdvancePacket(scene.id()));
        }
        onClose();
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        next();
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 32 || key == 257 || key == 335) {
            next();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        BlueUi.background(g, width, height);
        int boxW = Math.min(width - 24, 440);
        int boxH = 78;
        int left = (width - boxW) / 2;
        int boxY = height - boxH - 16;
        g.drawCenteredString(font, Component.translatable(scene.titleKey()), width / 2, 14, BlueUi.GOLD);
        g.drawCenteredString(font, Component.literal((index + 1) + " / " + scene.lines().size()), width / 2, 26, BlueUi.GREY);

        String speaker = line().speaker();
        boolean hall = "selection_hall".equals(scene.place());
        if (hall) {
            drawHall(g, boxY, speaker.equals("ego"));
        }
        if (!speaker.equals("narrator") && !(hall && speaker.equals("ego"))) {
            double ease = 1.0 - Math.min(1.0, slide / 7.0);
            drawPortrait(g, speaker, width / 2 - 36 + (int) Math.round(ease * ease * 60), boxY - 102, 72, 96);
        }
        BlueUi.panel(g, left, boxY, boxW, boxH);
        Component name = speakerName(speaker);
        if (name != null) {
            g.drawString(font, name, left + 8, boxY + 6, speaker.equals("ego") ? BlueUi.GOLD : BlueUi.CYAN, true);
        }
        String all = text();
        String visible = all.substring(0, Math.min(all.length(), shown));
        List<FormattedCharSequence> rows = font.split(Component.literal(visible), boxW - 16);
        int y = boxY + 20;
        for (FormattedCharSequence row : rows) {
            g.drawString(font, row, left + 8, y, BlueUi.WHITE, true);
            y += 11;
        }
        if (shown >= all.length() && (ticks / 10) % 2 == 0) {
            g.drawString(font, "v", left + boxW - 14, boxY + boxH - 14, BlueUi.GOLD, true);
        }
        g.drawString(font, Component.translatable("bluelock.story_ui.hint"), left, height - 12, BlueUi.GREY, false);
        super.render(g, mouseX, mouseY, partialTick);
    }

    /** The Selection Hall backdrop: the giant screen with the supervisor's lenses above 300 small figures in rows. */
    private void drawHall(GuiGraphics g, int boxY, boolean egoSpeaking) {
        int sw = Math.min(width - 40, 240);
        int sx = (width - sw) / 2;
        int sy = 38;
        int sh = 58;
        g.fill(sx - 2, sy - 2, sx + sw + 2, sy + sh + 2, BlueUi.CYAN);
        g.fill(sx, sy, sx + sw, sy + sh, 0xFF05080F);
        int pulse = egoSpeaking ? 0xFFFFD35A : 0xFF6B5A28;
        int lensW = sw / 4;
        int lensY = sy + 14;
        g.fill(sx + sw / 2 - lensW - 8, lensY, sx + sw / 2 - 8, lensY + 16, pulse);
        g.fill(sx + sw / 2 + 8, lensY, sx + sw / 2 + lensW + 8, lensY + 16, pulse);
        g.fill(sx + sw / 2 - 8, lensY + 6, sx + sw / 2 + 8, lensY + 9, pulse);
        boolean talking = egoSpeaking && shown < text().length();
        int mouth = talking && (ticks / 3) % 2 == 0 ? 4 : 1;
        g.fill(sx + sw / 2 - 30, sy + sh - 14, sx + sw / 2 + 30, sy + sh - 14 + mouth, 0xFFB8892A);
        // the 300: 20 columns by 15 rows, smaller towards the back
        int top = sy + sh + 8;
        int bottom = boxY - 6;
        int[] shirts = {0xFF2D4F9E, 0xFFE8E8E8, 0xFFC4363A, 0xFF9AA4B5, 0xFF3CB4E0, 0xFFE07A2D};
        for (int row = 0; row < 15; row++) {
            float depth = row / 14.0F;
            int size = 2 + Math.round(depth * 2);
            int y = top + Math.round((bottom - top - 8) * depth);
            int span = width - 60;
            for (int col = 0; col < 20; col++) {
                int x = 30 + Math.round(span * (col + 0.5F) / 20) + (row % 2) * 2;
                int sway = (int) Math.round(Math.sin(ticks / 14.0 + col * 0.9 + row) * 0.6);
                int h = col * 5 + row * 3 + (col * row) % 4;
                g.fill(x, y + sway, x + size, y + size + sway, 0xFFB98A62);
                g.fill(x - 1, y + size + sway, x + size + 1, y + size * 3 + sway, shirts[h % shirts.length]);
                g.fill(x, y + sway - 1, x + size, y + sway, (h / 2) % 5 == 0 ? 0xFFD8D8D8 : 0xFF1A1418);
            }
        }
    }

    private static Component speakerName(String speaker) {
        switch (speaker) {
            case "narrator":
                return null;
            case "ego":
                return Component.translatable("bluelock.story_ui.ego");
            case "player":
                return Component.literal(ClientMenuState.profile == null ? "" : ClientMenuState.profile.name());
            default:
                FootballCharacter c = Roster.byId(speaker);
                return Component.literal(c == null ? speaker : c.displayName());
        }
    }

    private void drawPortrait(GuiGraphics g, String speaker, int x, int y, int w, int h) {
        HairDesign hair;
        BodyDesign body;
        int shirt = 0x1B3A8A;
        boolean ego = speaker.equals("ego");
        if (ego) {
            hair = HairDesign.preset(1, 0x15151A);
            body = BodyDesign.standard();
            shirt = 0x202028;
        } else if (speaker.equals("player")) {
            PlayerProfile p = ClientMenuState.profile;
            hair = p == null ? HairDesign.standard() : p.hair();
            body = p == null ? BodyDesign.standard() : p.body();
        } else {
            FootballCharacter c = Roster.byId(speaker);
            hair = c == null ? HairDesign.standard() : c.hair();
            body = c == null ? BodyDesign.standard() : c.body();
        }
        g.fill(x, y, x + w, y + h, 0xCC0A1226);
        g.fill(x, y, x + w, y + 1, BlueUi.CYAN);
        g.fill(x, y + h - 1, x + w, y + h, BlueUi.CYAN);
        int bob = (int) Math.round(Math.sin(ticks / 12.0));
        int skin = 0xFF000000 | body.skin();
        int hairColor = 0xFF000000 | hair.color();
        g.fill(x + 6, y + h - 26, x + w - 6, y + h - 1, 0xFF000000 | shirt);
        g.fill(x + w / 2 - 6, y + h - 34 + bob, x + w / 2 + 6, y + h - 24, skin);
        int hx = x + w / 2 - 18;
        int hy = y + 18 + bob;
        g.fill(hx, hy, hx + 36, hy + 42, skin);
        int cap = 8 + hair.top() / 12;
        g.fill(hx - 2, hy - cap, hx + 38, hy + 8, hairColor);
        g.fill(hx - 3, hy, hx + 1, hy + 22 + hair.sides() / 10, hairColor);
        g.fill(hx + 35, hy, hx + 39, hy + 22 + hair.sides() / 10, hairColor);
        int spikes = hair.spikes() / 20;
        for (int i = 0; i < spikes; i++) {
            int sx = hx + 2 + i * (32 / Math.max(1, spikes));
            g.fill(sx, hy - cap - 5 - (i % 2) * 3, sx + 5, hy - cap, hairColor);
        }
        g.fill(hx + 2, hy + 6, hx + 34, hy + 8 + hair.front() / 14, hairColor);
        int eye = 0xFF000000 | body.eyeColor();
        for (int s = -1; s <= 1; s += 2) {
            int ex = hx + 18 + s * 9 - 4;
            g.fill(ex, hy + 20, ex + 8, hy + 26, 0xFFF2F2F2);
            g.fill(ex + 2, hy + 20, ex + 6, hy + 26, eye);
            g.fill(ex + 3, hy + 21, ex + 5, hy + 25, 0xFF1C1418);
            g.fill(ex - 1, hy + 16 - body.brow() % 2, ex + 9, hy + 18 - body.brow() % 2, hairColor);
        }
        boolean talking = shown < text().length();
        int mouth = talking && (ticks / 3) % 2 == 0 ? 5 : 2;
        g.fill(hx + 14, hy + 34, hx + 22, hy + 34 + mouth, 0xFF8A3F3F);
        if (ego) {
            g.fill(hx + 2, hy + 19, hx + 34, hy + 21, 0xFFE8B84A);
        }
    }
}
