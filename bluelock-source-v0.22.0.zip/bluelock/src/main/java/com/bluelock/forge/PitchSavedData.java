package com.bluelock.forge;

import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.pitch.PitchPlacement;
import java.util.Optional;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Remembers where the last pitch was built (position, direction, size and dimension), saved with the world
 * (file: data/bluelock_pitch.dat). After a server restart the pitch is "loaded" again by itself, so players do not
 * have to build it again; the blocks themselves are saved by Minecraft as usual.
 */
public final class PitchSavedData extends SavedData {
    public static final String NAME = "bluelock_pitch";

    private boolean present;
    private int centreX;
    private int floorY;
    private int centreZ;
    private boolean alongX;
    private int length;
    private int width;
    private String dimension = "";
    private boolean auto = true;

    public static PitchSavedData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(PitchSavedData::loadFromTag, PitchSavedData::new, NAME);
    }

    public static PitchSavedData loadFromTag(CompoundTag t) {
        PitchSavedData d = new PitchSavedData();
        d.present = t.getBoolean("present");
        d.centreX = t.getInt("x");
        d.floorY = t.getInt("y");
        d.centreZ = t.getInt("z");
        d.alongX = t.getBoolean("alongX");
        d.length = t.getInt("length");
        d.width = t.getInt("width");
        d.dimension = t.getString("dimension");
        d.auto = !t.contains("auto") || t.getBoolean("auto");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putBoolean("present", present);
        t.putInt("x", centreX);
        t.putInt("y", floorY);
        t.putInt("z", centreZ);
        t.putBoolean("alongX", alongX);
        t.putInt("length", length);
        t.putInt("width", width);
        t.putString("dimension", dimension);
        t.putBoolean("auto", auto);
        return t;
    }

    public void remember(PitchPlacement placement, String dimensionId, boolean autoSized) {
        present = true;
        centreX = placement.centreX();
        floorY = placement.floorY();
        centreZ = placement.centreZ();
        alongX = placement.alongX();
        length = placement.layout().length();
        width = placement.layout().width();
        dimension = dimensionId;
        auto = autoSized;
        setDirty();
    }

    public void forget() {
        if (present) {
            present = false;
            setDirty();
        }
    }

    public String dimension() {
        return dimension;
    }

    public boolean autoSized() {
        return auto;
    }

    /** The remembered pitch, or empty when there is none or the saved size is not valid any more. */
    public Optional<PitchPlacement> placement() {
        if (!present) {
            return Optional.empty();
        }
        try {
            return Optional.of(new PitchPlacement(centreX, floorY, centreZ, alongX, new PitchLayout(length, width)));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }
}
