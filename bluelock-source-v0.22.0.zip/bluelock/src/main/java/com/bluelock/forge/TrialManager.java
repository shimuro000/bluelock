package com.bluelock.forge;

import com.bluelock.common.story.StoryBook;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/**
 * The touch trial (Chapter 1): a ball is fired at the player again and again, faster as time runs; touching it ends the
 * trial for good (the retry button is in the STORY tab). The other 299 candidates are a counter that falls as the clock runs.
 */
public final class TrialManager {
    private static final int START_INTERVAL = 50;
    private static final int END_INTERVAL = 18;
    private static final double START_SPEED = 0.65;
    private static final double END_SPEED = 1.45;

    private static Run run;

    private TrialManager() {
    }

    private static final class Run {
        final UUID player;
        final int beatIndex;
        final int totalTicks;
        final ServerLevel level;
        BallEntity ball;
        int ticks;
        int nextFire = 40;

        Run(UUID player, int beatIndex, int totalTicks, ServerLevel level) {
            this.player = player;
            this.beatIndex = beatIndex;
            this.totalTicks = totalTicks;
            this.level = level;
        }
    }

    public static boolean running() {
        return run != null;
    }

    public static void start(ServerPlayer player, int beatIndex, StoryBook.Beat beat) {
        if (run != null) {
            end(player.getServer(), false, false);
        }
        run = new Run(player.getUUID(), beatIndex, beat.length() * 20, (ServerLevel) player.level());
        player.sendSystemMessage(Component.translatable(beat.briefKey()));
        player.sendSystemMessage(Component.translatable("bluelock.trial.start"));
    }

    /** The remaining candidates for a clock position (0..1): 300 falls to about 90. */
    public static int remaining(double progress) {
        return 300 - (int) Math.round(210 * Math.pow(Math.max(0, Math.min(1, progress)), 1.3));
    }

    public static void tick(MinecraftServer server) {
        if (run == null) {
            return;
        }
        Run r = run;
        ServerPlayer player = server.getPlayerList().getPlayer(r.player);
        if (player == null || player.isDeadOrDying() || player.level() != r.level) {
            end(server, false, true);
            return;
        }
        r.ticks++;
        double progress = (double) r.ticks / r.totalTicks;
        if (r.ball != null && !r.ball.isAlive()) {
            r.ball = null;
        }
        if (r.ball != null && touched(r.ball, player)) {
            end(server, false, false);
            return;
        }
        if (r.ticks >= r.nextFire) {
            fire(r, player, progress);
            int interval = (int) Math.round(START_INTERVAL + (END_INTERVAL - START_INTERVAL) * progress);
            r.nextFire = r.ticks + interval;
        }
        if (r.ticks % 20 == 0) {
            int secondsLeft = (r.totalTicks - r.ticks) / 20;
            player.displayClientMessage(Component.translatable("bluelock.trial.hud", remaining(progress), secondsLeft), true);
        }
        if (r.ticks >= r.totalTicks) {
            end(server, true, false);
        }
    }

    private static boolean touched(BallEntity ball, ServerPlayer player) {
        if (ball.carrier() == player || player.getUUID().equals(ball.lastToucher())) {
            return true;
        }
        double dx = ball.getX() - player.getX();
        double dz = ball.getZ() - player.getZ();
        double dy = ball.getY() - player.getY();
        return dx * dx + dz * dz < 0.8 * 0.8 && dy > -0.6 && dy < 2.0;
    }

    private static void fire(Run r, ServerPlayer player, double progress) {
        if (r.ball != null) {
            r.ball.discard();
        }
        java.util.Random random = new java.util.Random();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        double ox = player.getX();
        double oz = player.getZ();
        for (int attempt = 0; attempt < 12; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double distance = 7 + random.nextDouble() * 4;
            double x = player.getX() + Math.cos(angle) * distance;
            double z = player.getZ() + Math.sin(angle) * distance;
            pos.set(Math.floor(x), Math.floor(player.getY()), Math.floor(z));
            if (r.level.getBlockState(pos).isAir() && r.level.getBlockState(pos.above()).isAir()) {
                ox = x;
                oz = z;
                break;
            }
        }
        r.ball = BallEntity.spawn(r.level, ox, player.getY() + 0.3, oz);
        double aimX = player.getX() + (random.nextDouble() - 0.5) * 3 - ox;
        double aimZ = player.getZ() + (random.nextDouble() - 0.5) * 3 - oz;
        double speed = START_SPEED + (END_SPEED - START_SPEED) * progress;
        r.ball.knockLoose(aimX, aimZ, speed);
        r.level.playSound(null, r.ball.blockPosition(), ModSounds.KICK.get(), net.minecraft.sounds.SoundSource.PLAYERS, 0.7F, 0.9F);
    }

    /** Ends the trial. quiet: no message (the player left). */
    private static void end(MinecraftServer server, boolean passed, boolean quiet) {
        Run r = run;
        run = null;
        if (r == null) {
            return;
        }
        if (r.ball != null) {
            r.ball.discard();
        }
        ServerPlayer player = server.getPlayerList().getPlayer(r.player);
        if (player != null && !quiet) {
            player.sendSystemMessage(Component.translatable(passed ? "bluelock.trial.passed" : "bluelock.trial.failed"));
        }
        if (!quiet) {
            StoryManager.onTrialFinished(server, r.player, r.beatIndex, passed);
        }
    }
}
