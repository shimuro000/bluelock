package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Server to client: profile, skill and quest definitions and match settings for the menu screens. */
public record MenuStatePacket(CompoundTag data) {
    public static void encode(MenuStatePacket m, FriendlyByteBuf buf) {
        MenuPackets.write(buf, m.data());
    }

    public static MenuStatePacket decode(FriendlyByteBuf buf) {
        CompoundTag tag = buf.readNbt();
        return new MenuStatePacket(tag == null ? new CompoundTag() : tag);
    }

    public static void handle(MenuStatePacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> ClientMenuState.update(m.data()));
        context.setPacketHandled(true);
    }
}
