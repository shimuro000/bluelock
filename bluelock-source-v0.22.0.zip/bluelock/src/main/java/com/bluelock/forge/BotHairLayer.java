package com.bluelock.forge;

import com.bluelock.common.ai.Roster;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;

/** Draws the 3D hair of a bot on the plain (non-animated) bot model. Client only. */
public final class BotHairLayer extends RenderLayer<BotEntity, HumanoidModel<BotEntity>> {
    public BotHairLayer(RenderLayerParent<BotEntity, HumanoidModel<BotEntity>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, BotEntity bot,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (bot.isInvisible()) {
            return;
        }
        poseStack.pushPose();
        getParentModel().head.translateAndRotate(poseStack);
        poseStack.scale(1.0F / 16.0F, 1.0F / 16.0F, 1.0F / 16.0F);
        BodyDraw.head(poseStack, buffer, Roster.bodyForLook(bot.look()), packedLight);
        HairDraw.draw(poseStack, buffer, Roster.hairForLook(bot.look()), packedLight);
        poseStack.popPose();
    }
}
