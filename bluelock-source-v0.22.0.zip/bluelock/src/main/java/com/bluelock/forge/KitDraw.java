package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import com.bluelock.common.appearance.KitDesign;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Draws a football kit as coloured blocks laid over the body parts (client only). The pose stack has to be in a
 * body part's own pixel space; the callers set that up for the plain model (vanilla part space, y down) and for the
 * animated model (model space, y up). Number and name are drawn as text on the back.
 */
public final class KitDraw {
    private static final ResourceLocation WHITE = new ResourceLocation(BlueLockConstants.MOD_ID, "textures/hair/white.png");
    private static final float G = 0.5F;   // how far the kit stands off the body (the skin's own jacket layer is 0.25)

    private KitDraw() {
    }

    /** One box, all sizes in pixels. */
    public static void box(PoseStack ps, MultiBufferSource buffer, float x0, float y0, float z0, float x1, float y1, float z1,
                           int rgb, int light) {
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(WHITE));
        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        float[][] face = {
                {x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, 0, 0, -1, 0.80F},   // -z
                {x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1, 0, 0, 1, 0.80F},    // +z
                {x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, -1, 0, 0, 0.65F},   // -x
                {x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, 1, 0, 0, 0.65F},    // +x
                {x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, 0, -1, 0, 0.55F},   // -y
                {x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, 0, 1, 0, 1.00F},    // +y
        };
        for (float[] f : face) {
            int r = Math.min(255, Math.round(((rgb >> 16) & 255) * f[15]));
            int g = Math.min(255, Math.round(((rgb >> 8) & 255) * f[15]));
            int b = Math.min(255, Math.round((rgb & 255) * f[15]));
            for (int i = 0; i < 4; i++) {
                vc.vertex(m, f[i * 3] , f[i * 3 + 1], f[i * 3 + 2])
                        .color(r, g, b, 255)
                        .uv(0.5F, 0.5F)
                        .overlayCoords(OverlayTexture.NO_OVERLAY)
                        .uv2(light)
                        .normal(n, f[12], f[13], f[14])
                        .endVertex();
            }
        }
    }

    /** Which part of the kit a body part carries. */
    public enum Part { BODY, RIGHT_ARM, LEFT_ARM, RIGHT_LEG, LEFT_LEG }

    /**
     * Draws the kit pieces of one body part. The box sizes are for the plain model (vanilla part space: the part's
     * pivot is the origin, y points down). yDown false means the animated model: absolute model space, y up.
     */
    public static void part(PoseStack ps, MultiBufferSource buffer, KitDesign kit, Part part, boolean yDown, int light) {
        if (yDown) {
            switch (part) {
                case BODY -> {
                    box(ps, buffer, -4 - G, 0 - G, -2 - G, 4 + G, 12 + G, 2 + G, kit.shirt(), light);
                    box(ps, buffer, -1.5F, -G, -2 - G - 0.05F, 1.5F, 0.6F, 2 + G + 0.05F, kit.trim(), light);       // collar
                }
                case RIGHT_ARM -> {
                    box(ps, buffer, -3 - G, -2 - G, -2 - G, 1 + G, 4, 2 + G, kit.shirt(), light);
                    box(ps, buffer, -3 - G - 0.05F, 3, -2 - G - 0.05F, 1 + G + 0.05F, 4, 2 + G + 0.05F, kit.trim(), light);
                }
                case LEFT_ARM -> {
                    box(ps, buffer, -1 - G, -2 - G, -2 - G, 3 + G, 4, 2 + G, kit.shirt(), light);
                    box(ps, buffer, -1 - G - 0.05F, 3, -2 - G - 0.05F, 3 + G + 0.05F, 4, 2 + G + 0.05F, kit.trim(), light);
                }
                case RIGHT_LEG, LEFT_LEG -> {
                    box(ps, buffer, -2 - G, 0 - G, -2 - G, 2 + G, 6, 2 + G, kit.shorts(), light);
                    box(ps, buffer, -2 - G, 7, -2 - G, 2 + G, 12 + 0.1F, 2 + G, kit.socks(), light);
                    box(ps, buffer, -2 - G - 0.05F, 7, -2 - G - 0.05F, 2 + G + 0.05F, 8, 2 + G + 0.05F, kit.trim(), light);
                }
            }
        } else {
            switch (part) {
                case BODY -> {
                    box(ps, buffer, -4 - G, 12 - G, -2 - G, 4 + G, 24 + G, 2 + G, kit.shirt(), light);
                    box(ps, buffer, -1.5F, 23.4F, -2 - G - 0.05F, 1.5F, 24 + G, 2 + G + 0.05F, kit.trim(), light);
                }
                case RIGHT_ARM -> {
                    box(ps, buffer, -8 - G, 18, -2 - G, -4 + G, 24 + G, 2 + G, kit.shirt(), light);
                    box(ps, buffer, -8 - G - 0.05F, 18, -2 - G - 0.05F, -4 + G + 0.05F, 19, 2 + G + 0.05F, kit.trim(), light);
                }
                case LEFT_ARM -> {
                    box(ps, buffer, 4 - G, 18, -2 - G, 8 + G, 24 + G, 2 + G, kit.shirt(), light);
                    box(ps, buffer, 4 - G - 0.05F, 18, -2 - G - 0.05F, 8 + G + 0.05F, 19, 2 + G + 0.05F, kit.trim(), light);
                }
                case RIGHT_LEG -> legUp(ps, buffer, kit, -3.9F, 0.1F, light);
                case LEFT_LEG -> legUp(ps, buffer, kit, -0.1F, 3.9F, light);
            }
        }
    }

    private static void legUp(PoseStack ps, MultiBufferSource buffer, KitDesign kit, float x0, float x1, int light) {
        box(ps, buffer, x0 - G, 6, -2 - G, x1 + G, 12 + G, 2 + G, kit.shorts(), light);
        box(ps, buffer, x0 - G, -0.1F, -2 - G, x1 + G, 5, 2 + G, kit.socks(), light);
        box(ps, buffer, x0 - G - 0.05F, 4, -2 - G - 0.05F, x1 + G + 0.05F, 5, 2 + G + 0.05F, kit.trim(), light);
    }

    /**
     * Number and name on the back of the shirt. The pose stack is in the body's pixel space. centreY is the pixel
     * height of the middle of the number; yDown tells which way y points.
     */
    public static void backText(PoseStack ps, MultiBufferSource buffer, KitDesign kit, boolean yDown, int light) {
        Font font = Minecraft.getInstance().font;
        float z = 2 + G + 0.12F;
        float ySign = yDown ? 1.0F : -1.0F;         // text itself always runs downward
        float numberTop = yDown ? 3.2F : 20.6F;
        float nameTop = yDown ? 0.9F : 22.9F;
        int color = 0xFF000000 | kit.trim();
        String number = Integer.toString(kit.number());
        ps.pushPose();
        ps.translate(0.0F, numberTop, z);
        float s = 0.62F;
        ps.scale(-s, ySign * s, s);
        font.drawInBatch(number, -font.width(number) / 2.0F, 0, color, false, ps.last().pose(), buffer, Font.DisplayMode.NORMAL, 0, light);
        ps.popPose();
        if (!kit.name().isEmpty()) {
            float ns = Math.min(0.30F, 7.6F / Math.max(1, font.width(kit.name())));
            ps.pushPose();
            ps.translate(0.0F, nameTop, z);
            ps.scale(-ns, ySign * ns, ns);
            font.drawInBatch(kit.name(), -font.width(kit.name()) / 2.0F, 0, color, false, ps.last().pose(), buffer, Font.DisplayMode.NORMAL, 0, light);
            ps.popPose();
        }
    }
}
