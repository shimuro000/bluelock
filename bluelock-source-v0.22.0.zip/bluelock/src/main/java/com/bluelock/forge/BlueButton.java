package com.bluelock.forge;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** A flat navy button with a coloured edge and a blue hover flash (client only). */
public final class BlueButton extends Button {
    private final int accent;

    public BlueButton(int x, int y, int width, int height, Component label, OnPress onPress, int accent) {
        super(x, y, width, height, label, onPress, DEFAULT_NARRATION);
        this.accent = accent;
    }

    @Override
    protected void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        boolean hover = isHoveredOrFocused() && active;
        int background = !active ? 0xAA121B2E : hover ? BlueUi.BLUE : 0xDD0F2A5C;
        g.fill(getX(), getY(), getX() + width, getY() + height, background);
        g.fill(getX(), getY(), getX() + 3, getY() + height, active ? accent : 0xFF3A4660);
        Font font = Minecraft.getInstance().font;
        g.drawCenteredString(font, getMessage(), getX() + width / 2 + 1, getY() + (height - 8) / 2, active ? BlueUi.WHITE : 0xFF6B7A99);
    }
}
