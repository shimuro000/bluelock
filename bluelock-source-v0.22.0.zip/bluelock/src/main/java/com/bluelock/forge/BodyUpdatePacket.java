package com.bluelock.forge;

import com.bluelock.common.appearance.BodyDesign;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Client to server: "this is my new body" (from the body maker opened in the menu). The server clamps every value. */
public record BodyUpdatePacket(int[] body) {
    public static void encode(BodyUpdatePacket m, FriendlyByteBuf buf) {
        for (int i = 0; i < BodyDesign.INT_COUNT; i++) {
            buf.writeInt(i < m.body().length ? m.body()[i] : 0);
        }
    }

    public static BodyUpdatePacket decode(FriendlyByteBuf buf) {
        int[] body = new int[BodyDesign.INT_COUNT];
        for (int i = 0; i < body.length; i++) {
            body[i] = buf.readInt();
        }
        return new BodyUpdatePacket(body);
    }

    public static void handle(BodyUpdatePacket m, Supplier<NetworkEvent.Context> ctx) {
        MenuPackets.serverSide(ctx, player -> BodySync.update(player, BodyDesign.fromInts(m.body())));
    }
}
