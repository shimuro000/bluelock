package com.bluelock.forge;

import com.bluelock.common.match.Side;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.progression.SkillRules;
import com.bluelock.common.story.StoryBook;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Story mode on the server: opens the player's current beat (a scene is sent to the client, a match is started on the
 * pitch), judges the match result against the objective, pays the reward and moves on. The progress is one number on the
 * profile, so it survives restarts. Only one story match runs at a time.
 */
public final class StoryManager {
    private static final int NEXT_DELAY_TICKS = 100;
    private static final String HOME_TEAM = "team_z";

    /** Players whose story match is running: player id to the beat index being played. */
    private static final Map<UUID, Integer> PLAYING = new HashMap<>();
    /** Players waiting for the next beat to open after a match: player id to ticks left. */
    private static final Map<UUID, Integer> WAITING = new HashMap<>();

    /** Where each player was last taken, so the place title shows only when they arrive somewhere new. */
    private static final Map<UUID, String> LAST_PLACE = new HashMap<>();

    private StoryManager() {
    }

    private static Optional<PlayerProfile> profile(MinecraftServer server, UUID id) {
        return ProfileSavedData.get(server).load(id);
    }

    /** Opens whatever the player's current beat is. */
    public static void open(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        Optional<PlayerProfile> found = profile(server, player.getUUID());
        if (found.isEmpty()) {
            player.sendSystemMessage(Component.translatable("bluelock.error.no_profile"));
            return;
        }
        PlayerProfile p = found.get();
        StoryBook.Beat beat = StoryBook.beat(p.storyBeat());
        if (CampusBuilder.built(server) && CampusBuilder.go(player, beat.place())) {
            announcePlace(player, beat.place());
        }
        switch (beat.kind()) {
            case SCENE -> {
                WAITING.remove(player.getUUID());
                BlueLockNetwork.sendToPlayer(player, new StoryScenePacket(beat.id()));
            }
            case MATCH -> startMatch(player, p, beat);
            case TRIAL -> TrialManager.start(player, p.storyBeat(), beat);
            case END -> player.sendSystemMessage(Component.translatable("bluelock.story_ui.finished"));
        }
    }

    private static void announcePlace(ServerPlayer player, String place) {
        if (place.equals(LAST_PLACE.put(player.getUUID(), place))) {
            return;
        }
        player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket(10, 50, 15));
        player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket(Component.translatable("bluelock.place.sub")));
        player.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket(Component.translatable("bluelock.place." + place)));
    }

    private static void startMatch(ServerPlayer player, PlayerProfile p, StoryBook.Beat beat) {
        if (!MatchManager.hasPitch()) {
            player.sendSystemMessage(Component.translatable("bluelock.story_ui.need_pitch"));
            return;
        }
        if (!PLAYING.isEmpty() && !PLAYING.containsKey(player.getUUID())) {
            player.sendSystemMessage(Component.translatable("bluelock.story_ui.busy"));
            return;
        }
        MinecraftServer server = player.getServer();
        MatchManager.stopMatch();
        if (CampusBuilder.built(server)) {
            MatchManager.setMode(com.bluelock.common.team.MatchMode.ELEVEN_V_ELEVEN);   // the campus stadium is a full-size pitch
            MatchManager.setPractice(false);
        }
        MatchManager.setBotsEnabled(true);
        MatchManager.setTeam(Side.HOME, HOME_TEAM);
        MatchManager.setTeam(Side.AWAY, beat.opponent());
        MatchManager.join(player.getUUID(), Side.HOME, p.archetype());
        MatchManager.startMatch(server, beat.length());
        PLAYING.put(player.getUUID(), p.storyBeat());
        player.sendSystemMessage(Component.translatable(StoryBook.beat(p.storyBeat()).briefKey()));
        player.sendSystemMessage(Component.translatable("bluelock.story_ui.objective",
                Component.translatable("bluelock.story.objective." + beat.objective().name().toLowerCase(java.util.Locale.ROOT))));
    }

    /** The client finished reading a scene: move to the next beat (only if it really is the current scene). */
    public static void advance(ServerPlayer player, String sceneId) {
        MinecraftServer server = player.getServer();
        Optional<PlayerProfile> found = profile(server, player.getUUID());
        if (found.isEmpty()) {
            return;
        }
        PlayerProfile p = found.get();
        StoryBook.Beat beat = StoryBook.beat(p.storyBeat());
        if (beat.kind() != StoryBook.Kind.SCENE || !beat.id().equals(sceneId)) {
            return;
        }
        p.setStoryBeat(p.storyBeat() + 1);
        ProfileSavedData.get(server).save(p);
        MenuServer.sendState(player);
        if (StoryBook.beat(p.storyBeat()).kind() == StoryBook.Kind.MATCH) {
            open(player);   // a scene that leads into a match goes straight to the pitch
        } else if (StoryBook.isFinished(p.storyBeat())) {
            open(player);
        }
    }

    public static void restart(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        profile(server, player.getUUID()).ifPresent(p -> {
            p.setStoryBeat(0);
            ProfileSavedData.get(server).save(p);
        });
        PLAYING.remove(player.getUUID());
        WAITING.remove(player.getUUID());
        MenuServer.sendState(player);
        player.sendSystemMessage(Component.translatable("bluelock.story_ui.restarted"));
    }

    public static void status(ServerPlayer player) {
        profile(player.getServer(), player.getUUID()).ifPresent(p -> {
            int beat = p.storyBeat();
            player.sendSystemMessage(Component.translatable("bluelock.story_ui.progress", Math.min(beat + 1, StoryBook.size()), StoryBook.size()));
            player.sendSystemMessage(Component.translatable(StoryBook.beat(beat).titleKey()));
        });
    }

    /** Called when a match ends: judges every story player that was playing it. */
    public static void onFinished(MinecraftServer server, int homeGoals, int awayGoals) {
        Iterator<Map.Entry<UUID, Integer>> it = PLAYING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            it.remove();
            ServerPlayer player = server.getPlayerList().getPlayer(e.getKey());
            Optional<PlayerProfile> found = profile(server, e.getKey());
            if (player == null || found.isEmpty()) {
                continue;
            }
            PlayerProfile p = found.get();
            if (p.storyBeat() != e.getValue()) {
                continue;
            }
            StoryBook.Beat beat = StoryBook.beat(p.storyBeat());
            if (beat.kind() != StoryBook.Kind.MATCH) {
                continue;
            }
            if (StoryBook.passed(beat.objective(), homeGoals, awayGoals)) {
                passBeat(server, player, p, beat);
            } else {
                player.sendSystemMessage(Component.translatable("bluelock.story_ui.failed"));
            }
        }
    }

    /** Pays the reward of a beat, moves on and schedules the next beat to open. */
    private static void passBeat(MinecraftServer server, ServerPlayer player, PlayerProfile p, StoryBook.Beat beat) {
        int rankBefore = com.bluelock.common.rank.Ranking.rankOf(p.rankPoints());
        reward(player, p, beat);
        p.addRankPoints(beat.xp());
        p.setStoryBeat(p.storyBeat() + 1);
        ProfileSavedData.get(server).save(p);
        MenuServer.sendState(player);
        player.sendSystemMessage(Component.translatable("bluelock.story_ui.passed", beat.xp(), beat.skillPoints(), beat.devPoints()));
        Rewards.announceRank(player, rankBefore, com.bluelock.common.rank.Ranking.rankOf(p.rankPoints()));
        WAITING.put(player.getUUID(), NEXT_DELAY_TICKS);
    }

    /** The touch trial ended: judge it like a match. */
    public static void onTrialFinished(MinecraftServer server, UUID id, int beatIndex, boolean passed) {
        ServerPlayer player = server.getPlayerList().getPlayer(id);
        Optional<PlayerProfile> found = profile(server, id);
        if (player == null || found.isEmpty()) {
            return;
        }
        PlayerProfile p = found.get();
        StoryBook.Beat beat = StoryBook.beat(p.storyBeat());
        if (p.storyBeat() != beatIndex || beat.kind() != StoryBook.Kind.TRIAL) {
            return;
        }
        if (passed) {
            passBeat(server, player, p, beat);
        } else {
            player.sendSystemMessage(Component.translatable("bluelock.story_ui.failed"));
        }
    }

    private static void reward(ServerPlayer player, PlayerProfile p, StoryBook.Beat beat) {
        Progression.LevelUp up = Progression.award(p, beat.xp());
        p.setProgression(p.level(), p.xp(), p.skillPoints() + beat.skillPoints(), p.developmentPoints() + beat.devPoints());
        SkillRules.autoUnlockRoots(p, BlueLockData.get());
        if (up.happened()) {
            player.sendSystemMessage(Component.translatable("bluelock.progress.levelup", up.newLevel(),
                    Progression.SKILL_POINTS_PER_LEVEL * up.levelsGained(), Progression.DEVELOPMENT_POINTS_PER_LEVEL * up.levelsGained()));
        }
    }

    /** A player left, or the match was stopped by hand: forget the running story match. */
    public static void forget(UUID player) {
        PLAYING.remove(player);
        WAITING.remove(player);
    }

    public static void tick(MinecraftServer server) {
        if (WAITING.isEmpty()) {
            return;
        }
        Iterator<Map.Entry<UUID, Integer>> it = WAITING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            if (e.setValue(e.getValue() - 1) <= 1) {
                it.remove();
                ServerPlayer player = server.getPlayerList().getPlayer(e.getKey());
                if (player != null) {
                    open(player);
                }
            }
        }
    }
}
