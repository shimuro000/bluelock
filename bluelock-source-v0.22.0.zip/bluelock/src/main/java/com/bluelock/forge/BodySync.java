package com.bluelock.forge;

import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.profile.PlayerProfile;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

/** Server side of the body: saves a changed body and tells every client, so other players see it too. */
public final class BodySync {
    private BodySync() {
    }

    /** A player changed their body in the menu. Only players with a character can have one. */
    public static void update(ServerPlayer player, BodyDesign design) {
        ProfileSavedData store = ProfileSavedData.get(player.getServer());
        Optional<PlayerProfile> profile = store.load(player.getUUID());
        if (profile.isEmpty()) {
            return;
        }
        profile.get().setBody(design);
        store.save(profile.get());
        broadcast(player.getUUID(), design);
        MenuServer.sendState(player);
    }

    /** Sends one player's body to everybody. */
    public static void broadcast(UUID id, BodyDesign design) {
        BlueLockNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), new BodySyncPacket(id, design.toInts()));
    }

    /** A player joined: they learn everybody's body, and everybody learns theirs. */
    public static void onLogin(ServerPlayer joiner) {
        ProfileSavedData store = ProfileSavedData.get(joiner.getServer());
        for (ServerPlayer other : joiner.getServer().getPlayerList().getPlayers()) {
            store.load(other.getUUID()).ifPresent(p ->
                    BlueLockNetwork.sendToPlayer(joiner, new BodySyncPacket(other.getUUID(), p.body().toInts())));
        }
        store.load(joiner.getUUID()).ifPresent(p -> broadcast(joiner.getUUID(), p.body()));
    }
}
