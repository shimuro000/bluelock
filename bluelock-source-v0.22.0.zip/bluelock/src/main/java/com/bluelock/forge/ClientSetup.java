package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/** Client-only setup: entity renderers, the hair layer, key bindings and the on-screen display. */
@Mod.EventBusSubscriber(modid = BlueLockConstants.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.BALL.get(), context -> new ThrownItemRenderer<>(context, 0.9F, false));
        event.registerEntityRenderer(ModEntities.BOT.get(), GeoClientSupport::createBotRenderer);
    }

    /** Adds the 3D hair to every player model (the normal and the slim arm model). */
    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers event) {
        for (String skin : event.getSkins()) {
            EntityRenderer<? extends Player> renderer = event.getSkin(skin);
            if (renderer instanceof PlayerRenderer playerRenderer) {
                playerRenderer.addLayer(new KitRenderLayer(playerRenderer));
                playerRenderer.addLayer(new HairRenderLayer(playerRenderer));
            }
        }
    }

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(AnimationBridge::initClient);
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        for (var key : ClientKeys.BY_ACTION) {
            event.register(key);
        }
        for (var key : ClientKeys.SLOTS) {
            event.register(key);
        }
        event.register(ClientKeys.MENU);
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("hud", new ClientHud());
    }
}
