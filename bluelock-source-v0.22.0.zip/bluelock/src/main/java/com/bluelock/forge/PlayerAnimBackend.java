package com.bluelock.forge;

import net.minecraft.world.entity.player.Player;

/** Plays custom player animations. Implemented with PlayerAnimator (only present in the build with animation libraries). */
public interface PlayerAnimBackend {
    void play(Player player, String name);

    void stop(Player player);
}
