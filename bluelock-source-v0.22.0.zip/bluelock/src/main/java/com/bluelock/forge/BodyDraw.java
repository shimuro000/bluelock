package com.bluelock.forge;

import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.appearance.KitDesign;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;

/**
 * Draws a {@link BodyDesign} (client only): the skin tone as a coat of blocks over the head, body, arms and legs, and
 * the face (eyes, eyebrows, mouth, a mark) as thin flat blocks on the front of the head. It reuses {@link KitDraw#box}.
 * Head methods work in the vanilla head space (pixels, y down, the front is -z). Limb methods work in either the
 * plain model's part space (yDown true) or the animated model's absolute space (yDown false).
 */
public final class BodyDraw {
    /** What a player wears with no match kit on: a plain dark training kit. */
    public static final KitDesign TRAINING = new KitDesign(0x1B2A4A, 0x3CC8FF, 0x10182C, 0x1B2A4A, 0, "");

    private static final float S = 0.3F;            // the skin coat stands this far off the model
    private static final int WHITE = 0xF2F2F2;
    private static final int LIP = 0x8A3F3F;
    private static final int DARK = 0x1C1418;

    private BodyDraw() {
    }

    private static int shade(int rgb, double f) {
        int r = (int) Math.min(255, Math.round(((rgb >> 16) & 255) * f));
        int g = (int) Math.min(255, Math.round(((rgb >> 8) & 255) * f));
        int b = (int) Math.min(255, Math.round((rgb & 255) * f));
        return (r << 16) | (g << 8) | b;
    }

    // ---------- limbs ----------

    public static void limb(PoseStack ps, MultiBufferSource buffer, BodyDesign body, KitDraw.Part part, boolean yDown, int light) {
        float x0;
        float x1;
        float y0;
        float y1;
        if (yDown) {
            switch (part) {
                case BODY -> { x0 = -4; x1 = 4; y0 = 0; y1 = 12; }
                case RIGHT_ARM -> { x0 = -3; x1 = 1; y0 = -2; y1 = 10; }
                case LEFT_ARM -> { x0 = -1; x1 = 3; y0 = -2; y1 = 10; }
                default -> { x0 = -2; x1 = 2; y0 = 0; y1 = 12; }
            }
        } else {
            switch (part) {
                case BODY -> { x0 = -4; x1 = 4; y0 = 12; y1 = 24; }
                case RIGHT_ARM -> { x0 = -8; x1 = -4; y0 = 12; y1 = 24; }
                case LEFT_ARM -> { x0 = 4; x1 = 8; y0 = 12; y1 = 24; }
                case RIGHT_LEG -> { x0 = -3.9F; x1 = 0.1F; y0 = 0; y1 = 12; }
                default -> { x0 = -0.1F; x1 = 3.9F; y0 = 0; y1 = 12; }
            }
        }
        KitDraw.box(ps, buffer, x0 - S, y0 - S, -2 - S, x1 + S, y1 + S, 2 + S, body.skin(), light);
    }

    // ---------- head and face ----------

    public static void head(PoseStack ps, MultiBufferSource buffer, BodyDesign body, int light) {
        KitDraw.box(ps, buffer, -4 - S, -8 - S, -4 - S, 4 + S, 0 + S, 4 + S, body.skin(), light);
        face(ps, buffer, body, light);
    }

    private static void face(PoseStack ps, MultiBufferSource buffer, BodyDesign body, int light) {
        float z = -4 - S - 0.02F;
        int hair = 0x2A1E1A;
        int skin = body.skin();
        for (int side = -1; side <= 1; side += 2) {
            // eye shape: {half width of the white, height, iris width}
            float[] e = switch (body.eyeStyle()) {
                case 1 -> new float[] {1.0F, 1.0F, 0.9F};
                case 2 -> new float[] {1.0F, 2.0F, 1.5F};
                case 3 -> new float[] {1.0F, 1.2F, 1.0F};
                case 4 -> new float[] {1.0F, 1.0F, 1.0F};
                case 5 -> new float[] {1.2F, 1.8F, 1.6F};
                default -> new float[] {1.0F, 1.4F, 1.0F};
            };
            float inner = 0.9F;
            float outer = inner + e[0] * 2;
            float top = -4.6F;
            float bottom = top + e[1];
            fx(ps, buffer, side, inner, outer, top, bottom, z, WHITE, light);
            float mid = (inner + outer) / 2;
            fx(ps, buffer, side, mid - e[2] / 2, mid + e[2] / 2, top, bottom, z - 0.02F, body.eyeColor(), light);
            fx(ps, buffer, side, mid - 0.35F, mid + 0.35F, top + 0.15F, bottom - 0.15F, z - 0.04F, DARK, light);
            if (body.eyeStyle() == 3) {
                fx(ps, buffer, side, inner, outer, top, top + e[1] * 0.5F, z - 0.06F, shade(skin, 0.85), light);
            }
            switch (body.brow()) {
                case 1 -> fx(ps, buffer, side, 0.8F, 3.3F, -5.7F, -5.1F, z, hair, light);
                case 2 -> {
                    fx(ps, buffer, side, 0.8F, 2.0F, -5.2F, -4.7F, z, hair, light);
                    fx(ps, buffer, side, 2.0F, 3.3F, -5.7F, -5.2F, z, hair, light);
                }
                case 3 -> fx(ps, buffer, side, 0.7F, 3.4F, -6.0F, -5.0F, z, hair, light);
                default -> fx(ps, buffer, side, 1.0F, 3.1F, -5.5F, -5.1F, z, shade(hair, 1.4), light);
            }
            if (body.mark() == 4) {
                fx(ps, buffer, side, 2.2F, 3.6F, -2.9F, -2.1F, z, 0xE58A8A, light);
            }
        }
        switch (body.mouth()) {
            case 1 -> {
                fx(ps, buffer, 1, -1.2F, 1.2F, -1.4F, -1.0F, z, LIP, light);
                fx(ps, buffer, 1, 1.2F, 1.6F, -1.8F, -1.4F, z, LIP, light);
                fx(ps, buffer, 1, -1.6F, -1.2F, -1.8F, -1.4F, z, LIP, light);
            }
            case 2 -> {
                fx(ps, buffer, 1, -1.0F, 1.0F, -1.4F, -1.0F, z, LIP, light);
                fx(ps, buffer, 1, 1.0F, 1.5F, -1.8F, -1.4F, z, LIP, light);
            }
            case 3 -> {
                fx(ps, buffer, 1, -1.5F, 1.5F, -1.8F, -0.9F, z, WHITE, light);
                fx(ps, buffer, 1, -1.5F, 1.5F, -1.4F, -1.25F, z - 0.02F, DARK, light);
            }
            default -> fx(ps, buffer, 1, -1.0F, 1.0F, -1.4F, -1.0F, z, LIP, light);
        }
        switch (body.mark()) {
            case 1 -> {
                int dot = 0x9C5B3A;
                for (int side = -1; side <= 1; side += 2) {
                    fx(ps, buffer, side, 1.2F, 1.7F, -2.9F, -2.4F, z, dot, light);
                    fx(ps, buffer, side, 2.2F, 2.7F, -3.1F, -2.6F, z, dot, light);
                    fx(ps, buffer, side, 2.9F, 3.4F, -2.6F, -2.1F, z, dot, light);
                }
            }
            case 2 -> {
                fx(ps, buffer, 1, 1.6F, 2.0F, -6.2F, -2.8F, z - 0.08F, 0xA03A3A, light);
                fx(ps, buffer, 1, 1.1F, 2.5F, -4.4F, -4.1F, z - 0.1F, 0xD7A0A0, light);
            }
            case 3 -> fx(ps, buffer, 1, 2.2F, 2.7F, -1.9F, -1.4F, z, DARK, light);
            default -> { }
        }
    }

    /** A flat block on the face plane. side +1/-1 mirrors x; x0..x1 are measured from the middle of the face outwards. */
    private static void fx(PoseStack ps, MultiBufferSource buffer, int side, float x0, float x1, float y0, float y1, float z, int rgb, int light) {
        float a = side * x0;
        float b = side * x1;
        KitDraw.box(ps, buffer, Math.min(a, b), y0, z - 0.04F, Math.max(a, b), y1, z, rgb, light);
    }
}
