package com.bluelock.forge;

import com.bluelock.common.ai.BotDifficulty;
import com.bluelock.common.ai.BotEnergy;
import com.bluelock.common.ai.BotSpeed;
import com.bluelock.common.ai.CharacterTraits;
import com.bluelock.common.ai.FootballCharacter;
import com.bluelock.common.ai.Roster;
import com.bluelock.common.appearance.KitDesign;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatEffects;
import net.minecraft.core.particles.ParticleTypes;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.bluelock.common.ai.BotStats;
import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.stats.StatBlock;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * A football bot (the AI opponent or team-mate). It has no normal Minecraft AI: the match manager asks the bot
 * brain (common module) what to do a few times per second and tells the entity where to run.
 * Bots are not saved with the world and cannot be hurt.
 */
public class BotEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> DATA_SIDE = SynchedEntityData.defineId(BotEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_CARRYING = SynchedEntityData.defineId(BotEntity.class, EntityDataSerializers.BOOLEAN);

    private static final EntityDataAccessor<Integer> DATA_LOOK = SynchedEntityData.defineId(BotEntity.class, EntityDataSerializers.INT);

    private static final EntityDataAccessor<Integer> DATA_KIT_COLOR = SynchedEntityData.defineId(BotEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_NUMBER = SynchedEntityData.defineId(BotEntity.class, EntityDataSerializers.INT);
    /** Blocks per tick that one point of the movement-speed attribute is worth when the bot drives itself. */
    private static final double BLOCKS_PER_ATTRIBUTE = 2.0;

    private double wantX;
    private double wantZ;
    private double wantFactor;
    private long wantUntil = -1;
    private long boostUntil;
    private double boostMul = 1.0;
    private final Map<String, Long> skillReadyAt = new HashMap<>();
    private CharacterTraits traits = CharacterTraits.NEUTRAL;
    private BotEnergy energy = new BotEnergy(CharacterTraits.NEUTRAL.sprintSeconds());
    private FootballCharacter character;
    private double jogAttribute = 0.17;
    private double sprintMultiplier = 1.35;
    private Position botPosition = Position.CM;
    private int slotIndex;
    private int rating = 50;
    private StatBlock stats = BotStats.forRating(50, Position.CM);
    long tackleReadyAt;
    private int diveTicks;
    private double diveX;
    private double diveZ;
    private int diveSign;
    long keeperLockUntil;

    public BotEntity(EntityType<? extends BotEntity> type, Level level) {
        super(type, level);
        setInvulnerable(true);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MOVEMENT_SPEED, 0.12D)
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_SIDE, 0);
        this.entityData.define(DATA_CARRYING, false);
        this.entityData.define(DATA_LOOK, -1);
        this.entityData.define(DATA_KIT_COLOR, 0x2F6BFF);
        this.entityData.define(DATA_NUMBER, 0);
    }

    public void configure(Side side, int slot, Position position, int rating, double speedFactor) {
        configure(side, slot, position, rating, speedFactor, null);
    }

    /** character may be null: the bot is then a nameless player with position-based traits. */
    public void configure(Side side, int slot, Position position, int rating, double speedFactor, FootballCharacter character) {
        this.entityData.set(DATA_SIDE, side == Side.HOME ? 0 : 1);
        this.slotIndex = slot;
        this.botPosition = position;
        this.character = character;
        this.traits = character != null ? character.traits() : CharacterTraits.forPosition(position);
        int total = character != null ? rating + character.ratingBonus() : rating;
        this.rating = Math.max(20, Math.min(95, total));
        this.stats = character != null ? BotStats.forCharacter(rating, character) : BotStats.forRating(this.rating, position);
        this.energy = new BotEnergy(traits.sprintSeconds() * StatEffects.sprintLength(stats.permanent(Stat.STAMINA)));
        double statSpeed = StatEffects.moveSpeed(stats.permanent(Stat.TOP_SPEED), stats.permanent(Stat.ACCELERATION));
        this.jogAttribute = BotSpeed.jog(this.rating, speedFactor, traits, statSpeed);
        this.sprintMultiplier = BotSpeed.sprintMultiplier(jogAttribute, traits);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(jogAttribute);
        this.entityData.set(DATA_LOOK, Roster.lookOf(character, side == Side.HOME ? slot : 50 + slot));
        if (character != null) {
            setCustomName(Component.literal(character.displayName()));
            setCustomNameVisible(true);
        }
    }

    /** The shirt colour and number of this bot (set by the match manager). */
    public void setKit(int colorRgb, int number) {
        this.entityData.set(DATA_KIT_COLOR, colorRgb & 0xFFFFFF);
        this.entityData.set(DATA_NUMBER, number);
    }

    /** What this bot wears: his team's colours, his number and his name. Works on the client too (synced data). */
    public KitDesign kit() {
        FootballCharacter c = Roster.byLook(look());
        return KitDesign.forTeam(this.entityData.get(DATA_KIT_COLOR), this.entityData.get(DATA_NUMBER), c == null ? "" : c.shirtName());
    }

    /** Model size of this bot's character (1.0 for nameless bots). Works on the client too. */
    public float heightScale() {
        FootballCharacter c = Roster.byLook(look());
        return c == null ? 1.0F : (float) c.heightScale();
    }

    /** How wide this bot is compared with normal (from his body design). Works on the client too. */
    public float buildScale() {
        return (float) com.bluelock.common.ai.Roster.bodyForLook(look()).buildScale();
    }

    public List<String> skills() {
        return character == null ? List.of() : character.skills();
    }

    /** Uses a skill if it is off cooldown; returns true when it fired. */
    public boolean tryUse(String skill, long now, int cooldownTicks) {
        if (now < skillReadyAt.getOrDefault(skill, 0L)) {
            return false;
        }
        skillReadyAt.put(skill, now + cooldownTicks);
        return true;
    }

    /** A short speed boost (burst dribble, sprint burst). */
    public void boost(int ticks, double multiplier) {
        this.boostUntil = tickCount + ticks;
        this.boostMul = multiplier;
    }

    public CharacterTraits traits() { return traits; }
    public FootballCharacter character() { return character; }
    public BotEnergy energy() { return energy; }

    /** Synced look code (see Roster.lookOf): clients use it to draw this bot's hair. */
    public int look() {
        return this.entityData.get(DATA_LOOK);
    }

    /** Called with every brain decision: updates the sprint energy and sets the bot's real running speed. */
    public void applySprint(boolean wantSprint, int ticks) {
        boolean sprinting = energy.update(wantSprint, ticks);
        double factor = sprinting ? sprintMultiplier : energy.speedFactor();
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(jogAttribute * factor);
    }

    public Side side() {
        return this.entityData.get(DATA_SIDE) == 0 ? Side.HOME : Side.AWAY;
    }

    /** True while this bot has the ball at his feet (used by the animations). */
    public boolean isCarryingBall() {
        return this.entityData.get(DATA_CARRYING);
    }

    public void setCarrying(boolean carrying) {
        this.entityData.set(DATA_CARRYING, carrying);
    }

    /** Plays a one-shot animation (kick, tackle, dive...). Does nothing without the animation libraries. */
    public void animate(String name) {
        AnimationBridge.playOnBot(this, name);
    }

    public Position botPosition() { return botPosition; }
    public int slotIndex() { return slotIndex; }
    public int rating() { return rating; }
    public StatBlock stats() { return stats; }

    /**
     * Runs toward a world spot. speedFactor 1.0 is the bot's full jog (or sprint). The bot drives itself every tick
     * (see aiStep) instead of using the vanilla move control, so its speed is exactly what the speed numbers say.
     */
    public void runTo(double x, double z, double speedFactor) {
        this.wantX = x;
        this.wantZ = z;
        this.wantFactor = speedFactor;
        this.wantUntil = tickCount + 5;
        getLookControl().setLookAt(x, getEyeY(), z);
    }

    public void stopRunning() {
        getNavigation().stop();
        this.wantUntil = -1;
    }

    /** The goalkeeper throws himself sideways. direction is the world-space sideways vector (unit), sign -1 or +1 (0 = no dive). */
    public void startDive(double dirX, double dirZ, int sign) {
        this.diveX = dirX * sign;
        this.diveZ = dirZ * sign;
        this.diveSign = sign;
        this.diveTicks = 10;
    }

    public boolean isDiving() {
        return diveTicks > 0;
    }

    public int diveSign() {
        return diveSign;
    }

    @Override
    public void aiStep() {
        if (!level().isClientSide && diveTicks <= 0) {
            if (tickCount <= wantUntil) {
                double dx = wantX - getX();
                double dz = wantZ - getZ();
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > 0.2) {
                    double mul = tickCount <= boostUntil ? boostMul : 1.0;
                    double step = Math.min(getAttributeValue(Attributes.MOVEMENT_SPEED) * BLOCKS_PER_ATTRIBUTE * wantFactor * mul, dist);
                    Vec3 old = getDeltaMovement();
                    setDeltaMovement(old.x * 0.3 + dx / dist * step * 0.7, old.y, old.z * 0.3 + dz / dist * step * 0.7);
                    float yaw = (float) (Math.atan2(-dx, dz) * (180.0 / Math.PI));
                    setYRot(yaw);
                    yBodyRot = yaw;
                    yHeadRot = yaw;
                }
            }
        }
        super.aiStep();
        if (!level().isClientSide && energy.isSprinting() && onGround() && tickCount % 3 == 0) {
            Juice.particles(level(), ParticleTypes.CLOUD, getX(), getY() + 0.05, getZ(), 1, 0.12, 0.01);
            if (tickCount % 6 == 0) {
                Juice.sound(level(), getX(), getY(), getZ(), ModSounds.STEP, 0.3F, 0.9F + random.nextFloat() * 0.25F);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && diveTicks > 0) {
            setDeltaMovement(diveX * 0.55, getDeltaMovement().y, diveZ * 0.55);
            diveTicks--;
        }
    }

    @Override
    protected void registerGoals() {
        // no vanilla AI: the match manager drives bots
    }

    @Override
    public boolean removeWhenFarAway(double distanceSquared) {
        return false;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }
}
