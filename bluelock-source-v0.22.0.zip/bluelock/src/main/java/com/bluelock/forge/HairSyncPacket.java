package com.bluelock.forge;

import com.bluelock.common.appearance.HairDesign;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Server to client: the hair of one player. */
public record HairSyncPacket(UUID player, int[] hair) {
    public static void encode(HairSyncPacket m, FriendlyByteBuf buf) {
        buf.writeUUID(m.player());
        for (int i = 0; i < HairDesign.INT_COUNT; i++) {
            buf.writeInt(i < m.hair().length ? m.hair()[i] : 0);
        }
    }

    public static HairSyncPacket decode(FriendlyByteBuf buf) {
        UUID id = buf.readUUID();
        int[] hair = new int[HairDesign.INT_COUNT];
        for (int i = 0; i < hair.length; i++) {
            hair[i] = buf.readInt();
        }
        return new HairSyncPacket(id, hair);
    }

    public static void handle(HairSyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> ClientHair.set(m.player(), HairDesign.fromInts(m.hair())));
        context.setPacketHandled(true);
    }
}
