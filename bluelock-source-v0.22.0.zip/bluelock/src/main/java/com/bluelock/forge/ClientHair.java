package com.bluelock.forge;

import com.bluelock.common.appearance.HairDesign;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * What the client knows about hair: the design of every player (sent by the server), and the design that the hair
 * maker is showing right now on the local player (the preview). Plain data, no client-only classes.
 */
public final class ClientHair {
    private static final Map<UUID, HairDesign> DESIGNS = new HashMap<>();
    /** Set while the hair maker or the creation screen is open; the local player is drawn with this hair. */
    public static HairDesign preview;
    /** How far the preview is turned, in degrees (dragging in the hair maker). */
    public static float previewSpin;

    private ClientHair() {
    }

    public static void set(UUID player, HairDesign design) {
        DESIGNS.put(player, design);
    }

    public static HairDesign get(UUID player) {
        return DESIGNS.get(player);
    }

    public static void clear() {
        DESIGNS.clear();
    }
}
