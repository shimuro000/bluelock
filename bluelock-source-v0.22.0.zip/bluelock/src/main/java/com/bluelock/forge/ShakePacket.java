package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Server to client: shake the camera for a moment. */
public record ShakePacket(float strength, int ticks) {
    public static void encode(ShakePacket m, FriendlyByteBuf buf) {
        buf.writeFloat(m.strength());
        buf.writeVarInt(m.ticks());
    }

    public static ShakePacket decode(FriendlyByteBuf buf) {
        return new ShakePacket(buf.readFloat(), buf.readVarInt());
    }

    public static void handle(ShakePacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> ClientShake.start(m.strength(), m.ticks()));
        context.setPacketHandled(true);
    }
}
