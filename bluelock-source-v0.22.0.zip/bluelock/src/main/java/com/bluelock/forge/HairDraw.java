package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.appearance.HairModel;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Draws a HairDesign as 3D blocks. Shared by the player layer and the two bot layers (client only). */
public final class HairDraw {
    private static final ResourceLocation WHITE = new ResourceLocation(BlueLockConstants.MOD_ID, "textures/hair/white.png");
    private static final int CACHE_LIMIT = 96;
    private static final Map<HairDesign, List<HairModel.Quad>> CACHE = new HashMap<>();

    private HairDraw() {
    }

    public static List<HairModel.Quad> quadsFor(HairDesign design) {
        List<HairModel.Quad> quads = CACHE.get(design);
        if (quads == null) {
            if (CACHE.size() >= CACHE_LIMIT) {
                CACHE.clear();
            }
            quads = HairModel.build(design);
            CACHE.put(design, quads);
        }
        return quads;
    }

    /**
     * Draws the hair. The pose stack must already be at the head, in head-model pixels
     * (x right, y down, front = -z), i.e. with 1/16 scale applied.
     */
    public static void draw(PoseStack poseStack, MultiBufferSource buffer, HairDesign design, int packedLight) {
        List<HairModel.Quad> quads = quadsFor(design);
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(WHITE));
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        Matrix3f normal = pose.normal();
        for (HairModel.Quad q : quads) {
            for (int i = 0; i < 4; i++) {
                int rgb = HairModel.colorAt(design, q.t[i]);
                int r = Math.min(255, Math.round(((rgb >> 16) & 255) * q.shade));
                int g = Math.min(255, Math.round(((rgb >> 8) & 255) * q.shade));
                int b = Math.min(255, Math.round((rgb & 255) * q.shade));
                consumer.vertex(matrix, q.x[i], q.y[i], q.z[i])
                        .color(r, g, b, 255)
                        .uv(0.5F, 0.5F)
                        .overlayCoords(OverlayTexture.NO_OVERLAY)
                        .uv2(packedLight)
                        .normal(normal, q.nx, q.ny, q.nz)
                        .endVertex();
            }
        }
    }
}
