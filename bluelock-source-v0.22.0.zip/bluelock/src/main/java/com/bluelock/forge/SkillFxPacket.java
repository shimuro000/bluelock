package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * Server to client: mark these entities (by entity id) on this player's screen for a while. Used by the vision
 * skills (open passing lanes, opponents, the ball). Only the player who used the skill receives it.
 * kind: see ClientFx (0 = open team-mate, 1 = opponent, 2 = ball, 3 = marked opponent).
 */
public record SkillFxPacket(int kind, int[] entityIds, int ticks) {
    public static void encode(SkillFxPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.kind());
        buf.writeVarIntArray(m.entityIds());
        buf.writeVarInt(m.ticks());
    }

    public static SkillFxPacket decode(FriendlyByteBuf buf) {
        return new SkillFxPacket(buf.readVarInt(), buf.readVarIntArray(), buf.readVarInt());
    }

    public static void handle(SkillFxPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientFx.mark(m.kind(), m.entityIds(), m.ticks())));
        context.setPacketHandled(true);
    }
}
