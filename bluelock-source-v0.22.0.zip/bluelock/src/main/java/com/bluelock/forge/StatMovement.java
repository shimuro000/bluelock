package com.bluelock.forge;

import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import com.bluelock.common.stats.StatEffects;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;

/** Stats that change how players move: Top Speed and Acceleration (running speed) and Jump. Only for players in a match. */
public final class StatMovement {
    private static final UUID SPEED_ID = UUID.fromString("5b1d3c0e-2a64-4c1e-9f0a-0b1e10c4a001");

    private StatMovement() {
    }

    /** Call every tick: updates the speed modifier every second, and draws sprint dust. */
    public static void tick(MinecraftServer server) {
        boolean update = server.getTickCount() % 20 == 0;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            boolean active = MatchManager.isMember(player.getUUID());
            if (update) {
                apply(server, player, active);
            }
            if (active && player.isSprinting() && player.onGround() && server.getTickCount() % 4 == 0) {
                Juice.particles(player.level(), ParticleTypes.CLOUD, player.getX(), player.getY() + 0.05, player.getZ(), 1, 0.12, 0.01);
            }
        }
    }

    private static void apply(MinecraftServer server, ServerPlayer player, boolean active) {
        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed == null) {
            return;
        }
        double want = 0.0;
        if (active) {
            StatBlock stats = ActorStats.of(server, player);
            want = StatEffects.moveSpeed(stats.permanent(Stat.TOP_SPEED), stats.permanent(Stat.ACCELERATION)) - 1.0;
        }
        AttributeModifier existing = speed.getModifier(SPEED_ID);
        if (existing != null && Math.abs(existing.getAmount() - want) < 0.005) {
            return;
        }
        if (existing == null && Math.abs(want) < 0.005) {
            return;
        }
        if (existing != null) {
            speed.removeModifier(SPEED_ID);
        }
        if (Math.abs(want) >= 0.005) {
            speed.addTransientModifier(new AttributeModifier(SPEED_ID, "bluelock stats", want, AttributeModifier.Operation.MULTIPLY_TOTAL));
        }
    }

    /** A player jumped: the Jump stat changes how high. */
    public static void onJump(ServerPlayer player) {
        if (!MatchManager.isMember(player.getUUID())) {
            return;
        }
        double mult = StatEffects.jumpHeight(ActorStats.of(player.getServer(), player).permanent(Stat.JUMP));
        Vec3 d = player.getDeltaMovement();
        player.setDeltaMovement(d.x, d.y * mult, d.z);
    }
}
