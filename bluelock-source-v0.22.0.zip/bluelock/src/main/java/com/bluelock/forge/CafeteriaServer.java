package com.bluelock.forge;

import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.rank.Cafeteria;
import com.bluelock.common.rank.Ranking;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** The cafeteria: one meal every few minutes, and what you get depends on your rank. Needs a trip to the cafeteria when the campus exists. */
public final class CafeteriaServer {
    private static final Map<UUID, Long> NEXT_MEAL = new HashMap<>();

    private CafeteriaServer() {
    }

    public static void eat(ServerPlayer player) {
        Optional<PlayerProfile> found = ProfileSavedData.get(player.getServer()).load(player.getUUID());
        if (found.isEmpty()) {
            player.sendSystemMessage(Component.translatable("bluelock.error.no_profile"));
            return;
        }
        double distance = CampusBuilder.distanceTo(player, "cafeteria");
        if (CampusBuilder.built(player.getServer()) && (distance < 0 || distance > Cafeteria.RANGE_BLOCKS)) {
            player.sendSystemMessage(Component.translatable("bluelock.cafe.far"));
            return;
        }
        long now = player.getServer().overworld().getGameTime();
        long next = NEXT_MEAL.getOrDefault(player.getUUID(), 0L);
        if (now < next) {
            player.sendSystemMessage(Component.translatable("bluelock.cafe.wait", (next - now) / 20 + 1));
            return;
        }
        int rank = Ranking.rankOf(found.get().rankPoints());
        Cafeteria.Meal meal = Cafeteria.mealFor(rank);
        player.getFoodData().eat(meal.food(), 0.8F);
        if (meal.speedLevel() >= 0 && meal.speedSeconds() > 0) {
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, meal.speedSeconds() * 20, meal.speedLevel()));
        }
        if (meal.regenSeconds() > 0) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, meal.regenSeconds() * 20, 0));
        }
        if (meal.resistSeconds() > 0) {
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, meal.resistSeconds() * 20, 0));
        }
        NEXT_MEAL.put(player.getUUID(), now + Cafeteria.COOLDOWN_TICKS);
        player.sendSystemMessage(Component.translatable("bluelock.cafe.served", rank,
                Component.translatable(Cafeteria.tierKey(meal.tier())), Component.translatable(meal.nameKey())));
    }
}
