package com.bluelock.forge;

import com.bluelock.common.appearance.KitDesign;
import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.team.TeamSetup;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

/** Server side of the kits: players in a match wear their team's kit with their name and a number from their position. */
public final class KitSync {
    private static final Map<UUID, KitDesign> SENT = new HashMap<>();

    private KitSync() {
    }

    /** Works out who should wear what and tells every client about changes. Cheap: call it a few times per second. */
    public static void refresh(MinecraftServer server) {
        Map<UUID, KitDesign> wanted = new HashMap<>();
        for (Side side : Side.values()) {
            Optional<TeamSetup> setup = MatchManager.activeSetup(side);
            if (setup.isEmpty()) {
                continue;
            }
            int colour = MatchManager.teamColor(side);
            for (int slot = 0; slot < setup.get().size(); slot++) {
                UUID id = setup.get().occupant(slot);
                if (id == null) {
                    continue;
                }
                Position pos = setup.get().formation().slots().get(slot).position();
                String name = "";
                Optional<PlayerProfile> profile = ProfileSavedData.get(server).load(id);
                if (profile.isPresent()) {
                    name = profile.get().name();
                }
                wanted.put(id, KitDesign.forTeam(colour, KitDesign.numberFor(pos), name));
            }
        }
        for (Map.Entry<UUID, KitDesign> e : wanted.entrySet()) {
            if (!e.getValue().equals(SENT.get(e.getKey()))) {
                SENT.put(e.getKey(), e.getValue());
                BlueLockNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), KitSyncPacket.of(e.getKey(), e.getValue()));
            }
        }
        for (UUID id : new java.util.ArrayList<>(SENT.keySet())) {
            if (!wanted.containsKey(id)) {
                SENT.remove(id);
                BlueLockNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), KitSyncPacket.none(id));
            }
        }
    }

    /** The match is over: everybody takes the kit off. */
    public static void clearAll() {
        for (UUID id : new java.util.ArrayList<>(SENT.keySet())) {
            BlueLockNetwork.CHANNEL.send(PacketDistributor.ALL.noArg(), KitSyncPacket.none(id));
        }
        SENT.clear();
    }

    /** A player joined: they learn who wears what. */
    public static void onLogin(ServerPlayer joiner) {
        for (Map.Entry<UUID, KitDesign> e : SENT.entrySet()) {
            BlueLockNetwork.sendToPlayer(joiner, KitSyncPacket.of(e.getKey(), e.getValue()));
        }
    }
}
