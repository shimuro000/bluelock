#!/usr/bin/env python3
"""Generates the roster block of Roster.java and data/bluelock/story/characters.json from ONE table, so the game and
the story-mode data cannot disagree.   Run:  python3 tools/gen_roster.py

Season 1 ("s1") teams are the First Selection teams Z, V, W, X, Y. A character with s1 = "" is in the roster but on no
Season 1 team (not in the First Selection, or his team could not be confirmed): matches never pick him for a squad, and
story mode places him at the right moment. `verified` lists what was checked against the Blue Lock wiki
(https://bluelock.fandom.com) and Wikipedia's list of Blue Lock characters; everything else is a first guess.
"""
import json
import os
import re

ROOT = os.path.join(os.path.dirname(__file__), "..")
JAVA = os.path.join(ROOT, "src/main/java/com/bluelock/common/ai/Roster.java")
JSON = os.path.join(ROOT, "src/main/resources/data/bluelock/story/characters.json")

# skin index into BodyDesign.SKIN_TONES; eyes rgb; eyeStyle 0-5; brow 0-3; mouth 0-3; build 0-100
# hair: (style, color, tip, tipAmount, seed, sliders or None); style: 0 buzz 1 short 2 spiky 3 messy 4 fluffy 5 lazy 6 swept 7 long 8 ponytail 9 mohawk
C = []


def add(**k):
    C.append(k)


add(id="isagi", name="Yoichi Isagi", shirt="ISAGI", s1="team_z", pos="CF", bonus=6, tr=(1.00, 1.38, 12, 55, 70, 50, 85), jersey=11, cm=175,
    skills=["spatial_read", "advanced_field_vision", "direct_shot", "passing_lane_read", "awareness"],
    hair=(6, 0x16224F, 0x16224F, 0, 11, None), body=(1, 0x1F3FA0, 1, 1, 0, 45),
    verified=["s1_team", "s1_jersey", "hair", "eyes", "role"], hair_text="short dark blue, V-shaped fringe, plant-shaped ahoge", eyes_text="deep blue",
    later=["Team White (2nd, #15)", "Team A (3rd, #15)", "Blue Lock Eleven", "Japan U-20", "Bastard Munchen"], notes="Raumdeuter; Metavision; Direct Shot; initial rank 299/300")
add(id="bachira", name="Meguru Bachira", shirt="BACHIRA", s1="team_z", pos="LW", bonus=8, tr=(1.06, 1.40, 10, 55, 100, 35, 55), jersey=8, cm=175,
    skills=["feint", "chain_dribble", "burst_dribble", "control", "monster_dribble"],
    hair=(3, 0x14110E, 0xD9A82A, 40, 21, [70, 40, 40, 45, 20, 60, 0]), body=(1, 0xF2C230, 5, 0, 1, 40),
    verified=["s1_team", "s1_jersey", "hair", "eyes"], hair_text="black chin-length bob curling at the ends, golden under-lights", eyes_text="bright yellow",
    later=["Team White (2nd, #16)", "Team A / Team C (3rd, #7)", "Blue Lock Eleven", "FC Barcha"], notes="Monster dribble; initial rank 7")
add(id="kunigami", name="Rensuke Kunigami", shirt="KUNIGAMI", s1="team_z", pos="ST", bonus=6, tr=(1.03, 1.38, 12, 50, 35, 70, 70), jersey=9, cm=187,
    skills=["shoulder_charge", "direct_shot", "pressure_finisher"],
    hair=(2, 0xB8581F, 0xB8581F, 0, 31, None), body=(2, 0xC8641E, 1, 3, 0, 70),
    verified=["s1_team", "hair", "eyes"], hair_text="orange (official art)", eyes_text="orange", later=["Bastard Munchen"], notes="powerful left-foot shot; jersey number not confirmed")
add(id="chigiri", name="Hyoma Chigiri", shirt="CHIGIRI", s1="team_z", pos="RW", bonus=8, tr=(1.25, 1.55, 8, 40, 45, 35, 65), jersey=4, cm=178,
    skills=["sprint_burst", "burst_dribble"],
    hair=(8, 0xD9506A, 0xE8789C, 35, 41, None), body=(0, 0xC03070, 0, 0, 0, 35),
    verified=["s1_team", "s1_jersey", "hair", "eyes", "role"], hair_text="reddish pink, shoulder length, one long right bang, often braided in games", eyes_text="deep pink",
    later=["Team Red (2nd, #44)", "Team B (3rd, #44)", "Blue Lock Eleven", "Manshine City"], notes="fastest player in Blue Lock; counter-attacker; rank 44")
add(id="raichi", name="Jingo Raichi", shirt="RAICHI", s1="team_z", pos="CF", bonus=3, tr=(1.00, 1.36, 9, 80, 30, 60, 50), jersey=99, cm=186,
    skills=["direct_shot", "finishing", "pressure_finisher"],
    hair=(2, 0xE8DCA0, 0xE8DCA0, 0, 51, None), body=(2, 0xD9A02A, 4, 2, 3, 65),
    verified=["s1_team", "hair", "eyes"], hair_text="flat pale blonde, like Nagi's", eyes_text="amber, shark-like teeth", later=["Team Red (2nd)", "Blue Lock Eleven bench", "Bastard Munchen"], notes="immense stamina, man-marking; jersey number not confirmed")
add(id="gagamaru", name="Gin Gagamaru", shirt="GAGAMARU", s1="team_z", pos="GK", bonus=5, tr=(0.97, 1.28, 8, 25, 15, 45, 40), jersey=6, cm=198,
    skills=["composure_focus", "awareness"],
    hair=(1, 0x14110E, 0xC9CED6, 40, 61, None), body=(3, 0x14110E, 2, 3, 1, 90),
    verified=["s1_team", "s1_jersey", "hair", "eyes"], hair_text="long black hair in a bun, dyed silver later", eyes_text="black, no eyelids",
    later=["Team Red (2nd, #88)", "Team C (3rd, #88)", "Japan U-20 match #1", "Bastard Munchen (#99)"], notes="started as a forward; becomes the goalkeeper; very tall")
add(id="kuon", name="Wataru Kuon", shirt="KUON", s1="team_z", pos="ST", bonus=3, tr=(1.00, 1.34, 14, 30, 35, 60, 80), jersey=17, cm=185,
    skills=["finishing", "awareness", "direct_shot"],
    hair=(1, 0x3B2A1E, 0x3B2A1E, 0, 71, None), body=(1, 0x4A2E1A, 0, 1, 0, 50),
    verified=["s1_team", "hair", "role"], hair_text="dark brown, about chin length", eyes_text="not stated",
    later=["Team Z leaks information to Team W during the First Selection, then helps win the final game"], notes="goal poacher, strategist, 68 cm vertical jump; jersey number not confirmed")
add(id="igarashi", name="Gurimu Igarashi", shirt="IGARASHI", s1="team_z", pos="CB", bonus=2, tr=(0.98, 1.32, 12, 25, 25, 75, 70), jersey=4, cm=185,
    skills=["shoulder_charge", "interception_read"],
    hair=(0, 0x3B2A1E, 0x3B2A1E, 0, 81, None), body=(3, 0x4A2E1A, 1, 3, 0, 85),
    verified=["s1_team"], hair_text="not checked", eyes_text="not checked", later=["Second Selection (with Shidou)", "Bastard Munchen"], notes="'Igaguri'; looks and role are guesses")
add(id="naruhaya", name="Asahi Naruhaya", shirt="NARUHAYA", s1="team_z", pos="CM", bonus=1, tr=(1.00, 1.34, 11, 35, 40, 50, 70), jersey=14, cm=176,
    skills=["passing_lane_read"],
    hair=(1, 0x5A3B24, 0x5A3B24, 0, 91, None), body=(1, 0x4A2E1A, 0, 1, 0, 50),
    verified=["s1_team"], hair_text="unchecked (placeholder)", eyes_text="unchecked", later=[], notes="Team Z member; looks, position and number are placeholders")
add(id="iemon", name="Okuhito Iemon", shirt="IEMON", s1="team_z", pos="GK", bonus=1, tr=(0.97, 1.28, 8, 25, 15, 45, 40), jersey=12, cm=184,
    skills=["awareness"],
    hair=(0, 0x14110E, 0x14110E, 0, 101, None), body=(1, 0x4A2E1A, 0, 1, 0, 55),
    verified=["s1_team"], hair_text="unchecked (placeholder)", eyes_text="unchecked", later=[], notes="Team Z; listed as a goalkeeper; Gagamaru takes the GK slot first")
add(id="imamura", name="Yudai Imamura", shirt="IMAMURA", s1="team_z", pos="LB", bonus=1, tr=(1.00, 1.34, 12, 30, 30, 60, 70), jersey=3, cm=177,
    skills=["interception_read"],
    hair=(1, 0x3B2A1E, 0x3B2A1E, 0, 111, None), body=(1, 0x4A2E1A, 0, 1, 0, 50),
    verified=["s1_team"], hair_text="unchecked (placeholder)", eyes_text="unchecked", later=[], notes="Team Z; looks, position and number are placeholders")

add(id="nagi", name="Seishiro Nagi", shirt="NAGI", s1="team_v", pos="CF", bonus=10, tr=(1.02, 1.38, 8, 60, 90, 20, 25), jersey=11, cm=190,
    skills=["control", "direct_shot", "finishing", "trap"],
    hair=(5, 0xF4F4F4, 0xC9CED6, 40, 101, None), body=(0, 0x1FA89A, 3, 0, 0, 40),
    verified=["s1_team", "s1_jersey", "hair", "eyes", "role"], hair_text="short white, V-shaped fringe", eyes_text="teal, large irises",
    later=["Team White (2nd, #7)", "Team C (3rd)", "Blue Lock Eleven", "Manshine City"], notes="perfect ball control, trapping; initial rank 6")
add(id="reo", name="Reo Mikage", shirt="REO", s1="team_v", pos="CM", bonus=9, tr=(1.02, 1.38, 11, 55, 75, 45, 80), jersey=9, cm=180,
    skills=["through_pass", "passing_lane_read", "feint", "chameleon"],
    hair=(8, 0x7B3FBF, 0xB28CE0, 25, 111, None), body=(0, 0x7B3FBF, 0, 1, 1, 50),
    verified=["s1_team", "s1_jersey", "hair", "eyes", "role"], hair_text="chin-length purple, high bun, two framing strands", eyes_text="bright purple",
    later=["Team Red (2nd, #10)", "Team C (3rd, #10)", "Blue Lock Eleven (#14)"], notes="the Chameleon; jack of all trades, skills 99/100; box-to-box; rank 10")
add(id="zantetsu", name="Zantetsu Tsurugi", shirt="TSURUGI", s1="team_v", pos="LW", bonus=4, tr=(1.04, 1.38, 11, 40, 40, 55, 70), jersey=6, cm=181,
    skills=["sprint_burst", "direct_shot"],
    hair=(2, 0x14110E, 0x14110E, 0, 241, None), body=(2, 0x1B1B1F, 1, 2, 0, 65),
    verified=["s1_team", "s1_jersey", "hair", "role"], hair_text="spiky, dark", eyes_text="not stated",
    later=["Team White (2nd, #53)", "Blue Lock Eleven bench", "Paris X Gen"], notes="left-footed inverted winger; explosive acceleration; rank 53")

add(id="junichi", name="Junichi Wanima", shirt="J. WANIMA", s1="team_w", pos="ST", bonus=4, tr=(1.02, 1.36, 11, 55, 45, 55, 70), jersey=9, cm=180,
    skills=["finishing", "direct_shot"],
    hair=(2, 0x1B1B1F, 0x1B1B1F, 0, 301, None), body=(1, 0x4A2E1A, 1, 2, 0, 55),
    verified=["s1_team"], hair_text="unchecked (placeholder)", eyes_text="unchecked", later=["Manshine City"], notes="older twin; Team W's top scorer; looks are placeholders")
add(id="keisuke", name="Keisuke Wanima", shirt="K. WANIMA", s1="team_w", pos="CAM", bonus=3, tr=(1.00, 1.36, 11, 45, 55, 50, 70), jersey=10, cm=180,
    skills=["through_pass"],
    hair=(2, 0x1B1B1F, 0x1B1B1F, 0, 311, None), body=(1, 0x4A2E1A, 1, 1, 1, 50),
    verified=["s1_team"], hair_text="unchecked (placeholder)", eyes_text="unchecked", later=[], notes="younger twin; looks are placeholders")

add(id="baro", name="Shoei Baro", shirt="BARO", s1="team_x", pos="ST", bonus=9, tr=(1.10, 1.45, 11, 100, 40, 85, 65), jersey=10, cm=187,
    skills=["precision_direct_shot", "finishing", "shoulder_charge"],
    hair=(2, 0x14110E, 0xB3261E, 20, 91, [75, 45, 30, 40, 90, 40, 0]), body=(2, 0xB02020, 4, 2, 2, 70),
    verified=["s1_team", "s1_jersey", "hair", "eyes", "height"], hair_text="long black, styled up in a spiky crown; red streaks only from the Neo Egoist League", eyes_text="slim, red",
    later=["Team Red (2nd, #18)", "Team B (3rd)", "Blue Lock Eleven (#13)", "Ubers (#13)"], notes="the King; Predator Eye; 187 cm; Team X's only Second Selection qualifier")
add(id="meiji", name="Haato Meiji", shirt="MEIJI", s1="team_x", pos="CM", bonus=2, tr=(1.00, 1.34, 12, 35, 45, 50, 70), jersey=8, cm=176,
    skills=["passing_lane_read"],
    hair=(1, 0x5A3B24, 0x5A3B24, 0, 321, None), body=(1, 0x4A2E1A, 0, 1, 0, 50),
    verified=["s1_team"], hair_text="unchecked (placeholder)", eyes_text="unchecked", later=[], notes="named in Team X's stats table; placeholders")
add(id="sanga", name="Rian Sanga", shirt="SANGA", s1="team_x", pos="LB", bonus=2, tr=(1.00, 1.34, 12, 30, 30, 60, 70), jersey=3, cm=178,
    skills=["interception_read"],
    hair=(1, 0x1B1B1F, 0x1B1B1F, 0, 331, None), body=(1, 0x4A2E1A, 0, 1, 0, 50),
    verified=["s1_team"], hair_text="unchecked (placeholder)", eyes_text="unchecked", later=[], notes="named in Team X's stats table; placeholders")
add(id="banku", name="Yawara Banku", shirt="BANKU", s1="team_x", pos="CB", bonus=2, tr=(0.98, 1.32, 12, 25, 25, 70, 70), jersey=5, cm=183,
    skills=["shoulder_charge"],
    hair=(0, 0x3B2A1E, 0x3B2A1E, 0, 341, None), body=(2, 0x4A2E1A, 1, 3, 0, 70),
    verified=["s1_team"], hair_text="unchecked (placeholder)", eyes_text="unchecked", later=[], notes="named in Team X's stats table; placeholders")

add(id="ikki", name="Niko Ikki", shirt="IKKI", s1="team_y", pos="CB", bonus=6, tr=(1.00, 1.36, 13, 35, 45, 85, 75), jersey=5, cm=185,
    skills=["shoulder_charge", "shadow_marking"],
    hair=(2, 0x8A8F98, 0x1B1B1F, 30, 231, None), body=(1, 0x8A8F98, 1, 3, 0, 80),
    verified=["position"], hair_text="not checked", eyes_text="not checked", later=["Blue Lock Eleven (centre-back)", "Ubers"], notes="Team Y per one wiki page, not stated on another: team is only partly confirmed")
add(id="okawa", name="Hibiki Okawa", shirt="OKAWA", s1="team_y", pos="CM", bonus=3, tr=(1.00, 1.34, 12, 35, 45, 50, 70), jersey=7, cm=178,
    skills=["passing_lane_read", "spatial_read"],
    hair=(1, 0x3B2A1E, 0x3B2A1E, 0, 351, None), body=(1, 0x4A2E1A, 0, 1, 0, 50),
    verified=["s1_team"], hair_text="unchecked (placeholder)", eyes_text="unchecked", later=[], notes="named on the First Selection page as Team Y; placeholders")

# not on a confirmed Season 1 team
add(id="rin", name="Rin Itoshi", shirt="RIN", s1="", pos="CM", bonus=12, tr=(1.05, 1.42, 13, 85, 85, 65, 75), jersey=10, cm=182,
    skills=["direct_shot", "advanced_field_vision", "through_pass", "awakening_direct_shot", "chain_dribble", "curved_shot"],
    hair=(6, 0x14181C, 0x14181C, 0, 151, None), body=(0, 0x1FA89A, 1, 2, 0, 55),
    verified=["hair", "eyes", "role", "no_s1_team"], hair_text="black, bang covering more of the right eye", eyes_text="slim teal",
    later=["Team Red (2nd, #1)", "Team A (3rd, #1)", "Blue Lock Eleven captain (#10)", "PXG"], notes="No First Selection team given; the No. 1 player of Blue Lock")
add(id="shidou", name="Ryusei Shidou", shirt="SHIDOU", s1="", pos="ST", bonus=10, tr=(1.10, 1.45, 10, 80, 100, 55, 60), jersey=13, cm=182,
    skills=["burst_dribble", "feint", "awakening_direct_shot", "sprint_burst", "dragon_drive"],
    hair=(2, 0xE8C84A, 0xE8C84A, 0, 161, None), body=(0, 0xE060A0, 1, 2, 2, 60),
    verified=["hair", "eyes", "role", "no_s1_team"], hair_text="spiky blonde, two strands at the sides", eyes_text="pink with slit pupils",
    later=["Second Selection", "Japan U-20 (#13)"], notes="Dragon Drive, Big Bang Drive; rank 2")
add(id="kaiser", name="Michael Kaiser", shirt="KAISER", s1="", pos="CF", bonus=12, tr=(1.04, 1.40, 10, 95, 75, 50, 55), jersey=9, cm=187,
    skills=["precision_direct_shot", "advanced_field_vision", "chain_dribble", "finishing", "curved_shot"],
    hair=(7, 0xE8C84A, 0x2F6BFF, 40, 171, None), body=(0, 0x2F6BFF, 1, 1, 2, 60),
    verified=["hair", "role", "no_s1_team"], hair_text="blonde mullet with blue streaks at the ends", eyes_text="not stated", later=["Bastard Munchen"], notes="Kaiser Impact (not built yet)")
add(id="sae", name="Sae Itoshi", shirt="SAE", s1="", pos="CAM", bonus=14, tr=(1.06, 1.42, 12, 75, 90, 55, 80), jersey=10, cm=185,
    skills=["through_pass", "advanced_field_vision", "precision_direct_shot", "composure_focus", "perfect_pass"],
    hair=(6, 0x6B3B30, 0x6B3B30, 0, 181, None), body=(0, 0x2FA070, 1, 2, 0, 55),
    verified=["hair", "eyes", "role", "no_s1_team"], hair_text="reddish brown (wiki wording)", eyes_text="green, long lower lashes",
    later=["Japan U-20 (#10)", "Real Madrid Youth", "Men's World 11"], notes="outside Blue Lock for most of Season 1")
add(id="noa", name="Noel Noa", shirt="NOA", s1="", pos="CF", bonus=14, tr=(1.06, 1.42, 15, 55, 80, 70, 95), jersey=9, cm=190,
    skills=["awareness", "spatial_read", "control", "shoulder_charge", "direct_shot", "finishing"],
    hair=(6, 0xF4F4F4, 0xF4F4F4, 0, 191, None), body=(0, 0xD9B45A, 1, 3, 0, 75),
    verified=["hair", "eyes", "role", "no_s1_team"], hair_text="white", eyes_text="yellow, black-shaded eyelids",
    later=["France national team (#9)", "Bastard Munchen coach (#9)"], notes="coach of the Germany stratum; supreme physicality, machine dribble, ambidextrous")
add(id="otoya", name="Eita Otoya", shirt="OTOYA", s1="", pos="RW", bonus=4, tr=(1.05, 1.40, 14, 40, 55, 50, 85), jersey=33, cm=177,
    skills=["sprint_burst", "burst_dribble"],
    hair=(1, 0xF4F4F4, 0x1F6B3A, 40, 201, None), body=(1, 0x1B1B1F, 2, 0, 1, 45),
    verified=["hair", "eyes", "role", "no_s1_team"], hair_text="short flat white with a dark green strand and underside", eyes_text="dark, thin, low-lidded",
    later=["Team Red (2nd, #33)", "Team B (3rd, #33)", "Blue Lock Eleven (#9)", "FC Barcha"], notes="First Selection: 'same team as Karasu' (team not named in the sources)")
add(id="tokimitsu", name="Aoshi Tokimitsu", shirt="TOKIMITSU", s1="", pos="ST", bonus=4, tr=(1.00, 1.36, 14, 30, 50, 55, 85), jersey=3, cm=184,
    skills=["shoulder_charge", "sprint_burst"],
    hair=(1, 0x14110E, 0x14110E, 0, 211, None), body=(1, 0x34B34A, 4, 1, 0, 85),
    verified=["hair", "eyes", "role", "no_s1_team"], hair_text="short black", eyes_text="round green, large irises", later=["Team Red (2nd, #3)", "Blue Lock Eleven bench"], notes="target man; strongest build; First Selection team not given in the sources")
add(id="aiku", name="Oliver Aiku", shirt="AIKU", s1="", pos="CB", bonus=5, tr=(1.00, 1.36, 13, 30, 40, 65, 80), jersey=2, cm=186,
    skills=["shadow_marking", "interception_read", "awareness"],
    hair=(3, 0x5A3B24, 0x34B34A, 40, 221, None), body=(1, 0x34B34A, 3, 1, 0, 60),
    verified=["hair", "eyes", "role", "no_s1_team"], hair_text="shaggy brown with green ends", eyes_text="heterochromia: left green, right purple",
    later=["Total Defense; Flow State on defence"], notes="First Selection team not given in the sources")
add(id="hiori", name="Yo Hiori", shirt="HIORI", s1="", pos="CM", bonus=6, tr=(1.00, 1.36, 12, 35, 55, 50, 85), jersey=27, cm=183,
    skills=["passing_lane_read", "spatial_read", "control", "through_pass"],
    hair=(1, 0x2FD0E8, 0x2FD0E8, 0, 121, None), body=(1, 0x9FE0E8, 1, 1, 0, 50),
    verified=["hair", "eyes", "role", "no_s1_team"], hair_text="short slightly choppy cyan", eyes_text="large round pale cyan",
    later=["Team Red (2nd, #27)", "Team A (3rd, #27)", "Blue Lock Eleven (#16)", "Bastard Munchen (#23)", "Japan U-20"], notes="Metavision, key passing; left-footed; First Selection team not given")
add(id="aryu", name="Jyubei Aryu", shirt="ARYU", s1="", pos="CB", bonus=6, tr=(0.98, 1.34, 11, 70, 60, 50, 70), jersey=2, cm=195,
    skills=["awareness", "shoulder_charge"],
    hair=(7, 0x14110E, 0x14110E, 0, 131, None), body=(1, 0x14110E, 1, 1, 0, 75),
    verified=["hair", "eyes", "height", "role", "no_s1_team"], hair_text="long black, waist length", eyes_text="black", later=["Team Red (2nd, #2)", "Team A (3rd, #2)", "Ubers", "Japan U-20 (#2)"], notes="195 cm; jumping header; rank 2 in the Second Selection")
add(id="nanase", name="Nijiro Nanase", shirt="NANASE", s1="", pos="LW", bonus=5, tr=(1.03, 1.40, 10, 50, 60, 40, 65), jersey=99, cm=178,
    skills=["burst_dribble", "sprint_burst"],
    hair=(3, 0xD9B45A, 0xF28C28, 30, 141, None), body=(1, 0x4A2E1A, 2, 0, 1, 60),
    verified=["role", "no_s1_team"], hair_text="not stated (wears a Blue Lock headband)", eyes_text="not stated", later=["Team White (2nd, #99)", "Team A (3rd, #99)", "Paris X Gen (#77)"], notes="ambidextrous left winger; looks are guesses")

BIAS = {
    "isagi": {"SPATIAL_AWARENESS": 14, "VISION": 8, "ANTICIPATION": 8, "FINISHING": 6, "FLOW_AFFINITY": 10},
    "bachira": {"DRIBBLING": 14, "CLOSE_CONTROL": 12, "AGILITY": 10, "BALL_CONTROL": 8, "CONFIDENCE": 6},
    "kunigami": {"SHOT_POWER": 12, "SHOOTING": 8, "STRENGTH": 8},
    "chigiri": {"TOP_SPEED": 16, "ACCELERATION": 14, "STAMINA": -8},
    "raichi": {"STAMINA": 14, "STRENGTH": 10, "MARKING": 6, "SHOOTING": 6},
    "gagamaru": {"REACTION": 10, "JUMP": 8, "AGILITY": 8},
    "kuon": {"POSITIONING": 10, "JUMP": 8, "DECISION_MAKING": 10, "FINISHING": 6},
    "igarashi": {"STRENGTH": 6, "BLOCKING": 6},
    "baro": {"SHOOTING": 10, "FINISHING": 12, "SHOT_POWER": 10, "STRENGTH": 8, "EGO_AFFINITY": 16, "ANTICIPATION": 6},
    "nagi": {"FIRST_TOUCH": 16, "BALL_CONTROL": 16, "CLOSE_CONTROL": 10, "STAMINA": -10},
    "reo": {"PASSING": 8, "VISION": 8, "DRIBBLING": 6, "SHOOTING": 6, "BALL_CONTROL": 6, "STAMINA": 6},
    "zantetsu": {"ACCELERATION": 12, "SHOOTING": 6},
    "junichi": {"FINISHING": 6, "SHOOTING": 4},
    "rin": {"SHOOTING": 12, "FINISHING": 10, "PASSING": 8, "VISION": 8, "BALL_CONTROL": 8, "CURVE": 8, "EGO_AFFINITY": 10},
    "shidou": {"AGILITY": 12, "DRIBBLING": 12, "ACCELERATION": 10, "REACTION": 10, "SPATIAL_AWARENESS": 8, "SHOT_POWER": 8},
    "kaiser": {"FINISHING": 12, "SHOOTING": 12, "POSITIONING": 10, "VOLLEY": 10, "SHOT_POWER": 8, "EGO_AFFINITY": 14},
    "sae": {"PASSING": 14, "LONG_PASSING": 14, "VISION": 12, "BALL_CONTROL": 10, "COMPOSURE": 10, "DRIBBLING": 8, "CURVE": 8},
    "noa": {"STRENGTH": 14, "BALANCE": 10, "SHOOTING": 10, "SHOT_POWER": 10, "DRIBBLING": 10, "BALL_CONTROL": 8, "COMPOSURE": 10},
    "otoya": {"ACCELERATION": 8, "POSITIONING": 10, "AGILITY": 8},
    "tokimitsu": {"STRENGTH": 14, "BALANCE": 10, "STAMINA": 14, "ACCELERATION": 4},
    "aiku": {"INTERCEPTION": 10, "ANTICIPATION": 10, "SPATIAL_AWARENESS": 8, "DEFENSIVE_POSITIONING": 8, "JUMP": 6, "STRENGTH": 4},
    "hiori": {"BALL_CONTROL": 10, "PASSING": 10, "VISION": 10, "SPATIAL_AWARENESS": 10, "COMPOSURE": 6},
    "aryu": {"JUMP": 14, "STRENGTH": 10, "BLOCKING": 8, "MARKING": 6, "TOP_SPEED": -4},
    "nanase": {"AGILITY": 6, "ACCELERATION": 4, "BALL_CONTROL": 4},
}


def hair_java(h):
    style, color, tip, amt, seed, sl = h
    s = "null" if sl is None else "new int[] {" + ", ".join(map(str, sl)) + "}"
    return f"hair({style}, 0x{color:06X}, 0x{tip:06X}, {amt}, {seed}, {s})"


def main():
    body_lines = []
    add_lines = []
    for c in C:
        b = c["body"]
        body_lines.append(f'        BODY_TABLE.put("{c["id"]}", new int[] {{{b[0]}, 0x{b[1]:06X}, {b[2]}, {b[3]}, {b[4]}, {b[5]}}});')
        t = c["tr"]
        skills = ", ".join(f'"{s}"' for s in c["skills"])
        add_lines.append(
            f'        add("{c["id"]}", "{c["name"]}", "{c["shirt"]}", "{c["s1"]}", Position.{c["pos"]}, {c["bonus"]}, '
            f't({t[0]:.2f}, {t[1]:.2f}, {t[2]}, {t[3]}, {t[4]}, {t[5]}, {t[6]}), {c["jersey"]}, {c["cm"]}, List.of({skills}), {hair_java(c["hair"])});')
    src = open(JAVA).read()
    src = re.sub(r"(    static \{\n)(        BODY_TABLE\.put.*?)(    \}\n\n    private static BodyDesign bodyFor)",
                 lambda m: m.group(1) + "\n".join(body_lines) + "\n" + m.group(3), src, flags=re.S)
    src = re.sub(r"(    static \{\n)(        add\(\".*?)(    \}\n\n    private Roster\(\))",
                 lambda m: m.group(1) + "\n".join(add_lines) + "\n" + m.group(3), src, flags=re.S)
    open(JAVA, "w").write(src)

    out = {"_about": "Canon data for the characters (Season 1 / Blue Lock). s1_team is the First Selection team or null. 'verified' lists the facts checked against the Blue Lock wiki and Wikipedia; everything else is a placeholder to check before story mode.",
           "teams_s1": {}, "characters": []}
    for c in C:
        if c["s1"]:
            out["teams_s1"].setdefault(c["s1"], []).append(c["id"])
        out["characters"].append({
            "id": c["id"], "name": c["name"], "s1_team": c["s1"] or None, "s1_jersey": c["jersey"] if c["s1"] else None,
            "position": c["pos"], "height_cm": c["cm"], "hair": c["hair_text"], "eyes": c["eyes_text"],
            "later_affiliations": c["later"], "notes": c["notes"], "verified": c["verified"],
            "skills": c["skills"], "stat_bias": BIAS.get(c["id"], {})})
    os.makedirs(os.path.dirname(JSON), exist_ok=True)
    json.dump(out, open(JSON, "w"), indent=2)

    # Java stat table
    lines = []
    for cid, m in BIAS.items():
        entries = ", ".join(f"Stat.{k}, {v}" for k, v in m.items())
        lines.append(f'        BIAS.put("{cid}", new Object[] {{{entries}}});')
    p = os.path.join(ROOT, "src/main/java/com/bluelock/common/ai/CanonStats.java")
    open(p, "w").write('''package com.bluelock.common.ai;

import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import java.util.HashMap;
import java.util.Map;

/**
 * What each named character is known for, as small stat changes on top of his rating and position (no Minecraft
 * code). Generated by tools/gen_roster.py from the same table as the roster; edit the table, not this file.
 */
public final class CanonStats {
    private static final Map<String, Object[]> BIAS = new HashMap<>();

    static {
''' + "\n".join(lines) + '''
    }

    private CanonStats() {
    }

    public static boolean has(String id) {
        return BIAS.containsKey(id);
    }

    /** Adds the character's strengths and weaknesses to the block. */
    public static void apply(String id, StatBlock block) {
        Object[] entries = BIAS.get(id);
        if (entries == null) {
            return;
        }
        for (int i = 0; i + 1 < entries.length; i += 2) {
            Stat s = (Stat) entries[i];
            block.setBase(s, block.base(s) + (Integer) entries[i + 1]);
        }
    }
}
''')
    print(len(C), "characters")


if __name__ == "__main__":
    main()
