package com.bluelock.common;

import com.bluelock.common.ai.*;
import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.team.TeamTactics;
import java.util.*;

/** Phase 5: Blue Lock characters, traits, sprint energy and speed. */
public final class CharacterSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    private static BotView view(Pos self, boolean hasBall, Pos ball, CharacterTraits t, Position pos, List<Pos> opp) {
        return new BotView(Side.HOME, pos, self, ball, hasBall, hasBall ? Side.HOME : null, hasBall ? self : null, 0, 60,
                TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED), new Pos(30, 18), List.of(new Pos(40, 10)), opp,
                PitchLayout.standard(), BallMotion.STILL, 0.2, 50, 50, t);
    }

    public static void main(String[] args) {
        roster();
        energy();
        speed();
        behaviour();
        looksAndSkills();
        statEffects();
        System.out.println(failures == 0 ? "ALL CHARACTER TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }

    private static void roster() {
        check(Roster.all().size() >= 20, "roster has 20+ characters (" + Roster.all().size() + ")");
        Set<String> ids = new HashSet<>();
        boolean uniq = true;
        for (FootballCharacter c : Roster.all()) uniq &= ids.add(c.id());
        check(uniq, "character ids are unique");
        check(Roster.byId("isagi") != null && Roster.byId("isagi").teamId().equals("team_z"), "Isagi is on team Z");
        check(Roster.byId("chigiri").traits().speed() > Roster.byId("kunigami").traits().speed(), "Chigiri is faster than Kunigami");
        check(Roster.byId("baro").traits().ego() > Roster.byId("isagi").traits().ego(), "Baro has more ego than Isagi");
        Set<String> taken = new HashSet<>();
        FootballCharacter st = Roster.assign("team_z", Position.ST, taken);
        check(st != null && st.position() == Position.ST, "an ST slot gets the ST character");
        taken.add(st.id());
        FootballCharacter again = Roster.assign("team_z", Position.ST, taken);
        check(again == null || !again.id().equals(st.id()), "a character is not given out twice");
        check(Roster.assign("team_z", Position.GK, new HashSet<>()).position() == Position.GK, "a GK slot gets the keeper");
        check(Roster.assign("nope", Position.ST, new HashSet<>()) == null, "unknown team gives no character");
        FootballCharacter isagi = Roster.byId("isagi");
        int look = Roster.lookOf(isagi, 0);
        check(Roster.byLook(look) == isagi && Roster.hairForLook(look).equals(isagi.hair()), "look code leads back to the character and his hair");
        check(Roster.hairForLook(-5).equals(Roster.hairForLook(-5)) && Roster.byLook(-5) == null, "nameless bots get the same hair on every client");
        check(BotStats.forCharacter(60, Roster.byId("chigiri")).base(Stat.TOP_SPEED) > BotStats.forRating(60, Position.RW).base(Stat.TOP_SPEED), "fast characters get speed stats");
    }

    private static void energy() {
        BotEnergy e = new BotEnergy(10);
        check(e.percent() == 100 && !e.isTired(), "energy starts full");
        int ticks = 0;
        while (!e.isTired() && ticks < 1000) { e.update(true, 2); ticks += 2; }
        check(ticks >= 190 && ticks <= 210, "10 s of sprint empties it (" + ticks + " ticks)");
        check(!e.update(true, 2), "a tired bot cannot sprint");
        check(e.speedFactor() < 1.0, "a tired bot jogs slower");
        for (int i = 0; i < 400 && e.isTired(); i++) e.update(false, 2);
        check(!e.isTired() && e.percent() >= BotEnergy.RECOVER_FROM_TIRED, "rest brings it back");
        check(e.update(true, 2), "after resting it can sprint again");
        BotEnergy big = new BotEnergy(20), small = new BotEnergy(5);
        int bigTicks = 0, smallTicks = 0;
        while (!big.isTired() && bigTicks < 2000) { big.update(true, 2); bigTicks += 2; }
        while (!small.isTired() && smallTicks < 2000) { small.update(true, 2); smallTicks += 2; }
        check(smallTicks < bigTicks, "stamina decides how long a sprint lasts");
    }

    private static void speed() {
        double jog = BotSpeed.jog(60, BotDifficulty.NORMAL.speedFactor(), CharacterTraits.NEUTRAL);
        check(jog > 0.13, "a jogging bot is faster than a sprinting player (" + String.format("%.3f", jog) + ")");
        double mult = BotSpeed.sprintMultiplier(jog, CharacterTraits.NEUTRAL);
        check(jog * mult > jog * 1.2 && jog * mult <= BotSpeed.SPRINT_CAP + 1e-9, "sprint is much faster but capped");
        CharacterTraits chigiri = Roster.byId("chigiri").traits();
        double j2 = BotSpeed.jog(90, BotDifficulty.PRO.speedFactor(), chigiri);
        check(j2 * BotSpeed.sprintMultiplier(j2, chigiri) <= BotSpeed.SPRINT_CAP + 1e-9, "even the fastest bot respects the cap");
        check(j2 > jog, "a fast character on PRO outruns a normal bot");
        check(AnimLogicProbe.sprintShownOnlyWhenFast(), "bots show the sprint animation only at sprint speed");
    }

    private static void behaviour() {
        PitchLayout l = PitchLayout.standard();
        // chasing a far ball: sprint
        BotView chase = new BotView(Side.HOME, Position.CM, new Pos(10, 18), new Pos(30, 18), false, null, null, 0, 60,
                TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED), new Pos(20, 18), List.of(), List.of(), l);
        BotDecision d = BotBrain.decide(chase);
        check(d.intent() == Intent.CHASE_BALL && d.sprint(), "chasing a far ball means sprinting");
        BotView close = new BotView(Side.HOME, Position.CM, new Pos(29, 18), new Pos(30, 18), false, null, null, 0, 60,
                TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED), new Pos(20, 18), List.of(), List.of(), l);
        check(!BotBrain.decide(close).sprint(), "a close ball needs no sprint");
        // ego: same spot, only the traits differ
        CharacterTraits egoist = new CharacterTraits(1, 1.35, 10, 100, 50, 50, 50);
        CharacterTraits team = new CharacterTraits(1, 1.35, 10, 10, 50, 50, 50);
        Pos self = new Pos(34, 18);   // 27 from the goal at u = 61
        BotDecision a = BotBrain.decide(view(self, true, self, egoist, Position.ST, List.of()));
        BotDecision b = BotBrain.decide(view(self, true, self, team, Position.ST, List.of()));
        Pos nearShot = new Pos(45, 18);
        boolean egoShoots = BotBrain.decide(view(nearShot, true, nearShot, egoist, Position.ST, List.of())).intent() == Intent.SHOOT;
        check(a.intent() != Intent.SHOOT && b.intent() != Intent.SHOOT && egoShoots, "an egoist shoots from range (sanity)");
        Pos mid = new Pos(40, 18);   // 21 from goal: only the egoist is in range at rating 60
        boolean egoMid = BotBrain.decide(view(mid, true, mid, egoist, Position.ST, List.of())).intent() == Intent.SHOOT;
        boolean teamMid = BotBrain.decide(view(mid, true, mid, team, Position.ST, List.of())).intent() == Intent.SHOOT;
        check(egoMid && !teamMid, "high ego shoots from further out than low ego");
        // old constructors still work
        check(CharacterTraits.forPosition(Position.GK).speed() < CharacterTraits.forPosition(Position.RW).speed(), "wingers are faster than keepers");
        check(new CharacterTraits(9, 9, 99, 500, -5, 0, 0).speed() <= 1.3, "traits are clamped");
    }

    private static void looksAndSkills() {
        boolean allSkillsReal = true, allHair = true, jerseys = true, heights = true;
        java.util.Set<String> realSkills = new HashSet<>(List.of("advanced_field_vision", "awakening_direct_shot", "awareness", "burst_dribble",
                "chain_dribble", "composure_focus", "control", "direct_shot", "feint", "finishing", "interception_read", "passing_lane_read",
                "precision_direct_shot", "pressure_finisher", "shadow_marking", "shoulder_charge", "spatial_read", "sprint_burst", "through_pass"));
        for (FootballCharacter c : Roster.all()) {
            allSkillsReal &= !c.skills().isEmpty() && realSkills.containsAll(c.skills());
            allHair &= c.hair() != null;
            jerseys &= c.jersey() >= 1 && c.jersey() <= 99 && !c.shirtName().isEmpty();
            heights &= c.heightScale() >= 0.92 && c.heightScale() <= 1.10;
        }
        check(allSkillsReal, "every character has skills, all of them skills that exist");
        check(allHair && jerseys && heights, "every character has hair, a shirt name and number and a sane height");
        Set<com.bluelock.common.appearance.HairDesign> hairs = new HashSet<>();
        for (FootballCharacter c : Roster.all()) hairs.add(c.hair());
        check(hairs.size() >= Roster.all().size() - 2, "characters look different from each other (" + hairs.size() + " different hairstyles)");
        check(Roster.byId("chigiri").hair().color() != Roster.byId("nagi").hair().color(), "Chigiri's and Nagi's hair colours differ");
        check(Roster.byId("rin").skills().contains("awakening_direct_shot") && Roster.byId("chigiri").skills().contains("sprint_burst"), "Rin has the awakening shot, Chigiri the sprint burst");
        check(Roster.byId("kaiser").heightCm() > Roster.byId("isagi").heightCm(), "Kaiser is taller than Isagi");
        BotSkillRules.ShotBoost none = BotSkillRules.shot(List.of());
        BotSkillRules.ShotBoost awaken = BotSkillRules.shot(List.of("awakening_direct_shot"));
        BotSkillRules.ShotBoost precise = BotSkillRules.shot(List.of("precision_direct_shot"));
        check(none.spreadMul() == 1.0 && none.powerMul() == 1.0 && none.anim() == null, "no skill: the shot is unchanged");
        check(awaken.powerMul() > precise.powerMul() && precise.spreadMul() < awaken.spreadMul(), "awakening shoots harder, precision shoots straighter");
        check("feint".equals(BotSkillRules.dribbleSkill(List.of("feint", "burst_dribble"), true, true)), "under pressure a bot feints");
        check("burst_dribble".equals(BotSkillRules.dribbleSkill(List.of("feint", "burst_dribble"), false, true)), "in open space a bot bursts");
        check(BotSkillRules.dribbleSkill(List.of(), true, true) == null, "no skills: no dribble skill");
        check(BotSkillRules.passLead(List.of("through_pass")) > BotSkillRules.passLead(List.of()), "through pass leads the runner further");
        com.bluelock.common.appearance.KitDesign blue = com.bluelock.common.appearance.KitDesign.forTeam(0x2F6BFF, 7, "chigiri");
        com.bluelock.common.appearance.KitDesign yellow = com.bluelock.common.appearance.KitDesign.forTeam(0xF4D03F, 7, "x");
        check(blue.shirt() == 0x2F6BFF && blue.name().equals("CHIGIRI") && blue.number() == 7, "kit has team colour, upper-case name and number");
        check(blue.trim() == 0xFFFFFF && yellow.trim() != 0xFFFFFF, "dark shirts get white trim, light shirts dark trim");
        check(com.bluelock.common.appearance.KitDesign.numberFor(Position.GK) == 1 && com.bluelock.common.appearance.KitDesign.numberFor(Position.ST) == 9, "position numbers: keeper 1, striker 9");
        check(new com.bluelock.common.appearance.KitDesign(0, 0, 0, 0, 500, "AVERYLONGNAMEINDEED").number() == 99
                && new com.bluelock.common.appearance.KitDesign(0, 0, 0, 0, 5, "AVERYLONGNAMEINDEED").name().length() <= 12, "kit number and name are limited");
    }

    private static void statEffects() {
        check(Math.abs(com.bluelock.common.stats.StatEffects.moveSpeed(50, 50) - 1.0) < 1e-9, "average stats run at normal speed");
        check(com.bluelock.common.stats.StatEffects.moveSpeed(90, 80) > com.bluelock.common.stats.StatEffects.moveSpeed(40, 40), "more Top Speed and Acceleration means faster");
        check(com.bluelock.common.stats.StatEffects.moveSpeed(100, 100) <= 1.2 && com.bluelock.common.stats.StatEffects.moveSpeed(0, 0) >= 0.8, "speed from stats stays in 80-120%");
        check(com.bluelock.common.stats.StatEffects.sprintLength(90) > com.bluelock.common.stats.StatEffects.sprintLength(30), "more stamina means longer sprints");
        check(com.bluelock.common.stats.StatEffects.jumpHeight(100) > com.bluelock.common.stats.StatEffects.jumpHeight(0), "more Jump means higher jumps");
        check(com.bluelock.common.stats.StatEffects.passReach(90) > com.bluelock.common.stats.StatEffects.passReach(20), "more Vision means a longer look for passes");
        double slow = BotSpeed.jog(60, 1.05, CharacterTraits.NEUTRAL, com.bluelock.common.stats.StatEffects.moveSpeed(20, 20));
        double fast = BotSpeed.jog(60, 1.05, CharacterTraits.NEUTRAL, com.bluelock.common.stats.StatEffects.moveSpeed(90, 90));
        check(fast > slow * 1.2, "a bot with high Top Speed is clearly faster than one with low");
        PitchLayout l = PitchLayout.standard();
        Pos self = new Pos(20, 18);
        Pos far = new Pos(44, 18);   // 24 blocks away: only a visionary sees it
        TeamTactics tt = TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED);
        BotView blind = new BotView(Side.HOME, Position.CM, self, self, true, Side.HOME, self, 0, 60, tt, new Pos(30, 18), List.of(far), List.of(), l,
                BallMotion.STILL, 0.2, 50, 50, CharacterTraits.NEUTRAL, 10);
        BotView seer = new BotView(Side.HOME, Position.CM, self, self, true, Side.HOME, self, 0, 60, tt, new Pos(30, 18), List.of(far), List.of(), l,
                BallMotion.STILL, 0.2, 50, 50, CharacterTraits.NEUTRAL, 95);
        check(BotBrain.decide(blind).intent() != Intent.PASS && BotBrain.decide(seer).intent() == Intent.PASS, "only a bot with good Vision plays the long pass");
    }

    /** Small helper so the test does not need the anim package imports above. */
    private static final class AnimLogicProbe {
        static boolean sprintShownOnlyWhenFast() {
            return com.bluelock.common.anim.AnimLogic.botLocomotion(0.30, false, false).equals("run")
                    && com.bluelock.common.anim.AnimLogic.botLocomotion(0.45, false, false).equals("sprint")
                    && com.bluelock.common.anim.AnimLogic.botLocomotion(0.45, true, false).equals("dribble_sprint")
                    && com.bluelock.common.anim.AnimLogic.botLocomotion(0.10, false, false).equals("walk");
        }
    }
}
