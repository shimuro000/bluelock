package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Sound effects (the .ogg files are in assets/bluelock/sounds, listed in sounds.json). */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, BlueLockConstants.MOD_ID);

    public static final RegistryObject<SoundEvent> KICK = register("kick");
    public static final RegistryObject<SoundEvent> SHOT = register("shot");
    public static final RegistryObject<SoundEvent> TACKLE = register("tackle");
    public static final RegistryObject<SoundEvent> WHISTLE = register("whistle");
    public static final RegistryObject<SoundEvent> GOAL = register("goal");
    public static final RegistryObject<SoundEvent> SKILL = register("skill");
    public static final RegistryObject<SoundEvent> TOUCH = register("touch");
    public static final RegistryObject<SoundEvent> BOUNCE = register("bounce");
    public static final RegistryObject<SoundEvent> POST = register("post");
    public static final RegistryObject<SoundEvent> NET = register("net");
    public static final RegistryObject<SoundEvent> CHEER = register("cheer");
    public static final RegistryObject<SoundEvent> GASP = register("gasp");
    public static final RegistryObject<SoundEvent> WHOOSH = register("whoosh");
    public static final RegistryObject<SoundEvent> SAVE = register("save");
    public static final RegistryObject<SoundEvent> CHARGE = register("charge");
    public static final RegistryObject<SoundEvent> IMPACT = register("impact");
    public static final RegistryObject<SoundEvent> STEP = register("step");

    private ModSounds() {
    }

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(BlueLockConstants.MOD_ID, name)));
    }
}
