package com.bluelock.forge;

import com.bluelock.common.action.KickModel;
import com.bluelock.common.ai.KeeperLogic;
import com.bluelock.common.ball.BallCarry;
import com.bluelock.common.ball.BallPhysics;
import com.bluelock.common.ball.Velocity;
import com.bluelock.common.content.Position;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * The match ball. All movement is decided on the server.
 * Touch it and it sticks to your feet while you run (dribbling); right-click or the pass/shot keys kick it away,
 * and opponents can win it with a tackle. Bots use exactly the same rules as players.
 * The physics and carry maths live in the common module (BallPhysics, BallCarry, KickModel).
 */
public class BallEntity extends Entity implements ItemSupplier {
    private static final BallPhysics.Config PHYSICS = BallPhysics.defaults();
    private static final EntityDataAccessor<Integer> DATA_CARRIER = SynchedEntityData.defineId(BallEntity.class, EntityDataSerializers.INT);
    private static final int NO_CONTROL_TICKS = 6;
    private static final int KICKER_LOCKOUT_TICKS = 12;

    private LivingEntity carrier;
    private int carriedSince;
    private double headingX;
    private double headingZ = 1.0;
    private int lastReleaseTick = -100;
    private UUID lastKicker;
    private UUID lastToucher;
    private int touchCount;

    public BallEntity(EntityType<? extends BallEntity> type, Level level) {
        super(type, level);
    }

    public static BallEntity spawn(Level level, double x, double y, double z) {
        BallEntity ball = new BallEntity(ModEntities.BALL.get(), level);
        ball.setPos(x, y, z);
        level.addFreshEntity(ball);
        return ball;
    }

    public UUID lastToucher() {
        return lastToucher;
    }

    /** Counts every touch and kick. The match uses it to notice that somebody touched the ball. */
    public int touchCount() {
        return touchCount;
    }

    public LivingEntity carrier() {
        return carrier;
    }

    /** How many ticks the current carrier has had the ball. */
    public int carriedTicks() {
        return carrier == null ? 0 : tickCount - carriedSince;
    }

    /** Puts the ball at rest on a spot (kick-offs and restarts). The carrier loses it. */
    public void placeAt(double x, double y, double z) {
        setCarrier(null);
        setPos(x, y, z);
        setDeltaMovement(0, 0, 0);
        lastReleaseTick = tickCount;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(DATA_CARRIER, -1);
    }

    /** Entity id of whoever carries the ball (synchronised to clients for the animations), or -1. */
    public int carrierId() {
        return this.entityData.get(DATA_CARRIER);
    }

    private void setCarrier(LivingEntity who) {
        if (carrier instanceof BotEntity old) {
            old.setCarrying(false);
        }
        carrier = who;
        this.entityData.set(DATA_CARRIER, who == null ? -1 : who.getId());
        if (who instanceof BotEntity bot) {
            bot.setCarrying(true);
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public ItemStack getItem() {
        return new ItemStack(ModItems.FOOTBALL.get());
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    // ---------- every tick ----------

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            return;
        }
        if (getY() < level().getMinBuildHeight() - 16) {
            discard();
            return;
        }
        if (carrier != null) {
            carryTick();
            return;
        }
        rollTick();
        keeperSave();
        scanForContact();
    }

    private void rollTick() {
        Vec3 motion = getDeltaMovement();
        Velocity v = BallPhysics.applyForces(new Velocity(motion.x, motion.y, motion.z), PHYSICS, isInWater());
        Vec3 before = position();
        move(MoverType.SELF, new Vec3(v.x(), v.y(), v.z()));
        Vec3 moved = position().subtract(before);

        boolean hitX = Math.abs(moved.x - v.x()) > 1.0E-6;
        boolean hitY = Math.abs(moved.y - v.y()) > 1.0E-6;
        boolean hitZ = Math.abs(moved.z - v.z()) > 1.0E-6;
        BallPhysics.Resolved result = BallPhysics.resolve(v, hitX, hitY, hitZ, PHYSICS);
        Velocity next = result.velocity();
        setDeltaMovement(next.x(), next.y(), next.z());
        double speedNow = Math.sqrt(v.x() * v.x() + v.y() * v.y() + v.z() * v.z());
        if (result.bounced() && !goalBlockHit(hitX || hitZ, speedNow)) {
            Juice.sound(level(), getX(), getY(), getZ(), ModSounds.BOUNCE, (float) Math.min(1.0, 0.25 + speedNow * 0.6),
                    0.9F + random.nextFloat() * 0.3F);
        }
        if (speedNow > 0.9) {
            Juice.particles(level(), net.minecraft.core.particles.ParticleTypes.CRIT, getX(), getY() + 0.15, getZ(), 1, 0.04, 0.01);
            if (speedNow > 1.35) {
                Juice.particles(level(), net.minecraft.core.particles.ParticleTypes.FLAME, getX(), getY() + 0.15, getZ(), 2, 0.03, 0.01);
            }
        }
    }

    /** The ball hit a post, the crossbar or the net: the right sound and a few sparks. Returns true when it did. */
    private boolean goalBlockHit(boolean horizontal, double speed) {
        if (!horizontal) {
            return false;
        }
        net.minecraft.core.BlockPos here = blockPosition();
        for (net.minecraft.core.Direction dir : net.minecraft.core.Direction.Plane.HORIZONTAL) {
            net.minecraft.world.level.block.state.BlockState state = level().getBlockState(here.relative(dir));
            if (state.is(net.minecraft.world.level.block.Blocks.IRON_BARS)) {
                Juice.sound(level(), getX(), getY(), getZ(), ModSounds.NET, (float) Math.min(1.2, 0.4 + speed), 1.0F);
                Juice.particles(level(), net.minecraft.core.particles.ParticleTypes.CLOUD, getX(), getY() + 0.2, getZ(), 6, 0.2, 0.02);
                return true;
            }
            if (state.is(net.minecraft.world.level.block.Blocks.WHITE_CONCRETE)) {
                Juice.sound(level(), getX(), getY(), getZ(), ModSounds.POST, (float) Math.min(1.4, 0.5 + speed), 0.95F + random.nextFloat() * 0.15F);
                Juice.particles(level(), net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.2, getZ(), 10, 0.2, 0.1);
                if (speed > 0.8) {
                    Juice.shake(level(), getX(), getY(), getZ(), 20, 0.35F, 6);
                }
                return true;
            }
        }
        return false;
    }

    /** The ball follows the carrier, a little way in front of the feet. */
    private void carryTick() {
        if (!carrier.isAlive() || carrier.isRemoved() || carrier.level() != level() || distanceTo(carrier) > 3.5F) {
            release();
            return;
        }
        double vx = carrier.getX() - carrier.xo;
        double vz = carrier.getZ() - carrier.zo;
        double speed = Math.sqrt(vx * vx + vz * vz);
        if (speed > 0.03) {
            headingX = vx / speed;
            headingZ = vz / speed;
        } else {
            Vec3 look = carrier.getLookAngle();
            double len = Math.sqrt(look.x * look.x + look.z * look.z);
            if (len > 1.0E-3) {
                headingX = look.x / len;
                headingZ = look.z / len;
            }
        }
        double[] target = BallCarry.target(carrier.getX(), carrier.getZ(), headingX, headingZ, BallCarry.distanceAt(tickCount, speed));
        setPos(getX() + (target[0] - getX()) * 0.6, carrier.getY(), getZ() + (target[1] - getZ()) * 0.6);
        setDeltaMovement(vx, 0, vz);

        StatBlock stats = ActorStats.of(getServer(), carrier);
        if (!PlayerActions.hasNoLoss(carrier, level().getGameTime())) {
            double chance = BallCarry.lossChancePerTick(stats.permanent(Stat.DRIBBLING), stats.permanent(Stat.CLOSE_CONTROL), speed, false);
            if (chance > 0 && PlayerActions.hasSkill(carrier, "control")) {
                chance *= 0.7;   // the Control skill: the ball stays closer
            }
            if (chance > 0 && ThreadLocalRandom.current().nextDouble() < chance) {
                loseControl();
            }
        }
    }

    /** Running too fast for your skill: the ball squirts a little way ahead. */
    private void loseControl() {
        LivingEntity old = carrier;
        release();
        lastKicker = old.getUUID();
        setDeltaMovement(headingX * 0.45, 0.05, headingZ * 0.45);
    }

    /**
     * A goalkeeper bot near the ball tries to save it. Fast shots are caught, pushed away, or beat the keeper,
     * depending on his Reaction, Positioning and Jump and on how hard and how far from him the shot is.
     */
    private void keeperSave() {
        List<BotEntity> keepers = level().getEntitiesOfClass(BotEntity.class, getBoundingBox().inflate(1.5, 1.2, 1.5),
                b -> b.botPosition() == Position.GK && b.isAlive());
        if (keepers.isEmpty()) {
            return;
        }
        BotEntity keeper = keepers.get(0);
        long now = level().getGameTime();
        if (now < keeper.keeperLockUntil || tickCount - lastReleaseTick < NO_CONTROL_TICKS) {
            return;
        }
        Vec3 motion = getDeltaMovement();
        double speed = motion.length();
        StatBlock st = keeper.stats();
        double chance = speed < 0.30 ? 0.97
                : KeeperLogic.saveChance(st.permanent(Stat.REACTION), st.permanent(Stat.POSITIONING), st.permanent(Stat.JUMP),
                        speed, keeper.isDiving() ? 0.6 : 1.3);
        KeeperLogic.SaveOutcome outcome = KeeperLogic.resolveSave(chance, ThreadLocalRandom.current()::nextDouble);
        keeper.keeperLockUntil = now + 12;
        switch (outcome) {
            case CATCH -> {
                keeper.animate("catch");
                takeBy(keeper);
                playSound(ModSounds.TACKLE.get(), 0.9F, 1.4F);
                Juice.sound(level(), getX(), getY(), getZ(), ModSounds.SAVE, 1.0F, 1.0F);
                Juice.particles(level(), net.minecraft.core.particles.ParticleTypes.CRIT, getX(), getY() + 0.3, getZ(), 12, 0.3, 0.1);
            }
            case PARRY -> {
                double side = ThreadLocalRandom.current().nextBoolean() ? 1 : -1;
                setDeltaMovement(-motion.x * 0.45 - motion.z * 0.3 * side, 0.28, -motion.z * 0.45 + motion.x * 0.3 * side);
                lastReleaseTick = tickCount;
                lastToucher = keeper.getUUID();
                touchCount++;
                playSound(ModSounds.SHOT.get(), 0.7F, 1.3F);
                Juice.sound(level(), getX(), getY(), getZ(), ModSounds.SAVE, 1.1F, 0.8F);
                Juice.sound(level(), getX(), getY(), getZ(), ModSounds.GASP, 1.6F, 1.0F);
                Juice.particles(level(), net.minecraft.core.particles.ParticleTypes.CRIT, getX(), getY() + 0.3, getZ(), 18, 0.35, 0.15);
                Juice.shake(level(), getX(), getY(), getZ(), 24, 0.5F, 8);
            }
            case BEATEN -> { }
        }
    }

    /** Somebody walks into a loose ball: settle it if their touch is good enough, otherwise it bounces off. */
    private void scanForContact() {
        if (tickCount - lastReleaseTick < NO_CONTROL_TICKS) {
            return;
        }
        long now = level().getGameTime();
        AABB box = getBoundingBox().inflate(0.45, 0.4, 0.45);
        // a wider search: interception read and diving give a bigger reach than the normal foot contact
        List<LivingEntity> nearby = level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(2.0, 1.2, 2.0), BallEntity::isActor);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : nearby) {
            if (e.getUUID().equals(lastKicker) && tickCount - lastReleaseTick < KICKER_LOCKOUT_TICKS) {
                continue;
            }
            double extraReach = PlayerActions.touchReach(e, now);
            boolean inFootReach = e.getBoundingBox().intersects(box);
            boolean inSkillReach = extraReach > 0 && Math.hypot(e.getX() - getX(), e.getZ() - getZ()) <= extraReach
                    && Math.abs(e.getY() - getY()) <= 1.6;
            if (!inFootReach && !inSkillReach) {
                continue;
            }
            double d = distanceToSqr(e);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        if (best == null) {
            return;
        }
        Vec3 motion = getDeltaMovement();
        double ballSpeed = motion.length();
        StatBlock stats = ActorStats.of(getServer(), best);
        boolean keeper = best instanceof BotEntity bot && bot.botPosition() == Position.GK;
        boolean canControl = keeper
                ? ballSpeed <= 0.30
                : BallCarry.canControl(ballSpeed, stats.permanent(Stat.FIRST_TOUCH) + PlayerActions.touchBonus(best, now),
                        stats.permanent(Stat.BALL_CONTROL) + PlayerActions.touchBonus(best, now));
        if (canControl) {
            takeBy(best);
        } else {
            setDeltaMovement(motion.x * -0.35, Math.max(motion.y, 0.08), motion.z * -0.35);
            lastReleaseTick = tickCount;
            lastToucher = best.getUUID();
            touchCount++;
            playSound(ModSounds.KICK.get(), 0.5F, 1.1F);
        }
    }

    /** True if this entity currently has a ball stuck to its feet. */
    public static boolean carriesBall(LivingEntity e) {
        return !e.level().getEntitiesOfClass(BallEntity.class, e.getBoundingBox().inflate(3.0), b -> b.carrier == e).isEmpty();
    }

    public static boolean isActor(LivingEntity e) {
        if (e instanceof Player player) {
            return player.isAlive() && !player.isSpectator();
        }
        return e instanceof BotEntity && e.isAlive();
    }

    // ---------- control and kicks ----------

    /** Gives the ball to this entity: it now sticks to their feet. */
    public void takeBy(LivingEntity who) {
        setCarrier(who);
        Juice.sound(level(), getX(), getY(), getZ(), ModSounds.TOUCH, 0.5F, 0.95F + random.nextFloat() * 0.2F);
        carriedSince = tickCount;
        lastToucher = who.getUUID();
        touchCount++;
        Vec3 look = who.getLookAngle();
        double len = Math.sqrt(look.x * look.x + look.z * look.z);
        if (len > 1.0E-3) {
            headingX = look.x / len;
            headingZ = look.z / len;
        }
        setDeltaMovement(0, 0, 0);
    }

    /** Lets go of the ball without kicking it. */
    public void release() {
        setCarrier(null);
        lastReleaseTick = tickCount;
    }

    /** Knocks the ball loose in a direction (after a tackle). */
    public void knockLoose(double dx, double dz, double speed) {
        double len = Math.sqrt(dx * dx + dz * dz);
        release();
        if (len > 1.0E-6) {
            setDeltaMovement(dx / len * speed, 0.1, dz / len * speed);
        }
        touchCount++;
    }

    /** A kick by this entity. Works whether or not they were carrying the ball. */
    public void kickBy(LivingEntity kicker, Velocity velocity, boolean hard) {
        release();
        setDeltaMovement(velocity.x(), velocity.y(), velocity.z());
        lastKicker = kicker.getUUID();
        lastToucher = kicker.getUUID();
        touchCount++;
        playSound(hard ? ModSounds.SHOT.get() : ModSounds.KICK.get(), hard ? 1.0F : 0.8F, 1.0F);
        double kickSpeed = Math.sqrt(velocity.x() * velocity.x() + velocity.y() * velocity.y() + velocity.z() * velocity.z());
        Juice.particles(level(), net.minecraft.core.particles.ParticleTypes.POOF, kicker.getX(), kicker.getY() + 0.1, kicker.getZ(), hard ? 8 : 3, 0.2, 0.02);
        if (hard && kickSpeed > 1.0) {
            Juice.particles(level(), net.minecraft.core.particles.ParticleTypes.CRIT, getX(), getY() + 0.2, getZ(), 14, 0.25, 0.2);
            Juice.shake(level(), getX(), getY(), getZ(), 18, (float) Math.min(0.7, 0.25 + (kickSpeed - 1.0) * 0.5), 6);
        }
        if (kicker instanceof BotEntity bot) {
            bot.animate(hard ? "kick_shot" : "kick_pass");
        }
    }

    /** Right-click on the ball: a pass. */
    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (!level().isClientSide && player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            PlayerActions.pass(serverPlayer);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    /** Left-click on the ball: a shot. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() instanceof net.minecraft.server.level.ServerPlayer player) {
            PlayerActions.shot(player);
            return true;
        }
        return false;
    }

    /** Helper for bots: a pass toward a world point. */
    public static Velocity passVelocity(double dx, double dz, double distance, StatBlock stats) {
        return KickModel.pass(dx, dz, distance, stats.permanent(Stat.PASSING), ThreadLocalRandom.current()::nextDouble);
    }
}
