# Testing the mod (Phase 5)

1. Get `bluelock-0.11.1.jar` (see BUILDING.md, "Getting the .jar without installing anything").
2. Install Minecraft Java 1.20.1 and Forge 47.4.0 (or newer 47.x), put the jar in the `mods` folder, start the game.
3. Create a Creative world (flat world is best), then:
   - `/bluelock pitch` builds a 61x37 pitch where you stand (grass stripes, white lines, two goals) and puts a ball at the centre. Stand on flat ground first; blocks above the pitch area are removed.
   - `/bluelock ball` puts a ball in front of you. The Football item is in the Tools & Utilities creative tab.
4. Play: run into the ball to dribble, right-click it to pass, left-click it to shoot.
5. Career commands: `/bluelock create striker competitive right Roy`, `/bluelock profile`, `/bluelock data`.

6. Play a match (Phase 6):
   - `/bluelock pitch` first, then `/bluelock match join home` (or `away`), then `/bluelock match start 3` (3 minutes; default 3).
   - The chat tells you where each goal is (X, Z). Home defends one goal and attacks the other.
   - Touch the ball to kick off; the clock runs only while the ball is in play.
   - Goals, own goals, ball out of play (put back on the line), kick-off after goals and full time are announced in chat.
   - `/bluelock match status` shows score, time and possession; `/bluelock match stop` ends it.
   - Alone? Join one side and shoot at the other goal. With a friend, join opposite sides.

7. Teams and formations (Phase 8):
   - `/bluelock match mode 5v5` picks the size (1v1, 2v2, 3v3, 4v4, 5v5, 7v7, 11v11). Default is 5v5.
   - `/bluelock team set home team_v` gives a side one of the five teams (V, W, X, Y, Z): their formation, style and rating.
   - `/bluelock team formation away 1_2_1` picks a formation that fits the mode; `/bluelock team show home` lists every slot (your name, or "(bot)" for slots the AI will fill later), plus rating and chemistry.
   - `/bluelock team slot 3` moves you to slot 3. Without it you are seated automatically by your archetype (a Striker gets ST, a Defender gets CB/LB/RB...).
   - At the start of a match and after every goal, joined players are moved to their formation spot, facing the other goal.

8. Gameplay update (carry, tackles, skills, bots, HUD, sound):
   - Walk into the ball and it sticks to your feet and travels with you. Run faster and it swings further ahead; weak dribblers can lose it when sprinting.
   - Keys (change them in Options > Controls > Blue Lock): R pass (auto-aims at the team-mate you look at), F shot (aim assist toward the goal), V slide tackle, Z feint, X burst dribble, C chain dribble, B sprint burst, G shoulder charge.
   - Tackle: left-click the player or bot who has the ball (standing tackle), or press V and slide into them. Better Tackling beats better Dribbling.
   - Skills: `/bluelock skills` lists them. Root skills (like Control) unlock by themselves when your stats allow it; others cost 1 skill point: `/bluelock skills unlock feint`. Skill points and development points come from levelling up (goals, tackles, passes, matches give XP). `/bluelock train passing` spends development points.
   - Bots: `/bluelock match start` fills every empty slot with a bot. `/bluelock match bots off` turns them off, `/bluelock match difficulty easy|normal|hard` changes their strength. Join a side first: `/bluelock match join home`.
   - The screen shows the score, clock, possession, your stamina, the key icons with cooldowns, and big GOAL / KICK-OFF / FULL TIME banners. Referee whistle, crowd cheer, kick, shot and tackle sounds are included.

Remove balls with `/kill @e[type=bluelock:ball]` and bots with `/kill @e[type=bluelock:bot]`.

## What is new in 0.11.1
- **Press M** for the Blue Lock menu: MATCH (build pitch, mode, length, bots, bot level, join a side, pick teams, start/stop), STATS (all 35 stats by category with +1 buttons), SKILLS (by category, unlock buttons), QUESTS (13 quests with progress and rewards).
- **New character screen** opens by itself the first time you join a world without a character. Choose name, position, style and personality. Your **dominant foot** is rolled by the game (60% right, 30% left, 10% both) and your **talent** too (25% Genius, 75% Normal). Genius: +2 on every stat, cheaper growth, cap 99 instead of 92, +15% XP.
- **Foot matters:** kicks that go across your body onto your weak foot are less accurate and weaker; both-footed players have no weak side; feints are shorter toward your weak side.
- **Bots are faster and sharper.** `/bluelock match difficulty easy|normal|hard|pro`. Normal bots now run slightly faster than a sprinting player and react twice as often.
- **Goalkeepers** stand on the line between the ball and the goal (stepping out when an attacker runs at goal), dive left or right at shots, and catch, push away or get beaten depending on Reaction, Positioning and Jump.
- **Quests:** `/bluelock quests` or the QUESTS tab.
- Commands: `/bluelock create <archetype> <personality> <position> <name>` (foot and talent are rolled), `/bluelock train <stat> up`.

## What is new in 0.11.1 (animations, scrolling menu, test cheats)
- **Animations.** Install the two libraries next to the Blue Lock jar (see CHANGELOG-v0.11.1.md): GeckoLib 4.8.1 and PlayerAnimator 1.0.2-rc1 for 1.20.1 Forge.
  - Bots get a new animated model: idle, walk, run, sprint, jump, the same with the ball, kicks, tackles, slide, feints, burst, spin, shoulder charge, goalkeeper dives and catches, and a celebration after goals.
  - Players keep the normal Minecraft walking, but get custom animations while dribbling (idle, walk, run, sprint, jump with the ball) and for kicks, tackles, slide tackles, every dribble skill and goal celebrations. Other players see them too.
  - `/bluelock` tells you whether they are active: "bot animations: ON, player animations: ON". The latest log also says "GeckoLib bot animations are active".
- **Menus scroll**: mouse wheel in every tab and in the character screen. The category rows stay fixed.
- **Test cheats** (singleplayer, or op on a server): `/bluelock cheat skillpoints <n>`, `/bluelock cheat devpoints <n>`, `/bluelock cheat xp <n>`, `/bluelock cheat unlockall`. The Stats and Skills tabs also have red TEST buttons.
