package com.bluelock.common;

/**
 * Loader-independent constants. Nothing in the "common" package may import
 * Forge classes, so the football logic stays portable and easy to test.
 */
public final class BlueLockConstants {
    public static final String MOD_ID = "bluelock";
    public static final String MOD_NAME = "Blue Lock";

    private BlueLockConstants() {
    }
}
