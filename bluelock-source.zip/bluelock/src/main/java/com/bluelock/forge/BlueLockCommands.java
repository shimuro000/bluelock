package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import com.bluelock.common.content.DefinitionPack;
import com.bluelock.common.profile.Archetype;
import com.bluelock.common.profile.CharacterCreator;
import com.bluelock.common.profile.DominantFoot;
import com.bluelock.common.profile.Personality;
import com.bluelock.common.match.MatchSession;
import com.bluelock.common.team.MatchMode;
import com.bluelock.common.team.TeamSetup;
import java.util.UUID;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.pitch.PitchPlacement;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.stats.OverallRating;
import com.bluelock.common.stats.RoleWeights;
import com.bluelock.common.stats.StatModifiers;
import com.bluelock.common.util.Result;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Temporary command-line version of the career flow, until the menus arrive (Phase 18).
 * Everything runs on the server; nothing the client says is trusted beyond the typed choices.
 */
public final class BlueLockCommands {
    private static final SuggestionProvider<CommandSourceStack> ARCHETYPE_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(names(Archetype.values()), builder);
    private static final SuggestionProvider<CommandSourceStack> PERSONALITY_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(names(Personality.values()), builder);
    private static final SuggestionProvider<CommandSourceStack> FOOT_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(names(DominantFoot.values()), builder);

    private static final SuggestionProvider<CommandSourceStack> SIDE_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(names(Side.values()), builder);

    private static final SuggestionProvider<CommandSourceStack> TEAM_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(BlueLockData.get().teams().asMap().keySet(), builder);
    private static final SuggestionProvider<CommandSourceStack> FORMATION_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(BlueLockData.get().formations().asMap().keySet(), builder);
    private static final SuggestionProvider<CommandSourceStack> MODE_SUGGESTIONS =
            (ctx, builder) -> {
                List<String> labels = new ArrayList<>();
                for (MatchMode m : MatchMode.values()) {
                    labels.add(m.label());
                }
                return SharedSuggestionProvider.suggest(labels, builder);
            };

    private BlueLockCommands() {
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal(BlueLockConstants.MOD_ID)
                .executes(BlueLockCommands::hello)
                .then(Commands.literal("data").executes(BlueLockCommands::data))
                .then(Commands.literal("create")
                        .then(Commands.argument("archetype", StringArgumentType.word()).suggests(ARCHETYPE_SUGGESTIONS)
                                .then(Commands.argument("personality", StringArgumentType.word()).suggests(PERSONALITY_SUGGESTIONS)
                                        .then(Commands.argument("foot", StringArgumentType.word()).suggests(FOOT_SUGGESTIONS)
                                                .then(Commands.argument("name", StringArgumentType.greedyString())
                                                        .executes(BlueLockCommands::create))))))
                .then(Commands.literal("ball").executes(BlueLockCommands::ball))
                .then(Commands.literal("pitch")
                        .requires(BlueLockCommands::canManage)
                        .executes(BlueLockCommands::pitch))
                .then(Commands.literal("match")
                        .then(Commands.literal("start")
                                .requires(BlueLockCommands::canManage)
                                .executes(ctx -> startMatch(ctx, 3))
                                .then(Commands.argument("minutes", IntegerArgumentType.integer(1, 30))
                                        .executes(ctx -> startMatch(ctx, IntegerArgumentType.getInteger(ctx, "minutes")))))
                        .then(Commands.literal("stop").requires(BlueLockCommands::canManage).executes(BlueLockCommands::stopMatch))
                        .then(Commands.literal("join")
                                .then(Commands.argument("side", StringArgumentType.word()).suggests(SIDE_SUGGESTIONS)
                                        .executes(BlueLockCommands::joinMatch)))
                        .then(Commands.literal("mode")
                                .requires(BlueLockCommands::canManage)
                                .then(Commands.argument("mode", StringArgumentType.word()).suggests(MODE_SUGGESTIONS)
                                        .executes(BlueLockCommands::matchMode)))
                        .then(Commands.literal("status").executes(BlueLockCommands::matchStatus)))
                .then(Commands.literal("team")
                        .then(Commands.literal("set").requires(BlueLockCommands::canManage)
                                .then(Commands.argument("side", StringArgumentType.word()).suggests(SIDE_SUGGESTIONS)
                                        .then(Commands.argument("team", StringArgumentType.word()).suggests(TEAM_SUGGESTIONS)
                                                .executes(BlueLockCommands::teamSet))))
                        .then(Commands.literal("formation").requires(BlueLockCommands::canManage)
                                .then(Commands.argument("side", StringArgumentType.word()).suggests(SIDE_SUGGESTIONS)
                                        .then(Commands.argument("formation", StringArgumentType.word()).suggests(FORMATION_SUGGESTIONS)
                                                .executes(BlueLockCommands::teamFormation))))
                        .then(Commands.literal("slot")
                                .then(Commands.argument("number", IntegerArgumentType.integer(1, 11))
                                        .executes(BlueLockCommands::teamSlot)))
                        .then(Commands.literal("show")
                                .then(Commands.argument("side", StringArgumentType.word()).suggests(SIDE_SUGGESTIONS)
                                        .executes(BlueLockCommands::teamShow))))
                .then(Commands.literal("profile").executes(BlueLockCommands::profile))
                .then(Commands.literal("reset")
                        .executes(ctx -> {
                            ctx.getSource().sendFailure(Component.translatable("bluelock.profile.reset_hint"));
                            return 0;
                        })
                        .then(Commands.literal("confirm").executes(BlueLockCommands::reset))));
    }

    private static int hello(CommandContext<CommandSourceStack> ctx) {
        ctx.getSource().sendSuccess(() -> Component.translatable("bluelock.command.hello", BlueLockConstants.MOD_NAME), false);
        return 1;
    }

    private static int data(CommandContext<CommandSourceStack> ctx) {
        DefinitionPack pack = BlueLockData.get();
        ctx.getSource().sendSuccess(() -> Component.translatable("bluelock.command.data",
                pack.skills().size(), pack.formations().size(), pack.teams().size(), pack.problems().size()), false);
        return 1;
    }

    private static int create(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        ProfileSavedData store = ProfileSavedData.get(source.getServer());

        if (store.load(player.getUUID()).isPresent()) {
            source.sendFailure(Component.translatable("bluelock.error.profile_exists"));
            return 0;
        }

        String archetypeText = StringArgumentType.getString(ctx, "archetype");
        String personalityText = StringArgumentType.getString(ctx, "personality");
        String footText = StringArgumentType.getString(ctx, "foot");
        Archetype archetype = parse(Archetype.class, archetypeText);
        Personality personality = parse(Personality.class, personalityText);
        DominantFoot foot = parse(DominantFoot.class, footText);
        if (archetype == null || personality == null || foot == null) {
            String bad = archetype == null ? archetypeText : personality == null ? personalityText : footText;
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", bad));
            return 0;
        }

        String name = StringArgumentType.getString(ctx, "name");
        Result<PlayerProfile> result = CharacterCreator.create(BlueLockData.get(), player.getUUID(), name, "", foot, archetype, personality);
        if (!result.isOk()) {
            source.sendFailure(Component.translatable(result.errorKey().orElse("bluelock.error.content_missing")));
            return 0;
        }

        PlayerProfile profile = result.value();
        store.save(profile);
        source.sendSuccess(() -> Component.translatable("bluelock.profile.created",
                profile.name(), Component.translatable("bluelock.archetype." + archetype.name().toLowerCase(Locale.ROOT))), false);
        return 1;
    }

    private static int ball(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        Vec3 look = player.getLookAngle();
        BallEntity.spawn(source.getLevel(), player.getX() + look.x * 1.5, player.getY() + 0.3, player.getZ() + look.z * 1.5);
        source.sendSuccess(() -> Component.translatable("bluelock.ball.spawned"), false);
        return 1;
    }

    private static int pitch(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        PitchLayout layout = PitchLayout.standard();
        BlockPos centre = player.blockPosition();
        PitchPlacement placement = PitchBuilder.build(source.getLevel(), centre, player.getDirection(), layout);
        MatchManager.setPitch(source.getLevel(), placement);
        BallEntity.spawn(source.getLevel(), centre.getX() + 2.5, centre.getY() + 0.3, centre.getZ() + 0.5);
        source.sendSuccess(() -> Component.translatable("bluelock.pitch.built", layout.length(), layout.width()), false);
        return 1;
    }

    private static boolean canManage(CommandSourceStack source) {
        return source.hasPermission(2) || !source.getServer().isDedicatedServer();
    }

    private static int startMatch(CommandContext<CommandSourceStack> ctx, int minutes) {
        CommandSourceStack source = ctx.getSource();
        if (!MatchManager.hasPitch()) {
            source.sendFailure(Component.translatable("bluelock.match.need_pitch"));
            return 0;
        }
        for (Side side : Side.values()) {
            if (MatchManager.setup(side).isEmpty()) {
                source.sendFailure(Component.translatable("bluelock.team.no_formation", MatchManager.mode().size()));
                return 0;
            }
        }
        MatchManager.startMatch(source.getServer(), minutes);
        source.sendSuccess(() -> Component.translatable("bluelock.match.started", minutes,
                MatchManager.goalPosition(Side.HOME), MatchManager.goalPosition(Side.AWAY)), true);
        return 1;
    }

    private static int stopMatch(CommandContext<CommandSourceStack> ctx) {
        MatchManager.stopMatch();
        ctx.getSource().sendSuccess(() -> Component.translatable("bluelock.match.stopped"), true);
        return 1;
    }

    private static int joinMatch(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        String text = StringArgumentType.getString(ctx, "side");
        Side side = parse(Side.class, text);
        if (side == null) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", text));
            return 0;
        }
        Archetype archetype = ProfileSavedData.get(source.getServer()).load(player.getUUID())
                .map(PlayerProfile::archetype).orElse(Archetype.ALL_ROUNDER);
        MatchManager.join(player.getUUID(), side, archetype);
        source.sendSuccess(() -> Component.translatable("bluelock.match.joined", MatchManager.sideName(side)), false);
        return 1;
    }

    private static int matchStatus(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        MatchSession match = MatchManager.session();
        if (match == null) {
            source.sendFailure(Component.translatable("bluelock.match.no_match"));
            return 0;
        }
        Component possession = match.possession() == null
                ? Component.translatable("bluelock.possession.none")
                : MatchManager.sideName(match.possession());
        source.sendSuccess(() -> Component.translatable("bluelock.match.status",
                match.homeGoals(), match.awayGoals(), clock(match.elapsedTicks()), clock(match.durationTicks()), possession), false);
        return 1;
    }

    private static int matchMode(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        String text = StringArgumentType.getString(ctx, "mode");
        Optional<MatchMode> parsed = MatchMode.parse(text);
        if (parsed.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", text));
            return 0;
        }
        MatchManager.setMode(parsed.get());
        source.sendSuccess(() -> Component.translatable("bluelock.match.mode_set", parsed.get().label()), true);
        return 1;
    }

    private static int teamSet(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        Side side = parse(Side.class, StringArgumentType.getString(ctx, "side"));
        String teamId = StringArgumentType.getString(ctx, "team");
        if (side == null || !BlueLockData.get().teams().contains(teamId)) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", side == null ? StringArgumentType.getString(ctx, "side") : teamId));
            return 0;
        }
        MatchManager.setTeam(side, teamId);
        source.sendSuccess(() -> Component.translatable("bluelock.team.set_done", MatchManager.sideName(side), MatchManager.teamName(side)), true);
        return 1;
    }

    private static int teamFormation(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        Side side = parse(Side.class, StringArgumentType.getString(ctx, "side"));
        String formationId = StringArgumentType.getString(ctx, "formation");
        if (side == null) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", StringArgumentType.getString(ctx, "side")));
            return 0;
        }
        String error = MatchManager.setFormation(side, formationId);
        if (error != null) {
            source.sendFailure(Component.translatable(error, formationId));
            return 0;
        }
        source.sendSuccess(() -> Component.translatable("bluelock.team.formation_set", MatchManager.sideName(side),
                Component.translatable("bluelock.formation." + formationId + ".name")), true);
        return 1;
    }

    private static int teamSlot(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        int number = IntegerArgumentType.getInteger(ctx, "number");
        if (MatchManager.sideOf(player.getUUID()) == null) {
            source.sendFailure(Component.translatable("bluelock.team.not_joined"));
            return 0;
        }
        if (!MatchManager.setSlot(player.getUUID(), number - 1)) {
            source.sendFailure(Component.translatable("bluelock.team.bad_slot", MatchManager.mode().size()));
            return 0;
        }
        source.sendSuccess(() -> Component.translatable("bluelock.team.slot_set", number), false);
        return 1;
    }

    private static int teamShow(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        Side side = parse(Side.class, StringArgumentType.getString(ctx, "side"));
        if (side == null) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", StringArgumentType.getString(ctx, "side")));
            return 0;
        }
        Optional<TeamSetup> found = MatchManager.setup(side);
        if (found.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.team.no_formation", MatchManager.mode().size()));
            return 0;
        }
        TeamSetup setup = found.get();
        int rating = MatchManager.rating(source.getServer(), side);
        int chemistry = MatchManager.chemistry(side);
        source.sendSuccess(() -> Component.translatable("bluelock.team.header", MatchManager.sideName(side),
                MatchManager.teamName(side), Component.translatable(setup.formation().nameKey()), rating, chemistry), false);
        for (int i = 0; i < setup.size(); i++) {
            UUID occupant = setup.occupant(i);
            int number = i + 1;
            String position = setup.formation().slots().get(i).position().name();
            Component who = occupant == null
                    ? Component.translatable("bluelock.team.bot")
                    : Component.literal(MatchManager.playerName(source.getServer(), occupant));
            source.sendSuccess(() -> Component.translatable("bluelock.team.slot_line", number, position, who), false);
        }
        return 1;
    }

    private static String clock(int ticks) {
        int seconds = ticks / 20;
        return String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60);
    }

    private static int profile(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        Optional<PlayerProfile> found = ProfileSavedData.get(source.getServer()).load(player.getUUID());
        if (found.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.error.no_profile"));
            return 0;
        }
        PlayerProfile p = found.get();
        int overall = OverallRating.compute(p.stats(), StatModifiers.NONE, RoleWeights.forArchetype(p.archetype()));
        source.sendSuccess(() -> Component.translatable("bluelock.profile.summary",
                p.name(),
                Component.translatable("bluelock.archetype." + p.archetype().name().toLowerCase(Locale.ROOT)),
                Component.translatable("bluelock.personality." + p.personality().name().toLowerCase(Locale.ROOT)),
                Component.translatable("bluelock.foot." + p.foot().name().toLowerCase(Locale.ROOT)),
                p.level(), overall), false);
        return 1;
    }

    private static int reset(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        ProfileSavedData.get(source.getServer()).delete(player.getUUID());
        source.sendSuccess(() -> Component.translatable("bluelock.profile.reset_done"), false);
        return 1;
    }

    private static <E extends Enum<E>> E parse(Class<E> type, String text) {
        try {
            return Enum.valueOf(type, text.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static <E extends Enum<E>> List<String> names(E[] values) {
        List<String> out = new ArrayList<>();
        for (E value : values) {
            out.add(value.name().toLowerCase(Locale.ROOT));
        }
        return out;
    }
}
