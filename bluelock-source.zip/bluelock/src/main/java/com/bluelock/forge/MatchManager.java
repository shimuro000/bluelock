package com.bluelock.forge;

import com.bluelock.common.content.DefinitionPack;
import com.bluelock.common.content.FormationDefinition;
import com.bluelock.common.content.TeamDefinition;
import com.bluelock.common.match.BallSnapshot;
import com.bluelock.common.match.MatchEvent;
import com.bluelock.common.match.MatchRules;
import com.bluelock.common.match.MatchSession;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchPlacement;
import com.bluelock.common.profile.Archetype;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.stats.OverallRating;
import com.bluelock.common.stats.RoleWeights;
import com.bluelock.common.stats.StatModifiers;
import com.bluelock.common.team.FormationSelector;
import com.bluelock.common.team.KickoffPositions;
import com.bluelock.common.team.MatchMode;
import com.bluelock.common.team.TeamSetup;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

/**
 * Runs the one active match of this server session: teams and formations, kick-off positions, and the match clock.
 * It finds the ball each tick, feeds the common MatchSession, and turns its events into chat messages and resets.
 * Everything here is kept in memory only: after a server restart build the pitch again with /bluelock pitch.
 */
public final class MatchManager {
    private static final double BALL_REST_HEIGHT = 0.05;
    private static final int DEFAULT_BOT_RATING = 40;
    private static final int DEFAULT_PLAYER_OVERALL = 35;

    private record Member(UUID id, Side side, Archetype archetype, Integer preferredSlot) {
    }

    private static ServerLevel level;
    private static PitchPlacement pitch;
    private static MatchSession session;
    private static UUID ballId;
    private static MatchMode mode = MatchMode.FIVE_V_FIVE;
    private static final Map<Side, String> TEAM_IDS = new EnumMap<>(Side.class);
    private static final Map<Side, String> FORMATION_OVERRIDES = new EnumMap<>(Side.class);
    private static final Map<UUID, Member> MEMBERS = new LinkedHashMap<>();

    private MatchManager() {
    }

    // ---------- pitch and match lifecycle ----------

    public static boolean hasPitch() {
        return pitch != null;
    }

    public static MatchSession session() {
        return session;
    }

    public static void setPitch(ServerLevel pitchLevel, PitchPlacement placement) {
        stopMatch();
        level = pitchLevel;
        pitch = placement;
    }

    public static void startMatch(MinecraftServer server, int minutes) {
        removeBall();
        session = new MatchSession(pitch.layout(), MatchRules.ofMinutes(minutes));
        MEMBERS.values().forEach(m -> session.join(m.id(), m.side()));
        spawnBallAtCentre();
        session.start();
        positionPlayers(server);
    }

    public static void stopMatch() {
        if (session != null) {
            session.stop();
        }
        session = null;
        removeBall();
    }

    public static void clear() {
        session = null;
        pitch = null;
        level = null;
        ballId = null;
    }

    // ---------- teams ----------

    public static MatchMode mode() {
        return mode;
    }

    public static void setMode(MatchMode newMode) {
        mode = newMode;
        MEMBERS.replaceAll((id, m) -> new Member(m.id(), m.side(), m.archetype(), null));
        FORMATION_OVERRIDES.entrySet().removeIf(e -> {
            Optional<FormationDefinition> f = BlueLockData.get().formations().get(e.getValue());
            return f.isEmpty() || f.get().slots().size() != mode.size();
        });
    }

    public static void join(UUID player, Side side, Archetype archetype) {
        Member old = MEMBERS.get(player);
        Integer keep = old != null && old.side() == side ? old.preferredSlot() : null;
        MEMBERS.put(player, new Member(player, side, archetype, keep));
        if (session != null) {
            session.join(player, side);
        }
    }

    public static Side sideOf(UUID player) {
        Member m = MEMBERS.get(player);
        return m == null ? null : m.side();
    }

    /** slotIndex is 0-based. Returns false when the player has not joined a side or the slot does not exist. */
    public static boolean setSlot(UUID player, int slotIndex) {
        Member m = MEMBERS.get(player);
        if (m == null || slotIndex < 0 || slotIndex >= mode.size()) {
            return false;
        }
        MEMBERS.put(player, new Member(m.id(), m.side(), m.archetype(), slotIndex));
        return true;
    }

    public static void setTeam(Side side, String teamId) {
        TEAM_IDS.put(side, teamId);
    }

    /** Returns a language key describing the problem, or null when the formation was accepted. */
    public static String setFormation(Side side, String formationId) {
        Optional<FormationDefinition> f = BlueLockData.get().formations().get(formationId);
        if (f.isEmpty()) {
            return "bluelock.error.unknown_choice";
        }
        if (f.get().slots().size() != mode.size()) {
            return "bluelock.team.wrong_size";
        }
        FORMATION_OVERRIDES.put(side, formationId);
        return null;
    }

    public static Optional<TeamDefinition> teamDefinition(Side side) {
        String id = TEAM_IDS.get(side);
        return id == null ? Optional.empty() : BlueLockData.get().teams().get(id);
    }

    public static Component teamName(Side side) {
        String id = TEAM_IDS.get(side);
        return id == null || teamDefinition(side).isEmpty()
                ? Component.translatable("bluelock.team.custom")
                : Component.translatable("bluelock.team." + id + ".name");
    }

    public static Optional<TeamSetup> setup(Side side) {
        DefinitionPack pack = BlueLockData.get();
        String teamFormation = teamDefinition(side).map(TeamDefinition::formationId).orElse(null);
        Optional<FormationDefinition> formation =
                FormationSelector.choose(pack.formations(), mode.size(), FORMATION_OVERRIDES.get(side), teamFormation);
        if (formation.isEmpty()) {
            return Optional.empty();
        }
        List<TeamSetup.Candidate> candidates = new ArrayList<>();
        for (Member m : MEMBERS.values()) {
            if (m.side() == side) {
                candidates.add(new TeamSetup.Candidate(m.id(), m.archetype(), m.preferredSlot()));
            }
        }
        return Optional.of(TeamSetup.seat(formation.get(), candidates));
    }

    public static int chemistry(Side side) {
        return setup(side).map(s -> s.chemistry(archetypes(side))).orElse(0);
    }

    public static int rating(MinecraftServer server, Side side) {
        int bot = teamDefinition(side).map(TeamDefinition::rating).orElse(DEFAULT_BOT_RATING);
        Map<UUID, Integer> overalls = new HashMap<>();
        for (Member m : MEMBERS.values()) {
            if (m.side() == side) {
                overalls.put(m.id(), overallOf(server, m.id()));
            }
        }
        return setup(side).map(s -> s.rating(overalls, archetypes(side), bot)).orElse(bot);
    }

    private static Map<UUID, Archetype> archetypes(Side side) {
        Map<UUID, Archetype> map = new HashMap<>();
        for (Member m : MEMBERS.values()) {
            if (m.side() == side) {
                map.put(m.id(), m.archetype());
            }
        }
        return map;
    }

    private static int overallOf(MinecraftServer server, UUID player) {
        Optional<PlayerProfile> profile = ProfileSavedData.get(server).load(player);
        return profile
                .map(p -> OverallRating.compute(p.stats(), StatModifiers.NONE, RoleWeights.forArchetype(p.archetype())))
                .orElse(DEFAULT_PLAYER_OVERALL);
    }

    /** Moves every seated human to their formation spot, facing the opponent's goal. */
    private static void positionPlayers(MinecraftServer server) {
        if (pitch == null || level == null) {
            return;
        }
        for (Side side : Side.values()) {
            Optional<TeamSetup> setup = setup(side);
            if (setup.isEmpty()) {
                continue;
            }
            for (int i = 0; i < setup.get().size(); i++) {
                UUID occupant = setup.get().occupant(i);
                if (occupant == null) {
                    continue;
                }
                ServerPlayer player = server.getPlayerList().getPlayer(occupant);
                if (player == null || player.level() != level) {
                    continue;
                }
                double[] spot = KickoffPositions.spot(pitch.layout(), side, setup.get().formation().slots().get(i));
                player.connection.teleport(pitch.worldX(spot[0], spot[1]), pitch.worldY(0.0), pitch.worldZ(spot[0], spot[1]),
                        pitch.yawAlongPitch(side == Side.HOME), 0.0F);
            }
        }
    }

    /** World position (x, z) of the centre of the goal each side defends. */
    public static String goalPosition(Side defending) {
        double u = defending == Side.HOME ? -1.0 : pitch.layout().length() + 1.0;
        double v = pitch.layout().centreV() + 0.5;
        return Math.round(pitch.worldX(u, v)) + ", " + Math.round(pitch.worldZ(u, v));
    }

    // ---------- every tick ----------

    public static void tick(MinecraftServer server) {
        if (session == null || !session.isActive() || pitch == null || level == null) {
            return;
        }
        BallEntity ball = findBall();
        if (ball == null) {
            ball = spawnBallAtCentre();
            session.ballReplaced();
        }
        BallSnapshot snapshot = new BallSnapshot(
                pitch.localU(ball.getX(), ball.getZ()),
                pitch.localV(ball.getX(), ball.getZ()),
                pitch.localHeight(ball.getY() + 0.2),
                ball.touchCount(),
                ball.lastToucher());
        List<MatchEvent> events = session.tick(snapshot);
        for (MatchEvent event : events) {
            handle(server, ball, event);
        }
    }

    private static void handle(MinecraftServer server, BallEntity ball, MatchEvent event) {
        if (event instanceof MatchEvent.PlayStarted) {
            broadcast(server, Component.translatable("bluelock.match.kickoff"));
        } else if (event instanceof MatchEvent.GoalScored goal) {
            Component side = sideName(goal.scoringSide());
            if (goal.ownGoal()) {
                broadcast(server, Component.translatable("bluelock.match.own_goal", side, goal.homeGoals(), goal.awayGoals()));
            } else if (goal.scorer() != null) {
                broadcast(server, Component.translatable("bluelock.match.goal_by", side, playerName(server, goal.scorer()),
                        goal.homeGoals(), goal.awayGoals()));
            } else {
                broadcast(server, Component.translatable("bluelock.match.goal", side, goal.homeGoals(), goal.awayGoals()));
            }
        } else if (event instanceof MatchEvent.BallOut out) {
            ball.placeAt(pitch.worldX(out.restartU(), out.restartV()), pitch.worldY(BALL_REST_HEIGHT),
                    pitch.worldZ(out.restartU(), out.restartV()));
            broadcast(server, Component.translatable("bluelock.match.out"));
        } else if (event instanceof MatchEvent.KickoffReset) {
            placeAtCentre(ball);
            positionPlayers(server);
            broadcast(server, Component.translatable("bluelock.match.kickoff_ready"));
        } else if (event instanceof MatchEvent.MatchFinished finished) {
            if (finished.winner() == null) {
                broadcast(server, Component.translatable("bluelock.match.finished_draw", finished.homeGoals(), finished.awayGoals()));
            } else {
                broadcast(server, Component.translatable("bluelock.match.finished", finished.homeGoals(), finished.awayGoals(),
                        sideName(finished.winner())));
            }
        }
    }

    public static Component sideName(Side side) {
        return Component.translatable("bluelock.side." + side.name().toLowerCase(Locale.ROOT));
    }

    public static String playerName(MinecraftServer server, UUID id) {
        ServerPlayer player = server.getPlayerList().getPlayer(id);
        return player == null ? "?" : player.getGameProfile().getName();
    }

    private static void broadcast(MinecraftServer server, Component message) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.sendSystemMessage(message);
        }
    }

    private static BallEntity findBall() {
        if (ballId == null) {
            return null;
        }
        Entity entity = level.getEntity(ballId);
        if (entity instanceof BallEntity ball && !ball.isRemoved()) {
            return ball;
        }
        return null;
    }

    private static void removeBall() {
        BallEntity ball = findBall();
        if (ball != null) {
            ball.discard();
        }
        ballId = null;
    }

    private static BallEntity spawnBallAtCentre() {
        BallEntity ball = BallEntity.spawn(level, 0, 0, 0);
        placeAtCentre(ball);
        ballId = ball.getUUID();
        return ball;
    }

    private static void placeAtCentre(BallEntity ball) {
        double u = pitch.layout().centreU() + 0.5;
        double v = pitch.layout().centreV() + 0.5;
        ball.placeAt(pitch.worldX(u, v), pitch.worldY(BALL_REST_HEIGHT), pitch.worldZ(u, v));
    }
}
