package com.bluelock.forge;

import com.bluelock.common.ball.BallPhysics;
import com.bluelock.common.ball.Velocity;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * The match ball. All movement is decided on the server (the client only displays the position it receives).
 * Controls, no keybinds needed: run into it = dribble, right-click = pass, left-click = shot.
 * The physics rules themselves live in the common module (BallPhysics).
 */
public class BallEntity extends Entity implements ItemSupplier {
    private static final BallPhysics.Config PHYSICS = BallPhysics.defaults();
    private static final int TOUCH_COOLDOWN_TICKS = 4;

    private int lastTouchTick = -100;
    private UUID lastToucher;
    private int touchCount;

    public BallEntity(EntityType<? extends BallEntity> type, Level level) {
        super(type, level);
    }

    public static BallEntity spawn(Level level, double x, double y, double z) {
        BallEntity ball = new BallEntity(ModEntities.BALL.get(), level);
        ball.setPos(x, y, z);
        level.addFreshEntity(ball);
        return ball;
    }

    public UUID lastToucher() {
        return lastToucher;
    }

    /** Counts every dribble touch and kick. The match uses it to notice that somebody touched the ball. */
    public int touchCount() {
        return touchCount;
    }

    /** Puts the ball at rest on a spot (used for kick-offs and restarts). */
    public void placeAt(double x, double y, double z) {
        setPos(x, y, z);
        setDeltaMovement(0, 0, 0);
    }

    @Override
    protected void defineSynchedData() {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public ItemStack getItem() {
        return new ItemStack(ModItems.FOOTBALL.get());
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            return;
        }
        if (getY() < level().getMinBuildHeight() - 16) {
            discard();
            return;
        }

        Vec3 motion = getDeltaMovement();
        Velocity v = BallPhysics.applyForces(new Velocity(motion.x, motion.y, motion.z), PHYSICS, isInWater());
        Vec3 before = position();
        move(MoverType.SELF, new Vec3(v.x(), v.y(), v.z()));
        Vec3 moved = position().subtract(before);

        boolean hitX = Math.abs(moved.x - v.x()) > 1.0E-6;
        boolean hitY = Math.abs(moved.y - v.y()) > 1.0E-6;
        boolean hitZ = Math.abs(moved.z - v.z()) > 1.0E-6;
        BallPhysics.Resolved result = BallPhysics.resolve(v, hitX, hitY, hitZ, PHYSICS);
        Velocity next = result.velocity();
        setDeltaMovement(next.x(), next.y(), next.z());
        if (result.bounced()) {
            playSound(SoundEvents.SLIME_SQUISH_SMALL, 0.4F, 1.4F);
        }
    }

    /** Running into the ball: it rolls ahead of the player. */
    @Override
    public void playerTouch(Player player) {
        if (level().isClientSide || tickCount - lastTouchTick < TOUCH_COOLDOWN_TICKS) {
            return;
        }
        Velocity push = BallPhysics.dribble(player.getX() - player.xo, player.getZ() - player.zo, PHYSICS);
        if (push.equals(Velocity.ZERO)) {
            return;
        }
        setDeltaMovement(push.x(), getDeltaMovement().y, push.z());
        lastToucher = player.getUUID();
        touchCount++;
    }

    /** Right-click: a pass along the ground in the direction you are looking. */
    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (!level().isClientSide) {
            Vec3 look = player.getLookAngle();
            applyKick(player, BallPhysics.kick(look.x, 0, look.z, PHYSICS.passSpeed(), 0), 1.0F);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    /** Left-click: a hard shot with a little lift. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() instanceof Player player) {
            if (!level().isClientSide) {
                Vec3 look = player.getLookAngle();
                applyKick(player, BallPhysics.kick(look.x, Math.max(look.y, 0), look.z, PHYSICS.shotSpeed(), PHYSICS.shotLift()), 1.4F);
            }
            return true;
        }
        return false;
    }

    private void applyKick(Player player, Velocity kick, float soundPitch) {
        if (kick.equals(Velocity.ZERO)) {
            return;
        }
        setDeltaMovement(kick.x(), kick.y(), kick.z());
        lastTouchTick = tickCount;
        lastToucher = player.getUUID();
        touchCount++;
        playSound(SoundEvents.SLIME_SQUISH_SMALL, 0.8F, soundPitch);
    }
}
