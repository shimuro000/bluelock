# Blue Lock (Minecraft Java 1.20.1, Forge 47.4.0)

Football RPG mod inspired by Blue Lock. See `BUILDING.md` to build and run it.

Status: spec phases 0-5, a first match engine and Phase 8 (teams and formations) done. See docs/TESTING.md to try it.

## Layout
- `src/main/java/com/bluelock/common`  loader-independent game logic (no Forge imports allowed here)
- `src/main/java/com/bluelock/forge`   Forge entry point, events, commands, registration
- `src/main/resources/assets/bluelock` language files (en_us, ar_sa), later textures/models/sounds
- `src/test/java`                       unit tests for common logic (later)
- `docs/`                               design docs (ARCHITECTURE.md, ...)
