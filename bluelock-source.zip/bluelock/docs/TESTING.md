# Testing the mod (Phase 5)

1. Get `bluelock-0.8.0.jar` (see BUILDING.md, "Getting the .jar without installing anything").
2. Install Minecraft Java 1.20.1 and Forge 47.4.0 (or newer 47.x), put the jar in the `mods` folder, start the game.
3. Create a Creative world (flat world is best), then:
   - `/bluelock pitch` builds a 61x37 pitch where you stand (grass stripes, white lines, two goals) and puts a ball at the centre. Stand on flat ground first; blocks above the pitch area are removed.
   - `/bluelock ball` puts a ball in front of you. The Football item is in the Tools & Utilities creative tab.
4. Play: run into the ball to dribble, right-click it to pass, left-click it to shoot.
5. Career commands: `/bluelock create striker competitive right Roy`, `/bluelock profile`, `/bluelock data`.

6. Play a match (Phase 6):
   - `/bluelock pitch` first, then `/bluelock match join home` (or `away`), then `/bluelock match start 3` (3 minutes; default 3).
   - The chat tells you where each goal is (X, Z). Home defends one goal and attacks the other.
   - Touch the ball to kick off; the clock runs only while the ball is in play.
   - Goals, own goals, ball out of play (put back on the line), kick-off after goals and full time are announced in chat.
   - `/bluelock match status` shows score, time and possession; `/bluelock match stop` ends it.
   - Alone? Join one side and shoot at the other goal. With a friend, join opposite sides.

7. Teams and formations (Phase 8):
   - `/bluelock match mode 5v5` picks the size (1v1, 2v2, 3v3, 4v4, 5v5, 7v7, 11v11). Default is 5v5.
   - `/bluelock team set home team_v` gives a side one of the five teams (V, W, X, Y, Z): their formation, style and rating.
   - `/bluelock team formation away 1_2_1` picks a formation that fits the mode; `/bluelock team show home` lists every slot (your name, or "(bot)" for slots the AI will fill later), plus rating and chemistry.
   - `/bluelock team slot 3` moves you to slot 3. Without it you are seated automatically by your archetype (a Striker gets ST, a Defender gets CB/LB/RB...).
   - At the start of a match and after every goal, joined players are moved to their formation spot, facing the other goal.

Remove balls with `/kill @e[type=bluelock:ball]`.
