# Architecture (Phase 0 decisions)

- Platform: Minecraft Java 1.20.1, Java 17, Forge 47.4.0 (latest recommended build for 1.20.1), official Mojang mappings, ForgeGradle 6.0.x, Gradle 8.8 via the included wrapper.
- Single Gradle module. The "common vs loader" rule from the spec is enforced by package, not by a second module: `com.bluelock.common` must never import `net.minecraftforge.*`. If a second loader is ever wanted, `common` can be split into its own Gradle module without rewriting it.
- Server authoritative: clients only send intents; goals, XP, stats, cooldowns and ball state are decided on the server.
- All UI text goes through language files (`assets/bluelock/lang/*.json`), never hardcoded.
- Loader choice: Forge only. Fabric/NeoForge are out of scope for the first playable version.

## Phase 2: common module (done)
All in `com.bluelock.common`, no Forge imports, verified by `src/test/java/.../CommonSelfTest.java`.
- `stats`: `Stat` (35 stats from spec section 8), `StatBlock` (base + permanent growth, server-owned), `StatModifiers` (equipment/skill/temporary/flow/context layers), `StatCalculator` (EffectiveStat formula, clamped 0-100), `GrowthCurve`/`DefaultGrowthCurve` (progression bands; soft cap 99, 100 only via milestone), `RoleWeights` + `OverallRating` (role-weighted, not a plain average).
- `profile`: `PlayerProfile`, `Archetype`, `Personality`, `DominantFoot`, name validation returning language keys.
- `persistence`: `ProfileCodec` (profile <-> plain Map, versioned, tolerant of missing/broken fields), `ProfileRepository` (interface; Forge implements storage later).
- `util`: `Result` (success or language-key error).
Next (Phase 3): registries and data-driven definitions (skills, teams, formations) loaded from `data/bluelock/`.

## Phase 3: registries and data-driven content (done)
- `common/registry/Registry`: id -> definition table, ids limited to a-z, 0-9, `_`; frozen after loading.
- `common/content`: `SkillDefinition` (stat requirements, skill-tree parents, cooldown, stamina/Ego cost, mastery), `FormationDefinition`, `TeamDefinition`, and `DefinitionPack`, which builds everything from raw data, skips bad files and reports them in `problems()`. Skill trees are checked for missing parents and loops; teams must name an existing formation.
- Data files: `src/main/resources/data/bluelock/definitions/{skills,formations,teams}/<id>.json` (19 skills, 5 formations, 5 teams). Names and descriptions are language keys, so Arabic and English both work.
- `forge/DefinitionReloadListener`: loads the files on world load and on `/reload`; `/bluelock data` prints counts.
- Tests: `ContentSelfTest` loads the real data files through the real parser and checks every language key exists in both languages.
- Note: data lives under `definitions/` (not directly under `data/bluelock/`) so one reload listener can read all content types at once.
Next (Phase 4): player profile storage on the Forge side and the character creation flow.

## Phase 4: player profile and character creation (done)
- `common/profile/CharacterCreator`: builds a new player on the server. Every stat starts at 35; the archetype and personality shifts (JSON in `definitions/archetypes` and `definitions/personalities`) are applied. All shifts add up to zero, so every one of the 42 combinations has the same total (1225 points) and every build starts with weak spots.
- Balance check (test): own-role overall rating of all 42 builds lies within 35..38, so no starting class is clearly best.
- `forge/ProfileSavedData`: stores all profiles in the world (`data/bluelock_profiles.dat`), saved by Minecraft with the world, never every tick. Unreadable entries are skipped.
- Temporary commands until the menus (Phase 18): `/bluelock create <archetype> <personality> <foot> <name>`, `/bluelock profile`, `/bluelock reset confirm`. Tab-completion lists the choices.
- Nickname, appearance and jersey come with the creation screen in Phase 18.
Next (Phase 5): the ball and the pitch.

## Phase 5: the ball and the pitch (done)
- `common/ball/BallPhysics`: gravity, drag, bounces, rolling friction, kicks and dribbling as pure math (units: blocks per tick). Server-authoritative: only the server moves the ball.
- `forge/BallEntity`: the ball entity. Run into it = dribble, right-click = pass, left-click = shot. Rendered as the football sprite, always facing the camera.
- `common/pitch/PitchLayout` + `forge/PitchBuilder`: lines, centre circle, penalty and goal areas, stripes, two goals with nets. Built with vanilla blocks (grass, moss, white concrete, iron bars), so no custom block assets are needed.
- Assets: `assets/bluelock/textures/item/football.png` (64x64, drawn procedurally), `models/item/football.json`.
- Commands: `/bluelock pitch`, `/bluelock ball`. `/bluelock pitch` needs op rights on a dedicated server; in singleplayer anyone can use it.
- Known limits: ball motion is shown at 20 updates per second (smoothing comes later); no goal detection or score yet (Phase 6 and match phases).
Next (Phase 6): goal detection, possession and the first match rules.

## Phase 6: match rules (done)
- `common/pitch/PitchPlacement`: world <-> pitch coordinates; the pitch builder and the match both use it, so they always agree on where the goals are.
- `common/match`: `GoalDetector` (in play / goal / out, with posts, crossbar and goal depth), `MatchSession` (phases, score, clock, teams, possession, own goals, restarts), `MatchEvent`, `MatchRules`. Pure logic, 32 tests.
- Rules: clock runs only while the ball is in play; first touch after a kick-off starts it; a goal pauses play for 3 s then resets the ball to the centre; a ball that leaves the pitch (including over the crossbar) is put back on the nearest line spot and play resumes on the next touch; full time ends the match (draw allowed). HOME defends the goal behind u = 0.
- `forge/MatchManager`: one active match per server session; reads the ball every server tick, feeds the session, announces events in chat, resets the ball. `BallEntity.touchCount()` tells it when someone touched the ball.
- Commands: `/bluelock match start [minutes]`, `stop`, `join home|away`, `status`.
- Known limits: the pitch position is remembered only until the server stops (build the pitch again after a restart); no throw-ins, corners or fouls yet; no goalkeeper rules.
Next (Phase 7): player actions with stats (shot power, pass accuracy and so on use the profile's stats).

## Phase 8: teams and formations (done)
- `common/team`: `MatchMode` (1v1 to 11v11), `TeamSetup` (formation + who stands in each slot; empty slots are for AI bots; rebuilt from candidates every time so results are deterministic), `PositionFit` (archetype vs position), `FormationSelector` (explicit choice, then the team's own formation, then 4-3-3 or the first one that fits), `KickoffPositions` (every slot starts in its own half, outside the centre circle, mirrored for AWAY), `TeamTactics` (defensive line, pressing, tempo from the playstyle).
- Team rating = average of every slot (human overall or bot rating), lowered up to 10% by poor chemistry (chemistry = average position fit of the humans).
- Data: 6 new formations for the small modes (solo, duo, trio, diamond, 1-2-1, 2-3-1) next to the five 11-player ones.
- `forge/MatchManager`: mode, per-side team and formation, seating, kick-off teleports at the start and after goals.
- Commands: `/bluelock match mode`, `/bluelock team set|formation|slot|show`.
- Not done yet (their own phases): AI bots filling empty slots (Phase 13), tactics actually changing behaviour, substitutions, saving teams between sessions.
- Numbering note: this follows the spec's roadmap (Phase 6 football controls, 7 match engine, 8 teams). Football controls with stat-driven shot power and pass accuracy are only partly done (basic dribble, pass and shot exist); the stat link comes with Stats + progression (Phase 9).
