#!/usr/bin/env python3
"""
Generates the Blue Lock animation files from one description, so bots (GeckoLib) and players (PlayerAnimator)
stay consistent. Run from the project root:  python3 tools/make_animations.py

Angles are degrees in Minecraft's model convention:
  limbs: negative x swings the limb FORWARD, positive x swings it back
  torso: positive x leans FORWARD
  right arm out = +z, left arm out = -z
Times are seconds. Keys that end in @bot or @player apply to only that target.
"""
import json, math, os

BASE = "src/main/resources/assets/bluelock"
PARTS = ["head", "torso", "rightArm", "leftArm", "rightLeg", "leftLeg"]
BONE = {"root": "root", "head": "head", "torso": "waist", "rightArm": "right_arm", "leftArm": "left_arm",
        "rightLeg": "right_leg", "leftLeg": "left_leg"}

A = {}  # name -> (loop, length, {part[@target]: {"rot": [(t,(x,y,z))], "pos": [(t,(x,y,z))]}})

def R(*keys):   # rotation keys: (t, x, y, z)
    return [(k[0], tuple(k[1:4]) + (0,) * (4 - len(k[1:4]) - 1)) if False else (k[0], (k[1], k[2] if len(k) > 2 else 0, k[3] if len(k) > 3 else 0)) for k in keys]

def add(name, loop, length, **parts):
    A[name] = (loop, length, {p.replace("__", "@"): {"rot": R(*v)} if isinstance(v, list) else v for p, v in parts.items()})

def two(a, b, mid=None):
    """arm/leg swing: value a at 0, b at half, a at the end"""
    return None

def cycle(length, a, b, ya=0, yb=0, za=0, zb=0):
    return [(0, a, ya, za), (length / 2, b, yb, zb), (length, a, ya, za)]

# ---------- locomotion (bots; players only use the dribbling ones) ----------
add("idle", True, 2.0,
    torso=[(0, 0), (1.0, 1.5), (2.0, 0)],
    rightArm=[(0, 0, 0, 2), (1.0, 0, 0, 5), (2.0, 0, 0, 2)],
    leftArm=[(0, 0, 0, -2), (1.0, 0, 0, -5), (2.0, 0, 0, -2)])
add("walk", True, 1.0, rightLeg=cycle(1.0, 30, -30), leftLeg=cycle(1.0, -30, 30),
    rightArm=cycle(1.0, -25, 25), leftArm=cycle(1.0, 25, -25), torso=[(0, 3), (0.5, 3), (1.0, 3)])
add("run", True, 0.6, rightLeg=cycle(0.6, 45, -45), leftLeg=cycle(0.6, -45, 45),
    rightArm=cycle(0.6, -55, 55), leftArm=cycle(0.6, 55, -55), torso=[(0, 9), (0.3, 9), (0.6, 9)])
add("sprint", True, 0.45, rightLeg=cycle(0.45, 65, -65), leftLeg=cycle(0.45, -65, 65),
    rightArm=cycle(0.45, -75, 75), leftArm=cycle(0.45, 75, -75), torso=[(0, 18), (0.22, 18), (0.45, 18)],
    head=[(0, -8), (0.22, -8), (0.45, -8)])
add("jump", False, 0.7, rightLeg=[(0, 0), (0.2, -40), (0.5, -20), (0.7, 0)], leftLeg=[(0, 0), (0.2, 15), (0.5, 8), (0.7, 0)],
    rightArm=[(0, 0), (0.2, -140), (0.5, -60), (0.7, 0)], leftArm=[(0, 0), (0.2, -140), (0.5, -60), (0.7, 0)],
    root={"pos": [(0, (0, 0, 0)), (0.25, (0, 4, 0)), (0.5, (0, 2, 0)), (0.7, (0, 0, 0))]})

# ---------- with the ball (bots and players) ----------
add("idle_ball", True, 1.6,
    torso=[(0, 8), (0.8, 10), (1.6, 8)], head=[(0, 12), (0.8, 14), (1.6, 12)],
    rightLeg=[(0, 6), (0.8, -4), (1.6, 6)], leftLeg=[(0, -6), (0.8, 4), (1.6, -6)],
    rightArm=[(0, 0, 0, 22), (0.8, 0, 0, 26), (1.6, 0, 0, 22)], leftArm=[(0, 0, 0, -22), (0.8, 0, 0, -26), (1.6, 0, 0, -22)])
add("dribble_walk", True, 1.0, rightLeg=cycle(1.0, 22, -22), leftLeg=cycle(1.0, -22, 22),
    rightArm=[(0, 10, 0, 22), (0.5, -10, 0, 22), (1.0, 10, 0, 22)], leftArm=[(0, -10, 0, -22), (0.5, 10, 0, -22), (1.0, -10, 0, -22)],
    torso=[(0, 8), (0.5, 8), (1.0, 8)], head=[(0, 12), (0.5, 12), (1.0, 12)])
add("dribble_run", True, 0.6, rightLeg=cycle(0.6, 42, -42), leftLeg=cycle(0.6, -42, 42),
    rightArm=[(0, 20, 0, 30), (0.3, -20, 0, 30), (0.6, 20, 0, 30)], leftArm=[(0, -20, 0, -30), (0.3, 20, 0, -30), (0.6, -20, 0, -30)],
    torso=[(0, 14), (0.3, 14), (0.6, 14)], head=[(0, 10), (0.3, 10), (0.6, 10)])
add("dribble_sprint", True, 0.45, rightLeg=cycle(0.45, 62, -62), leftLeg=cycle(0.45, -62, 62),
    rightArm=[(0, 30, 0, 35), (0.22, -30, 0, 35), (0.45, 30, 0, 35)], leftArm=[(0, -30, 0, -35), (0.22, 30, 0, -35), (0.45, -30, 0, -35)],
    torso=[(0, 22), (0.22, 22), (0.45, 22)], head=[(0, 6), (0.22, 6), (0.45, 6)])
add("dribble_jump", False, 0.7, rightLeg=[(0, 0), (0.2, -35), (0.5, -15), (0.7, 0)], leftLeg=[(0, 0), (0.2, 12), (0.5, 6), (0.7, 0)],
    rightArm=[(0, 0, 0, 25), (0.2, -20, 0, 50), (0.5, 0, 0, 40), (0.7, 0, 0, 25)], leftArm=[(0, 0, 0, -25), (0.2, -20, 0, -50), (0.5, 0, 0, -40), (0.7, 0, 0, -25)],
    root={"pos": [(0, (0, 0, 0)), (0.25, (0, 4, 0)), (0.5, (0, 2, 0)), (0.7, (0, 0, 0))]})

# ---------- kicks and tackles ----------
add("kick_pass", False, 0.5, rightLeg=[(0, 0), (0.1, 40), (0.22, -65), (0.35, -30), (0.5, 0)], leftLeg=[(0, 0), (0.1, -10), (0.22, 10), (0.5, 0)],
    torso=[(0, 0), (0.1, -4), (0.22, 12), (0.5, 0)], leftArm=[(0, 0), (0.22, -35), (0.5, 0)], rightArm=[(0, 0), (0.22, 30), (0.5, 0)])
add("kick_shot", False, 0.6, rightLeg=[(0, 0), (0.15, 60), (0.28, -90), (0.45, -40), (0.6, 0)], leftLeg=[(0, 0), (0.28, 10), (0.6, 0)],
    torso=[(0, 0), (0.15, -10), (0.28, 18), (0.6, 0)],
    rightArm=[(0, 0, 0, 0), (0.28, -20, 0, 50), (0.6, 0, 0, 0)], leftArm=[(0, 0, 0, 0), (0.28, -20, 0, -50), (0.6, 0, 0, 0)])
add("tackle_stand", False, 0.5, rightLeg=[(0, 0), (0.15, -60), (0.3, -60), (0.5, 0)], leftLeg=[(0, 0), (0.15, 25), (0.5, 0)],
    torso=[(0, 0), (0.15, 22), (0.3, 22), (0.5, 0)],
    rightArm=[(0, 0, 0, 0), (0.15, 0, 0, 35), (0.5, 0, 0, 0)], leftArm=[(0, 0, 0, 0), (0.15, 0, 0, -35), (0.5, 0, 0, 0)])
add("slide", False, 0.9,
    rightLeg__bot=[(0, 0), (0.15, -25), (0.7, -25), (0.9, 0)], leftLeg__bot=[(0, 0), (0.15, -20), (0.7, -20), (0.9, 0)],
    rightLeg__player=[(0, 0), (0.15, -85), (0.7, -85), (0.9, 0)], leftLeg__player=[(0, 0), (0.15, -80), (0.7, -80), (0.9, 0)],
    torso__player=[(0, 0), (0.15, -55), (0.7, -55), (0.9, 0)],
    root__bot={"rot": R((0, 0), (0.15, -70), (0.7, -70), (0.9, 0)), "pos": [(0, (0, 0, 0)), (0.15, (0, -8, 0)), (0.7, (0, -8, 0)), (0.9, (0, 0, 0))]},
    rightArm=[(0, 0, 0, 0), (0.15, 0, 0, 40), (0.7, 0, 0, 40), (0.9, 0, 0, 0)], leftArm=[(0, 0, 0, 0), (0.15, 0, 0, -40), (0.7, 0, 0, -40), (0.9, 0, 0, 0)])

# ---------- skills ----------
for side, s in (("left", -1), ("right", 1)):
    add("feint_" + side, False, 0.45,
        torso=[(0, 0, 0, 0), (0.2, 8, 20 * s, 15 * s), (0.45, 0, 0, 0)], head=[(0, 0, 0, 0), (0.2, 0, -15 * s, -10 * s), (0.45, 0, 0, 0)],
        rightLeg=[(0, 0), (0.15, -25 if s > 0 else 15), (0.45, 0)], leftLeg=[(0, 0), (0.15, 15 if s > 0 else -25), (0.45, 0)],
        rightArm=[(0, 0, 0, 0), (0.2, 0, 0, 30), (0.45, 0, 0, 0)], leftArm=[(0, 0, 0, 0), (0.2, 0, 0, -30), (0.45, 0, 0, 0)])
add("burst", False, 0.5, torso=[(0, 0), (0.1, 25), (0.5, 10)], rightArm=[(0, 0), (0.1, 50), (0.5, 20)], leftArm=[(0, 0), (0.1, 50), (0.5, 20)],
    rightLeg=[(0, 0), (0.1, -50), (0.5, 0)], leftLeg=[(0, 0), (0.1, 45), (0.5, 0)])
add("chain_spin", False, 0.7, torso=[(0, 0, 0, 0), (0.7, 0, 360, 0)],
    rightArm=[(0, 0, 0, 0), (0.1, 0, 0, 70), (0.6, 0, 0, 70), (0.7, 0, 0, 0)], leftArm=[(0, 0, 0, 0), (0.1, 0, 0, -70), (0.6, 0, 0, -70), (0.7, 0, 0, 0)],
    rightLeg=[(0, 0), (0.2, 15), (0.5, -15), (0.7, 0)], leftLeg=[(0, 0), (0.2, -15), (0.5, 15), (0.7, 0)])
add("sprint_burst", False, 0.6, torso=[(0, 0), (0.15, 30), (0.6, 18)], rightArm=[(0, 0), (0.15, 65), (0.6, 30)], leftArm=[(0, 0), (0.15, 65), (0.6, 30)],
    rightLeg=[(0, 0), (0.15, -60), (0.3, 50), (0.6, 0)], leftLeg=[(0, 0), (0.15, 40), (0.3, -60), (0.6, 0)], head=[(0, 0), (0.15, -10), (0.6, -5)])
add("shoulder", False, 0.55, torso=[(0, 0, 0, 0), (0.15, 8, -30, 0), (0.3, 15, -10, 0), (0.55, 0, 0, 0)],
    rightArm=[(0, 0, 0, 0), (0.2, -35, 0, 20), (0.55, 0, 0, 0)], leftArm=[(0, 0, 0, 0), (0.2, 0, 0, -60), (0.55, 0, 0, 0)],
    rightLeg=[(0, 0), (0.2, -35), (0.55, 0)], leftLeg=[(0, 0), (0.2, 20), (0.55, 0)])

# ---------- goalkeeper and celebration (bots; celebrate also for players) ----------
for side, s in (("left", 1), ("right", -1)):
    add("dive_" + side, False, 0.9,
        root={"rot": R((0, 0, 0, 0), (0.25, 0, 0, 80 * s), (0.7, 0, 0, 80 * s), (0.9, 0, 0, 0)),
              "pos": [(0, (0, 0, 0)), (0.25, (6 * -s, -4, 0)), (0.7, (6 * -s, -6, 0)), (0.9, (0, 0, 0))]},
        rightArm=[(0, 0), (0.25, -170), (0.7, -170), (0.9, 0)], leftArm=[(0, 0), (0.25, -170), (0.7, -170), (0.9, 0)],
        rightLeg=[(0, 0), (0.25, 10), (0.9, 0)], leftLeg=[(0, 0), (0.25, 10), (0.9, 0)])
add("catch", False, 0.5, rightArm=[(0, 0), (0.15, -85), (0.35, -85), (0.5, -40)], leftArm=[(0, 0), (0.15, -85), (0.35, -85), (0.5, -40)],
    torso=[(0, 0), (0.15, 10), (0.5, 4)], head=[(0, 0), (0.15, 12), (0.5, 5)], rightLeg=[(0, 0), (0.15, -8), (0.5, 0)], leftLeg=[(0, 0), (0.15, 8), (0.5, 0)])
add("celebrate", False, 1.4, head=[(0, 0), (0.2, -10), (1.2, -10), (1.4, 0)],
    rightArm=[(0, 0, 0, 0), (0.2, -160, 0, 20), (0.5, -160, 0, 35), (0.8, -160, 0, 20), (1.1, -160, 0, 35), (1.4, 0, 0, 0)],
    leftArm=[(0, 0, 0, 0), (0.2, -160, 0, -20), (0.5, -160, 0, -35), (0.8, -160, 0, -20), (1.1, -160, 0, -35), (1.4, 0, 0, 0)],
    root={"pos": [(0, (0, 0, 0)), (0.2, (0, 3, 0)), (0.4, (0, 0, 0)), (0.6, (0, 3, 0)), (0.8, (0, 0, 0)), (1.0, (0, 3, 0)), (1.2, (0, 0, 0)), (1.4, (0, 0, 0))]})

BOT_NAMES = ["idle", "walk", "run", "sprint", "jump", "idle_ball", "dribble_walk", "dribble_run", "dribble_sprint", "dribble_jump",
             "kick_pass", "kick_shot", "tackle_stand", "slide", "feint_left", "feint_right", "burst", "chain_spin", "sprint_burst",
             "shoulder", "dive_left", "dive_right", "catch", "celebrate"]
PLAYER_NAMES = ["idle_ball", "dribble_walk", "dribble_run", "dribble_sprint", "dribble_jump", "kick_pass", "kick_shot", "tackle_stand",
                "slide", "feint_left", "feint_right", "burst", "chain_spin", "sprint_burst", "shoulder", "celebrate"]
assert set(A) == set(BOT_NAMES), set(A) ^ set(BOT_NAMES)

def resolve(parts, target):
    """merge part@target overrides; returns {part: {"rot":[...], "pos":[...]}}"""
    out = {}
    for key, val in parts.items():
        part, _, tgt = key.partition("@")
        if tgt and tgt != target:
            continue
        out[part] = val
    return out

def fmt_t(t):
    return str(round(t, 4)).rstrip("0").rstrip(".") if t else "0"

# ---------- bot (GeckoLib) ----------
anims = {}
for name in BOT_NAMES:
    loop, length, parts = A[name]
    bones = {}
    for part, ch in resolve(parts, "bot").items():
        bone = BONE.get(part)
        entry = {}
        if "rot" in ch:
            entry["rotation"] = {fmt_t(t): [round(v, 3) for v in vals] for t, vals in ch["rot"]}
        if "pos" in ch:
            entry["position"] = {fmt_t(t): [round(v, 3) for v in vals] for t, vals in ch["pos"]}
        bones[bone] = entry
    anims[name] = {"loop": bool(loop), "animation_length": length, "bones": bones}
os.makedirs(f"{BASE}/animations/entity", exist_ok=True)
json.dump({"format_version": "1.8.0", "animations": anims}, open(f"{BASE}/animations/entity/bot.animation.json", "w"), indent=1)

# ---------- bot model (same UV layout as the Minecraft player skin) ----------
def cube(origin, size, uv):
    return {"origin": origin, "size": size, "uv": uv}
bones = [
    {"name": "root", "pivot": [0, 0, 0]},
    {"name": "waist", "parent": "root", "pivot": [0, 12, 0]},
    {"name": "body", "parent": "waist", "pivot": [0, 12, 0], "cubes": [cube([-4, 12, -2], [8, 12, 4], [16, 16])]},
    {"name": "head", "parent": "waist", "pivot": [0, 24, 0], "cubes": [cube([-4, 24, -4], [8, 8, 8], [0, 0])]},
    {"name": "right_arm", "parent": "waist", "pivot": [-5, 22, 0], "cubes": [cube([-8, 12, -2], [4, 12, 4], [40, 16])]},
    {"name": "left_arm", "parent": "waist", "pivot": [5, 22, 0], "cubes": [cube([4, 12, -2], [4, 12, 4], [32, 48])]},
    {"name": "right_leg", "parent": "root", "pivot": [-1.9, 12, 0], "cubes": [cube([-3.9, 0, -2], [4, 12, 4], [0, 16])]},
    {"name": "left_leg", "parent": "root", "pivot": [1.9, 12, 0], "cubes": [cube([-0.1, 0, -2], [4, 12, 4], [16, 48])]},
]
os.makedirs(f"{BASE}/geo/entity", exist_ok=True)
json.dump({"format_version": "1.12.0", "minecraft:geometry": [{"description": {
    "identifier": "geometry.bluelock.bot", "texture_width": 64, "texture_height": 64,
    "visible_bounds_width": 3, "visible_bounds_height": 3, "visible_bounds_offset": [0, 1, 0]}, "bones": bones}]},
    open(f"{BASE}/geo/entity/bot.geo.json", "w"), indent=1)

# ---------- player (PlayerAnimator, Emotecraft format v3) ----------
os.makedirs(f"{BASE}/player_animations", exist_ok=True)
for name in PLAYER_NAMES:
    loop, length, parts = A[name]
    parts = resolve(parts, "player")
    if "root" in parts and "rot" in parts["root"] and "torso" not in parts:
        parts["torso"] = {"rot": parts["root"]["rot"]}          # root tilt becomes torso lean for players
    ticks = {}
    for part in PARTS:
        ch = parts.get(part)
        if not ch or "rot" not in ch:
            continue
        for t, (x, y, z) in ch["rot"]:
            tick = int(round(t * 20))
            ticks.setdefault(tick, {})[part] = {"pitch": round(math.radians(x), 4), "yaw": round(math.radians(y), 4), "roll": round(math.radians(z), 4)}
    end = int(round(length * 20))
    moves = []
    for tick in sorted(ticks):
        move = {"tick": tick, "easing": "LINEAR", "turn": 0}
        move.update(ticks[tick])
        moves.append(move)
    json.dump({"version": 3, "name": name, "author": "Blue Lock mod", "emote": {
        "beginTick": 0, "endTick": end, "stopTick": end, "isLoop": bool(loop), "returnTick": 0, "nsfw": False,
        "degrees": False, "moves": moves}}, open(f"{BASE}/player_animations/{name}.json", "w"), indent=1)
print("bot animations:", len(BOT_NAMES), "player animations:", len(PLAYER_NAMES))
