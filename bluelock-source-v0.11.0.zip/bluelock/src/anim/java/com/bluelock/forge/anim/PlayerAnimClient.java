package com.bluelock.forge.anim;

import com.bluelock.common.BlueLockConstants;
import com.bluelock.forge.AnimationBridge;
import com.bluelock.forge.PlayerAnimBackend;
import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.api.layered.ModifierLayer;
import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationFactory;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationRegistry;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

/**
 * Plays the player animations in assets/bluelock/player_animations/ with PlayerAnimator.
 * Only compiled when the animation libraries are part of the build. Client only.
 */
public final class PlayerAnimClient implements PlayerAnimBackend {
    private static final ResourceLocation LAYER = new ResourceLocation(BlueLockConstants.MOD_ID, "main");

    private PlayerAnimClient() {
    }

    /** Called by AnimationBridge at client start-up (through reflection). */
    public static void init() {
        PlayerAnimationFactory.ANIMATION_DATA_FACTORY.registerFactory(LAYER, 42, player -> new ModifierLayer<>());
        AnimationBridge.setPlayerBackend(new PlayerAnimClient());
    }

    @SuppressWarnings("unchecked")
    private static ModifierLayer<IAnimation> layerOf(Player player) {
        if (player instanceof AbstractClientPlayer clientPlayer) {
            return (ModifierLayer<IAnimation>) PlayerAnimationAccess.getPlayerAssociatedData(clientPlayer).get(LAYER);
        }
        return null;
    }

    @Override
    public void play(Player player, String name) {
        ModifierLayer<IAnimation> layer = layerOf(player);
        if (layer == null) {
            return;
        }
        KeyframeAnimation animation = PlayerAnimationRegistry.getAnimation(new ResourceLocation(BlueLockConstants.MOD_ID, name));
        if (animation != null) {
            layer.setAnimation(new KeyframeAnimationPlayer(animation));
        }
    }

    @Override
    public void stop(Player player) {
        ModifierLayer<IAnimation> layer = layerOf(player);
        if (layer != null) {
            layer.setAnimation(null);
        }
    }
}
