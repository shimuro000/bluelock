package com.bluelock.common.anim;

import java.util.List;

/**
 * Which animation plays when. Pure logic shared by the bots (GeckoLib) and the players (PlayerAnimator).
 * Bots animate everything; players keep the normal Minecraft walking and only use custom animations
 * while dribbling and for kicks, tackles and skills.
 */
public final class AnimLogic {
    /** Every animation in assets/bluelock/animations/entity/bot.animation.json. */
    public static final List<String> BOT_ANIMATIONS = List.of(
            "idle", "walk", "run", "sprint", "jump",
            "idle_ball", "dribble_walk", "dribble_run", "dribble_sprint", "dribble_jump",
            "kick_pass", "kick_shot", "tackle_stand", "slide", "feint_left", "feint_right", "burst", "chain_spin",
            "sprint_burst", "shoulder", "dive_left", "dive_right", "catch", "celebrate");

    /** Every animation in assets/bluelock/player_animations/. */
    public static final List<String> PLAYER_ANIMATIONS = List.of(
            "idle_ball", "dribble_walk", "dribble_run", "dribble_sprint", "dribble_jump",
            "kick_pass", "kick_shot", "tackle_stand", "slide", "feint_left", "feint_right", "burst", "chain_spin",
            "sprint_burst", "shoulder", "celebrate");

    /** Animations that repeat until something else starts. */
    public static final List<String> LOOPING = List.of(
            "idle", "walk", "run", "sprint", "idle_ball", "dribble_walk", "dribble_run", "dribble_sprint");

    private AnimLogic() {
    }

    /** Full locomotion for bots. speed is blocks per tick. */
    public static String locomotion(double speed, boolean carrying, boolean airborne) {
        if (airborne) return carrying ? "dribble_jump" : "jump";
        if (speed < 0.02) return carrying ? "idle_ball" : "idle";
        if (speed < 0.12) return carrying ? "dribble_walk" : "walk";
        if (speed < 0.20) return carrying ? "dribble_run" : "run";
        return carrying ? "dribble_sprint" : "sprint";
    }

    /** For players: a custom animation only while carrying the ball; null means "leave the normal Minecraft animation". */
    public static String playerLocomotion(double speed, boolean carrying, boolean airborne) {
        return carrying ? locomotion(speed, true, airborne) : null;
    }

    /** Skill id to animation. sideSign: +1 right-hand side, -1 left (for feints). Null when a skill has no animation. */
    public static String forSkill(String skillId, int sideSign) {
        if (skillId == null) return null;
        return switch (skillId) {
            case "feint" -> sideSign >= 0 ? "feint_right" : "feint_left";
            case "burst_dribble" -> "burst";
            case "chain_dribble" -> "chain_spin";
            case "sprint_burst" -> "sprint_burst";
            case "shoulder_charge" -> "shoulder";
            default -> null;
        };
    }

    /** How long a one-shot player animation lasts, in ticks (the client resumes the dribble loop afterwards). */
    public static int durationTicks(String name) {
        if (name == null) return 0;
        return switch (name) {
            case "kick_pass" -> 10;
            case "kick_shot" -> 12;
            case "tackle_stand" -> 10;
            case "slide" -> 18;
            case "feint_left", "feint_right" -> 9;
            case "burst" -> 10;
            case "chain_spin" -> 14;
            case "sprint_burst" -> 12;
            case "shoulder" -> 11;
            case "celebrate" -> 28;
            case "dribble_jump" -> 14;
            default -> 0;
        };
    }
}
