package com.bluelock.common.persistence;

import com.bluelock.common.profile.Archetype;
import com.bluelock.common.profile.DominantFoot;
import com.bluelock.common.profile.Personality;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Converts a PlayerProfile to/from a plain Map. The Forge side turns that Map into NBT/JSON,
 * so this class needs no Minecraft code and is fully testable.
 * Loading tolerates missing or broken fields (partially missing save) by falling back to defaults.
 */
public final class ProfileCodec {
    /** Bump when the save layout changes, and add a migration step in {@link #migrate}. */
    public static final int CURRENT_VERSION = 1;

    private ProfileCodec() {
    }

    public static Map<String, Object> toMap(PlayerProfile p) {
        Map<String, Object> m = new HashMap<>();
        m.put("version", CURRENT_VERSION);
        m.put("id", p.id().toString());
        m.put("name", p.name());
        m.put("nickname", p.nickname());
        m.put("foot", p.foot().name());
        m.put("archetype", p.archetype().name());
        m.put("personality", p.personality().name());
        m.put("level", p.level());
        m.put("xp", p.xp());
        m.put("skillPoints", p.skillPoints());
        m.put("developmentPoints", p.developmentPoints());
        Map<String, Object> base = new HashMap<>();
        Map<String, Object> growth = new HashMap<>();
        for (Stat s : Stat.values()) {
            base.put(s.name(), p.stats().base(s));
            growth.put(s.name(), p.stats().growth(s));
        }
        m.put("talent", p.talent().name());
        m.put("position", p.preferredPosition().name());
        m.put("hairStyle", p.hairStyle());
        m.put("hairColor", p.hairColor());
        m.put("hair", p.hair().toMap());
        m.put("body", p.body().toMap());
        Map<String, Object> bind = new HashMap<>();
        for (int i = 0; i < PlayerProfile.BIND_SLOTS; i++) {
            if (p.bound(i) != null) bind.put(Integer.toString(i), p.bound(i));
        }
        m.put("bound", bind);
        Map<String, Object> quests = new HashMap<>();
        for (Map.Entry<String, Integer> e : p.questProgressView().entrySet()) {
            quests.put(e.getKey(), e.getValue());
        }
        m.put("quests", quests);
        Map<String, Object> done = new HashMap<>();
        for (String q : p.questsDone()) {
            done.put(q, 1);
        }
        m.put("questsDone", done);
        m.put("goals", p.goals());
        m.put("assists", p.assists());
        Map<String, Object> skills = new HashMap<>();
        for (String id : p.unlockedSkills()) {
            skills.put(id, 1);
        }
        m.put("skills", skills);
        m.put("statBase", base);
        m.put("statGrowth", growth);
        return m;
    }

    public static PlayerProfile fromMap(Map<String, Object> raw) {
        Map<String, Object> m = migrate(raw);
        UUID id = parseUuid(m.get("id"));
        String name = str(m.get("name"), "Player");
        if (PlayerProfile.validateName(name) != null) name = "Player";
        StatBlock stats = new StatBlock();
        readStats(stats, m.get("statBase"), true);
        readStats(stats, m.get("statGrowth"), false);
        PlayerProfile p = new PlayerProfile(id, name, str(m.get("nickname"), ""),
                enumOf(DominantFoot.class, m.get("foot"), DominantFoot.RIGHT),
                enumOf(Archetype.class, m.get("archetype"), Archetype.ALL_ROUNDER),
                enumOf(Personality.class, m.get("personality"), Personality.COMPETITIVE), stats);
        p.setProgression(num(m.get("level"), 1).intValue(), num(m.get("xp"), 0).longValue(),
                num(m.get("skillPoints"), 0).intValue(), num(m.get("developmentPoints"), 0).intValue());
        p.setCreationExtras(enumOf(com.bluelock.common.profile.Talent.class, m.get("talent"), com.bluelock.common.profile.Talent.NORMAL),
                enumOf(com.bluelock.common.content.Position.class, m.get("position"), p.archetype().defaultPosition()),
                num(m.get("hairStyle"), 1).intValue(), num(m.get("hairColor"), 0x3B2A1E).intValue());
        if (m.get("hair") instanceof Map<?, ?> hairMap) {
            p.setHair(com.bluelock.common.appearance.HairDesign.fromMap(hairMap));   // saves from 0.13.0 on
        }
        if (m.get("body") instanceof Map<?, ?> bodyMap) {
            p.setBody(com.bluelock.common.appearance.BodyDesign.fromMap(bodyMap));
        }
        if (m.get("quests") instanceof Map<?, ?> quests) {
            for (Map.Entry<?, ?> e : quests.entrySet()) {
                if (e.getKey() instanceof String questId && e.getValue() instanceof Number n) p.setQuestProgress(questId, n.intValue());
            }
        }
        if (m.get("questsDone") instanceof Map<?, ?> done) {
            for (Object key : done.keySet()) {
                if (key instanceof String questId) p.markQuestDone(questId);
            }
        }
        p.setCareerCounters(num(m.get("goals"), 0).intValue(), num(m.get("assists"), 0).intValue());
        if (m.get("skills") instanceof Map<?, ?> skills) {
            for (Object key : skills.keySet()) {
                if (key instanceof String skillId) p.unlockSkill(skillId);
            }
        }
        if (m.get("bound") instanceof Map<?, ?> bind) {
            for (Map.Entry<?, ?> e : bind.entrySet()) {
                try {
                    if (e.getValue() instanceof String skillId) p.bind(Integer.parseInt(String.valueOf(e.getKey())), skillId);
                } catch (NumberFormatException ignored) {
                    // a damaged slot number is skipped
                }
            }
        }
        return p;
    }

    /** Upgrades older save layouts to {@link #CURRENT_VERSION}. Version 1 is the first, so nothing to do yet. */
    static Map<String, Object> migrate(Map<String, Object> raw) {
        Map<String, Object> m = new HashMap<>(raw);
        int version = num(m.get("version"), 1).intValue();
        // Example for later:  if (version < 2) { ...rename fields...; version = 2; }
        m.put("version", Math.max(version, 1));
        return m;
    }

    @SuppressWarnings("unchecked")
    private static void readStats(StatBlock block, Object node, boolean isBase) {
        if (!(node instanceof Map)) return;
        Map<String, Object> map = (Map<String, Object>) node;
        for (Stat s : Stat.values()) {
            Object v = map.get(s.name());
            if (v instanceof Number n) {
                if (isBase) block.setBase(s, n.intValue()); else block.setGrowth(s, n.intValue());
            }
        }
    }

    private static UUID parseUuid(Object o) {
        try {
            return UUID.fromString(String.valueOf(o));
        } catch (IllegalArgumentException e) {
            return UUID.randomUUID();
        }
    }

    private static String str(Object o, String def) {
        return o instanceof String s ? s : def;
    }

    private static Number num(Object o, Number def) {
        return o instanceof Number n ? n : def;
    }

    private static <E extends Enum<E>> E enumOf(Class<E> type, Object o, E def) {
        if (!(o instanceof String s)) return def;
        try {
            return Enum.valueOf(type, s.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return def;
        }
    }
}
