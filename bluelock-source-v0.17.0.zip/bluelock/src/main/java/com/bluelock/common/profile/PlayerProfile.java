package com.bluelock.common.profile;

import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.content.Position;
import com.bluelock.common.stats.GrowthCurve;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import com.bluelock.common.stats.TalentGrowthCurve;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/** Persistent career data of one player (identity, look, talent, progression, skills, quests, stats). Server-owned. */
public final class PlayerProfile {
    public static final int NAME_MIN = 2;
    public static final int NAME_MAX = 16;

    private final UUID id;
    private String name;
    private String nickname;
    private DominantFoot foot;
    private Archetype archetype;
    private Personality personality;
    private Talent talent = Talent.NORMAL;
    private Position preferredPosition;
    private HairDesign hair = HairDesign.standard();
    private BodyDesign body = BodyDesign.standard();
    public static final int BIND_SLOTS = 3;
    private final String[] bound = new String[BIND_SLOTS];
    private int level = 1;
    private long xp = 0;
    private int skillPoints = 0;
    private int developmentPoints = 0;
    private int goals = 0;
    private int assists = 0;
    private final Set<String> unlockedSkills = new LinkedHashSet<>();
    private final Map<String, Integer> questProgress = new HashMap<>();
    private final Set<String> questsDone = new LinkedHashSet<>();
    private final StatBlock stats;

    public PlayerProfile(UUID id, String name, String nickname, DominantFoot foot,
                         Archetype archetype, Personality personality, StatBlock stats) {
        this.id = Objects.requireNonNull(id);
        this.name = name;
        this.nickname = nickname == null ? "" : nickname;
        this.foot = Objects.requireNonNull(foot);
        this.archetype = Objects.requireNonNull(archetype);
        this.personality = Objects.requireNonNull(personality);
        this.preferredPosition = archetype.defaultPosition();
        this.stats = Objects.requireNonNull(stats);
    }

    /** Letters (any language), digits, spaces, '_' and '-'; length 2-16. Returns a lang key on failure, else null. */
    public static String validateName(String name) {
        if (name == null) return "bluelock.error.name_empty";
        String trimmed = name.trim();
        if (trimmed.length() < NAME_MIN) return "bluelock.error.name_too_short";
        if (trimmed.length() > NAME_MAX) return "bluelock.error.name_too_long";
        for (int i = 0; i < trimmed.length(); i++) {
            char c = trimmed.charAt(i);
            if (!(Character.isLetterOrDigit(c) || c == ' ' || c == '_' || c == '-')) {
                return "bluelock.error.name_invalid_chars";
            }
        }
        return null;
    }

    public UUID id() { return id; }
    public String name() { return name; }
    public String nickname() { return nickname; }
    public DominantFoot foot() { return foot; }
    public Archetype archetype() { return archetype; }
    public Personality personality() { return personality; }
    public Talent talent() { return talent; }
    public Position preferredPosition() { return preferredPosition; }
    public HairDesign hair() { return hair; }
    public int hairStyle() { return hair.style(); }
    public int hairColor() { return hair.color(); }
    public void setHair(HairDesign design) { this.hair = design == null ? HairDesign.standard() : design; }
    public BodyDesign body() { return body; }
    public void setBody(BodyDesign design) { this.body = design == null ? BodyDesign.standard() : design; }

    /** The skill on key slot 0..2, or null when the slot is empty. */
    public String bound(int slot) { return slot >= 0 && slot < BIND_SLOTS ? bound[slot] : null; }

    /** Which slot (0..2) a skill is bound to, or -1. */
    public int slotOf(String skillId) {
        for (int i = 0; i < BIND_SLOTS; i++) {
            if (skillId != null && skillId.equals(bound[i])) return i;
        }
        return -1;
    }

    /**
     * Puts an owned skill on a slot (a skill sits on one slot only), or empties the slot when skillId is null.
     * Returns false when the skill is not owned. Unbinding never takes the skill away.
     */
    public boolean bind(int slot, String skillId) {
        if (slot < 0 || slot >= BIND_SLOTS) return false;
        if (skillId == null) {
            bound[slot] = null;
            return true;
        }
        if (!isUnlocked(skillId)) return false;
        for (int i = 0; i < BIND_SLOTS; i++) {
            if (skillId.equals(bound[i])) bound[i] = null;
        }
        bound[slot] = skillId;
        return true;
    }

    public int level() { return level; }
    public long xp() { return xp; }
    public int skillPoints() { return skillPoints; }
    public int developmentPoints() { return developmentPoints; }
    public StatBlock stats() { return stats; }
    public int goals() { return goals; }
    public int assists() { return assists; }
    public Set<String> unlockedSkills() { return Collections.unmodifiableSet(unlockedSkills); }
    public boolean isUnlocked(String skillId) { return unlockedSkills.contains(skillId); }
    public void unlockSkill(String skillId) { unlockedSkills.add(skillId); }
    public void spendSkillPoints(int n) { skillPoints = Math.max(0, skillPoints - n); }
    public void setCareerCounters(int goals, int assists) { this.goals = Math.max(0, goals); this.assists = Math.max(0, assists); }
    public void addGoal() { goals++; }

    /** Look, talent and favourite position, chosen or rolled at character creation. */
    public void setCreationExtras(Talent talent, Position position, int hairStyle, int hairColor) {
        this.talent = talent == null ? Talent.NORMAL : talent;
        this.preferredPosition = position == null ? archetype.defaultPosition() : position;
        this.hair = HairDesign.preset(Math.max(0, hairStyle), hairColor);
    }

    /** Like the version above, with a fully designed 3D hair from the hair maker. */
    public void setCreationExtras(Talent talent, Position position, HairDesign design) {
        setCreationExtras(talent, position, 1, HairDesign.DEFAULT_COLOR);
        setHair(design);
    }

    public void setProgression(int level, long xp, int skillPoints, int developmentPoints) {
        this.level = Math.max(1, level);
        this.xp = Math.max(0, xp);
        this.skillPoints = Math.max(0, skillPoints);
        this.developmentPoints = Math.max(0, developmentPoints);
    }

    public void addPoints(int skill, int development) {
        this.skillPoints += Math.max(0, skill);
        this.developmentPoints += Math.max(0, development);
    }

    /** Growth costs and the stat cap depend on talent. */
    public GrowthCurve growthCurve() {
        return TalentGrowthCurve.of(talent);
    }

    // ---------- quests ----------

    public int questProgress(String questId) { return questProgress.getOrDefault(questId, 0); }
    public boolean isQuestDone(String questId) { return questsDone.contains(questId); }
    public Set<String> questsDone() { return Collections.unmodifiableSet(questsDone); }
    public Map<String, Integer> questProgressView() { return Collections.unmodifiableMap(questProgress); }
    public void setQuestProgress(String questId, int value) { questProgress.put(questId, Math.max(0, value)); }
    public void markQuestDone(String questId) { questsDone.add(questId); }

    // ---------- stat growth ----------

    /** Spends all development points on a stat via the growth curve. Returns points spent. */
    public int spendDevelopment(Stat stat, GrowthCurve curve) {
        int spent = stats.spendOn(stat, developmentPoints, curve);
        developmentPoints -= spent;
        return spent;
    }

    /** Like {@link #spendDevelopment(Stat, GrowthCurve)} but spends at most {@code maxPoints}. */
    public int spendDevelopment(Stat stat, GrowthCurve curve, int maxPoints) {
        int spent = stats.spendOn(stat, Math.min(developmentPoints, Math.max(0, maxPoints)), curve);
        developmentPoints -= spent;
        return spent;
    }

    /** Raises a stat by exactly one level if you can afford it. Returns the points spent (0 if not possible). */
    public int raiseOneLevel(Stat stat, GrowthCurve curve) {
        int value = stats.permanent(stat);
        if (value >= curve.softCap()) return 0;
        int cost = curve.costToRaise(value);
        if (developmentPoints < cost) return 0;
        int spent = stats.spendOn(stat, cost, curve);
        developmentPoints -= spent;
        return spent;
    }
}
