package com.bluelock.forge;

import com.bluelock.common.action.DirectShot;
import com.bluelock.common.action.FootModel;
import com.bluelock.common.action.KickModel;
import com.bluelock.common.action.PassAssist;
import com.bluelock.common.action.PassLanes;
import com.bluelock.common.anim.AnimLogic;
import com.bluelock.common.ball.Velocity;
import com.bluelock.common.content.SkillDefinition;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * What a football key does for a player: pass, shot, slide, direct shot, through pass, dive and every skill.
 * Basic actions are always available; skills must be unlocked, cost stamina (and ego for the big ones) and have a
 * cooldown. The maths lives in the common module (KickModel, DirectShot, PassLanes...); this class finds the ball
 * and the other players in the world and applies the result.
 */
public final class PlayerActions {
    private static final int SLIDE_COST = 15;
    private static final int SLIDE_COOLDOWN = 50;
    private static final int DIVE_COST = 14;
    private static final int DIVE_COOLDOWN = 80;

    private PlayerActions() {
    }

    public static void handle(ServerPlayer player, int action) {
        switch (action) {
            case ActionIds.PASS -> pass(player);
            case ActionIds.SHOT -> shot(player);
            case ActionIds.SLIDE -> slide(player);
            case ActionIds.DIRECT -> directShot(player);
            case ActionIds.THROUGH -> throughPass(player);
            case ActionIds.DIVE -> dive(player);
            default -> skill(player, action);
        }
    }

    // ---------- small helpers ----------

    private static Optional<PlayerProfile> profileOf(ServerPlayer player) {
        return ProfileSavedData.get(player.getServer()).load(player.getUUID());
    }

    /** True if this entity is a player who owns the skill. Bots have no skills. */
    static boolean hasSkill(LivingEntity entity, String skillId) {
        return entity instanceof ServerPlayer player && profileOf(player).map(p -> p.isUnlocked(skillId)).orElse(false);
    }

    private static void tell(ServerPlayer player, String key) {
        player.displayClientMessage(Component.translatable(key), true);
    }

    private static long gameTime(ServerPlayer player) {
        return player.level().getGameTime();
    }

    private static void sound(ServerPlayer player, SoundEvent event, float volume, float pitch) {
        player.playNotifySound(event, SoundSource.PLAYERS, volume, pitch);
    }

    private static void particles(ServerPlayer player, ParticleOptions type, double x, double y, double z, int count, double spread, double speed) {
        if (player.level() instanceof ServerLevel level) {
            level.sendParticles(type, x, y, z, count, spread, spread, spread, speed);
        }
    }

    private static int[] ids(List<? extends Entity> entities) {
        int[] out = new int[entities.size()];
        for (int i = 0; i < out.length; i++) {
            out[i] = entities.get(i).getId();
        }
        return out;
    }

    private static List<double[]> positions(List<? extends Entity> entities) {
        List<double[]> list = new ArrayList<>();
        for (Entity e : entities) {
            list.add(new double[] {e.getX(), e.getZ()});
        }
        return list;
    }

    static boolean isImmune(LivingEntity entity, long now) {
        if (!(entity instanceof ServerPlayer player)) {
            return false;
        }
        PlayerState state = PlayerStates.peek(player.getUUID());
        return state != null && now < state.immuneUntil;
    }

    static boolean hasNoLoss(LivingEntity entity, long now) {
        if (!(entity instanceof ServerPlayer player)) {
            return false;
        }
        PlayerState state = PlayerStates.peek(player.getUUID());
        return state != null && now < state.noLossUntil;
    }

    /** Extra reach (blocks) for touching a loose ball while a skill is active, or 0 for the normal reach. */
    static double touchReach(LivingEntity entity, long now) {
        if (!(entity instanceof ServerPlayer player)) {
            return 0;
        }
        PlayerState state = PlayerStates.peek(player.getUUID());
        if (state == null) {
            return 0;
        }
        if (now < state.trapUntil) {
            return 1.5;
        }
        if (now < state.interceptUntil) {
            return 1.9;
        }
        return now < state.diveUntil ? 1.7 : 0;
    }

    /** Extra First Touch / Ball Control while settling a ball, from skills that are active or owned. */
    static int touchBonus(LivingEntity entity, long now) {
        if (entity instanceof BotEntity bot) {
            return com.bluelock.common.ai.BotSkillRules.touchBonus(bot.skills());
        }
        if (!(entity instanceof ServerPlayer player)) {
            return 0;
        }
        PlayerState state = PlayerStates.peek(player.getUUID());
        int bonus = hasSkill(player, "control") ? 8 : 0;
        if (state != null) {
            if (now < state.trapUntil) {
                bonus += 100;
            }
            if (now < state.interceptUntil) {
                bonus += 35;
            }
            if (now < state.diveUntil) {
                bonus += 20;
            }
            if (now < state.composedUntil) {
                bonus += 15;
            }
        }
        return bonus;
    }

    /** The ball this player can kick: the one at their feet, or a loose one within reach. */
    private static BallEntity ballFor(ServerPlayer player) {
        List<BallEntity> balls = player.level().getEntitiesOfClass(BallEntity.class, player.getBoundingBox().inflate(3.0));
        BallEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (BallEntity ball : balls) {
            if (ball.carrier() == player) {
                return ball;
            }
            double d = ball.distanceTo(player);
            if (ball.carrier() == null && d < 2.6 && d < bestDist) {
                bestDist = d;
                best = ball;
            }
        }
        return best;
    }

    /** A ball nobody carries, within the direct-shot reach of the player (on the ground or in the air). */
    private static BallEntity looseBallInReach(ServerPlayer player) {
        BallEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (BallEntity ball : player.level().getEntitiesOfClass(BallEntity.class,
                player.getBoundingBox().inflate(DirectShot.REACH + 1.0, 3.0, DirectShot.REACH + 1.0))) {
            double horizontal = Math.hypot(ball.getX() - player.getX(), ball.getZ() - player.getZ());
            if (DirectShot.canStrike(horizontal, ball.getY() - player.getY(), ball.carrier() != null) && horizontal < bestDist) {
                bestDist = horizontal;
                best = ball;
            }
        }
        return best;
    }

    private static BallEntity nearestLooseBall(ServerPlayer player, double radius) {
        BallEntity best = null;
        double bestDist = radius;
        for (BallEntity ball : player.level().getEntitiesOfClass(BallEntity.class, player.getBoundingBox().inflate(radius))) {
            double d = ball.distanceTo(player);
            if (ball.carrier() == null && d < bestDist) {
                bestDist = d;
                best = ball;
            }
        }
        return best;
    }

    // ---------- pass and through pass ----------

    public static void pass(ServerPlayer player) {
        BallEntity ball = ballFor(player);
        if (ball == null) {
            return;
        }
        MinecraftServer server = player.getServer();
        PlayerState state = PlayerStates.get(player);
        long now = gameTime(player);
        StatBlock stats = ActorStats.of(server, player);
        Vec3 look = player.getLookAngle();
        boolean vision = now < state.visionUntil;
        boolean lanes = now < state.lanesUntil;
        boolean composed = now < state.composedUntil;
        boolean aware = hasSkill(player, "awareness");
        double cone = vision ? 48.0 : lanes ? 40.0 : aware ? 34.0 : 28.0;
        double range = vision ? 64.0 : lanes ? 55.0 : aware ? 50.0 : 45.0;

        List<LivingEntity> mates = MatchManager.teammatesOf(player);
        int target = PassAssist.pick(player.getX(), player.getZ(), look.x, look.z, positions(mates), cone, 3.0, range);
        double dx = look.x;
        double dz = look.z;
        double distance = 0;
        if (target >= 0) {
            LivingEntity mate = mates.get(target);
            double leadX = mate.getX() + (mate.getX() - mate.xo) * 6;
            double leadZ = mate.getZ() + (mate.getZ() - mate.zo) * 6;
            dx = leadX - ball.getX();
            dz = leadZ - ball.getZ();
            distance = Math.sqrt(dx * dx + dz * dz);
        }
        FootModel.Factors foot = footFactors(server, player, dx, dz);
        double steadier = (composed ? 0.45 : 1.0) * (lanes ? 0.7 : 1.0) * (vision ? 0.7 : 1.0);
        Velocity v = KickModel.pass(dx, dz, distance, stats.permanent(Stat.PASSING), foot.spread() * steadier, foot.power(),
                ThreadLocalRandom.current()::nextDouble);
        ball.kickBy(player, v, false);
        AnimationBridge.playOnPlayer(player, "kick_pass");
        Rewards.give(server, player.getUUID(), Progression.XpAction.PASS);
    }

    /** Through pass: a fast ground ball to the space ahead of the team-mate you look at. */
    private static void throughPass(ServerPlayer player) {
        SkillContext ctx = skillContext(player, ActionIds.THROUGH);
        if (ctx == null) {
            return;
        }
        BallEntity ball = ballFor(player);
        if (ball == null) {
            tell(player, "bluelock.action.need_ball");
            return;
        }
        if (!pay(player, ctx)) {
            return;
        }
        MinecraftServer server = player.getServer();
        PlayerState state = ctx.state;
        long now = ctx.now;
        StatBlock stats = ActorStats.of(server, player);
        Vec3 look = player.getLookAngle();
        boolean vision = now < state.visionUntil;
        List<LivingEntity> mates = MatchManager.teammatesOf(player);
        int pick = PassAssist.pick(player.getX(), player.getZ(), look.x, look.z, positions(mates), vision ? 70.0 : 55.0, 4.0, vision ? 80.0 : 70.0);
        double tx;
        double tz;
        if (pick >= 0) {
            LivingEntity mate = mates.get(pick);
            Vec3 goal = MatchManager.attackTarget(player);
            double gx = goal == null ? look.x : goal.x - mate.getX();
            double gz = goal == null ? look.z : goal.z - mate.getZ();
            double[] spot = PassLanes.throughTarget(mate.getX(), mate.getZ(), mate.getX() - mate.xo, mate.getZ() - mate.zo, gx, gz, 14.0, 4.5);
            tx = spot[0];
            tz = spot[1];
        } else {
            tx = player.getX() + look.x * 18.0;
            tz = player.getZ() + look.z * 18.0;
        }
        double dx = tx - ball.getX();
        double dz = tz - ball.getZ();
        double distance = Math.sqrt(dx * dx + dz * dz);
        FootModel.Factors foot = footFactors(server, player, dx, dz);
        double steadier = (now < state.composedUntil ? 0.5 : 1.0) * (vision ? 0.7 : 1.0);
        Velocity v = KickModel.through(dx, dz, distance, stats.permanent(Stat.PASSING), stats.permanent(Stat.VISION),
                foot.spread() * steadier, foot.power(), ThreadLocalRandom.current()::nextDouble);
        ball.kickBy(player, v, false);
        AnimationBridge.playOnPlayer(player, "through_pass");
        sound(player, ModSounds.SKILL.get(), 0.6F, 1.3F);
        Rewards.give(server, player.getUUID(), Progression.XpAction.PASS);
    }

    // ---------- shots ----------

    public static void shot(ServerPlayer player) {
        BallEntity ball = ballFor(player);
        if (ball != null) {
            fire(player, ball, 1.0, 1.0, 18.0, 0.7, false, "kick_shot");
        }
    }

    /**
     * The one place every shot is made. powerMul and spreadMul come from the shot type (normal or a direct shot
     * tier); skills the player owns (finishing, composure focus, pressure finisher) adjust it further.
     */
    private static void fire(ServerPlayer player, BallEntity ball, double powerMul, double spreadMul, double aimAngle,
                             double aimBlend, boolean corner, String animation) {
        MinecraftServer server = player.getServer();
        PlayerState state = PlayerStates.get(player);
        long now = gameTime(player);
        StatBlock stats = ActorStats.of(server, player);
        Vec3 look = player.getLookAngle();
        double[] dir = new double[] {look.x, look.y, look.z};
        Vec3 goal = corner ? MatchManager.attackCorner(player, look) : MatchManager.attackTarget(player);
        if (goal != null) {
            double[] toGoal = new double[] {goal.x - ball.getX(), goal.y - ball.getY(), goal.z - ball.getZ()};
            dir = KickModel.aimToward(dir, toGoal, aimAngle, aimBlend);
        }
        FootModel.Factors foot = footFactors(server, player, dir[0], dir[2]);
        double spread = spreadMul * foot.spread();
        double power = powerMul * foot.power();
        if (now < state.composedUntil) {
            spread *= 0.5;
        }
        if (hasSkill(player, "finishing")) {
            spread *= 0.85;
        }
        if (tryPressureFinisher(player, state, now)) {
            spread *= 0.45;
            power *= 1.12;
        }
        Velocity v = KickModel.shot(dir[0], Math.max(dir[1], 0.0), dir[2],
                stats.permanent(Stat.SHOOTING), stats.permanent(Stat.FINISHING), stats.permanent(Stat.SHOT_POWER),
                1.0, 0.12, spread, power, ThreadLocalRandom.current()::nextDouble);
        ball.kickBy(player, v, true);
        AnimationBridge.playOnPlayer(player, animation);
        Rewards.give(server, player.getUUID(), Progression.XpAction.SHOT);
    }

    /** Pressure finisher fires by itself on a shot when an opponent is within 5 blocks and the skill is ready. */
    private static boolean tryPressureFinisher(ServerPlayer player, PlayerState state, long now) {
        if (now < state.pressureReadyAt || !hasSkill(player, "pressure_finisher")) {
            return false;
        }
        Optional<SkillDefinition> def = BlueLockData.get().skills().get("pressure_finisher");
        if (def.isEmpty()) {
            return false;
        }
        boolean pressured = false;
        for (LivingEntity foe : MatchManager.opponentsOf(player)) {
            if (foe.distanceTo(player) <= 5.0F) {
                pressured = true;
                break;
            }
        }
        if (!pressured || state.stamina.current() < def.get().staminaCost() || state.ego.current() < def.get().egoCost()) {
            return false;
        }
        state.stamina.spend(def.get().staminaCost());
        state.ego.spend(def.get().egoCost());
        state.pressureReadyAt = now + def.get().cooldownTicks();
        tell(player, "bluelock.skill.pressure_finisher.fired");
        particles(player, ParticleTypes.CRIT, player.getX(), player.getY() + 1.0, player.getZ(), 14, 0.5, 0.2);
        return true;
    }

    /**
     * Direct shot: hit a loose ball (rolling or flying, nobody carrying it) within two blocks first time.
     * The key uses the best tier the player owns and can afford: awakening, then precision, then normal.
     */
    private static void directShot(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        Optional<PlayerProfile> profile = profileOf(player);
        if (profile.isEmpty()) {
            tell(player, "bluelock.error.no_profile");
            return;
        }
        PlayerProfile p = profile.get();
        if (!DirectShot.ownsAny(p::isUnlocked)) {
            player.displayClientMessage(Component.translatable("bluelock.skill.locked",
                    Component.translatable("bluelock.skill.direct_shot.name")), true);
            return;
        }
        PlayerState state = PlayerStates.get(player);
        long now = gameTime(player);
        BallEntity ball = looseBallInReach(player);
        if (ball == null) {
            tell(player, BallEntity.carriesBall(player) ? "bluelock.action.direct_carrying" : "bluelock.action.direct_no_ball");
            return;
        }
        DirectShot.Tier tier = DirectShot.best(p::isUnlocked, t -> tierReady(state, t, now));
        if (tier == null) {
            boolean onCooldown = false;
            for (DirectShot.Tier t : DirectShot.Tier.values()) {
                if (p.isUnlocked(t.skillId()) && now < state.directReadyAt[t.ordinal()]) {
                    onCooldown = true;
                }
            }
            if (!onCooldown) {
                tell(player, state.stamina.exhausted() || state.stamina.percent() < 30 ? "bluelock.action.tired" : "bluelock.action.no_ego");
            }
            return;
        }
        SkillDefinition def = BlueLockData.get().skills().get(tier.skillId()).orElseThrow();
        state.stamina.spend(def.staminaCost());
        state.ego.spend(def.egoCost());
        state.directReadyAt[tier.ordinal()] = now + def.cooldownTicks();
        state.directCooldownLength[tier.ordinal()] = Math.max(1, def.cooldownTicks());

        StatBlock stats = ActorStats.of(server, player);
        DirectShot.Params params = DirectShot.params(tier, stats.permanent(Stat.SHOOTING), stats.permanent(Stat.FINISHING),
                stats.permanent(Stat.COMPOSURE), stats.permanent(Stat.AWAKENING_POTENTIAL));
        fire(player, ball, params.powerMul(), params.spreadMul(), params.aimAngleDegrees(), params.aimBlend(), params.cornerAim(),
                AnimLogic.forSkill(tier.skillId(), 1));
        if (tier == DirectShot.Tier.AWAKENING) {
            particles(player, ParticleTypes.FLAME, ball.getX(), ball.getY() + 0.2, ball.getZ(), 40, 0.35, 0.12);
            particles(player, ParticleTypes.ELECTRIC_SPARK, player.getX(), player.getY() + 1.0, player.getZ(), 30, 0.6, 0.3);
            sound(player, ModSounds.SKILL.get(), 1.0F, 0.6F);
        } else if (tier == DirectShot.Tier.PRECISION) {
            particles(player, ParticleTypes.CRIT, ball.getX(), ball.getY() + 0.2, ball.getZ(), 16, 0.25, 0.1);
            sound(player, ModSounds.SKILL.get(), 0.7F, 1.4F);
        } else {
            particles(player, ParticleTypes.CRIT, ball.getX(), ball.getY() + 0.2, ball.getZ(), 8, 0.2, 0.05);
        }
        Rewards.give(server, player.getUUID(), Progression.XpAction.SKILL_USED);
    }

    private static boolean tierReady(PlayerState state, DirectShot.Tier tier, long now) {
        Optional<SkillDefinition> def = BlueLockData.get().skills().get(tier.skillId());
        return def.isPresent() && now >= state.directReadyAt[tier.ordinal()]
                && state.stamina.current() >= def.get().staminaCost() && state.ego.current() >= def.get().egoCost();
    }

    /** Cooldown shown for the direct-shot icon: the shortest remaining cooldown among the tiers the player owns. */
    static int directCooldownPercent(ServerPlayer player, PlayerState state, long now) {
        Optional<PlayerProfile> profile = profileOf(player);
        if (profile.isEmpty()) {
            return 0;
        }
        int best = 100;
        boolean any = false;
        for (DirectShot.Tier t : DirectShot.Tier.values()) {
            if (!profile.get().isUnlocked(t.skillId())) {
                continue;
            }
            any = true;
            long left = Math.max(0, state.directReadyAt[t.ordinal()] - now);
            int length = Math.max(1, state.directCooldownLength[t.ordinal()]);
            best = Math.min(best, (int) Math.min(100, Math.round(100.0 * left / length)));
        }
        return any ? best : 0;
    }

    private static FootModel.Factors footFactors(MinecraftServer server, ServerPlayer player, double dx, double dz) {
        Optional<PlayerProfile> profile = ProfileSavedData.get(server).load(player.getUUID());
        if (profile.isEmpty()) {
            return new FootModel.Factors(1.0, 1.0);
        }
        Vec3 h = heading(player);
        return FootModel.kick(profile.get().foot(), FootModel.sideOf(h.x, h.z, dx, dz));
    }

    // ---------- slide and dive ----------

    private static void slide(ServerPlayer player) {
        PlayerState state = PlayerStates.get(player);
        long now = gameTime(player);
        if (now < state.readyAt[ActionIds.SLIDE]) {
            return;
        }
        if (!state.stamina.spend(SLIDE_COST)) {
            tell(player, "bluelock.action.tired");
            return;
        }
        state.startCooldown(ActionIds.SLIDE, now, SLIDE_COOLDOWN);
        Vec3 heading = heading(player);
        state.slideX = heading.x;
        state.slideZ = heading.z;
        state.slideUntil = now + 10;
        AnimationBridge.playOnPlayer(player, "slide");
        sound(player, ModSounds.SKILL.get(), 0.8F, 0.8F);
    }

    /** A full-stretch dive toward the nearest loose ball (or where you run): a bigger reach for a few ticks. */
    private static void dive(ServerPlayer player) {
        PlayerState state = PlayerStates.get(player);
        long now = gameTime(player);
        if (now < state.readyAt[ActionIds.DIVE]) {
            return;
        }
        if (!state.stamina.spend(DIVE_COST)) {
            tell(player, "bluelock.action.tired");
            return;
        }
        state.startCooldown(ActionIds.DIVE, now, DIVE_COOLDOWN);
        Vec3 h = heading(player);
        double dx = h.x;
        double dz = h.z;
        BallEntity ball = nearestLooseBall(player, 6.0);
        if (ball != null) {
            double bx = ball.getX() - player.getX();
            double bz = ball.getZ() - player.getZ();
            double len = Math.sqrt(bx * bx + bz * bz);
            if (len > 0.3) {
                dx = bx / len;
                dz = bz / len;
            }
        }
        push(player, new Vec3(dx * 0.85, 0.28, dz * 0.85));
        state.diveUntil = now + 16;
        AnimationBridge.playOnPlayer(player, "dive");
        sound(player, ModSounds.SKILL.get(), 0.7F, 0.7F);
        Rewards.give(player.getServer(), player.getUUID(), Progression.XpAction.SKILL_USED);
    }

    // ---------- skills ----------

    /** What a skill key needs before it can run: the definition, the profile, the player state and the time. */
    private record SkillContext(String skillId, SkillDefinition def, PlayerProfile profile, PlayerState state, long now, int action) {
    }

    /** Checks the skill exists, is unlocked and is off cooldown. Returns null (with a message where useful) otherwise. */
    private static SkillContext skillContext(ServerPlayer player, int action) {
        String skillId = ActionIds.SKILL[action];
        if (skillId == null) {
            return null;
        }
        Optional<SkillDefinition> def = BlueLockData.get().skills().get(skillId);
        Optional<PlayerProfile> profile = profileOf(player);
        if (def.isEmpty()) {
            return null;
        }
        if (profile.isEmpty()) {
            tell(player, "bluelock.error.no_profile");
            return null;
        }
        if (!profile.get().isUnlocked(skillId)) {
            player.displayClientMessage(Component.translatable("bluelock.skill.locked", Component.translatable(def.get().nameKey())), true);
            return null;
        }
        PlayerState state = PlayerStates.get(player);
        long now = gameTime(player);
        if (now < state.readyAt[action]) {
            return null;
        }
        return new SkillContext(skillId, def.get(), profile.get(), state, now, action);
    }

    /** Spends stamina and ego and starts the cooldown. Returns false (with a message) if the player cannot afford it. */
    private static boolean pay(ServerPlayer player, SkillContext ctx) {
        if (ctx.state.stamina.current() < ctx.def.staminaCost()) {
            tell(player, "bluelock.action.tired");
            return false;
        }
        if (ctx.state.ego.current() < ctx.def.egoCost()) {
            tell(player, "bluelock.action.no_ego");
            return false;
        }
        ctx.state.stamina.spend(ctx.def.staminaCost());
        ctx.state.ego.spend(ctx.def.egoCost());
        ctx.state.startCooldown(ctx.action, ctx.now, ctx.def.cooldownTicks());
        return true;
    }

    private static void skill(ServerPlayer player, int action) {
        SkillContext ctx = skillContext(player, action);
        if (ctx == null) {
            return;
        }
        MinecraftServer server = player.getServer();
        PlayerState state = ctx.state;
        long now = ctx.now;
        String skillId = ctx.skillId;

        // skills that need something in the world check it first, so a failed attempt costs nothing
        List<LivingEntity> mates = List.of();
        List<LivingEntity> foes = List.of();
        LivingEntity shadowTarget = null;
        switch (skillId) {
            case "passing_lane_read", "spatial_read", "advanced_field_vision", "shadow_marking" -> {
                mates = MatchManager.teammatesOf(player);
                foes = MatchManager.opponentsOf(player);
                if (skillId.equals("shadow_marking")) {
                    shadowTarget = nearestOpponent(player, foes, 10.0);
                    if (shadowTarget == null) {
                        tell(player, "bluelock.action.no_target");
                        return;
                    }
                } else if (mates.isEmpty() && foes.isEmpty()) {
                    tell(player, "bluelock.action.nobody_around");
                    return;
                }
            }
            default -> { }
        }
        if (!pay(player, ctx)) {
            return;
        }

        Vec3 h = heading(player);
        Vec3 side = new Vec3(-h.z, 0, h.x);
        AnimationBridge.playOnPlayer(player, AnimLogic.forSkill(skillId, state.feintSide));
        switch (skillId) {
            case "feint" -> {
                push(player, side.scale(0.55 * state.feintSide * moveStrength(ctx.profile, state.feintSide)).add(h.scale(0.15)));
                state.feintSide = -state.feintSide;
                state.immuneUntil = now + 12;
            }
            case "burst_dribble" -> {
                push(player, h.scale(0.8));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 25, 1, false, false));
                state.immuneUntil = now + 14;
            }
            case "chain_dribble" -> {
                push(player, side.scale(0.4 * state.feintSide * moveStrength(ctx.profile, state.feintSide)).add(h.scale(0.5)));
                state.feintSide = -state.feintSide;
                state.immuneUntil = now + 30;
                state.noLossUntil = now + 40;
            }
            case "sprint_burst" -> player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 50, 2, false, false));
            case "shoulder_charge" -> TackleActions.attempt(server, player, TackleActions.Mode.SHOULDER);
            case "composure_focus" -> {
                state.composedUntil = now + 160;
                state.noLossUntil = Math.max(state.noLossUntil, now + 160);
                particles(player, ParticleTypes.ENCHANT, player.getX(), player.getY() + 1.2, player.getZ(), 30, 0.6, 0.5);
                tell(player, "bluelock.skill.composure_focus.fired");
            }
            case "passing_lane_read" -> {
                state.lanesUntil = now + 120;
                List<double[]> foePositions = positions(foes);
                double[] me = new double[] {player.getX(), player.getZ()};
                List<LivingEntity> open = new ArrayList<>();
                for (LivingEntity mate : mates) {
                    if (PassLanes.laneOpen(me, new double[] {mate.getX(), mate.getZ()}, foePositions)) {
                        open.add(mate);
                    }
                }
                BlueLockNetwork.sendToPlayer(player, new SkillFxPacket(ClientFx.KIND_OPEN_MATE, ids(open), 120));
                BlueLockNetwork.sendToPlayer(player, new SkillFxPacket(ClientFx.KIND_OPPONENT, ids(foes), 120));
                player.displayClientMessage(Component.translatable("bluelock.skill.passing_lane_read.fired", open.size(), mates.size()), true);
            }
            case "spatial_read" -> {
                List<LivingEntity> near = within(player, foes, 32.0);
                BlueLockNetwork.sendToPlayer(player, new SkillFxPacket(ClientFx.KIND_OPPONENT, ids(near), 100));
                List<double[]> foePositions = positions(foes);
                List<LivingEntity> free = new ArrayList<>();
                for (LivingEntity mate : mates) {
                    if (PassLanes.unmarked(new double[] {mate.getX(), mate.getZ()}, foePositions, 4.0)) {
                        free.add(mate);
                    }
                }
                BlueLockNetwork.sendToPlayer(player, new SkillFxPacket(ClientFx.KIND_OPEN_MATE, ids(free), 100));
                player.displayClientMessage(Component.translatable("bluelock.skill.spatial_read.fired", near.size(), free.size()), true);
            }
            case "advanced_field_vision" -> {
                state.lanesUntil = now + 160;
                state.visionUntil = now + 160;
                List<double[]> foePositions = positions(foes);
                double[] me = new double[] {player.getX(), player.getZ()};
                List<LivingEntity> open = new ArrayList<>();
                for (LivingEntity mate : mates) {
                    if (PassLanes.laneOpen(me, new double[] {mate.getX(), mate.getZ()}, foePositions)) {
                        open.add(mate);
                    }
                }
                BlueLockNetwork.sendToPlayer(player, new SkillFxPacket(ClientFx.KIND_OPEN_MATE, ids(open), 160));
                BlueLockNetwork.sendToPlayer(player, new SkillFxPacket(ClientFx.KIND_OPPONENT, ids(foes), 160));
                BallEntity ball = nearestBall(player, 80.0);
                if (ball != null) {
                    BlueLockNetwork.sendToPlayer(player, new SkillFxPacket(ClientFx.KIND_BALL, new int[] {ball.getId()}, 160));
                }
                particles(player, ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0, player.getZ(), 24, 0.7, 0.05);
                player.displayClientMessage(Component.translatable("bluelock.skill.advanced_field_vision.fired", open.size()), true);
            }
            case "interception_read" -> {
                state.interceptUntil = now + 100;
                BallEntity ball = nearestBall(player, 60.0);
                if (ball != null) {
                    BlueLockNetwork.sendToPlayer(player, new SkillFxPacket(ClientFx.KIND_BALL, new int[] {ball.getId()}, 100));
                }
                particles(player, ParticleTypes.CRIT, player.getX(), player.getY() + 1.0, player.getZ(), 16, 0.5, 0.2);
                tell(player, "bluelock.skill.interception_read.fired");
            }
            case "shadow_marking" -> {
                state.shadowUntil = now + 80;
                shadowTarget.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, false, false));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 80, 1, false, false));
                BlueLockNetwork.sendToPlayer(player, new SkillFxPacket(ClientFx.KIND_MARKED, new int[] {shadowTarget.getId()}, 80));
                particles(player, ParticleTypes.SMOKE, shadowTarget.getX(), shadowTarget.getY() + 1.0, shadowTarget.getZ(), 20, 0.4, 0.02);
                tell(player, "bluelock.skill.shadow_marking.fired");
            }
            default -> { }
        }
        sound(player, ModSounds.SKILL.get(), 0.7F, 1.0F);
        boolean carrying = isCarryingBall(player);
        Rewards.give(server, player.getUUID(), carrying ? Progression.XpAction.DRIBBLE_MOVE : Progression.XpAction.SKILL_USED);
    }

    // ---------- signature techniques and bind slots ----------

    /** A bind-slot key: fires whichever skill the player bound to that slot. */
    static void useBound(ServerPlayer player, int slot) {
        Optional<PlayerProfile> profile = profileOf(player);
        if (profile.isEmpty()) {
            tell(player, "bluelock.error.no_profile");
            return;
        }
        String id = profile.get().bound(slot);
        if (id == null) {
            tell(player, "bluelock.slot.empty");
            return;
        }
        int action = ActionIds.actionOfSkill(id);
        if (action < 0) {
            tell(player, "bluelock.slot.passive");
        } else if (action >= ActionIds.SIG_BASE) {
            signature(player, action - ActionIds.SIG_BASE);
        } else {
            handle(player, action);
        }
    }

    private static boolean needsBall(String id) {
        return id.equals("dragon_drive") || id.equals("curved_shot") || id.equals("perfect_pass");
    }

    /** The six Blue Lock signature techniques. */
    static void signature(ServerPlayer player, int index) {
        if (index < 0 || index >= ActionIds.SIGNATURE.length) {
            return;
        }
        String id = ActionIds.SIGNATURE[index];
        Optional<SkillDefinition> def = BlueLockData.get().skills().get(id);
        Optional<PlayerProfile> profile = profileOf(player);
        if (def.isEmpty()) {
            return;
        }
        if (profile.isEmpty()) {
            tell(player, "bluelock.error.no_profile");
            return;
        }
        if (!profile.get().isUnlocked(id)) {
            player.displayClientMessage(Component.translatable("bluelock.skill.locked", Component.translatable(def.get().nameKey())), true);
            return;
        }
        PlayerState state = PlayerStates.get(player);
        long now = gameTime(player);
        if (now < state.sigReadyAt[index]) {
            return;
        }
        BallEntity ball = null;
        if (needsBall(id)) {
            ball = ballFor(player);
            if (ball == null) {
                tell(player, "bluelock.action.need_ball");
                return;
            }
        }
        if (state.stamina.current() < def.get().staminaCost()) {
            tell(player, "bluelock.action.tired");
            return;
        }
        if (state.ego.current() < def.get().egoCost()) {
            tell(player, "bluelock.action.no_ego");
            return;
        }
        state.stamina.spend(def.get().staminaCost());
        state.ego.spend(def.get().egoCost());
        state.sigReadyAt[index] = now + def.get().cooldownTicks();
        state.sigLength[index] = Math.max(1, def.get().cooldownTicks());
        AnimationBridge.playOnPlayer(player, AnimLogic.forSkill(id, state.feintSide));
        Vec3 h = heading(player);
        switch (id) {
            case "dragon_drive" -> {
                fire(player, ball, 1.55, 0.6, 30.0, 0.85, false, "awakening_shot");
                ball.setDeltaMovement(ball.getDeltaMovement().add(0, 0.05, 0));
                particles(player, ParticleTypes.FLAME, player.getX(), player.getY() + 1.0, player.getZ(), 30, 0.5, 0.08);
                Juice.shake(player.level(), player.getX(), player.getY(), player.getZ(), 24, 0.8F, 8);
            }
            case "curved_shot" -> {
                fire(player, ball, 1.1, 0.8, 40.0, 0.8, true, "direct_shot");
                double rate = (state.feintSide >= 0 ? 1 : -1) * 0.016;
                Vec3 m = ball.getDeltaMovement();
                double a = -rate * 15;
                ball.setDeltaMovement(m.x * Math.cos(a) - m.z * Math.sin(a), m.y, m.x * Math.sin(a) + m.z * Math.cos(a));
                ball.setCurve(rate, 30);
                state.feintSide = -state.feintSide;
                particles(player, ParticleTypes.CLOUD, ball.getX(), ball.getY() + 0.2, ball.getZ(), 10, 0.2, 0.02);
            }
            case "perfect_pass" -> {
                Vec3 look = player.getLookAngle();
                List<LivingEntity> mates = MatchManager.teammatesOf(player);
                int pick = PassAssist.pick(player.getX(), player.getZ(), look.x, look.z, positions(mates), 70.0, 3.0, 80.0);
                double dx = look.x;
                double dz = look.z;
                double distance = 0;
                if (pick >= 0) {
                    LivingEntity mate = mates.get(pick);
                    dx = mate.getX() + (mate.getX() - mate.xo) * 8 - ball.getX();
                    dz = mate.getZ() + (mate.getZ() - mate.zo) * 8 - ball.getZ();
                    distance = Math.sqrt(dx * dx + dz * dz);
                }
                FootModel.Factors foot = footFactors(player.getServer(), player, dx, dz);
                Velocity v = KickModel.pass(dx, dz, distance, 100, 0.0, 1.25, ThreadLocalRandom.current()::nextDouble);
                ball.kickBy(player, v, false);
                particles(player, ParticleTypes.END_ROD, ball.getX(), ball.getY() + 0.2, ball.getZ(), 14, 0.2, 0.04);
            }
            case "monster_dribble" -> {
                state.monsterUntil = now + 36;
                state.monsterNext = now;
                state.immuneUntil = Math.max(state.immuneUntil, now + 36);
                state.noLossUntil = Math.max(state.noLossUntil, now + 40);
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 1, false, false));
                particles(player, ParticleTypes.SWEEP_ATTACK, player.getX(), player.getY() + 1.0, player.getZ(), 4, 0.5, 0.0);
            }
            case "chameleon" -> {
                state.composedUntil = Math.max(state.composedUntil, now + 160);
                state.noLossUntil = Math.max(state.noLossUntil, now + 160);
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 80, 0, false, false));
                particles(player, ParticleTypes.WITCH, player.getX(), player.getY() + 1.0, player.getZ(), 30, 0.5, 0.1);
                tell(player, "bluelock.skill.chameleon.fired");
            }
            case "trap" -> {
                state.trapUntil = now + 100;
                particles(player, ParticleTypes.ENCHANT, player.getX(), player.getY() + 0.5, player.getZ(), 16, 0.4, 0.3);
                tell(player, "bluelock.skill.trap.fired");
            }
            default -> { }
        }
        sound(player, ModSounds.SKILL.get(), 0.8F, 0.9F);
        Rewards.give(player.getServer(), player.getUUID(), isCarryingBall(player) ? Progression.XpAction.DRIBBLE_MOVE : Progression.XpAction.SKILL_USED);
    }

    /** Per-tick effects of the signature techniques (the zig-zag of the monster dribble). */
    static void tickSignature(ServerPlayer player, PlayerState state, long now) {
        if (now < state.monsterUntil && now >= state.monsterNext) {
            state.monsterNext = now + 6;
            Vec3 h = heading(player);
            Vec3 side = new Vec3(-h.z, 0, h.x);
            state.feintSide = -state.feintSide;
            push(player, side.scale(0.32 * state.feintSide).add(h.scale(0.12)));
        }
    }

    private static LivingEntity nearestOpponent(ServerPlayer player, List<LivingEntity> foes, double radius) {
        LivingEntity best = null;
        double bestDist = radius;
        for (LivingEntity foe : foes) {
            double d = foe.distanceTo(player);
            if (d < bestDist) {
                bestDist = d;
                best = foe;
            }
        }
        return best;
    }

    private static List<LivingEntity> within(ServerPlayer player, List<LivingEntity> entities, double radius) {
        List<LivingEntity> list = new ArrayList<>();
        for (LivingEntity e : entities) {
            if (e.distanceTo(player) <= radius) {
                list.add(e);
            }
        }
        return list;
    }

    private static BallEntity nearestBall(ServerPlayer player, double radius) {
        BallEntity best = null;
        double bestDist = radius;
        for (BallEntity ball : player.level().getEntitiesOfClass(BallEntity.class, player.getBoundingBox().inflate(radius))) {
            double d = ball.distanceTo(player);
            if (d < bestDist) {
                bestDist = d;
                best = ball;
            }
        }
        return best;
    }

    private static double moveStrength(PlayerProfile profile, int sideSign) {
        return FootModel.moveStrength(profile.foot(), sideSign);
    }

    private static boolean isCarryingBall(ServerPlayer player) {
        for (BallEntity ball : player.level().getEntitiesOfClass(BallEntity.class, player.getBoundingBox().inflate(4.0))) {
            if (ball.carrier() == player) {
                return true;
            }
        }
        return false;
    }

    private static void push(ServerPlayer player, Vec3 velocity) {
        player.setDeltaMovement(player.getDeltaMovement().add(velocity));
        player.hurtMarked = true;
    }

    /** The direction the player is moving, or looking when standing still. Unit vector, y = 0. */
    private static Vec3 heading(ServerPlayer player) {
        double dx = player.getX() - player.xo;
        double dz = player.getZ() - player.zo;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len > 0.03) {
            return new Vec3(dx / len, 0, dz / len);
        }
        Vec3 look = player.getLookAngle();
        double l = Math.sqrt(look.x * look.x + look.z * look.z);
        return l < 1.0E-3 ? new Vec3(0, 0, 1) : new Vec3(look.x / l, 0, look.z / l);
    }
}
