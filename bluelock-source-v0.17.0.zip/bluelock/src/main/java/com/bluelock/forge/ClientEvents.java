package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client-only game events: turns key presses into messages to the server and advances the HUD clock. */
@Mod.EventBusSubscriber(modid = BlueLockConstants.MOD_ID, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {
    }

    /** Players with a body design are drawn at their own height and build. Undone in the Post event. */
    @SubscribeEvent
    public static void onPlayerPre(net.minecraftforge.client.event.RenderPlayerEvent.Pre event) {
        com.bluelock.common.appearance.BodyDesign look = ClientBody.designFor(event.getEntity().getUUID());
        event.getPoseStack().pushPose();
        if (look != null) {
            float h = (float) look.heightScale();
            float w = h * (float) look.buildScale();
            event.getPoseStack().scale(w, h, w);
        }
    }

    @SubscribeEvent
    public static void onPlayerPost(net.minecraftforge.client.event.RenderPlayerEvent.Post event) {
        event.getPoseStack().popPose();
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        ClientHudState.tick();
        ClientAnimBridge.tick();
        ClientFx.tick();
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return;
        }
        while (ClientKeys.MENU.consumeClick()) {
            if (minecraft.screen == null) {
                BlueLockNetwork.CHANNEL.sendToServer(new MenuRequestPacket());
                minecraft.setScreen(ClientMenuState.hasProfile || !ClientMenuState.received ? new MainMenuScreen() : new CharacterCreationScreen());
            }
        }
        if (ClientMenuState.consumeAutoOpen() && minecraft.screen == null) {
            minecraft.setScreen(new CharacterCreationScreen());
        }
        for (int action = 0; action < ClientKeys.BY_ACTION.length; action++) {
            while (ClientKeys.BY_ACTION[action].consumeClick()) {
                if (minecraft.screen == null) {
                    BlueLockNetwork.CHANNEL.sendToServer(new ActionPacket(action));
                }
            }
        }
        for (int slot = 0; slot < ClientKeys.SLOTS.length; slot++) {
            while (ClientKeys.SLOTS[slot].consumeClick()) {
                if (minecraft.screen == null) {
                    BlueLockNetwork.CHANNEL.sendToServer(new ActionPacket(ActionIds.SLOT_BASE + slot));
                }
            }
        }
    }
}
