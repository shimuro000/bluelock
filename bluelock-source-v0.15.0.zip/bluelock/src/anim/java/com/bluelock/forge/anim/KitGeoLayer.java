package com.bluelock.forge.anim;

import com.bluelock.common.appearance.KitDesign;
import com.bluelock.forge.KitDraw;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

/**
 * The football kit on the animated bot: blocks over the body, arms and legs bones, and the number and name on the
 * back. The pose is the bone's, so everything follows the animation. renderForBone has no @Override on purpose: if a
 * GeckoLib version changed its signature the kit would just not show, instead of the build failing.
 */
public class KitGeoLayer extends GeoRenderLayer<GeoBotEntity> {
    public KitGeoLayer(GeoRenderer<GeoBotEntity> renderer) {
        super(renderer);
    }

    public void renderForBone(PoseStack poseStack, GeoBotEntity bot, GeoBone bone, RenderType renderType,
                              MultiBufferSource bufferSource, VertexConsumer buffer, float partialTick,
                              int packedLight, int packedOverlay) {
        if (bot.isInvisible()) {
            return;
        }
        KitDraw.Part part = switch (bone.getName()) {
            case "body" -> KitDraw.Part.BODY;
            case "right_arm" -> KitDraw.Part.RIGHT_ARM;
            case "left_arm" -> KitDraw.Part.LEFT_ARM;
            case "right_leg" -> KitDraw.Part.RIGHT_LEG;
            case "left_leg" -> KitDraw.Part.LEFT_LEG;
            default -> null;
        };
        if (part == null) {
            return;
        }
        KitDesign kit = bot.kit();
        poseStack.pushPose();
        // model space: x is mirrored compared with the plain model, y points up
        poseStack.scale(-1.0F / 16.0F, 1.0F / 16.0F, 1.0F / 16.0F);
        KitDraw.part(poseStack, bufferSource, kit, part, false, packedLight);
        if (part == KitDraw.Part.BODY) {
            KitDraw.backText(poseStack, bufferSource, kit, false, packedLight);
        }
        poseStack.popPose();
    }
}
