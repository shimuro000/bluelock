package com.bluelock.forge.anim;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Draws the animated bot. Client only. */
public class GeoBotRenderer extends GeoEntityRenderer<GeoBotEntity> {
    public GeoBotRenderer(EntityRendererProvider.Context context) {
        super(context, new GeoBotModel());
        this.shadowRadius = 0.5F;
        addRenderLayer(new HairGeoLayer(this));
        addRenderLayer(new KitGeoLayer(this));
    }

    /** Every character has his own height. */
    @Override
    public void render(GeoBotEntity bot, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        float scale = bot.heightScale();
        poseStack.pushPose();
        poseStack.scale(scale, scale, scale);
        super.render(bot, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        poseStack.popPose();
    }
}
