package com.bluelock.common.anim;

import java.util.List;

/**
 * Which animation plays when. Pure logic (no Minecraft code) so it can be tested.
 * Animation names are shared by the bots (GeckoLib, assets/bluelock/animations/entity/bot.animation.json)
 * and by the players (PlayerAnimator, assets/bluelock/player_animation/NAME.json).
 */
public final class AnimLogic {
    /** Every animation in bot.animation.json. */
    public static final List<String> BOT_ANIMATIONS = List.of(
            "idle", "walk", "run", "sprint", "jump",
            "idle_ball", "dribble_walk", "dribble_run", "dribble_sprint", "dribble_jump",
            "kick_pass", "kick_shot", "tackle_stand", "slide",
            "feint_left", "feint_right", "burst", "chain_spin", "sprint_burst", "shoulder",
            "direct_shot", "awakening_shot", "through_pass",
            "read_scan", "vision_open", "intercept_step", "shadow_step", "focus_breath",
            "dive", "dive_left", "dive_right", "catch", "celebrate");

    /** Every animation in assets/bluelock/player_animation/ (PlayerAnimator reads that exact folder name). */
    public static final List<String> PLAYER_ANIMATIONS = List.of(
            "idle", "walk", "run", "sprint", "jump",
            "idle_ball", "dribble_walk", "dribble_run", "dribble_sprint", "dribble_jump",
            "kick_pass", "kick_shot", "tackle_stand", "slide",
            "feint_left", "feint_right", "burst", "chain_spin", "sprint_burst", "shoulder",
            "direct_shot", "awakening_shot", "through_pass",
            "read_scan", "vision_open", "intercept_step", "shadow_step", "focus_breath",
            "dive", "celebrate");

    public static final List<String> LOOPING = List.of(
            "idle", "walk", "run", "sprint", "idle_ball", "dribble_walk", "dribble_run", "dribble_sprint");

    /** Speeds are blocks per tick. A player walks at about 0.22, sprints at about 0.28; sneaking is about 0.07. */
    public static final double STILL_BELOW = 0.025;
    public static final double WALK_BELOW = 0.15;
    public static final double RUN_BELOW = 0.26;

    private AnimLogic() {
    }

    public static String locomotion(double speed, boolean carrying, boolean airborne) {
        if (airborne) {
            return carrying ? "dribble_jump" : "jump";
        } else if (speed < STILL_BELOW) {
            return carrying ? "idle_ball" : "idle";
        } else if (speed < WALK_BELOW) {
            return carrying ? "dribble_walk" : "walk";
        } else if (speed < RUN_BELOW) {
            return carrying ? "dribble_run" : "run";
        } else {
            return carrying ? "dribble_sprint" : "sprint";
        }
    }

    /** Bots are faster than players: a jog is a "run", only a real sprint shows the sprint animation. */
    public static final double BOT_RUN_BELOW = 0.44;

    public static String botLocomotion(double speed, boolean carrying, boolean airborne) {
        if (airborne || speed < RUN_BELOW) {
            return locomotion(speed, carrying, airborne);
        }
        if (speed < BOT_RUN_BELOW) {
            return carrying ? "dribble_run" : "run";
        }
        return carrying ? "dribble_sprint" : "sprint";
    }

    /** Players use the same locomotion set as bots: idle, walk, run and sprint with or without the ball. */
    public static String playerLocomotion(double speed, boolean carrying, boolean airborne) {
        return locomotion(speed, carrying, airborne);
    }

    /** The animation a skill plays, or null when it has none. */
    public static String forSkill(String skillId, int sideSign) {
        if (skillId == null) {
            return null;
        }
        return switch (skillId) {
            case "feint" -> sideSign >= 0 ? "feint_right" : "feint_left";
            case "burst_dribble" -> "burst";
            case "chain_dribble" -> "chain_spin";
            case "sprint_burst" -> "sprint_burst";
            case "shoulder_charge" -> "shoulder";
            case "direct_shot", "precision_direct_shot" -> "direct_shot";
            case "awakening_direct_shot" -> "awakening_shot";
            case "through_pass" -> "through_pass";
            case "passing_lane_read", "spatial_read" -> "read_scan";
            case "advanced_field_vision" -> "vision_open";
            case "interception_read" -> "intercept_step";
            case "shadow_marking" -> "shadow_step";
            case "composure_focus" -> "focus_breath";
            default -> null;
        };
    }

    /** How long (ticks) a one-shot animation locks out the locomotion animation. 0 for looping or unknown names. */
    public static int durationTicks(String name) {
        if (name == null) {
            return 0;
        }
        return switch (name) {
            case "kick_pass" -> 10;
            case "kick_shot" -> 12;
            case "tackle_stand" -> 10;
            case "slide" -> 18;
            case "feint_left", "feint_right" -> 9;
            case "burst" -> 10;
            case "chain_spin" -> 14;
            case "sprint_burst" -> 12;
            case "shoulder" -> 11;
            case "celebrate" -> 28;
            case "dribble_jump" -> 14;
            case "direct_shot" -> 12;
            case "awakening_shot" -> 22;
            case "through_pass" -> 11;
            case "read_scan" -> 24;
            case "vision_open" -> 32;
            case "intercept_step" -> 14;
            case "shadow_step" -> 14;
            case "focus_breath" -> 30;
            case "dive" -> 20;
            case "dive_left", "dive_right" -> 18;
            default -> 0;
        };
    }
}
