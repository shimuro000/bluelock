package com.bluelock.common.ai;

import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.content.Position;
import java.util.List;

/**
 * A named Blue Lock footballer that a bot can play as: position, rating bonus, play style, hair, shirt name and
 * number, height and the skills he plays with (ids from data/bluelock/definitions/skills; the real techniques are
 * bound to the characters in the skills phase). Squads, looks and heights are first versions.
 */
public record FootballCharacter(String id, String name, String shirtName, String teamId, Position position,
                                int ratingBonus, CharacterTraits traits, HairDesign hair, int jersey,
                                int heightCm, List<String> skills) {

    public String displayName() {
        return name;
    }

    /** Model size: 1.0 is 178 cm; kept within a small range so nobody looks like a giant or a child. */
    public double heightScale() {
        return Math.max(0.92, Math.min(1.10, heightCm / 178.0));
    }
}
