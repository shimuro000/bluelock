package com.bluelock.common.ai;

import java.util.List;

/**
 * How a bot's skills change what it does (no Minecraft code). Skill ids are the ones in
 * data/bluelock/definitions/skills. Skills the bot does not own change nothing.
 */
public final class BotSkillRules {
    public static final int DRIBBLE_SKILL_COOLDOWN = 140;

    /** Shot changes: spreadMul below 1 is more accurate, powerMul above 1 is harder. anim may be null. */
    public record ShotBoost(double spreadMul, double powerMul, String anim) {
    }

    private BotSkillRules() {
    }

    public static ShotBoost shot(List<String> skills) {
        double spread = 1.0;
        double power = 1.0;
        String anim = null;
        if (skills.contains("awakening_direct_shot")) {
            spread = 0.5; power = 1.45; anim = "awakening_shot";
        } else if (skills.contains("precision_direct_shot")) {
            spread = 0.3; power = 1.1; anim = "direct_shot";
        } else if (skills.contains("direct_shot")) {
            spread = 0.75; power = 1.2; anim = "direct_shot";
        }
        if (skills.contains("finishing")) spread *= 0.85;
        return new ShotBoost(spread, power, anim);
    }

    /** The dribble skill to use now, or null. Under pressure: feints. With open space: bursts. */
    public static String dribbleSkill(List<String> skills, boolean pressured, boolean openSpace) {
        if (pressured) {
            if (skills.contains("chain_dribble")) return "chain_dribble";
            if (skills.contains("feint")) return "feint";
        }
        if (openSpace) {
            if (skills.contains("burst_dribble")) return "burst_dribble";
            if (skills.contains("sprint_burst")) return "sprint_burst";
        }
        return null;
    }

    /** How far ahead of a running team-mate a pass is aimed: 1.0 normal, longer with Through Pass. */
    public static double passLead(List<String> skills) {
        return skills.contains("through_pass") ? 1.6 : 1.0;
    }

    public static boolean hasShoulderCharge(List<String> skills) {
        return skills.contains("shoulder_charge");
    }
}
