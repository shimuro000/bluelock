package com.bluelock.forge;

import com.bluelock.common.appearance.KitDesign;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;

/** Draws a kit on a humanoid model's parts (shared by the player and the plain bot layer). */
final class KitLayerHelper {
    private KitLayerHelper() {
    }

    static void draw(PoseStack ps, MultiBufferSource buffer, KitDesign kit, int light,
                     ModelPart body, ModelPart rightArm, ModelPart leftArm, ModelPart rightLeg, ModelPart leftLeg) {
        part(ps, buffer, kit, light, body, KitDraw.Part.BODY);
        part(ps, buffer, kit, light, rightArm, KitDraw.Part.RIGHT_ARM);
        part(ps, buffer, kit, light, leftArm, KitDraw.Part.LEFT_ARM);
        part(ps, buffer, kit, light, rightLeg, KitDraw.Part.RIGHT_LEG);
        part(ps, buffer, kit, light, leftLeg, KitDraw.Part.LEFT_LEG);
        ps.pushPose();
        body.translateAndRotate(ps);
        ps.scale(1.0F / 16.0F, 1.0F / 16.0F, 1.0F / 16.0F);
        KitDraw.backText(ps, buffer, kit, true, light);
        ps.popPose();
    }

    private static void part(PoseStack ps, MultiBufferSource buffer, KitDesign kit, int light, ModelPart part, KitDraw.Part which) {
        ps.pushPose();
        part.translateAndRotate(ps);
        ps.scale(1.0F / 16.0F, 1.0F / 16.0F, 1.0F / 16.0F);
        KitDraw.part(ps, buffer, kit, which, true, light);
        ps.popPose();
    }
}
