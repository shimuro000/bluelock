package com.bluelock.common.ai;

import com.bluelock.common.appearance.BodyDesign;
import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.content.Position;
import java.util.ArrayList;
import java.util.List;

/**
 * The Blue Lock characters bots can play as, grouped by team (team_v, team_w, team_x, team_y, team_z).
 * Pure data and a small assignment rule, so it can be tested without Minecraft.
 */
public final class Roster {
    private static final List<FootballCharacter> ALL = new ArrayList<>();

    private static final java.util.Map<String, int[]> BODY_TABLE = new java.util.HashMap<>();
    static {
        BODY_TABLE.put("isagi", new int[] {1, 0x2F9FCF, 1, 1, 0, 45});
        BODY_TABLE.put("bachira", new int[] {1, 0xD9B45A, 5, 0, 1, 40});
        BODY_TABLE.put("kunigami", new int[] {2, 0x4A2E1A, 1, 3, 0, 70});
        BODY_TABLE.put("chigiri", new int[] {0, 0xB3261E, 0, 0, 0, 35});
        BODY_TABLE.put("raichi", new int[] {2, 0x1B1B1F, 4, 2, 3, 65});
        BODY_TABLE.put("gagamaru", new int[] {3, 0x4A2E1A, 2, 3, 1, 90});
        BODY_TABLE.put("kuon", new int[] {1, 0x1B1B1F, 0, 1, 0, 50});
        BODY_TABLE.put("igarashi", new int[] {3, 0x4A2E1A, 1, 3, 0, 85});
        BODY_TABLE.put("baro", new int[] {2, 0xF28C28, 4, 2, 2, 70});
        BODY_TABLE.put("nagi", new int[] {0, 0x7B3FBF, 3, 0, 0, 40});
        BODY_TABLE.put("reo", new int[] {0, 0x7B3FBF, 0, 1, 1, 50});
        BODY_TABLE.put("hiori", new int[] {1, 0x4A2E1A, 0, 1, 0, 50});
        BODY_TABLE.put("aryu", new int[] {1, 0x2F6BFF, 1, 1, 2, 55});
        BODY_TABLE.put("nanase", new int[] {1, 0xF28C28, 2, 0, 1, 45});
        BODY_TABLE.put("rin", new int[] {0, 0x1FA89A, 1, 2, 0, 55});
        BODY_TABLE.put("shidou", new int[] {2, 0xB3261E, 4, 2, 2, 60});
        BODY_TABLE.put("kaiser", new int[] {0, 0x2F6BFF, 1, 1, 2, 60});
        BODY_TABLE.put("sae", new int[] {0, 0x1FA89A, 3, 1, 0, 55});
        BODY_TABLE.put("noa", new int[] {1, 0x8A8F98, 1, 3, 0, 70});
        BODY_TABLE.put("otoya", new int[] {1, 0x34B34A, 2, 0, 1, 45});
        BODY_TABLE.put("tokimitsu", new int[] {1, 0x4A2E1A, 0, 1, 0, 50});
        BODY_TABLE.put("aiku", new int[] {1, 0x2F6BFF, 0, 1, 1, 55});
        BODY_TABLE.put("ikki", new int[] {3, 0x8A8F98, 1, 3, 0, 80});
        BODY_TABLE.put("zantetsu", new int[] {2, 0x1B1B1F, 1, 2, 0, 65});
    }

    private static BodyDesign bodyFor(String id, int cm) {
        int[] b = BODY_TABLE.getOrDefault(id, new int[] {1, 0x4A2E1A, 0, 1, 0, 50});
        return BodyDesign.forHeightCm(cm, BodyDesign.SKIN_TONES[b[0]], b[1], b[2], b[3], b[4], 0, b[5]);
    }

    private static CharacterTraits t(double speed, double boost, double secs, int ego, int cre, int agg, int work) {
        return new CharacterTraits(speed, boost, secs, ego, cre, agg, work);
    }

    /** A hair design from a preset: style, colour, tip colour and amount, seed, optional sliders (top, front, sides, back, spikes, fluff, tail). */
    private static HairDesign hair(int style, int color, int tip, int tipAmount, int seed, int[] s) {
        HairDesign d = HairDesign.preset(style, color);
        if (s != null) d = d.withSliders(s[0], s[1], s[2], s[3], s[4], s[5], s[6]);
        return d.withColors(color, tip, tipAmount).withSeed(seed);
    }

    private static void add(String id, String name, String shirt, String team, Position pos, int bonus, CharacterTraits tr,
                            int jersey, int cm, List<String> skills, HairDesign hair) {
        ALL.add(new FootballCharacter(id, name, shirt, team, pos, bonus, tr, hair, bodyFor(id, cm), jersey, cm, skills));
    }

    static {
        add("isagi", "Yoichi Isagi", "ISAGI", "team_z", Position.CAM, 6, t(1.00, 1.38, 12, 55, 70, 50, 85), 11, 175, List.of("spatial_read", "advanced_field_vision", "direct_shot", "passing_lane_read", "awareness"), hair(6, 0x1B1B1F, 0x1F2D6B, 35, 11, null));
        add("bachira", "Meguru Bachira", "BACHIRA", "team_z", Position.LW, 8, t(1.06, 1.40, 10, 55, 100, 35, 55), 8, 175, List.of("feint", "chain_dribble", "burst_dribble", "control", "monster_dribble"), hair(3, 0x2B2118, 0xD9B45A, 40, 21, new int[] {70, 40, 40, 45, 20, 60, 0}));
        add("kunigami", "Rensuke Kunigami", "KUNIGAMI", "team_z", Position.ST, 6, t(1.03, 1.38, 12, 50, 35, 70, 70), 9, 187, List.of("shoulder_charge", "direct_shot", "pressure_finisher"), hair(2, 0x1B1B1F, 0x1B1B1F, 0, 31, null));
        add("chigiri", "Hyoma Chigiri", "CHIGIRI", "team_z", Position.RW, 8, t(1.25, 1.55, 8, 40, 45, 35, 65), 7, 178, List.of("sprint_burst", "burst_dribble"), hair(8, 0xB3261E, 0xE86AA6, 35, 41, null));
        add("raichi", "Jingo Raichi", "RAICHI", "team_z", Position.CF, 3, t(1.00, 1.36, 9, 80, 30, 60, 50), 99, 181, List.of("direct_shot", "finishing", "pressure_finisher"), hair(2, 0x1B1B1F, 0xB3261E, 25, 51, null));
        add("gagamaru", "Gin Gagamaru", "GAGAMARU", "team_z", Position.GK, 5, t(0.97, 1.28, 8, 25, 15, 45, 40), 1, 198, List.of("composure_focus", "awareness"), hair(1, 0x3B2A1E, 0x3B2A1E, 0, 61, null));
        add("kuon", "Wataru Kuon", "KUON", "team_z", Position.CDM, 3, t(1.00, 1.34, 14, 30, 35, 60, 80), 6, 181, List.of("interception_read", "shadow_marking"), hair(4, 0xF0E8C8, 0xD9B45A, 30, 71, null));
        add("igarashi", "Gurimu Igarashi", "IGARASHI", "team_z", Position.CB, 2, t(0.98, 1.32, 12, 25, 25, 75, 70), 4, 185, List.of("shoulder_charge", "interception_read"), hair(0, 0x3B2A1E, 0x3B2A1E, 0, 81, null));
        add("baro", "Shoei Baro", "BARO", "team_v", Position.ST, 9, t(1.10, 1.45, 11, 100, 40, 85, 65), 9, 185, List.of("precision_direct_shot", "finishing", "shoulder_charge"), hair(2, 0x1B1B1F, 0x8A8F98, 30, 91, new int[] {75, 45, 30, 40, 90, 40, 0}));
        add("nagi", "Seishiro Nagi", "NAGI", "team_v", Position.CF, 9, t(1.02, 1.38, 8, 60, 90, 20, 25), 19, 190, List.of("control", "direct_shot", "finishing", "trap"), hair(5, 0xF4F4F4, 0xC9CED6, 40, 101, null));
        add("reo", "Reo Mikage", "REO", "team_v", Position.RW, 8, t(1.02, 1.38, 11, 55, 75, 45, 75), 14, 178, List.of("through_pass", "passing_lane_read", "feint", "chameleon"), hair(6, 0x7B3FBF, 0xE86AA6, 25, 111, null));
        add("hiori", "Yo Hiori", "HIORI", "team_v", Position.CM, 6, t(1.00, 1.36, 12, 35, 55, 50, 85), 8, 176, List.of("passing_lane_read", "spatial_read"), hair(1, 0x1B1B1F, 0x1B1B1F, 0, 121, null));
        add("aryu", "Jyubei Aryu", "ARYU", "team_v", Position.CAM, 6, t(1.02, 1.38, 11, 70, 60, 50, 70), 10, 183, List.of("through_pass", "awareness"), hair(6, 0x5E3BE0, 0x2F6BFF, 30, 131, null));
        add("nanase", "Nijiro Nanase", "NANASE", "team_v", Position.LW, 5, t(1.03, 1.40, 10, 50, 60, 40, 65), 11, 176, List.of("burst_dribble", "sprint_burst"), hair(3, 0xD9B45A, 0xF28C28, 30, 141, null));
        add("rin", "Rin Itoshi", "RIN", "team_w", Position.CM, 11, t(1.05, 1.42, 13, 85, 85, 65, 75), 10, 182, List.of("direct_shot", "advanced_field_vision", "through_pass", "awakening_direct_shot", "chain_dribble", "curved_shot"), hair(6, 0x1F3B4D, 0x1FA89A, 30, 151, null));
        add("shidou", "Ryusei Shidou", "SHIDOU", "team_w", Position.ST, 10, t(1.10, 1.45, 10, 80, 100, 55, 60), 13, 188, List.of("burst_dribble", "feint", "awakening_direct_shot", "sprint_burst", "dragon_drive"), hair(9, 0xB3261E, 0xF28C28, 35, 161, null));
        add("kaiser", "Michael Kaiser", "KAISER", "team_w", Position.CF, 12, t(1.04, 1.40, 10, 95, 75, 50, 55), 9, 187, List.of("precision_direct_shot", "advanced_field_vision", "chain_dribble", "finishing", "curved_shot"), hair(7, 0xD9B45A, 0x2F6BFF, 40, 171, null));
        add("sae", "Sae Itoshi", "SAE", "team_w", Position.CAM, 14, t(1.06, 1.42, 12, 75, 90, 55, 80), 10, 185, List.of("through_pass", "advanced_field_vision", "precision_direct_shot", "composure_focus", "perfect_pass"), hair(6, 0x1F3B4D, 0x1F3B4D, 0, 181, null));
        add("noa", "Noel Noa", "NOA", "team_w", Position.CM, 14, t(1.06, 1.42, 15, 55, 80, 70, 95), 10, 187, List.of("awareness", "spatial_read", "control", "interception_read", "direct_shot", "trap", "perfect_pass"), hair(6, 0xC9CED6, 0xF4F4F4, 30, 191, null));
        add("otoya", "Eita Otoya", "OTOYA", "team_x", Position.LM, 4, t(1.05, 1.40, 14, 40, 55, 50, 85), 11, 177, List.of("sprint_burst", "burst_dribble"), hair(3, 0x1FA89A, 0x34B34A, 30, 201, null));
        add("tokimitsu", "Aoshi Tokimitsu", "TOKIMITSU", "team_x", Position.CM, 4, t(1.00, 1.36, 13, 30, 50, 40, 85), 8, 175, List.of("passing_lane_read", "spatial_read"), hair(1, 0x1B1B1F, 0x1B1B1F, 0, 211, null));
        add("aiku", "Oliver Aiku", "AIKU", "team_x", Position.RB, 5, t(1.00, 1.36, 13, 30, 40, 65, 80), 2, 181, List.of("shadow_marking", "interception_read"), hair(1, 0x2F6BFF, 0x2F6BFF, 0, 221, null));
        add("ikki", "Niko Ikki", "IKKI", "team_y", Position.CB, 8, t(1.00, 1.36, 13, 35, 45, 85, 75), 5, 185, List.of("shoulder_charge", "shadow_marking"), hair(2, 0x8A8F98, 0x1B1B1F, 30, 231, null));
        add("zantetsu", "Zantetsu Tsurugi", "TSURUGI", "team_y", Position.LB, 3, t(1.00, 1.34, 12, 25, 30, 75, 70), 3, 181, List.of("shoulder_charge", "interception_read"), hair(0, 0x1B1B1F, 0x1B1B1F, 0, 241, null));
    }

    private Roster() {
    }

    public static List<FootballCharacter> all() {
        return List.copyOf(ALL);
    }

    public static List<FootballCharacter> ofTeam(String teamId) {
        List<FootballCharacter> out = new ArrayList<>();
        for (FootballCharacter c : ALL) {
            if (c.teamId().equals(teamId)) out.add(c);
        }
        return out;
    }

    public static FootballCharacter byId(String id) {
        for (FootballCharacter c : ALL) {
            if (c.id().equals(id)) return c;
        }
        return null;
    }

    /**
     * Picks the character for one slot of a team. Characters are used at most once ({@code taken} holds the ids
     * already given out). A character who plays exactly this position goes first, then one in the same line
     * (goal, defence, midfield, attack). Returns null when the team has nobody fitting: the bot is then a nameless
     * player with traits from its position.
     */
    public static FootballCharacter assign(String teamId, Position slotPosition, java.util.Set<String> taken) {
        List<FootballCharacter> team = ofTeam(teamId);
        for (FootballCharacter c : team) {
            if (!taken.contains(c.id()) && c.position() == slotPosition) return c;
        }
        for (FootballCharacter c : team) {
            if (!taken.contains(c.id()) && line(c.position()) == line(slotPosition)) return c;
        }
        return null;
    }

    /** Look codes are synced to clients as one number: 0 or more = index in the roster, negative = a nameless bot. */
    public static int lookOf(FootballCharacter c, int fallbackSeed) {
        if (c == null) return -1 - Math.abs(fallbackSeed % 100000);
        return ALL.indexOf(c);
    }

    public static FootballCharacter byLook(int look) {
        return look >= 0 && look < ALL.size() ? ALL.get(look) : null;
    }

    /** The hair of a look: the character's own, or a made-up one from the seed (the same on every client). */
    public static HairDesign hairForLook(int look) {
        FootballCharacter c = byLook(look);
        if (c != null) return c.hair();
        return HairDesign.random(new java.util.Random(look * 7919L + 13));
    }

    /** The body of a look: the character's own, or a made-up one from the seed (the same on every client). */
    public static BodyDesign bodyForLook(int look) {
        FootballCharacter c = byLook(look);
        if (c != null) return c.body();
        return BodyDesign.random(new java.util.Random(look * 104729L + 7));
    }

    private static int line(Position p) {
        return switch (p) {
            case GK -> 0;
            case CB, LB, RB, LWB, RWB, CDM -> 1;
            case CM, CAM, LM, RM -> 2;
            case LW, RW, ST, CF -> 3;
        };
    }
}
