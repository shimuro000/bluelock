package com.bluelock.common.ai;

/**
 * What a bot wants to do. speed is 0..1 of its top speed. passIndex is the pass target in BotView.mates (or -1);
 * for Intent.DIVE it is the dive direction instead (-1 or +1 across the pitch, 0 = just stand and reach).
 */
public record BotDecision(Intent intent, Pos target, double speed, int passIndex) {
    static BotDecision of(Intent intent, Pos target, double speed) {
        return new BotDecision(intent, target, speed, -1);
    }
}
