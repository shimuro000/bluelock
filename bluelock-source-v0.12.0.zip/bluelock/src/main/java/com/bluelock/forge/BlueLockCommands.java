package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import com.bluelock.common.content.DefinitionPack;
import com.bluelock.common.ai.BotDifficulty;
import com.bluelock.common.content.Position;
import com.bluelock.common.content.QuestDefinition;
import com.bluelock.common.profile.Archetype;
import com.bluelock.common.profile.CharacterRoll;
import com.bluelock.common.profile.CharacterCreator;
import com.bluelock.common.profile.DominantFoot;
import com.bluelock.common.profile.Personality;
import com.bluelock.common.content.SkillDefinition;
import com.bluelock.common.match.MatchSession;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.progression.Quests;
import com.bluelock.common.progression.SkillRules;
import com.bluelock.common.stats.DefaultGrowthCurve;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.team.MatchMode;
import com.bluelock.common.team.TeamSetup;
import java.util.UUID;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.pitch.PitchPlacement;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.stats.OverallRating;
import com.bluelock.common.stats.RoleWeights;
import com.bluelock.common.stats.StatModifiers;
import com.bluelock.common.util.Result;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Temporary command-line version of the career flow, until the menus arrive (Phase 18).
 * Everything runs on the server; nothing the client says is trusted beyond the typed choices.
 */
public final class BlueLockCommands {
    private static final SuggestionProvider<CommandSourceStack> ARCHETYPE_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(names(Archetype.values()), builder);
    private static final SuggestionProvider<CommandSourceStack> PERSONALITY_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(names(Personality.values()), builder);
    private static final SuggestionProvider<CommandSourceStack> POSITION_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(names(Position.values()), builder);

    private static final SuggestionProvider<CommandSourceStack> SIDE_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(names(Side.values()), builder);

    private static final SuggestionProvider<CommandSourceStack> TEAM_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(BlueLockData.get().teams().asMap().keySet(), builder);
    private static final SuggestionProvider<CommandSourceStack> FORMATION_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(BlueLockData.get().formations().asMap().keySet(), builder);
    private static final SuggestionProvider<CommandSourceStack> MODE_SUGGESTIONS =
            (ctx, builder) -> {
                List<String> labels = new ArrayList<>();
                for (MatchMode m : MatchMode.values()) {
                    labels.add(m.label());
                }
                return SharedSuggestionProvider.suggest(labels, builder);
            };

    private static final SuggestionProvider<CommandSourceStack> SKILL_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(BlueLockData.get().skills().asMap().keySet(), builder);
    private static final SuggestionProvider<CommandSourceStack> STAT_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(names(Stat.values()), builder);
    private static final SuggestionProvider<CommandSourceStack> ON_OFF_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(List.of("on", "off"), builder);
    private static final SuggestionProvider<CommandSourceStack> DIFFICULTY_SUGGESTIONS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(List.of("easy", "normal", "hard", "pro"), builder);

    private BlueLockCommands() {
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal(BlueLockConstants.MOD_ID)
                .executes(BlueLockCommands::hello)
                .then(Commands.literal("data").executes(BlueLockCommands::data))
                .then(Commands.literal("create")
                        .then(Commands.argument("archetype", StringArgumentType.word()).suggests(ARCHETYPE_SUGGESTIONS)
                                .then(Commands.argument("personality", StringArgumentType.word()).suggests(PERSONALITY_SUGGESTIONS)
                                        .then(Commands.argument("position", StringArgumentType.word()).suggests(POSITION_SUGGESTIONS)
                                                .then(Commands.argument("name", StringArgumentType.greedyString())
                                                        .executes(BlueLockCommands::create))))))
                .then(Commands.literal("ball").executes(BlueLockCommands::ball))
                .then(Commands.literal("pitch")
                        .requires(BlueLockCommands::canManage)
                        .executes(BlueLockCommands::pitch))
                .then(Commands.literal("match")
                        .then(Commands.literal("start")
                                .requires(BlueLockCommands::canManage)
                                .executes(ctx -> startMatch(ctx, 3))
                                .then(Commands.argument("minutes", IntegerArgumentType.integer(1, 30))
                                        .executes(ctx -> startMatch(ctx, IntegerArgumentType.getInteger(ctx, "minutes")))))
                        .then(Commands.literal("stop").requires(BlueLockCommands::canManage).executes(BlueLockCommands::stopMatch))
                        .then(Commands.literal("join")
                                .then(Commands.argument("side", StringArgumentType.word()).suggests(SIDE_SUGGESTIONS)
                                        .executes(BlueLockCommands::joinMatch)))
                        .then(Commands.literal("mode")
                                .requires(BlueLockCommands::canManage)
                                .then(Commands.argument("mode", StringArgumentType.word()).suggests(MODE_SUGGESTIONS)
                                        .executes(BlueLockCommands::matchMode)))
                        .then(Commands.literal("bots")
                                .requires(BlueLockCommands::canManage)
                                .then(Commands.argument("state", StringArgumentType.word()).suggests(ON_OFF_SUGGESTIONS)
                                        .executes(BlueLockCommands::matchBots)))
                        .then(Commands.literal("difficulty")
                                .requires(BlueLockCommands::canManage)
                                .then(Commands.argument("level", StringArgumentType.word()).suggests(DIFFICULTY_SUGGESTIONS)
                                        .executes(BlueLockCommands::matchDifficulty)))
                        .then(Commands.literal("status").executes(BlueLockCommands::matchStatus)))
                .then(Commands.literal("skills")
                        .executes(BlueLockCommands::skillsList)
                        .then(Commands.literal("unlock")
                                .then(Commands.argument("skill", StringArgumentType.word()).suggests(SKILL_SUGGESTIONS)
                                        .executes(BlueLockCommands::skillUnlock))))
                .then(Commands.literal("quests").executes(BlueLockCommands::quests))
                .then(Commands.literal("cheat")
                        .requires(BlueLockCommands::canManage)
                        .then(Commands.literal("skillpoints").then(Commands.argument("amount", IntegerArgumentType.integer(1, 1_000_000))
                                .executes(ctx -> cheat(ctx, "skillpoints"))))
                        .then(Commands.literal("devpoints").then(Commands.argument("amount", IntegerArgumentType.integer(1, 1_000_000))
                                .executes(ctx -> cheat(ctx, "devpoints"))))
                        .then(Commands.literal("xp").then(Commands.argument("amount", IntegerArgumentType.integer(1, 1_000_000))
                                .executes(ctx -> cheat(ctx, "xp"))))
                        .then(Commands.literal("unlockall").executes(ctx -> cheat(ctx, "unlockall")))
                        .then(Commands.literal("refill").executes(ctx -> cheat(ctx, "refill"))))
                .then(Commands.literal("train")
                        .then(Commands.argument("stat", StringArgumentType.word()).suggests(STAT_SUGGESTIONS)
                                .executes(ctx -> train(ctx, Integer.MAX_VALUE))
                                .then(Commands.literal("up").executes(BlueLockCommands::trainUp))
                                .then(Commands.argument("points", IntegerArgumentType.integer(1, 100))
                                        .executes(ctx -> train(ctx, IntegerArgumentType.getInteger(ctx, "points"))))))
                .then(Commands.literal("team")
                        .then(Commands.literal("set").requires(BlueLockCommands::canManage)
                                .then(Commands.argument("side", StringArgumentType.word()).suggests(SIDE_SUGGESTIONS)
                                        .then(Commands.argument("team", StringArgumentType.word()).suggests(TEAM_SUGGESTIONS)
                                                .executes(BlueLockCommands::teamSet))))
                        .then(Commands.literal("formation").requires(BlueLockCommands::canManage)
                                .then(Commands.argument("side", StringArgumentType.word()).suggests(SIDE_SUGGESTIONS)
                                        .then(Commands.argument("formation", StringArgumentType.word()).suggests(FORMATION_SUGGESTIONS)
                                                .executes(BlueLockCommands::teamFormation))))
                        .then(Commands.literal("slot")
                                .then(Commands.argument("number", IntegerArgumentType.integer(1, 11))
                                        .executes(BlueLockCommands::teamSlot)))
                        .then(Commands.literal("show")
                                .then(Commands.argument("side", StringArgumentType.word()).suggests(SIDE_SUGGESTIONS)
                                        .executes(BlueLockCommands::teamShow))))
                .then(Commands.literal("profile").executes(BlueLockCommands::profile))
                .then(Commands.literal("reset")
                        .executes(ctx -> {
                            ctx.getSource().sendFailure(Component.translatable("bluelock.profile.reset_hint"));
                            return 0;
                        })
                        .then(Commands.literal("confirm").executes(BlueLockCommands::reset))));
    }

    private static int hello(CommandContext<CommandSourceStack> ctx) {
        ctx.getSource().sendSuccess(() -> Component.translatable("bluelock.command.hello", BlueLockConstants.MOD_NAME, BlueLockConstants.VERSION,
                AnimationBridge.botAnimationsAvailable() ? "ON" : "OFF", AnimationBridge.playerAnimationsAvailable() ? "ON" : "OFF"), false);
        return 1;
    }

    private static int data(CommandContext<CommandSourceStack> ctx) {
        DefinitionPack pack = BlueLockData.get();
        ctx.getSource().sendSuccess(() -> Component.translatable("bluelock.command.data",
                pack.skills().size(), pack.formations().size(), pack.teams().size(), pack.problems().size()), false);
        return 1;
    }

    private static int create(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        ProfileSavedData store = ProfileSavedData.get(source.getServer());

        if (store.load(player.getUUID()).isPresent()) {
            source.sendFailure(Component.translatable("bluelock.error.profile_exists"));
            return 0;
        }

        String archetypeText = StringArgumentType.getString(ctx, "archetype");
        String personalityText = StringArgumentType.getString(ctx, "personality");
        String positionText = StringArgumentType.getString(ctx, "position");
        Archetype archetype = parse(Archetype.class, archetypeText);
        Personality personality = parse(Personality.class, personalityText);
        Position position = parse(Position.class, positionText);
        if (archetype == null || personality == null || position == null) {
            String bad = archetype == null ? archetypeText : personality == null ? personalityText : positionText;
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", bad));
            return 0;
        }

        // the two dice: dominant foot (60% right, 30% left, 10% both) and talent (25% genius)
        CharacterRoll.Result roll = CreationRolls.get(player.getUUID());
        String name = StringArgumentType.getString(ctx, "name");
        Result<PlayerProfile> result = CharacterCreator.create(BlueLockData.get(), player.getUUID(), name, "", roll.foot(),
                archetype, personality, roll.talent(), position, 1, 0x3B2A1E);
        if (!result.isOk()) {
            source.sendFailure(Component.translatable(result.errorKey().orElse("bluelock.error.content_missing")));
            return 0;
        }

        PlayerProfile profile = result.value();
        SkillRules.autoUnlockRoots(profile, BlueLockData.get());
        store.save(profile);
        CreationRolls.clear(player.getUUID());
        source.sendSuccess(() -> Component.translatable("bluelock.profile.created_roll", profile.name(),
                Component.translatable("bluelock.archetype." + archetype.name().toLowerCase(Locale.ROOT)),
                Component.translatable("bluelock.foot." + roll.foot().name().toLowerCase(Locale.ROOT)),
                Component.translatable(roll.talent().langKey())), false);
        return 1;
    }

    private static int ball(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        Vec3 look = player.getLookAngle();
        BallEntity.spawn(source.getLevel(), player.getX() + look.x * 1.5, player.getY() + 0.3, player.getZ() + look.z * 1.5);
        source.sendSuccess(() -> Component.translatable("bluelock.ball.spawned"), false);
        return 1;
    }

    private static int pitch(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        PitchLayout layout = PitchLayout.standard();
        BlockPos centre = player.blockPosition();
        PitchPlacement placement = PitchBuilder.build(source.getLevel(), centre, player.getDirection(), layout);
        MatchManager.setPitch(source.getLevel(), placement);
        BallEntity.spawn(source.getLevel(), centre.getX() + 2.5, centre.getY() + 0.3, centre.getZ() + 0.5);
        source.sendSuccess(() -> Component.translatable("bluelock.pitch.built", layout.length(), layout.width()), false);
        return 1;
    }

    private static boolean canManage(CommandSourceStack source) {
        return source.hasPermission(2) || !source.getServer().isDedicatedServer();
    }

    private static int startMatch(CommandContext<CommandSourceStack> ctx, int minutes) {
        CommandSourceStack source = ctx.getSource();
        if (!MatchManager.hasPitch()) {
            source.sendFailure(Component.translatable("bluelock.match.need_pitch"));
            return 0;
        }
        for (Side side : Side.values()) {
            if (MatchManager.setup(side).isEmpty()) {
                source.sendFailure(Component.translatable("bluelock.team.no_formation", MatchManager.mode().size()));
                return 0;
            }
        }
        MatchManager.startMatch(source.getServer(), minutes);
        source.sendSuccess(() -> Component.translatable("bluelock.match.started", minutes,
                MatchManager.goalPosition(Side.HOME), MatchManager.goalPosition(Side.AWAY)), true);
        return 1;
    }

    private static int stopMatch(CommandContext<CommandSourceStack> ctx) {
        MatchManager.stopMatch();
        ctx.getSource().sendSuccess(() -> Component.translatable("bluelock.match.stopped"), true);
        return 1;
    }

    private static int joinMatch(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        String text = StringArgumentType.getString(ctx, "side");
        Side side = parse(Side.class, text);
        if (side == null) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", text));
            return 0;
        }
        Archetype archetype = ProfileSavedData.get(source.getServer()).load(player.getUUID())
                .map(PlayerProfile::archetype).orElse(Archetype.ALL_ROUNDER);
        MatchManager.join(player.getUUID(), side, archetype);
        source.sendSuccess(() -> Component.translatable("bluelock.match.joined", MatchManager.sideName(side)), false);
        return 1;
    }

    private static int matchStatus(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        MatchSession match = MatchManager.session();
        if (match == null) {
            source.sendFailure(Component.translatable("bluelock.match.no_match"));
            return 0;
        }
        Component possession = match.possession() == null
                ? Component.translatable("bluelock.possession.none")
                : MatchManager.sideName(match.possession());
        source.sendSuccess(() -> Component.translatable("bluelock.match.status",
                match.homeGoals(), match.awayGoals(), clock(match.elapsedTicks()), clock(match.durationTicks()), possession), false);
        return 1;
    }

    private static int matchMode(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        String text = StringArgumentType.getString(ctx, "mode");
        Optional<MatchMode> parsed = MatchMode.parse(text);
        if (parsed.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", text));
            return 0;
        }
        MatchManager.setMode(parsed.get());
        source.sendSuccess(() -> Component.translatable("bluelock.match.mode_set", parsed.get().label()), true);
        return 1;
    }

    private static int teamSet(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        Side side = parse(Side.class, StringArgumentType.getString(ctx, "side"));
        String teamId = StringArgumentType.getString(ctx, "team");
        if (side == null || !BlueLockData.get().teams().contains(teamId)) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", side == null ? StringArgumentType.getString(ctx, "side") : teamId));
            return 0;
        }
        MatchManager.setTeam(side, teamId);
        source.sendSuccess(() -> Component.translatable("bluelock.team.set_done", MatchManager.sideName(side), MatchManager.teamName(side)), true);
        return 1;
    }

    private static int teamFormation(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        Side side = parse(Side.class, StringArgumentType.getString(ctx, "side"));
        String formationId = StringArgumentType.getString(ctx, "formation");
        if (side == null) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", StringArgumentType.getString(ctx, "side")));
            return 0;
        }
        String error = MatchManager.setFormation(side, formationId);
        if (error != null) {
            source.sendFailure(Component.translatable(error, formationId));
            return 0;
        }
        source.sendSuccess(() -> Component.translatable("bluelock.team.formation_set", MatchManager.sideName(side),
                Component.translatable("bluelock.formation." + formationId + ".name")), true);
        return 1;
    }

    private static int teamSlot(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        int number = IntegerArgumentType.getInteger(ctx, "number");
        if (MatchManager.sideOf(player.getUUID()) == null) {
            source.sendFailure(Component.translatable("bluelock.team.not_joined"));
            return 0;
        }
        if (!MatchManager.setSlot(player.getUUID(), number - 1)) {
            source.sendFailure(Component.translatable("bluelock.team.bad_slot", MatchManager.mode().size()));
            return 0;
        }
        source.sendSuccess(() -> Component.translatable("bluelock.team.slot_set", number), false);
        return 1;
    }

    private static int teamShow(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        Side side = parse(Side.class, StringArgumentType.getString(ctx, "side"));
        if (side == null) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", StringArgumentType.getString(ctx, "side")));
            return 0;
        }
        Optional<TeamSetup> found = MatchManager.setup(side);
        if (found.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.team.no_formation", MatchManager.mode().size()));
            return 0;
        }
        TeamSetup setup = found.get();
        int rating = MatchManager.rating(source.getServer(), side);
        int chemistry = MatchManager.chemistry(side);
        source.sendSuccess(() -> Component.translatable("bluelock.team.header", MatchManager.sideName(side),
                MatchManager.teamName(side), Component.translatable(setup.formation().nameKey()), rating, chemistry), false);
        for (int i = 0; i < setup.size(); i++) {
            UUID occupant = setup.occupant(i);
            int number = i + 1;
            String position = setup.formation().slots().get(i).position().name();
            Component who = occupant == null
                    ? Component.translatable("bluelock.team.bot")
                    : Component.literal(MatchManager.playerName(source.getServer(), occupant));
            source.sendSuccess(() -> Component.translatable("bluelock.team.slot_line", number, position, who), false);
        }
        return 1;
    }

    private static int matchBots(CommandContext<CommandSourceStack> ctx) {
        String state = StringArgumentType.getString(ctx, "state").toLowerCase(Locale.ROOT);
        if (!state.equals("on") && !state.equals("off")) {
            ctx.getSource().sendFailure(Component.translatable("bluelock.error.unknown_choice", state));
            return 0;
        }
        MatchManager.setBotsEnabled(state.equals("on"));
        ctx.getSource().sendSuccess(() -> Component.translatable("bluelock.match.bots_set", state), true);
        return 1;
    }

    private static int matchDifficulty(CommandContext<CommandSourceStack> ctx) {
        String level = StringArgumentType.getString(ctx, "level");
        Optional<BotDifficulty> parsed = BotDifficulty.parse(level);
        if (parsed.isEmpty()) {
            ctx.getSource().sendFailure(Component.translatable("bluelock.error.unknown_choice", level));
            return 0;
        }
        MatchManager.setDifficulty(parsed.get());
        ctx.getSource().sendSuccess(() -> Component.translatable("bluelock.match.difficulty_set", parsed.get().label()), true);
        return 1;
    }

    private static int skillsList(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        ProfileSavedData store = ProfileSavedData.get(source.getServer());
        Optional<PlayerProfile> found = store.load(player.getUUID());
        if (found.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.error.no_profile"));
            return 0;
        }
        PlayerProfile p = found.get();
        if (!SkillRules.autoUnlockRoots(p, BlueLockData.get()).isEmpty()) {
            store.save(p);
        }
        source.sendSuccess(() -> Component.translatable("bluelock.skills.header", p.skillPoints()), false);
        source.sendSuccess(() -> Component.translatable("bluelock.skills.keys"), false);
        for (SkillDefinition skill : BlueLockData.get().skills().values()) {
            Component status;
            if (p.isUnlocked(skill.id())) {
                status = Component.translatable("bluelock.skills.status.unlocked");
            } else {
                String error = SkillRules.check(p, skill);
                status = error == null
                        ? Component.translatable("bluelock.skills.status.ready", skill.id())
                        : Component.translatable("bluelock.skills.status.locked", Component.translatable(error));
            }
            Component name = Component.translatable(skill.nameKey());
            Component shownStatus = status;
            source.sendSuccess(() -> Component.translatable("bluelock.skills.line", name, shownStatus), false);
        }
        return 1;
    }

    private static int skillUnlock(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        ProfileSavedData store = ProfileSavedData.get(source.getServer());
        Optional<PlayerProfile> found = store.load(player.getUUID());
        if (found.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.error.no_profile"));
            return 0;
        }
        String id = StringArgumentType.getString(ctx, "skill");
        Optional<SkillDefinition> skill = BlueLockData.get().skills().get(id);
        if (skill.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", id));
            return 0;
        }
        String error = SkillRules.unlock(found.get(), skill.get());
        if (error != null) {
            source.sendFailure(Component.translatable(error));
            return 0;
        }
        store.save(found.get());
        source.sendSuccess(() -> Component.translatable("bluelock.skills.unlocked", Component.translatable(skill.get().nameKey())), false);
        return 1;
    }

    /** TEST ONLY: gives skill points, development points or XP, or unlocks every skill. */
    private static int cheat(CommandContext<CommandSourceStack> ctx, String what) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        ProfileSavedData store = ProfileSavedData.get(source.getServer());
        Optional<PlayerProfile> found = store.load(player.getUUID());
        if (found.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.error.no_profile"));
            return 0;
        }
        PlayerProfile p = found.get();
        Component message;
        switch (what) {
            case "skillpoints" -> {
                int n = IntegerArgumentType.getInteger(ctx, "amount");
                p.addPoints(n, 0);
                message = Component.translatable("bluelock.cheat.skillpoints", n, p.skillPoints());
            }
            case "devpoints" -> {
                int n = IntegerArgumentType.getInteger(ctx, "amount");
                p.addPoints(0, n);
                message = Component.translatable("bluelock.cheat.devpoints", n, p.developmentPoints());
            }
            case "xp" -> {
                int n = IntegerArgumentType.getInteger(ctx, "amount");
                Progression.LevelUp up = Progression.award(p, n);
                message = Component.translatable("bluelock.cheat.xp", n, p.level());
            }
            case "refill" -> {
                PlayerState st = PlayerStates.get(player);
                st.stamina.fill();
                st.ego.fill();
                java.util.Arrays.fill(st.readyAt, 0L);
                java.util.Arrays.fill(st.directReadyAt, 0L);
                st.pressureReadyAt = 0L;
                st.tackleReadyAt = 0L;
                message = Component.translatable("bluelock.cheat.refill");
            }
            default -> {
                for (SkillDefinition skill : BlueLockData.get().skills().values()) {
                    p.unlockSkill(skill.id());
                }
                message = Component.translatable("bluelock.cheat.unlockall", p.unlockedSkills().size());
            }
        }
        store.save(p);
        source.sendSuccess(() -> message, false);
        return 1;
    }

    private static int trainUp(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        ProfileSavedData store = ProfileSavedData.get(source.getServer());
        Optional<PlayerProfile> found = store.load(player.getUUID());
        if (found.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.error.no_profile"));
            return 0;
        }
        String text = StringArgumentType.getString(ctx, "stat");
        Stat stat = parse(Stat.class, text);
        if (stat == null) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", text));
            return 0;
        }
        PlayerProfile p = found.get();
        int spent = p.raiseOneLevel(stat, p.growthCurve());
        if (spent == 0) {
            source.sendFailure(Component.translatable("bluelock.train.none", p.developmentPoints()));
            return 0;
        }
        store.save(p);
        source.sendSuccess(() -> Component.translatable("bluelock.train.done", spent,
                Component.translatable(stat.langKey()), p.stats().permanent(stat)), false);
        return 1;
    }

    private static int quests(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        Optional<PlayerProfile> found = ProfileSavedData.get(source.getServer()).load(player.getUUID());
        if (found.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.error.no_profile"));
            return 0;
        }
        PlayerProfile p = found.get();
        source.sendSuccess(() -> Component.translatable("bluelock.quests.header", Quests.doneCount(p, BlueLockData.get()),
                BlueLockData.get().quests().size()), false);
        for (QuestDefinition quest : BlueLockData.get().quests().values()) {
            Component state = p.isQuestDone(quest.id())
                    ? Component.translatable("bluelock.quests.done")
                    : Component.literal(p.questProgress(quest.id()) + "/" + quest.target());
            source.sendSuccess(() -> Component.translatable("bluelock.quests.line", Component.translatable(quest.nameKey()),
                    Component.translatable(quest.descriptionKey()), state), false);
        }
        return 1;
    }

    private static int train(CommandContext<CommandSourceStack> ctx, int maxPoints) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        ProfileSavedData store = ProfileSavedData.get(source.getServer());
        Optional<PlayerProfile> found = store.load(player.getUUID());
        if (found.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.error.no_profile"));
            return 0;
        }
        String text = StringArgumentType.getString(ctx, "stat");
        Stat stat = parse(Stat.class, text);
        if (stat == null) {
            source.sendFailure(Component.translatable("bluelock.error.unknown_choice", text));
            return 0;
        }
        PlayerProfile p = found.get();
        int spent = p.spendDevelopment(stat, p.growthCurve(), maxPoints);
        if (spent == 0) {
            source.sendFailure(Component.translatable("bluelock.train.none", p.developmentPoints()));
            return 0;
        }
        store.save(p);
        source.sendSuccess(() -> Component.translatable("bluelock.train.done", spent,
                Component.translatable(stat.langKey()), p.stats().permanent(stat)), false);
        return 1;
    }

    private static String clock(int ticks) {
        int seconds = ticks / 20;
        return String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60);
    }

    private static int profile(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        Optional<PlayerProfile> found = ProfileSavedData.get(source.getServer()).load(player.getUUID());
        if (found.isEmpty()) {
            source.sendFailure(Component.translatable("bluelock.error.no_profile"));
            return 0;
        }
        PlayerProfile p = found.get();
        int overall = OverallRating.compute(p.stats(), StatModifiers.NONE, RoleWeights.forArchetype(p.archetype()));
        source.sendSuccess(() -> Component.translatable("bluelock.profile.summary",
                p.name(),
                Component.translatable("bluelock.archetype." + p.archetype().name().toLowerCase(Locale.ROOT)),
                Component.translatable("bluelock.personality." + p.personality().name().toLowerCase(Locale.ROOT)),
                Component.translatable("bluelock.foot." + p.foot().name().toLowerCase(Locale.ROOT)),
                p.level(), overall), false);
        source.sendSuccess(() -> Component.translatable("bluelock.profile.traits",
                Component.translatable(p.talent().langKey()),
                Component.translatable("bluelock.foot." + p.foot().name().toLowerCase(Locale.ROOT)),
                p.preferredPosition().name()), false);
        source.sendSuccess(() -> Component.translatable("bluelock.profile.progress", p.level(), p.xp(),
                Progression.xpToNext(p.level()), p.skillPoints(), p.developmentPoints(), p.goals()), false);
        return 1;
    }

    private static int reset(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer player = source.getPlayerOrException();
        ProfileSavedData.get(source.getServer()).delete(player.getUUID());
        source.sendSuccess(() -> Component.translatable("bluelock.profile.reset_done"), false);
        return 1;
    }

    private static <E extends Enum<E>> E parse(Class<E> type, String text) {
        try {
            return Enum.valueOf(type, text.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static <E extends Enum<E>> List<String> names(E[] values) {
        List<String> out = new ArrayList<>();
        for (E value : values) {
            out.add(value.name().toLowerCase(Locale.ROOT));
        }
        return out;
    }
}
