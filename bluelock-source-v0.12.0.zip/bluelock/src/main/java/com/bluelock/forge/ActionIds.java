package com.bluelock.forge;

/** Every football action a key can trigger. The number is the index used by ClientKeys, the HUD and the network. */
public final class ActionIds {
    public static final int PASS = 0;
    public static final int SHOT = 1;
    public static final int SLIDE = 2;
    public static final int FEINT = 3;
    public static final int BURST = 4;
    public static final int CHAIN = 5;
    public static final int SPRINT = 6;
    public static final int SHOULDER = 7;
    public static final int DIRECT = 8;
    public static final int THROUGH = 9;
    public static final int DIVE = 10;
    public static final int LANE = 11;
    public static final int SPATIAL = 12;
    public static final int VISION = 13;
    public static final int INTERCEPT = 14;
    public static final int SHADOW = 15;
    public static final int COMPOSURE = 16;
    public static final int COUNT = 17;

    /** The skill behind each action (null = a basic action that needs no skill). DIRECT picks its tier at run time. */
    public static final String[] SKILL = new String[COUNT];

    static {
        SKILL[FEINT] = "feint";
        SKILL[BURST] = "burst_dribble";
        SKILL[CHAIN] = "chain_dribble";
        SKILL[SPRINT] = "sprint_burst";
        SKILL[SHOULDER] = "shoulder_charge";
        SKILL[THROUGH] = "through_pass";
        SKILL[LANE] = "passing_lane_read";
        SKILL[SPATIAL] = "spatial_read";
        SKILL[VISION] = "advanced_field_vision";
        SKILL[INTERCEPT] = "interception_read";
        SKILL[SHADOW] = "shadow_marking";
        SKILL[COMPOSURE] = "composure_focus";
    }

    private ActionIds() {
    }
}
