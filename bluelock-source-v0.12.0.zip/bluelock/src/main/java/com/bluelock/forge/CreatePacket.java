package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/** Client to server: create my character. The foot and talent are rolled by the server, never chosen by the client. */
public record CreatePacket(String name, String archetype, String personality, String position) {
    public static void encode(CreatePacket m, FriendlyByteBuf buf) {
        buf.writeUtf(m.name(), 40);
        buf.writeUtf(m.archetype(), 24);
        buf.writeUtf(m.personality(), 24);
        buf.writeUtf(m.position(), 8);
    }

    public static CreatePacket decode(FriendlyByteBuf buf) {
        return new CreatePacket(buf.readUtf(40), buf.readUtf(24), buf.readUtf(24), buf.readUtf(8));
    }

    public static void handle(CreatePacket m, Supplier<NetworkEvent.Context> ctx) {
        MenuPackets.serverSide(ctx, player -> MenuServer.create(player, m.archetype(), m.personality(), m.position(), m.name()));
    }
}
