package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.appearance.HairModel;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Draws the 3D hair on a player's head (client only). The hair is a set of small tapered blocks made by
 * {@link HairModel}; they are drawn on a plain white texture and coloured per corner, so tips can fade into a
 * second colour. The layer follows the head of the player model, so it moves with every animation.
 */
public final class HairRenderLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation WHITE = new ResourceLocation(BlueLockConstants.MOD_ID, "textures/hair/white.png");
    private static final int CACHE_LIMIT = 64;
    private static final Map<HairDesign, List<HairModel.Quad>> CACHE = new HashMap<>();

    public HairRenderLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    /** The hair to draw on this player: the preview for the local player while a screen edits it, else what the server sent. */
    private static HairDesign designFor(AbstractClientPlayer player) {
        Minecraft mc = Minecraft.getInstance();
        boolean local = mc.player != null && player.getUUID().equals(mc.player.getUUID());
        if (local && ClientHair.preview != null) {
            return ClientHair.preview;
        }
        HairDesign design = ClientHair.get(player.getUUID());
        if (design == null && local && ClientMenuState.profile != null) {
            design = ClientMenuState.profile.hair();
        }
        return design;
    }

    private static List<HairModel.Quad> quadsFor(HairDesign design) {
        List<HairModel.Quad> quads = CACHE.get(design);
        if (quads == null) {
            if (CACHE.size() >= CACHE_LIMIT) {
                CACHE.clear();
            }
            quads = HairModel.build(design);
            CACHE.put(design, quads);
        }
        return quads;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (player.isInvisible() || player.isSpectator() || !player.getItemBySlot(EquipmentSlot.HEAD).isEmpty()) {
            return;
        }
        HairDesign design = designFor(player);
        if (design == null) {
            return;
        }
        List<HairModel.Quad> quads = quadsFor(design);
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(WHITE));

        poseStack.pushPose();
        getParentModel().head.translateAndRotate(poseStack);
        poseStack.scale(1.0F / 16.0F, 1.0F / 16.0F, 1.0F / 16.0F);
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        Matrix3f normal = pose.normal();
        for (HairModel.Quad q : quads) {
            for (int i = 0; i < 4; i++) {
                int rgb = HairModel.colorAt(design, q.t[i]);
                int r = Math.min(255, Math.round(((rgb >> 16) & 255) * q.shade));
                int g = Math.min(255, Math.round(((rgb >> 8) & 255) * q.shade));
                int b = Math.min(255, Math.round((rgb & 255) * q.shade));
                consumer.vertex(matrix, q.x[i], q.y[i], q.z[i])
                        .color(r, g, b, 255)
                        .uv(0.5F, 0.5F)
                        .overlayCoords(OverlayTexture.NO_OVERLAY)
                        .uv2(packedLight)
                        .normal(normal, q.nx, q.ny, q.nz)
                        .endVertex();
            }
        }
        poseStack.popPose();
    }
}
