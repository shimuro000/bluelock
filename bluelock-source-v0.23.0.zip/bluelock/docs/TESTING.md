# Testing the mod (Phase 5)

1. Get `bluelock-0.12.0.jar` (see BUILDING.md, "Getting the .jar without installing anything").
2. Install Minecraft Java 1.20.1 and Forge 47.4.0 (or newer 47.x), put the jar in the `mods` folder, start the game.
3. Create a Creative world (flat world is best), then:
   - `/bluelock pitch` builds a 61x37 pitch where you stand (grass stripes, white lines, two goals) and puts a ball at the centre. Stand on flat ground first; blocks above the pitch area are removed.
   - `/bluelock ball` puts a ball in front of you. The Football item is in the Tools & Utilities creative tab.
4. Play: run into the ball to dribble, right-click it to pass, left-click it to shoot.
5. Career commands: `/bluelock create striker competitive right Roy`, `/bluelock profile`, `/bluelock data`.

6. Play a match (Phase 6):
   - `/bluelock pitch` first, then `/bluelock match join home` (or `away`), then `/bluelock match start 3` (3 minutes; default 3).
   - The chat tells you where each goal is (X, Z). Home defends one goal and attacks the other.
   - Touch the ball to kick off; the clock runs only while the ball is in play.
   - Goals, own goals, ball out of play (put back on the line), kick-off after goals and full time are announced in chat.
   - `/bluelock match status` shows score, time and possession; `/bluelock match stop` ends it.
   - Alone? Join one side and shoot at the other goal. With a friend, join opposite sides.

7. Teams and formations (Phase 8):
   - `/bluelock match mode 5v5` picks the size (1v1, 2v2, 3v3, 4v4, 5v5, 7v7, 11v11). Default is 5v5.
   - `/bluelock team set home team_v` gives a side one of the five teams (V, W, X, Y, Z): their formation, style and rating.
   - `/bluelock team formation away 1_2_1` picks a formation that fits the mode; `/bluelock team show home` lists every slot (your name, or "(bot)" for slots the AI will fill later), plus rating and chemistry.
   - `/bluelock team slot 3` moves you to slot 3. Without it you are seated automatically by your archetype (a Striker gets ST, a Defender gets CB/LB/RB...).
   - At the start of a match and after every goal, joined players are moved to their formation spot, facing the other goal.

8. Gameplay update (carry, tackles, skills, bots, HUD, sound):
   - Walk into the ball and it sticks to your feet and travels with you. Run faster and it swings further ahead; weak dribblers can lose it when sprinting.
   - Keys (change them in Options > Controls > Blue Lock): R pass (auto-aims at the team-mate you look at), F shot (aim assist toward the goal), V slide tackle, Z feint, X burst dribble, C chain dribble, B sprint burst, G shoulder charge.
   - Tackle: left-click the player or bot who has the ball (standing tackle), or press V and slide into them. Better Tackling beats better Dribbling.
   - Skills: `/bluelock skills` lists them. Root skills (like Control) unlock by themselves when your stats allow it; others cost 1 skill point: `/bluelock skills unlock feint`. Skill points and development points come from levelling up (goals, tackles, passes, matches give XP). `/bluelock train passing` spends development points.
   - Bots: `/bluelock match start` fills every empty slot with a bot. `/bluelock match bots off` turns them off, `/bluelock match difficulty easy|normal|hard` changes their strength. Join a side first: `/bluelock match join home`.
   - The screen shows the score, clock, possession, your stamina, the key icons with cooldowns, and big GOAL / KICK-OFF / FULL TIME banners. Referee whistle, crowd cheer, kick, shot and tackle sounds are included.

Remove balls with `/kill @e[type=bluelock:ball]` and bots with `/kill @e[type=bluelock:bot]`.

## What is new in 0.12.0
- **Press M** for the Blue Lock menu: MATCH (build pitch, mode, length, bots, bot level, join a side, pick teams, start/stop), STATS (all 35 stats by category with +1 buttons), SKILLS (by category, unlock buttons), QUESTS (13 quests with progress and rewards).
- **New character screen** opens by itself the first time you join a world without a character. Choose name, position, style and personality. Your **dominant foot** is rolled by the game (60% right, 30% left, 10% both) and your **talent** too (25% Genius, 75% Normal). Genius: +2 on every stat, cheaper growth, cap 99 instead of 92, +15% XP.
- **Foot matters:** kicks that go across your body onto your weak foot are less accurate and weaker; both-footed players have no weak side; feints are shorter toward your weak side.
- **Bots are faster and sharper.** `/bluelock match difficulty easy|normal|hard|pro`. Normal bots now run slightly faster than a sprinting player and react twice as often.
- **Goalkeepers** stand on the line between the ball and the goal (stepping out when an attacker runs at goal), dive left or right at shots, and catch, push away or get beaten depending on Reaction, Positioning and Jump.
- **Quests:** `/bluelock quests` or the QUESTS tab.
- Commands: `/bluelock create <archetype> <personality> <position> <name>` (foot and talent are rolled), `/bluelock train <stat> up`.

## What is new in 0.12.0 (animations, scrolling menu, test cheats)
- **Animations.** Install the two libraries next to the Blue Lock jar (see CHANGELOG-v0.12.0.md): GeckoLib 4.8.1 and PlayerAnimator 1.0.2-rc1 for 1.20.1 Forge.
  - Bots get a new animated model: idle, walk, run, sprint, jump, the same with the ball, kicks, tackles, slide, feints, burst, spin, shoulder charge, goalkeeper dives and catches, and a celebration after goals.
  - Players keep the normal Minecraft walking, but get custom animations while dribbling (idle, walk, run, sprint, jump with the ball) and for kicks, tackles, slide tackles, every dribble skill and goal celebrations. Other players see them too.
  - `/bluelock` tells you whether they are active: "bot animations: ON, player animations: ON". The latest log also says "GeckoLib bot animations are active".
- **Menus scroll**: mouse wheel in every tab and in the character screen. The category rows stay fixed.
- **Test cheats** (singleplayer, or op on a server): `/bluelock cheat skillpoints <n>`, `/bluelock cheat devpoints <n>`, `/bluelock cheat xp <n>`, `/bluelock cheat unlockall`. The Stats and Skills tabs also have red TEST buttons.

9. Version 0.12.0: animations and skills that really work
   - Bots now spawn as the animated GeckoLib bot on the server, so kicks, tackles, slides, keeper dives and goal celebrations play on them.
   - Player animations (PlayerAnimator) now load: the files moved to `assets/bluelock/player_animation/` (singular, the folder PlayerAnimator reads). Idle, walk, run, sprint and jump play for you whenever you are in a match, carrying the ball, or within 24 blocks of a ball. Other time you keep the normal Minecraft animations.
   - New keys (change them in Options > Controls > Blue Lock): H direct shot, Y through pass, N dive, J passing lane read, K spatial read, I advanced field vision, O interception read, U shadow marking, comma (,) composure focus.
   - Direct shot (needs the skill): a crosshair appears on a loose ball (rolling or in the air, nobody carrying it) within 2 blocks. H uses the best tier you own and can afford: awakened, then precision, then normal. Precision aims at a top corner on the side you look at. Awakened costs Ego.
   - Ego is a new bar next to Stamina. It refills slowly. Big skills (pressure finisher, awakened shot, advanced vision) cost it.
   - Passive skills: Finishing (more accurate shots), Control (ball stays closer), Awareness (wider pass aim), Pressure Finisher (fires by itself on a shot with a defender within 5 blocks).
   - Vision skills draw markers on your screen only: green ring = open team-mate, red ring = opponent, gold ring = ball, orange = marked opponent. They need a match with other players on the pitch.
   - Testing helpers (operators / cheats on): `/bluelock cheat skillpoints 50`, `/bluelock cheat devpoints 500`, `/bluelock cheat unlockall`, and the new `/bluelock cheat refill` (full stamina and Ego, all cooldowns reset).

10. Version 0.13.0: pitch sizes and the 3D hair maker
   - **Pitch sizes.** `practice` 41x25, `standard` 61x37, `large` 81x49, `full` 105x69 (real-size penalty areas and centre circle). A real match uses `standard` for 1v1-3v3, `large` for 4v4-7v7 and `full` for 11v11. Practice mode (`/bluelock match practice on`, or the PRACTICE button in the menu) uses the small pitch for 1v1-3v3 and `standard` for 4v4-5v5; 7v7 and 11v11 never go below `large` / `full`.
   - **The pitch loads by itself.** `/bluelock match start` (or the START MATCH button) builds the right pitch around you when there is none, or when the existing one has the wrong size for the mode. A pitch you built on purpose with a size (`/bluelock pitch full`) is kept. `/bluelock pitch` alone builds the size the current mode needs. The pitch position is saved with the world, so after a restart it is found again without rebuilding. Holes, water and plants under the pitch are filled with dirt.
   - **Hair maker.** In the character screen press HAIR MAKER..., or press M and use HAIR MAKER at the bottom left to change it later. 12 style presets, sliders for top volume, fringe, sides, back length, spikes, fluff and ponytail, a main colour and a tip colour (swatches and red/green/blue sliders), RESHUFFLE (new random locks), RANDOM and RESET. Drag on the left to turn your character; FRONT / SIDE / BACK buttons snap the view. Other players see your hair. Helmets hide it.
   - Test checklist: build each size with `/bluelock pitch practice|standard|large|full` and check the lines; start 11v11 from nothing and check a full pitch appears; restart the world and start a match without building; open the hair maker, try every style, turn to the back view, set a tip colour, press DONE, relog and check the hair stays; join with a second player and check they see your hair.
   - Automatic tests: `HairPitchSelfTest` (sizes, mode rules, markings, every hair style builds valid geometry, tip colours, network and save round trips, old saves).

## 11. Phase 5 (0.14.0): Blue Lock characters, sprint, faster bots, hair on bots

1. Start a match against bots (`/bluelock match ...`). Bots of a team now carry names above their heads (Isagi, Bachira, Chigiri, ...) when the team has characters for their positions; other bots stay nameless.
2. Bots run clearly faster than before: a jog is faster than a sprinting player, and they sprint when chasing the ball, pressing, or breaking forward. A sprint lasts about 8 to 14 seconds (depends on the character), then the bot is tired, jogs slower and recovers while resting.
3. Characters play differently: Chigiri is very fast, Baro and Kaiser shoot from far away, Bachira dribbles under pressure, Rin and Isagi make long runs.
4. Every bot has 3D hair on its head: the animated bot and the plain fallback bot. Named characters have their own hair; nameless bots get a made-up one that is the same for everybody.
5. If the hair on animated bots looks back to front or floats, tell me; the offset is one constant in `HairGeoLayer`.

Automated: `CharacterSelfTest` (roster, assignment, energy, speed cap, ego and sprint behaviour). Run it with the other self tests.

## 12. 0.15.0: faster bots, character looks, skills, football kits

1. Bots now drive themselves: a jog is about 8 blocks per second, a sprint up to about 12. If they still feel slow or too fast, tell me the feeling; it is one number (`BLOCKS_PER_ATTRIBUTE` in `BotEntity`).
2. Every named character has his own hair colour, tips and style, his own height (about 92% to 110% of normal), his own shirt name and number, and skills.
3. Bots use their skills: feints and spins under pressure, bursts in open space, harder or straighter direct shots, longer through passes, shoulder charges.
4. Players in a match and all bots wear a kit in their team colour: shirt, sleeves with cuffs, collar, shorts, socks. The back shows the name and a number (from the position for players, the character's own for bots).
5. Check the animated bot's back: name and number must read correctly (not mirrored). If mirrored or on the front, tell me.

Automated: `CharacterSelfTest` now also covers looks, skills, skill rules and kits.

## 13. 0.16.0: slower bots, stats that matter, sound and juice

1. Bots are about 15% slower than 0.15.0 (jog roughly 7 blocks per second). One number: `BLOCKS_PER_ATTRIBUTE` in `BotEntity`.
2. Stats now change play for players in a match and for bots: Top Speed and Acceleration change running speed (85% to 117%), Jump changes jump height, Stamina changes how long bots sprint, Vision changes how far a bot looks for a pass. Dribbling, passing, shooting, tackling, strength, balance and keeper stats already worked and still do. Check with `/bluelock` stat commands: raise Top Speed and feel the difference.
3. 11 new sounds: ball touch, bounce, post, net, crowd cheer, crowd gasp, whoosh, keeper save, charge, impact, footsteps.
4. Juice: ball trail on hard shots (flames on the hardest), kick puffs, sprint dust, tackle sparks and slide dust, post sparks, goal fireworks, and camera shake on goals, power shots, saves, shoulder charges and awakening shots.

## 14. 0.17.0: real skills, bind slots, body and features

1. Six new skills (Dragon Drive, Curved Shot, Perfect Pass, Monster Dribble, Chameleon, Trap). Open M > Skills, unlock one (`/bluelock cheat unlockall` for a quick test), and press its button to bind it to slot 1, 2 or 3 (click again to cycle; the 4th click unbinds). Owned skills stay owned when unbound.
2. Slot keys are `[`, `]` and `\` (rebind in Controls). Dragon Drive: hard, accurate shot with flames. Curved Shot: the ball bends in flight. Perfect Pass: an accurate pass to the team-mate you face. Monster Dribble: zig-zag with the ball. Chameleon: steadier and faster for a few seconds. Trap: you control any ball for 5 seconds.
3. Bots that own these skills use them (curved shots, perfect passes, monster dribble, chameleon). Named characters got provisional assignments.
4. New Body & features button next to Hair, in the menu and on the creation screen: skin tone, eye colour and shape, eyebrows, mouth, a mark, height and build. "Look like" copies a character's body and hair. Drag on the left to turn, and use the view buttons.
5. Players with a character wear a dark training kit when not in a match. Check that the face shows on the front of the head, hair sits on top, and other players see your look.
6. Network protocol is now "6": everybody needs 0.17.0.

Automated: `CharacterSelfTest` covers body design, binds and the new skill rules.

## 15. 0.18.0: voices and canon technique bindings

1. Voices: 6 voice types (deep calm, deep fierce, mid calm, mid bold, high playful, high sharp) x 8 sounds (effort, shot, power roar, skill call, tackle grunt, goal cheer, hurt, laugh). They are synthesised shouts and grunts, not speech. Play a practice match with bots: bots grunt on passes, shout on shots, roar on awakening shots and Dragon Drive, call out dribble skills, grunt on tackles and cheer on goals. You do the same on your own shots, passes, skills, slides and goals.
2. Volume: the sounds use the vanilla Voice/Speech slider (Options > Music & Sounds), so you can turn them down or off there.
3. Every named character has a fixed voice type; nameless bots and players get one from their height and build (taller = deeper).
4. Your own voice files: replace any `voice_<type>_<event>.ogg` in `assets/bluelock/sounds` (same name, ogg vorbis, mono). `tools/make_voices.py` regenerates all of them.
5. Canon bindings (approximate, from the series): Bachira Monster Dribble, Reo Chameleon, Nagi Trap, Sae Perfect Pass, Shidou Dragon Drive, Rin and Kaiser Curved Shot, Noa Trap and Perfect Pass on top of his all-round skills. Tell me any that are wrong or missing.

Automated: `CharacterSelfTest` covers the bindings, voice types, cooldowns and file names.

## 16. 0.19.0: canon looks, squads and stats

1. Squads now follow the First Selection: Team Z has its 11 players (Isagi, Bachira, Kunigami, Chigiri, Raichi, Gagamaru, Kuon, Igarashi, Naruhaya, Iemon, Imamura), Team V has Nagi, Reo and Zantetsu, Team W the Wanima twins, Team X Baro plus three more, Team Y Ikki and Okawa. Teams with fewer than 11 named players fill the rest with nameless bots. Use the menu to pick teams and check who you face.
2. Rin, Shidou, Kaiser, Sae, Noa, Otoya, Tokimitsu, Aiku, Hiori, Aryu and Nanase are no longer on a team, so matches never pick them. They are still in the game ("Look like" in Body & features) and in `data/bluelock/story/characters.json` for story mode.
3. Looks changed to match the series: Isagi's dark blue hair, Bachira's yellow eyes, Chigiri's pink hair and eyes, Raichi's pale blonde hair, Nagi's teal eyes, Shidou's blonde hair and pink eyes, and so on. Jerseys use the First Selection numbers where known (Isagi 11, Chigiri 4, Gagamaru 6, Nagi 11, Reo 9, Baro 10).
4. Stats: each character gets strengths from the series (Chigiri's speed, Nagi's touch, Baro's finishing and ego, Isagi's spatial awareness...). Compare in a match: Chigiri should clearly outrun everyone.
5. Characters marked "placeholder" in the story file (Naruhaya, Iemon, Imamura, the Wanimas, Meiji, Sanga, Banku, Okawa) have invented looks and positions. Tell me the real ones and I will fix them.

Automated: `CharacterSelfTest` checks squads, jerseys, who is kept out of teams, the stat differences and that the story file lists everyone.

## 17. 0.20.0: story mode, Chapter 1

1. Open the menu (default key) and pick the STORY tab, or type `/bluelock story continue`. You start in Team Z. Scenes show a portrait, a name and typed text: click, Space or Enter to go on; Esc closes and you can resume from the tab.
2. Matches in the story need a pitch (`/bluelock pitch` first). The story sets your side to Team Z and the opponent, starts the match and tells you the objective. When the whistle goes the result is judged: pass and you get XP, skill points and development points and the next scene opens after a few seconds; fail and you can retry from the tab.
3. Order: arrival, Team Z, rules, then matches X (score a goal), Y (win), V (win), W (do not lose), with scenes between, and the end screen.
4. `/bluelock story status` shows your place, `/bluelock story restart` goes back to the start (your XP and skills are kept).
5. Portraits are drawn from each character's hair and body data. Story text is English only for now (Arabic menu labels exist).

Automated: `CharacterSelfTest` checks the beat order, the objective rules, that every speaker and opponent exists and that story progress is saved.

## 18. 0.21.0: the Blue Lock campus

1. Stand somewhere flat and open (the campus needs about 85 x 170 blocks, it clears trees and hills), look the way the front door should face, and press STORY, "Build Blue Lock campus" (or `/bluelock campus build`). It goes up over a few seconds, with progress messages, and builds the stadium pitch at the end.
2. Places: entrance, hall with the ranking wall, Team Z's room (11 beds and a big Z), briefing room with a screen, training room (bullseye wall, cones, agility ladder, treadmills, weights), locker room and showers, cafeteria, control room, a tunnel and the stadium (stands, boards, floodlights). Use the STORY tab buttons or `/bluelock go <place>`.
3. Story: each scene now takes you to its place (a title shows when you arrive somewhere new) and story matches go to the stadium gate. With the campus built, story matches are 7v7 on the stadium pitch.
4. Dialogue: portraits slide in and the mouth moves while the text types.
5. English only from now on: new text has no Arabic.

Automated: `CampusSelfTest` simulates the plan and checks every place is standable and can be walked to from the front door.

## 19. 0.22.0: the 300, the trial, the cafeteria, 11v11, rolls

1. Character creation: press ROLL in the destiny panel. The foot reel and the talent number spin, the foot stops first, then the talent lands (10 to 100%, average 50; the screen shows how rare it is). Confirm is locked until you have rolled. You roll once per character. 75% and up counts as Genius.
2. Build the campus again (it is bigger, about 160 x 250 blocks, so pick an open flat area). New: the Selection Hall (300 figures in rows, the giant screen with the supervisor's gold lenses), dormitory rooms for Teams V, W, X, Y, an analysis room, a medical room, a practice pitch in front of the building, "BLUE LOCK" in gold on the stadium's far wall, and a full-size 105 x 69 stadium pitch for 11v11. Team Z's room has a west door to the Selection Hall.
3. Story chapter 1 now opens in the Selection Hall: the supervisor's speech over the crowd, then the touch trial: a ball is fired at you for 60 seconds, faster as time runs; touching it loses the trial (retry from the STORY tab). Surviving pays XP, points and ranking points. Then Team Z and the four matches, now 11v11.
4. RANK tab: all 300 places, yours highlighted. Points come from goals, matches, wins and story beats. Cafeteria: stand in the cafeteria (or anywhere if there is no campus) and press "Eat at the cafeteria" or use `/bluelock eat`; better rank, better meal (tiers S to D), one meal every 3 minutes.
5. The places of named characters in the ranking are my approximation.

Automated: `CharacterSelfTest` checks the roll distribution (mean 50, rarer both ways), ranking and cafeteria; `CampusSelfTest` checks 300 figures and the 11v11 pitch size.

## 20. 0.23.0: big-block campus, NPCs, the last-touch trial
Test commands (op or singleplayer): `/bluelock debug talent <10-100>`, `/bluelock debug foot <right|left|both>`, `/bluelock story skip`.
1. `/bluelock campus build`: one big cube with BLUE LOCK in blue letters on the front, the stadium behind it; NPCs appear as you get close (hall, rooms, cafeteria) and talk.
2. `/bluelock story restart`, read the hall scene, then the Team Z scene. The trial starts in Team Z's room: 12 in a ring, one ball held by you, countdown 3-2-1, GO.
3. At zero the ball is dead: the next to touch it (or the holder) is eliminated. Bots from the main cast avoid it. If it is you, talk to Ego again to retry; `story skip` passes it for testing.
4. Honest note: the Forge layer is not compiled in the sandbox. If the build falls back to BASIC, paste the red error.
