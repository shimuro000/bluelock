package com.bluelock.forge;

import com.bluelock.common.ai.FootballCharacter;
import com.bluelock.common.ai.Roster;
import com.bluelock.common.audio.Voices;
import com.bluelock.common.campus.CampusPlan;
import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

/**
 * The people of the campus: Team Z in its room, rivals and nameless players in the hall, the rooms and the training
 * room, the supervisor at his desk. They are bots standing still (they are not saved, so they are placed again when a
 * player comes near and removed when everybody left). Now and then one of them says something.
 */
public final class AmbientNpcs {
    private static final int SPAWN_RANGE = 90;
    private static final int KEEP_RANGE = 160;
    private static final Random RANDOM = new Random();
    private static final BotEntity[] SPAWNED = new BotEntity[CampusPlan.npcs().size()];
    /** Candidates who were eliminated in the story: they do not come back until the story restarts. */
    private static final Set<Integer> GONE = new HashSet<>();
    private static int ticks;

    private AmbientNpcs() {
    }

    public static int colorOf(String team) {
        return switch (team) {
            case "team_z" -> 0x2F6BFF;
            case "team_v" -> 0xB02A2A;
            case "team_w" -> 0x2AA8B0;
            case "team_x" -> 0xE07A2D;
            case "team_y" -> 0xE8E8E8;
            default -> 0x444B5C;
        };
    }

    private static FootballCharacter characterOf(CampusPlan.Npc npc) {
        if (npc.team().isEmpty()) {
            return null;
        }
        List<FootballCharacter> list = Roster.ofTeam(npc.team());
        return list.isEmpty() ? null : list.get(npc.index() % list.size());
    }

    /** Makes a standing bot (not registered anywhere). */
    public static BotEntity makeBot(ServerLevel level, FootballCharacter character, int slot, int color, double x, double y, double z, float yaw) {
        BotEntity bot = ModEntities.BOT.get().create(level);
        if (bot == null) {
            return null;
        }
        bot.configure(Side.HOME, slot, Position.CM, 60, 1.0, character);
        bot.setKit(color, character != null ? character.jersey() : 10 + slot % 20);
        bot.moveTo(x, y, z, yaw, 0.0F);
        level.addFreshEntity(bot);
        return bot;
    }

    private static boolean alive(BotEntity bot) {
        return bot != null && bot.isAlive() && !bot.isRemoved();
    }

    private static boolean playerNear(ServerLevel level, double x, double z, double range) {
        for (ServerPlayer p : level.players()) {
            double dx = p.getX() - x;
            double dz = p.getZ() - z;
            if (dx * dx + dz * dz < range * range) {
                return true;
            }
        }
        return false;
    }

    private static void spawn(MinecraftServer server, ServerLevel level, int i) {
        CampusPlan.Npc n = CampusPlan.npcs().get(i);
        double[] w = CampusBuilder.worldOf(server, n.x(), 1, n.z());
        FootballCharacter c = characterOf(n);
        BotEntity bot = makeBot(level, c, i, colorOf(n.team()), w[0], w[1], w[2], CampusBuilder.yawOfTurn(server, n.turn()));
        if (bot != null) {
            if (!n.name().isEmpty()) {
                bot.setCustomName(Component.literal(n.name()));
                bot.setCustomNameVisible(true);
            }
            SPAWNED[i] = bot;
        }
    }

    /** Spawns Team Z's room members now (for the trial) and returns the ones who are still in the story. */
    public static List<BotEntity> teamZ(MinecraftServer server) {
        List<BotEntity> out = new ArrayList<>();
        ServerLevel level = CampusBuilder.levelOf(server);
        if (level == null) {
            return out;
        }
        for (int i = 0; i < CampusPlan.npcs().size(); i++) {
            if (!CampusPlan.npcs().get(i).team().equals("team_z") || GONE.contains(i)) {
                continue;
            }
            if (!alive(SPAWNED[i])) {
                spawn(server, level, i);
            }
            if (alive(SPAWNED[i])) {
                out.add(SPAWNED[i]);
            }
        }
        return out;
    }

    public static void eliminate(int index) {
        GONE.add(index);
        if (index >= 0 && index < SPAWNED.length && alive(SPAWNED[index])) {
            SPAWNED[index].discard();
        }
    }

    public static void resetEliminated() {
        GONE.clear();
    }

    /** Puts everybody back on their own spot (after the trial moved Team Z around). */
    public static void home(MinecraftServer server) {
        for (int i = 0; i < SPAWNED.length; i++) {
            if (alive(SPAWNED[i])) {
                CampusPlan.Npc n = CampusPlan.npcs().get(i);
                double[] w = CampusBuilder.worldOf(server, n.x(), 1, n.z());
                SPAWNED[i].moveTo(w[0], w[1], w[2], CampusBuilder.yawOfTurn(server, n.turn()), 0.0F);
                SPAWNED[i].stopRunning();
            }
        }
    }

    public static void tick(MinecraftServer server) {
        ticks++;
        if (ticks % 40 != 0) {
            return;
        }
        ServerLevel level = CampusBuilder.levelOf(server);
        if (level == null) {
            return;
        }
        for (int i = 0; i < SPAWNED.length; i++) {
            CampusPlan.Npc n = CampusPlan.npcs().get(i);
            double[] w = CampusBuilder.worldOf(server, n.x(), 1, n.z());
            boolean here = alive(SPAWNED[i]);
            if (!here && !GONE.contains(i) && playerNear(level, w[0], w[2], SPAWN_RANGE)
                    && level.hasChunkAt(new BlockPos((int) w[0], (int) w[1], (int) w[2]))) {
                spawn(server, level, i);
            } else if (here && !playerNear(level, w[0], w[2], KEEP_RANGE) && !TrialManager.running()) {
                SPAWNED[i].discard();
            }
        }
        if (ticks % 120 == 0 && !TrialManager.running()) {
            for (ServerPlayer p : level.players()) {
                List<BotEntity> near = new ArrayList<>();
                for (BotEntity bot : SPAWNED) {
                    if (alive(bot) && bot.distanceToSqr(p) < 16 * 16) {
                        near.add(bot);
                    }
                }
                if (!near.isEmpty()) {
                    BotEntity speaker = near.get(RANDOM.nextInt(near.size()));
                    Voice.say(speaker, Voices.Event.TALK, 1.0);
                    speaker.getLookControl().setLookAt(p, 30.0F, 30.0F);
                }
            }
        }
    }

    public static boolean isLevel(Level level) {
        return level instanceof ServerLevel;
    }
}
