package com.bluelock.forge;

import com.bluelock.common.ai.FootballCharacter;
import com.bluelock.common.audio.Voices;
import com.bluelock.common.story.StoryBook;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;

/**
 * The first test of the story, played in Team Z's room: twelve players (eleven of Team Z and you) stand in a ring with ONE
 * ball, which starts with the lowest ranked player. When the timer reaches zero the ball is dead and the next player to
 * touch it (or the one holding it) is the last to touch it: he loses his place and is eliminated. Seven of Team Z are
 * main characters and avoid the last touch; the other four may go. If it is you, the trial fails and you try again.
 */
public final class TrialManager {
    private static final Set<String> MAINS = Set.of("isagi", "bachira", "chigiri", "kunigami", "raichi", "gagamaru", "kuon");
    private static final double RING_RADIUS = 3.8;
    private static final int PREP_TICKS = 80;
    private static final int ENDING_TICKS = 110;
    private static final Random RANDOM = new Random();

    private static Run run;

    private TrialManager() {
    }

    private enum Phase { PREP, PLAY, ENDING, DONE }

    private static final class Run {
        final UUID player;
        final int beatIndex;
        final int playTicks;
        final ServerLevel level;
        final List<BotEntity> bots = new ArrayList<>();
        final List<double[]> spots = new ArrayList<>();
        double centreX;
        double centreY;
        double centreZ;
        BallEntity ball;
        Phase phase = Phase.PREP;
        int ticks;
        int endingTicks;
        int doneTicks;
        BotEntity holder;
        int holdTicks;
        int reaction = 18;
        long lastPassTick;
        LivingEntity previousHolder;
        boolean resolved;
        boolean loserIsPlayer;

        Run(UUID player, int beatIndex, int playTicks, ServerLevel level) {
            this.player = player;
            this.beatIndex = beatIndex;
            this.playTicks = playTicks;
            this.level = level;
        }
    }

    public static boolean running() {
        return run != null;
    }

    public static void start(ServerPlayer player, int beatIndex, StoryBook.Beat beat) {
        MinecraftServer server = player.getServer();
        if (run != null) {
            cancel(server);
        }
        ServerLevel level = (ServerLevel) player.level();
        Run r = new Run(player.getUUID(), beatIndex, beat.length() * 20, level);
        boolean campus = CampusBuilder.built(server) && CampusBuilder.levelOf(server) != null;
        if (campus) {
            double[] c = CampusBuilder.worldOf(server, -20, 1, 5);
            r.centreX = c[0];
            r.centreY = c[1];
            r.centreZ = c[2];
            r.bots.addAll(AmbientNpcs.teamZ(server));
        } else {
            r.centreX = player.getX() + 4;
            r.centreY = player.getY();
            r.centreZ = player.getZ();
            for (int i = 0; i < 11; i++) {
                List<FootballCharacter> z = com.bluelock.common.ai.Roster.ofTeam("team_z");
                FootballCharacter c = z.isEmpty() ? null : z.get(i % z.size());
                BotEntity bot = AmbientNpcs.makeBot(level, c, i, AmbientNpcs.colorOf("team_z"), r.centreX, r.centreY, r.centreZ, 0);
                if (bot != null) {
                    r.bots.add(bot);
                }
            }
        }
        // the ring: you at the first spot, the bots on the others
        int n = r.bots.size() + 1;
        for (int i = 0; i < n; i++) {
            double angle = Math.PI * 2 * i / n + Math.PI / 2;
            r.spots.add(new double[] {r.centreX + Math.cos(angle) * RING_RADIUS, r.centreZ + Math.sin(angle) * RING_RADIUS});
        }
        player.teleportTo(r.level, r.spots.get(0)[0], r.centreY, r.spots.get(0)[1], faceYaw(r.spots.get(0)[0], r.spots.get(0)[1], r), 0.0F);
        for (int i = 0; i < r.bots.size(); i++) {
            double[] s = r.spots.get(i + 1);
            r.bots.get(i).stopRunning();
            r.bots.get(i).moveTo(s[0], r.centreY, s[1], faceYaw(s[0], s[1], r), 0.0F);
        }
        // one ball, held by the lowest ranked player (you)
        r.ball = BallEntity.spawn(r.level, r.spots.get(0)[0], r.centreY + 0.2, r.spots.get(0)[1]);
        r.ball.takeBy(player);
        run = r;
        player.sendSystemMessage(Component.translatable(beat.briefKey()));
        player.sendSystemMessage(Component.translatable("bluelock.trial.start"));
        Titles.show(player, Component.translatable("bluelock.trial.title").withStyle(ChatFormatting.AQUA),
                Component.translatable("bluelock.trial.subtitle"), 10, 50, 10);
        Juice.sound(r.level, r.centreX, r.centreY, r.centreZ, ModSounds.CHARGE, 0.8F, 0.9F);
    }

    private static float faceYaw(double x, double z, Run r) {
        return (float) (Math.atan2(-(r.centreX - x), r.centreZ - z) * (180.0 / Math.PI));
    }

    private static boolean isMain(BotEntity bot) {
        return bot.character() != null && MAINS.contains(bot.character().id());
    }

    /** Candidates remaining on the big board (a flavour number: 300 falls to a lucky few). */
    public static int remaining(double progress) {
        return 300 - (int) Math.round(210 * Math.pow(Math.max(0, Math.min(1, progress)), 1.3));
    }

    private static void cancel(MinecraftServer server) {
        Run r = run;
        run = null;
        if (r != null) {
            if (r.ball != null) {
                r.ball.discard();
            }
            AmbientNpcs.home(server);
        }
    }

    public static void tick(MinecraftServer server) {
        if (run == null) {
            return;
        }
        Run r = run;
        ServerPlayer player = server.getPlayerList().getPlayer(r.player);
        if (player == null || player.isDeadOrDying() || player.level() != r.level) {
            cancel(server);
            return;
        }
        r.ticks++;
        if (r.ball != null && !r.ball.isAlive()) {
            r.ball = BallEntity.spawn(r.level, r.centreX, r.centreY + 0.3, r.centreZ);
        }
        // keep the player in the room
        double dx = player.getX() - r.centreX;
        double dz = player.getZ() - r.centreZ;
        if (r.phase != Phase.DONE && dx * dx + dz * dz > 8 * 8) {
            double[] s = r.spots.get(0);
            player.teleportTo(r.level, s[0], r.centreY, s[1], faceYaw(s[0], s[1], r), 0.0F);
        }
        switch (r.phase) {
            case PREP -> prep(r, player);
            case PLAY -> play(server, r, player);
            case ENDING -> ending(server, r, player);
            case DONE -> done(server, r);
        }
    }

    private static void prep(Run r, ServerPlayer player) {
        int left = (PREP_TICKS - r.ticks) / 20 + 1;
        if (r.ticks % 20 == 1 && r.ticks < PREP_TICKS) {
            Titles.show(player, Component.literal(String.valueOf(left)).withStyle(ChatFormatting.GOLD), null, 0, 16, 4);
            Juice.sound(r.level, player.getX(), player.getY(), player.getZ(), ModSounds.TOUCH, 0.8F, 0.8F + (3 - left) * 0.15F);
        }
        faceBots(r);
        if (r.ticks >= PREP_TICKS) {
            r.phase = Phase.PLAY;
            r.ticks = 0;
            Titles.show(player, Component.translatable("bluelock.trial.go").withStyle(ChatFormatting.AQUA), null, 0, 24, 8);
            Juice.sound(r.level, player.getX(), player.getY(), player.getZ(), ModSounds.WHISTLE, 0.9F, 1.1F);
            Juice.shake(r.level, r.centreX, r.centreY, r.centreZ, 16, 0.4F, 8);
        }
    }

    private static void faceBots(Run r) {
        for (BotEntity bot : r.bots) {
            bot.getLookControl().setLookAt(r.centreX, bot.getEyeY(), r.centreZ);
        }
    }

    private static void play(MinecraftServer server, Run r, ServerPlayer player) {
        int left = r.playTicks - r.ticks;
        double progress = (double) r.ticks / r.playTicks;
        if (r.ticks % 10 == 0) {
            LivingEntity carrier = r.ball.carrier();
            Component who = carrier == null ? Component.translatable("bluelock.trial.loose") : carrier.getDisplayName();
            player.displayClientMessage(Component.translatable("bluelock.trial.hud", left / 20 + 1, who, remaining(progress)), true);
        }
        // the last five seconds: a number on screen and a rising tick
        if (left > 0 && left <= 100 && left % 20 == 0) {
            int sec = left / 20;
            Titles.show(player, Component.literal(String.valueOf(sec)).withStyle(sec <= 2 ? ChatFormatting.RED : ChatFormatting.YELLOW), null, 0, 14, 4);
            Juice.sound(r.level, player.getX(), player.getY(), player.getZ(), ModSounds.TOUCH, 1.0F, 1.5F - sec * 0.1F);
            Juice.shake(r.level, r.centreX, r.centreY, r.centreZ, 12, 0.2F + (6 - sec) * 0.05F, 4);
        }
        botsPlay(r, left);
        if (left <= 0) {
            r.phase = Phase.ENDING;
            r.endingTicks = 0;
            Titles.show(player, Component.translatable("bluelock.trial.time").withStyle(ChatFormatting.RED),
                    Component.translatable("bluelock.trial.time_sub"), 0, 40, 10);
            Juice.sound(r.level, r.centreX, r.centreY, r.centreZ, ModSounds.WHISTLE, 1.2F, 0.8F);
            Juice.shake(r.level, r.centreX, r.centreY, r.centreZ, 16, 0.7F, 12);
            for (BotEntity bot : r.bots) {
                bot.stopRunning();
            }
        }
    }

    /** The bots: stand in the ring, take the ball when it comes to them, hold it for a moment, pass it on. */
    private static void botsPlay(Run r, int ticksLeft) {
        LivingEntity carrier = r.ball.carrier();
        if (carrier != r.holder) {
            r.holder = carrier instanceof BotEntity b ? b : null;
            r.holdTicks = 0;
            if (r.holder != null) {
                r.reaction = 14 + RANDOM.nextInt(20);
            }
        }
        for (int i = 0; i < r.bots.size(); i++) {
            BotEntity bot = r.bots.get(i);
            double[] spot = r.spots.get(i + 1);
            if (r.ball.carrier() == bot) {
                r.holdTicks++;
                bot.stopRunning();
                if (r.holdTicks >= r.reaction) {
                    pass(r, bot, ticksLeft);
                }
                continue;
            }
            double bx = r.ball.getX() - bot.getX();
            double bz = r.ball.getZ() - bot.getZ();
            double ballDist = Math.sqrt(bx * bx + bz * bz);
            boolean loose = r.ball.carrier() == null;
            double speed = r.ball.getDeltaMovement().horizontalDistance();
            if (loose && ballDist < 3.4 && r.ticks - r.lastPassTick > 12 && bot != r.previousHolder) {
                bot.runTo(r.ball.getX(), r.ball.getZ(), 1.0);
                if (ballDist < 1.1) {
                    r.ball.takeBy(bot);
                    Voice.say(bot, Voices.Event.EFFORT, 0.6);
                }
            } else {
                double sx = spot[0] - bot.getX();
                double sz = spot[1] - bot.getZ();
                if (sx * sx + sz * sz > 1.0) {
                    bot.runTo(spot[0], spot[1], 0.7);
                } else {
                    bot.getLookControl().setLookAt(r.ball.getX(), r.ball.getY(), r.ball.getZ());
                }
            }
            if (speed > 1.6 && ballDist < 3) {
                bot.getLookControl().setLookAt(r.ball.getX(), r.ball.getY(), r.ball.getZ());
            }
        }
    }

    private static void pass(Run r, BotEntity bot, int ticksLeft) {
        List<LivingEntity> targets = new ArrayList<>();
        List<Double> weights = new ArrayList<>();
        ServerPlayer player = r.level.getServer().getPlayerList().getPlayer(r.player);
        if (player != null) {
            targets.add(player);
            weights.add(1.6);
        }
        for (BotEntity other : r.bots) {
            if (other == bot || !other.isAlive()) {
                continue;
            }
            double w = isMain(other) ? 1.0 : 2.2;
            if (ticksLeft < 60 && isMain(other)) {
                w = 0.0;   // the last seconds: the mains never pass to each other, the ball goes to you or the four others
            }
            if (other == r.previousHolder) {
                w *= 0.3;
            }
            targets.add(other);
            weights.add(w);
        }
        double total = 0;
        for (double w : weights) {
            total += w;
        }
        if (total <= 0 || targets.isEmpty()) {
            return;
        }
        double pick = RANDOM.nextDouble() * total;
        LivingEntity target = targets.get(0);
        for (int i = 0; i < targets.size(); i++) {
            pick -= weights.get(i);
            if (pick <= 0) {
                target = targets.get(i);
                break;
            }
        }
        double dx = target.getX() - bot.getX();
        double dz = target.getZ() - bot.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        bot.getLookControl().setLookAt(target.getX(), target.getEyeY(), target.getZ());
        bot.setYRot((float) (Math.atan2(-dx, dz) * (180.0 / Math.PI)));
        r.ball.kickBy(bot, BallEntity.passVelocity(dx, dz, dist, bot.stats()), false);
        bot.animate("kick_pass");
        Voice.say(bot, Voices.Event.EFFORT, 0.7);
        Juice.particles(r.level, ParticleTypes.CRIT, bot.getX(), bot.getY() + 0.3, bot.getZ(), 5, 0.2, 0.05);
        r.previousHolder = bot;
        r.lastPassTick = r.ticks;
        r.holder = null;
    }

    private static void ending(MinecraftServer server, Run r, ServerPlayer player) {
        r.endingTicks++;
        // after the whistle nobody passes; whoever takes the ball is the last to touch it. Mains step away from it.
        LivingEntity carrier = r.ball.carrier();
        boolean loose = carrier == null;
        for (int i = 0; i < r.bots.size(); i++) {
            BotEntity bot = r.bots.get(i);
            double bx = r.ball.getX() - bot.getX();
            double bz = r.ball.getZ() - bot.getZ();
            double dist = Math.sqrt(bx * bx + bz * bz);
            if (isMain(bot)) {
                if (dist < 3.5) {
                    bot.runTo(bot.getX() - bx / Math.max(0.3, dist) * 3, bot.getZ() - bz / Math.max(0.3, dist) * 3, 1.0);
                }
            } else if (loose && dist < 4.0 && r.endingTicks > 20) {
                bot.runTo(r.ball.getX(), r.ball.getZ(), 0.9);
                if (dist < 1.1) {
                    r.ball.takeBy(bot);
                }
            }
        }
        carrier = r.ball.carrier();
        if (carrier != null) {
            resolve(server, r, player, carrier);
            return;
        }
        if (r.endingTicks >= ENDING_TICKS) {
            // nobody touched it: the last one who did before the whistle loses, unless that is a main; then the nearest of the four
            LivingEntity last = r.previousHolder;
            if (last == null || (last instanceof BotEntity b && isMain(b))) {
                BotEntity nearest = null;
                double best = Double.MAX_VALUE;
                for (BotEntity bot : r.bots) {
                    if (!isMain(bot) && bot.isAlive()) {
                        double d = bot.distanceToSqr(r.ball);
                        if (d < best) {
                            best = d;
                            nearest = bot;
                        }
                    }
                }
                last = nearest != null ? nearest : player;
            }
            resolve(server, r, player, last);
        }
    }

    private static void resolve(MinecraftServer server, Run r, ServerPlayer player, LivingEntity loser) {
        if (r.resolved) {
            return;
        }
        r.resolved = true;
        r.phase = Phase.DONE;
        r.doneTicks = 0;
        r.ball.release();
        r.ball.setDeltaMovement(0, 0, 0);
        Juice.shake(r.level, r.centreX, r.centreY, r.centreZ, 18, 0.9F, 14);
        if (loser == player) {
            Titles.show(player, Component.translatable("bluelock.trial.eliminated").withStyle(ChatFormatting.DARK_RED),
                    Component.translatable("bluelock.trial.you_lost"), 0, 60, 20);
            Juice.sound(r.level, player.getX(), player.getY(), player.getZ(), ModSounds.GASP, 1.0F, 0.8F);
            Juice.particles(r.level, ParticleTypes.SMOKE, player.getX(), player.getY() + 1, player.getZ(), 30, 0.5, 0.02);
            player.sendSystemMessage(Component.translatable("bluelock.trial.failed"));
            r.loserIsPlayer = true;
        } else {
            BotEntity bot = (BotEntity) loser;
            Component name = bot.getDisplayName();
            Titles.show(player, Component.translatable("bluelock.trial.eliminated").withStyle(ChatFormatting.RED), name, 0, 60, 20);
            Juice.sound(r.level, bot.getX(), bot.getY(), bot.getZ(), ModSounds.GASP, 1.0F, 0.9F);
            Juice.particles(r.level, ParticleTypes.LARGE_SMOKE, bot.getX(), bot.getY() + 1, bot.getZ(), 40, 0.5, 0.03);
            Juice.particles(r.level, ParticleTypes.FLASH, bot.getX(), bot.getY() + 1, bot.getZ(), 1, 0.0, 0.0);
            Voice.say(bot, Voices.Event.HURT, 1.0);
            player.sendSystemMessage(Component.translatable("bluelock.trial.eliminated_msg", name));
            AmbientNpcs.eliminate(bot.slotIndex());
            for (BotEntity other : r.bots) {
                if (other != bot && other.isAlive()) {
                    Voice.say(other, Voices.Event.CHEER, 0.5);
                }
            }
            player.sendSystemMessage(Component.translatable("bluelock.trial.passed"));
        }
    }

    private static void done(MinecraftServer server, Run r) {
        r.doneTicks++;
        if (r.doneTicks < 60) {
            return;
        }
        run = null;
        boolean passed = !r.loserIsPlayer;
        if (r.ball != null) {
            r.ball.discard();
        }
        AmbientNpcs.home(server);
        StoryManager.onTrialFinished(server, r.player, r.beatIndex, passed);
    }
}
