package com.bluelock.common.campus;

import java.util.ArrayList;
import java.util.List;

/**
 * The Blue Lock campus as a list of block fills, in a local frame that has nothing to do with Minecraft:
 * x grows to the right of the entrance, y up (0 is the floor surface), z grows from the front door towards the stadium.
 * The Forge side only has to map each {@link Mat} to a block and rotate the frame to wherever the player stands.
 * Original design: a black monolith with blue light strips, an entrance hall with a ranking wall, Team Z's room, a briefing
 * room, a training room, lockers, a cafeteria, the supervisor's control room, a tunnel and a stadium for 7v7 matches.
 */
public final class CampusPlan {
    public enum Mat {
        AIR, FOUND, PAVE, BLACK, GRAY, GRAY_LIGHT, FLOOR, FLOOR_DARK, GLASS, LIGHT, BLUE, CYAN, WHITE, RED, GOLD, ORANGE,
        WOOD, SLAB, BARS, IRON, WOOL_BLUE, WOOL_WHITE, SKIN
    }

    /** An inclusive box of one material. */
    public record Fill(Mat mat, int x0, int y0, int z0, int x1, int y1, int z1) {
        public long volume() {
            return (long) (x1 - x0 + 1) * (y1 - y0 + 1) * (z1 - z0 + 1);
        }
    }

    /** A spot to stand on (feet at y) and which way to look: turn 0 forward (+z), 1 right (+x), 2 back, 3 left. */
    public record Place(String id, int x, int y, int z, int turn) {
    }

    public static final int MIN_X = -92;
    public static final int MAX_X = 66;
    public static final int MIN_Z = -50;
    public static final int MAX_Z = 195;
    public static final int MIN_Y = -6;
    public static final int MAX_Y = 50;
    /** The monolith: a huge black block, this tall, with BLUE LOCK in blue on its front face. */
    public static final int BLOCK_HEIGHT = 44;

    /** The stadium pitch (PitchSize.FULL, 105 x 69, for 11v11) is centred here, along z. */
    public static final int PITCH_CENTRE_Z = 118;
    public static final int PITCH_LENGTH = 105;
    public static final int PITCH_WIDTH = 69;
    /** The small practice pitch (PitchSize.PRACTICE, 41 x 25) in front of the building runs along x and is centred here. */
    public static final int PRACTICE_CENTRE_Z = -30;
    /** The Selection Hall holds this many figures: the 300 candidates. */
    public static final int CROWD = 300;

    private static final List<Fill> FILLS = new ArrayList<>();
    private static final List<Place> PLACES = new ArrayList<>();
    private static final List<Npc> NPCS = new ArrayList<>();

    /**
     * Somebody standing in the campus: team is a team id whose roster supplies the character at this index ("" = a nameless
     * player), name is an optional custom name, turn is the way they face (see {@link Place}).
     */
    public record Npc(String team, int index, int x, int z, int turn, String name) {
    }

    private CampusPlan() {
    }

    public static List<Fill> fills() {
        return FILLS;
    }

    public static List<Place> places() {
        return PLACES;
    }

    public static List<Npc> npcs() {
        return NPCS;
    }

    public static Place place(String id) {
        for (Place p : PLACES) {
            if (p.id().equals(id)) {
                return p;
            }
        }
        return null;
    }

    public static long totalVolume() {
        long sum = 0;
        for (Fill f : FILLS) {
            sum += f.volume();
        }
        return sum;
    }

    // ---------- building the plan ----------

    private static void box(Mat m, int x0, int y0, int z0, int x1, int y1, int z1) {
        FILLS.add(new Fill(m, Math.min(x0, x1), Math.min(y0, y1), Math.min(z0, z1), Math.max(x0, x1), Math.max(y0, y1), Math.max(z0, z1)));
    }

    private static void dot(Mat m, int x, int y, int z) {
        box(m, x, y, z, x, y, z);
    }

    private static void air(int x0, int y0, int z0, int x1, int y1, int z1) {
        box(Mat.AIR, x0, y0, z0, x1, y1, z1);
    }

    private static void place(String id, int x, int z, int turn) {
        PLACES.add(new Place(id, x, 1, z, turn));
    }

    private static void build() {
        // ground: clear everything, fill holes, pave
        box(Mat.AIR, MIN_X, 1, MIN_Z, MAX_X, MAX_Y, MAX_Z);
        box(Mat.FOUND, MIN_X, MIN_Y, MIN_Z, MAX_X, -1, MAX_Z);
        box(Mat.PAVE, MIN_X, 0, MIN_Z, MAX_X, 0, MAX_Z);

        mainBuilding();
        hall();
        teamZRoom();
        briefingRoom();
        trainingRoom();
        lockerAndShowers();
        cafeteria();
        egoRoom();
        tunnel();
        stadium();
        exterior();

        selectionHall();
        annex();
        lettering();
        people();
        place("entrance", 0, -5, 0);
        place("practice_pitch", 0, -12, 0);
        place("selection_hall", -37, 7, 3);
        place("hall", 0, 4, 0);
        place("rank_wall", 0, 11, 0);
        place("team_z_room", -13, 7, 3);
        place("briefing", 13, 7, 1);
        place("training_room", 0, 19, 0);
        place("locker_room", -13, 24, 3);
        place("cafeteria", 13, 24, 1);
        place("ego_room", 13, 37, 1);
        place("dorm_v", 38, 3, 1);
        place("dorm_w", 38, 10, 1);
        place("dorm_x", 38, 17, 1);
        place("dorm_y", 38, 24, 1);
        place("analysis_room", 38, 31, 1);
        place("medical_room", 38, 38, 1);
        place("stadium_gate", 0, 53, 0);
        place("stadium", 0, PITCH_CENTRE_Z, 0);
    }

    private static void npc(String team, int index, int x, int z, int turn) {
        NPCS.add(new Npc(team, index, x, z, turn, ""));
    }

    /** Who is standing where: Team Z in its room, rivals and nameless players in the hall, the rooms and the training room. */
    private static void people() {
        int[][] teamZ = {{-22, 3}, {-19, 3}, {-16, 3}, {-14, 3}, {-22, 6}, {-19, 6}, {-15, 6}, {-14, 10}, {-22, 10}, {-14, 12}, {-26, 12}};
        for (int i = 0; i < teamZ.length; i++) {
            npc("team_z", i, teamZ[i][0], teamZ[i][1], 1);
        }
        int[] hallZ = {3, 6, 10, 14, 18, 22, 26, 30};
        String[] hallTeams = {"team_v", "team_v", "team_x", "", "", "team_y", "", ""};
        int[] hallIndex = {0, 1, 0, 0, 1, 0, 2, 3};
        for (int i = 0; i < hallZ.length; i++) {
            npc(hallTeams[i], hallIndex[i], i % 2 == 0 ? -39 : -37, hallZ[i], 3);
        }
        npc("", 4, 14, 21, 2);
        npc("", 5, 19, 22, 1);
        npc("team_y", 1, 24, 26, 3);
        npc("", 6, 14, 27, 0);
        npc("", 7, -6, 24, 0);
        npc("", 8, 5, 27, 0);
        npc("", 9, -3, 33, 0);
        npc("", 10, 2, 36, 0);
        int[][] rooms = {{3, 0}, {10, 0}, {17, 0}, {24, 0}};
        String[] teams = {"team_v", "team_w", "team_x", "team_y"};
        for (int r = 0; r < 4; r++) {
            int z = rooms[r][0];
            npc(teams[r], 0, 44, z + 1, 1);
            npc(teams[r], 1, 48, z + 2, 1);
            npc(teams[r], 2, 55, z + 1, 1);
        }
        npc("", 11, 47, 32, 1);
        npc("", 12, 51, 32, 1);
        npc("", 13, 46, 38, 1);
        NPCS.add(new Npc("", 14, 22, 36, 1, "Jinpachi Ego"));
    }

    private static void mainBuilding() {
        box(Mat.BLACK, -30, 0, 0, 30, BLOCK_HEIGHT, 43);   // one huge black block; the rooms are carved out of it
    }

    private static void hall() {
        air(-10, 1, 1, 10, 13, 15);
        box(Mat.FLOOR, -10, 0, 1, 10, 0, 15);
        box(Mat.BLUE, -1, 0, 1, 1, 0, 15);           // a blue carpet from the door to the wall
        air(-3, 1, 0, 3, 6, 0);                      // the front door
        // the ranking wall: a grid of grey blocks, a gold line on top, and a red row for the last block of eleven
        for (int x = -6; x <= 6; x++) {
            for (int y = 2; y <= 12; y++) {
                dot(((x + y) & 1) == 0 ? Mat.GRAY : Mat.GRAY_LIGHT, x, y, 15);
            }
        }
        box(Mat.GOLD, -6, 12, 15, 6, 12, 15);
        box(Mat.RED, -5, 2, 15, 5, 2, 15);
        box(Mat.LIGHT, -6, 1, 15, 6, 1, 15);
        air(-9, 1, 16, -7, 4, 16);                   // two doorways into the training room
        air(7, 1, 16, 9, 4, 16);
        for (int x = -8; x <= 8; x += 4) {            // ceiling lights
            for (int z = 3; z <= 13; z += 5) {
                dot(Mat.LIGHT, x, 14, z);
            }
        }
    }

    private static void teamZRoom() {
        air(-29, 1, 1, -12, 6, 13);
        box(Mat.FLOOR_DARK, -29, 0, 1, -12, 0, 13);
        air(-11, 1, 6, -11, 4, 8);                   // door from the hall
        air(-31, 1, 6, -30, 4, 8);                   // door west, to the Selection Hall
        for (int i = 0; i < 7; i++) {                // eleven beds: six along the wall (the door takes one place), five in a second row
            if (i == 3) {
                continue;
            }
            box(Mat.WOOL_BLUE, -29, 1, 1 + i * 2, -28, 1, 1 + i * 2);
            dot(Mat.WOOL_WHITE, -29, 1, 1 + i * 2);
        }
        for (int i = 0; i < 5; i++) {
            box(Mat.WOOL_BLUE, -25, 1, 1 + i * 2, -24, 1, 1 + i * 2);
            dot(Mat.WOOL_WHITE, -25, 1, 1 + i * 2);
        }
        box(Mat.WOOD, -20, 1, 9, -17, 1, 12);        // a long table with stools
        box(Mat.SLAB, -21, 1, 9, -21, 1, 12);
        box(Mat.SLAB, -16, 1, 9, -16, 1, 12);
        // a big blue Z on the far wall
        box(Mat.CYAN, -22, 6, 13, -18, 6, 13);
        box(Mat.CYAN, -22, 2, 13, -18, 2, 13);
        for (int i = 0; i < 3; i++) {
            dot(Mat.CYAN, -19 - i, 3 + i, 13);
        }
        for (int x = -28; x <= -14; x += 5) {
            for (int z = 3; z <= 11; z += 4) {
                dot(Mat.LIGHT, x, 7, z);
            }
        }
    }

    private static void briefingRoom() {
        air(12, 1, 1, 29, 6, 13);
        box(Mat.FLOOR_DARK, 12, 0, 1, 29, 0, 13);
        air(11, 1, 6, 11, 4, 8);
        box(Mat.BLACK, 29, 2, 2, 29, 5, 12);         // the big screen on the east wall
        box(Mat.CYAN, 29, 2, 2, 29, 2, 12);
        box(Mat.CYAN, 29, 5, 2, 29, 5, 12);
        box(Mat.LIGHT, 29, 3, 7, 29, 4, 7);
        for (int x = 17; x <= 23; x += 3) {          // rows of seats facing the screen
            box(Mat.SLAB, x, 1, 3, x, 1, 5);
            box(Mat.SLAB, x, 1, 9, x, 1, 11);
        }
        for (int x = 15; x <= 27; x += 6) {
            for (int z = 3; z <= 11; z += 4) {
                dot(Mat.LIGHT, x, 7, z);
            }
        }
    }

    private static void trainingRoom() {
        air(-10, 1, 17, 10, 8, 41);
        box(Mat.FLOOR_DARK, -10, 0, 17, 10, 0, 41);
        for (int x = -10; x <= 10; x += 5) {
            box(Mat.BLUE, x, 0, 17, x, 0, 41);
        }
        for (int z = 20; z <= 40; z += 5) {
            box(Mat.BLUE, -10, 0, z, 10, 0, z);
        }
        // a target wall: a bullseye on a goal-sized frame
        box(Mat.WHITE, -4, 1, 41, 4, 4, 41);
        box(Mat.RED, -3, 1, 41, 3, 3, 41);
        box(Mat.WHITE, -2, 1, 41, 2, 3, 41);
        box(Mat.RED, -1, 2, 41, 1, 2, 41);
        // cones for dribbling, in a zigzag
        for (int i = 0; i < 6; i++) {
            dot(Mat.ORANGE, i % 2 == 0 ? -3 : 3, 1, 22 + i * 2);
        }
        // an agility ladder painted on the floor
        for (int z = 20; z <= 34; z += 2) {
            box(Mat.WHITE, -8, 0, z, -6, 0, z);
        }
        box(Mat.WHITE, -8, 0, 20, -8, 0, 34);
        box(Mat.WHITE, -6, 0, 20, -6, 0, 34);
        // treadmills along the east wall, a mirror above them, weights at the back
        for (int i = 0; i < 4; i++) {
            box(Mat.SLAB, 7, 1, 20 + i * 4, 8, 1, 22 + i * 4);
            box(Mat.BARS, 9, 2, 20 + i * 4, 9, 3, 22 + i * 4);
        }
        box(Mat.GLASS, 10, 2, 24, 10, 5, 38);
        for (int z = 36; z <= 40; z += 2) {
            dot(Mat.IRON, -9, 1, z);
            dot(Mat.GRAY, -8, 1, z);
        }
        for (int x = -8; x <= 8; x += 4) {
            for (int z = 19; z <= 39; z += 5) {
                dot(Mat.LIGHT, x, 9, z);
            }
        }
    }

    private static void lockerAndShowers() {
        air(-29, 1, 18, -12, 6, 30);
        box(Mat.FLOOR, -29, 0, 18, -12, 0, 30);
        air(-11, 1, 22, -11, 4, 24);                 // door from the training room
        for (int z = 19; z <= 29; z += 2) {          // lockers along the west wall
            box(Mat.GRAY, -29, 1, z, -29, 3, z);
        }
        box(Mat.WOOD, -26, 1, 20, -26, 1, 28);       // a long bench
        box(Mat.WOOD, -20, 1, 20, -20, 1, 28);
        air(-29, 1, 32, -12, 6, 41);                 // showers
        box(Mat.FLOOR, -29, 0, 32, -12, 0, 41);
        air(-22, 1, 31, -20, 4, 31);
        for (int x = -28; x <= -14; x += 3) {
            box(Mat.GLASS, x, 1, 41, x, 3, 41);
            dot(Mat.BARS, x, 4, 40);
        }
        for (int x = -26; x <= -14; x += 6) {
            dot(Mat.LIGHT, x, 7, 24);
            dot(Mat.LIGHT, x, 7, 37);
        }
    }

    private static void cafeteria() {
        air(12, 1, 18, 29, 6, 30);
        box(Mat.FLOOR, 12, 0, 18, 29, 0, 30);
        air(11, 1, 22, 11, 4, 24);
        for (int x = 16; x <= 26; x += 5) {          // tables
            for (int z = 20; z <= 28; z += 4) {
                box(Mat.WOOD, x, 1, z, x + 1, 1, z + 1);
            }
        }
        box(Mat.WHITE, 29, 1, 19, 29, 2, 27);        // a serving counter along the east wall
        box(Mat.SLAB, 28, 2, 19, 28, 2, 27);
        air(30, 1, 29, 31, 4, 30);                   // a door east, to the dormitory wing
        for (int x = 14; x <= 26; x += 6) {
            dot(Mat.LIGHT, x, 7, 22);
            dot(Mat.LIGHT, x, 7, 28);
        }
    }

    private static void egoRoom() {
        air(12, 1, 32, 29, 6, 41);
        box(Mat.FLOOR_DARK, 12, 0, 32, 29, 0, 41);
        air(19, 1, 31, 21, 4, 31);
        box(Mat.BLACK, 29, 2, 33, 29, 5, 40);        // a wall of screens
        box(Mat.CYAN, 29, 2, 33, 29, 2, 40);
        box(Mat.CYAN, 29, 5, 33, 29, 5, 40);
        for (int z = 34; z <= 39; z += 2) {
            dot(Mat.LIGHT, 29, 3, z);
            dot(Mat.GOLD, 29, 4, z);
        }
        box(Mat.BLACK, 24, 1, 35, 26, 1, 38);        // a control desk
        box(Mat.GOLD, 24, 2, 35, 26, 2, 35);
        for (int x = 15; x <= 27; x += 6) {
            dot(Mat.LIGHT, x, 7, 36);
        }
    }

    private static void tunnel() {
        box(Mat.BLACK, -4, 0, 44, 4, 6, 57);
        air(-2, 1, 42, 2, 4, 57);
        box(Mat.FLOOR_DARK, -2, 0, 42, 2, 0, 57);
        for (int z = 44; z <= 56; z += 4) {
            dot(Mat.LIGHT, -2, 5, z);
            dot(Mat.LIGHT, 2, 5, z);
            dot(Mat.CYAN, -3, 3, z);
            dot(Mat.CYAN, 3, 3, z);
        }
        box(Mat.GOLD, -2, 5, 57, 2, 5, 57);          // a gold bar above the mouth
    }

    private static void stadium() {
        // low boards around the pitch, with a gap at the tunnel mouth
        box(Mat.BLUE, -47, 1, 59, -5, 2, 59);
        box(Mat.BLUE, 5, 1, 59, 47, 2, 59);
        box(Mat.LIGHT, -47, 2, 59, -5, 2, 59);
        box(Mat.LIGHT, 5, 2, 59, 47, 2, 59);
        for (int s = -1; s <= 1; s += 2) {
            box(Mat.BLUE, s * 37, 1, 60, s * 37, 2, 176);
            box(Mat.LIGHT, s * 37, 2, 60, s * 37, 2, 176);
            for (int k = 0; k < 10; k++) {           // stepped seats along both touchlines
                if (k > 0) {
                    box(Mat.GRAY, s * (38 + k), 1, 60, s * (38 + k), k, 176);
                }
                box(k % 2 == 0 ? Mat.BLUE : Mat.WHITE, s * (38 + k), k + 1, 60, s * (38 + k), k + 1, 176);
            }
            box(Mat.BLACK, s * 48, 1, 59, s * 48, 15, 186);
        }
        for (int k = 0; k < 8; k++) {                // the far end
            if (k > 0) {
                box(Mat.GRAY, -47, 1, 177 + k, 47, k, 177 + k);
            }
            box(k % 2 == 0 ? Mat.BLUE : Mat.WHITE, -47, k + 1, 177 + k, 47, k + 1, 177 + k);
        }
        box(Mat.BLACK, -48, 1, 185, 48, 19, 185);
        // floodlights in the four corners
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int z : new int[] {62, 182}) {
                box(Mat.BARS, sx * 50, 1, z, sx * 50, 17, z);
                dot(Mat.IRON, sx * 50, 1, z);
                box(Mat.LIGHT, sx * 50 - 1, 18, z - 1, sx * 50 + 1, 19, z + 1);
            }
        }
        // the gate in the near-end boards, in front of the tunnel
        box(Mat.GOLD, -5, 2, 59, -5, 4, 59);
        box(Mat.GOLD, 5, 2, 59, 5, 4, 59);
    }

    /** The Selection Hall: where the 300 candidates stand in rows in front of the supervisor's giant screen. */
    private static void selectionHall() {
        box(Mat.BLACK, -33, 0, 4, -31, 6, 10);       // a short corridor from Team Z's room
        air(-33, 1, 6, -31, 4, 8);
        box(Mat.BLACK, -84, 0, 0, -34, 16, 36);
        air(-83, 1, 1, -35, 15, 35);
        air(-34, 1, 6, -34, 4, 8);
        box(Mat.FLOOR_DARK, -83, 0, 1, -35, 0, 35);
        box(Mat.BLUE, -41, 0, 6, -35, 0, 8);
        for (int x = -78; x <= -40; x += 6) {
            for (int z = 4; z <= 34; z += 6) {
                dot(Mat.LIGHT, x, 16, z);
            }
        }
        // the giant screen on the west wall: a black panel with a cyan frame and a pair of gold lenses
        box(Mat.BLACK, -83, 3, 4, -83, 14, 32);
        box(Mat.CYAN, -83, 3, 4, -83, 3, 32);
        box(Mat.CYAN, -83, 14, 4, -83, 14, 32);
        box(Mat.CYAN, -83, 3, 4, -83, 14, 4);
        box(Mat.CYAN, -83, 3, 32, -83, 14, 32);
        box(Mat.GOLD, -83, 8, 9, -83, 11, 14);
        box(Mat.GOLD, -83, 8, 22, -83, 11, 27);
        box(Mat.GOLD, -83, 10, 15, -83, 10, 21);
        box(Mat.LIGHT, -83, 5, 13, -83, 5, 23);
        // the candidates: 20 columns by 15 rows of figures, four blocks tall (legs, shirt, head, hair)
        Mat[] shirts = {Mat.BLUE, Mat.WHITE, Mat.RED, Mat.GRAY_LIGHT, Mat.CYAN, Mat.ORANGE};
        Mat[] hairs = {Mat.BLACK, Mat.BLACK, Mat.GRAY, Mat.ORANGE, Mat.WHITE, Mat.GOLD, Mat.BLACK};
        for (int col = 0; col < 20; col++) {
            for (int row = 0; row < 15; row++) {
                int x = -80 + col * 2;
                int z = 3 + row * 2;
                int h = col * 5 + row * 3 + (col * row) % 4;
                dot(Mat.BLACK, x, 1, z);
                dot(shirts[h % shirts.length], x, 2, z);
                dot(Mat.SKIN, x, 3, z);
                dot(hairs[(h / 2) % hairs.length], x, 4, z);
            }
        }
    }

    /** The dormitory wing: a corridor with a room each for Teams V, W, X and Y, an analysis room and a medical room. */
    private static void annex() {
        box(Mat.BLACK, 31, 0, 0, 61, 9, 43);
        air(32, 1, 1, 35, 6, 41);
        air(30, 1, 29, 31, 4, 30);                   // the door from the cafeteria
        box(Mat.FLOOR, 32, 0, 1, 35, 0, 41);
        for (int z = 4; z <= 40; z += 9) {
            dot(Mat.LIGHT, 33, 7, z);
            dot(Mat.LIGHT, 34, 7, z);
        }
        int[][] rooms = {{1, 6}, {8, 13}, {15, 20}, {22, 27}, {29, 34}, {36, 41}};
        Mat[] banner = {Mat.RED, Mat.CYAN, Mat.ORANGE, Mat.WHITE};
        for (int i = 0; i < rooms.length; i++) {
            int a = rooms[i][0];
            int b = rooms[i][1];
            int mid = (a + b) / 2;
            air(37, 1, a, 60, 6, b);
            box(i == 5 ? Mat.WHITE : Mat.FLOOR_DARK, 37, 0, a, 60, 0, b);
            air(36, 1, mid, 36, 4, mid + 1);
            for (int x = 40; x <= 58; x += 6) {
                dot(Mat.LIGHT, x, 7, mid);
            }
            if (i < 4) {
                for (int x = 38; x <= 50; x += 4) {  // six beds, three along each long wall
                    box(Mat.WOOL_BLUE, x, 1, a, x + 1, 1, a);
                    dot(Mat.WOOL_WHITE, x, 1, a);
                    box(Mat.WOOL_BLUE, x, 1, b, x + 1, 1, b);
                    dot(Mat.WOOL_WHITE, x, 1, b);
                }
                box(banner[i], 60, 2, mid - 1, 60, 5, mid + 2);   // the team's colour on the far wall
                box(Mat.GOLD, 60, 6, mid - 1, 60, 6, mid + 2);
            } else if (i == 4) {                    // analysis: seats facing a wall of screens
                box(Mat.BLACK, 60, 2, a, 60, 5, b);
                box(Mat.CYAN, 60, 2, a, 60, 2, b);
                box(Mat.CYAN, 60, 5, a, 60, 5, b);
                box(Mat.LIGHT, 60, 3, mid - 1, 60, 4, mid + 1);
                for (int x = 45; x <= 53; x += 4) {
                    box(Mat.SLAB, x, 1, a + 1, x, 1, b - 1);
                }
            } else {                                // medical: white beds and a red cross
                for (int x = 40; x <= 52; x += 4) {
                    box(Mat.WOOL_WHITE, x, 1, a, x + 1, 1, a);
                    box(Mat.WOOL_WHITE, x, 1, b, x + 1, 1, b);
                }
                box(Mat.RED, 60, 3, mid - 1, 60, 3, mid + 2);
                box(Mat.RED, 60, 2, mid, 60, 4, mid + 1);
            }
        }
    }

    private static final String[][] GLYPHS = {
            {"XX.", "X.X", "XX.", "X.X", "XX."},   // B
            {"X..", "X..", "X..", "X..", "XXX"},   // L
            {"X.X", "X.X", "X.X", "X.X", "XXX"},   // U
            {"XXX", "X..", "XX.", "X..", "XXX"},   // E
            {"XXX", "X.X", "X.X", "X.X", "XXX"},   // O
            {"XXX", "X..", "X..", "X..", "XXX"},   // C
            {"X.X", "X.X", "XX.", "X.X", "X.X"}    // K
    };

    /** "BLUE LOCK" in big gold letters on the back wall of the stadium, facing the pitch. */
    private static void lettering() {
        text("BLUE LOCK", Mat.GOLD, -36, 19, 185, 2, 2);
    }

    /** Draws text (letters of BLUOCK only) on the plane z, left edge x, top row yTop, each cell scale blocks wide. */
    private static void text(String text, Mat mat, int x, int yTop, int z, int scale, int gap) {
        String order = "BLUEOCK";
        for (char c : text.toCharArray()) {
            if (c != ' ') {
                String[] glyph = GLYPHS[order.indexOf(c)];
                for (int row = 0; row < 5; row++) {
                    for (int col = 0; col < 3; col++) {
                        if (glyph[row].charAt(col) == 'X') {
                            box(mat, x + col * scale, yTop - row * scale - (scale - 1), z, x + col * scale + scale - 1, yTop - row * scale, z);
                        }
                    }
                }
            }
            x += 3 * scale + gap;
        }
    }

    private static void exterior() {
        for (int x : new int[] {-30, -20, -12, 12, 20, 30}) {   // blue light strips on the front of the monolith
            box(Mat.CYAN, x, 1, 0, x, 9, 0);
        }
        box(Mat.CYAN, -30, BLOCK_HEIGHT, 0, 30, BLOCK_HEIGHT, 0);
        for (int x : new int[] {-30, 30}) {                     // glowing edges up the corners of the block
            box(Mat.CYAN, x, 10, 0, x, BLOCK_HEIGHT, 0);
        }
        // BLUE LOCK in big blue letters on the front face: BLUE on top, LOCK below, each line underlined with light
        text("BLUE", Mat.BLUE, -22, 43, 0, 3, 3);
        text("LOCK", Mat.BLUE, -22, 23, 0, 3, 3);
        box(Mat.LIGHT, -24, 26, 0, 24, 26, 0);
        box(Mat.LIGHT, -24, 8, 0, 24, 8, 0);
        for (int x : new int[] {-27, -18, 16, 24}) {            // windows
            box(Mat.GLASS, x, 3, 0, x + 2, 4, 0);
        }
        for (int z : new int[] {3, 9}) {
            box(Mat.GLASS, -30, 3, z, -30, 4, z + 2);
            box(Mat.GLASS, 30, 3, z, 30, 4, z + 2);
        }
        box(Mat.GRAY_LIGHT, -4, 0, -4, 4, 0, -1);               // a plaza in front of the door
    }

    static {
        build();
    }
}
