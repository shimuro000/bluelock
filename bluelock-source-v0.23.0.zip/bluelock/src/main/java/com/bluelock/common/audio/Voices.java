package com.bluelock.common.audio;

import java.util.Map;

/**
 * Who sounds like what (no Minecraft code). There are six synthesised voice types and ten kinds of vocal sound.
 * Every character gets one type, nameless bots and players get one from their look, and a cooldown keeps anybody
 * from shouting on every touch.
 */
public final class Voices {
    public static final String[] TYPES = {"deep_calm", "deep_fierce", "mid_calm", "mid_bold", "high_playful", "high_sharp"};

    /** The kinds of vocal sound. The name is also the file name suffix: voice_&lt;type&gt;_&lt;event&gt;.ogg */
    public enum Event {
        EFFORT(30, 0.55F),    // a small push of air on a pass or a touch
        SHOT(25, 0.9F),       // a shout on a shot
        POWER(60, 1.2F),      // the big roar of an awakening or Dragon Drive
        SKILL(40, 0.8F),      // a short call on a dribble or a technique
        TACKLE(30, 0.8F),     // a grunt on a tackle or a charge
        GOAL(80, 1.2F),       // the celebration
        HURT(40, 0.7F),       // lost the ball, knocked over
        TAUNT(120, 0.8F),     // an ego laugh
        TALK(6, 0.45F),       // a short syllable: dialogue babble and chatter in the rooms
        CHEER(60, 1.0F);      // a short cheer: a win, a rank up, somebody saved

        /** Ticks the same speaker stays quiet after making this sound. */
        public final int cooldown;
        public final float volume;

        Event(int cooldown, float volume) {
            this.cooldown = cooldown;
            this.volume = volume;
        }

        public String fileName(int type) {
            return "voice_" + TYPES[type] + "_" + name().toLowerCase(java.util.Locale.ROOT);
        }
    }

    private static final Map<String, Integer> BY_CHARACTER = Map.ofEntries(
            Map.entry("isagi", 3), Map.entry("bachira", 4), Map.entry("kunigami", 0), Map.entry("chigiri", 2),
            Map.entry("raichi", 1), Map.entry("gagamaru", 0), Map.entry("kuon", 2), Map.entry("igarashi", 1),
            Map.entry("baro", 1), Map.entry("nagi", 2), Map.entry("reo", 3), Map.entry("hiori", 2),
            Map.entry("aryu", 5), Map.entry("nanase", 4), Map.entry("rin", 5), Map.entry("shidou", 4),
            Map.entry("kaiser", 1), Map.entry("sae", 2), Map.entry("noa", 0), Map.entry("otoya", 4),
            Map.entry("tokimitsu", 2), Map.entry("aiku", 3), Map.entry("ikki", 1), Map.entry("zantetsu", 3),
            Map.entry("naruhaya", 2), Map.entry("iemon", 0), Map.entry("imamura", 3), Map.entry("junichi", 3),
            Map.entry("keisuke", 4), Map.entry("meiji", 4), Map.entry("sanga", 3), Map.entry("banku", 1), Map.entry("okawa", 2));

    private Voices() {
    }

    /** The voice type of a named character, or -1 when the id has no voice of its own. */
    public static int ofCharacter(String id) {
        Integer type = BY_CHARACTER.get(id);
        return type == null ? -1 : type;
    }

    /** A voice for somebody without an assigned one: tall and broad sounds deeper, small sounds higher; the seed picks the mood. */
    public static int fromLook(int height, int build, int seed) {
        int pitchBand = height >= 62 ? 0 : height <= 36 ? 2 : 1;
        boolean bold = Math.floorMod(seed, 2) == 1 || build > 70;
        return pitchBand * 2 + (bold ? 1 : 0);
    }

    /** Pitch multiplier for one sound: a tiny random change so repeats do not sound identical. */
    public static float pitch(int type, double random01) {
        float base = switch (type / 2) {
            case 0 -> 0.92F;
            case 1 -> 1.0F;
            default -> 1.08F;
        };
        return base * (0.96F + (float) random01 * 0.08F);
    }

    /** True when a speaker whose last sound was at lastTick may make this one at now. */
    public static boolean mayAct(long lastTick, long now, Event event) {
        return now - lastTick >= event.cooldown;
    }
}
