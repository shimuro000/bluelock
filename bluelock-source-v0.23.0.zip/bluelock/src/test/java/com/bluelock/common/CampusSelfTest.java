package com.bluelock.common;

import com.bluelock.common.campus.CampusPlan;
import com.bluelock.common.campus.CampusPlan.Fill;
import com.bluelock.common.campus.CampusPlan.Mat;
import com.bluelock.common.campus.CampusPlan.Place;
import java.util.ArrayDeque;

/** The campus plan: every place is standable, every place can be walked to from the front gate, nothing is buried. */
public final class CampusSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    private static final int SX = CampusPlan.MAX_X - CampusPlan.MIN_X + 1;
    private static final int SY = CampusPlan.MAX_Y - CampusPlan.MIN_Y + 1;
    private static final int SZ = CampusPlan.MAX_Z - CampusPlan.MIN_Z + 1;

    private static int idx(int x, int y, int z) {
        return ((x - CampusPlan.MIN_X) * SY + (y - CampusPlan.MIN_Y)) * SZ + (z - CampusPlan.MIN_Z);
    }

    private static boolean inside(int x, int y, int z) {
        return x >= CampusPlan.MIN_X && x <= CampusPlan.MAX_X && y >= CampusPlan.MIN_Y && y <= CampusPlan.MAX_Y
                && z >= CampusPlan.MIN_Z && z <= CampusPlan.MAX_Z;
    }

    public static void main(String[] args) {
        Mat[] grid = new Mat[SX * SY * SZ];
        for (Fill f : CampusPlan.fills()) {
            boolean ok = inside(f.x0(), f.y0(), f.z0()) && inside(f.x1(), f.y1(), f.z1());
            if (!ok) {
                check(false, "fill inside the campus box: " + f);
                continue;
            }
            for (int x = f.x0(); x <= f.x1(); x++) {
                for (int y = f.y0(); y <= f.y1(); y++) {
                    for (int z = f.z0(); z <= f.z1(); z++) {
                        grid[idx(x, y, z)] = f.mat();
                    }
                }
            }
        }
        check(CampusPlan.places().size() >= 10, "the campus has places");
        boolean stand = true;
        for (Place p : CampusPlan.places()) {
            Mat feet = grid[idx(p.x(), p.y(), p.z())];
            Mat head = grid[idx(p.x(), p.y() + 1, p.z())];
            Mat floor = grid[idx(p.x(), p.y() - 1, p.z())];
            boolean ok = feet == Mat.AIR && head == Mat.AIR && floor != Mat.AIR && floor != null && floor != Mat.GLASS;
            if (!ok) {
                System.out.println("  cannot stand at " + p + ": " + floor + "/" + feet + "/" + head);
            }
            stand &= ok;
        }
        check(stand, "every place has air for feet and head and a floor below");

        boolean npcOk = true;
        java.util.Set<String> spots = new java.util.HashSet<>();
        for (CampusPlan.Npc n : CampusPlan.npcs()) {
            boolean ok = grid[idx(n.x(), 1, n.z())] == Mat.AIR && grid[idx(n.x(), 2, n.z())] == Mat.AIR
                    && grid[idx(n.x(), 0, n.z())] != Mat.AIR && grid[idx(n.x(), 0, n.z())] != Mat.GLASS && spots.add(n.x() + "," + n.z());
            if (!ok) System.out.println("  bad NPC spot " + n);
            npcOk &= ok;
        }
        check(npcOk && CampusPlan.npcs().size() >= 40, "every NPC has a free spot of its own (" + CampusPlan.npcs().size() + ")");
        int teamZCount = 0;
        for (CampusPlan.Npc n : CampusPlan.npcs()) if (n.team().equals("team_z")) teamZCount++;
        check(teamZCount == 11, "eleven Team Z members stand in their room");
        // the big block: black all the way up, with blue letters on the front face
        int blue = 0;
        for (int x = -30; x <= 30; x++) for (int y = 8; y <= CampusPlan.BLOCK_HEIGHT; y++) if (grid[idx(x, y, 0)] == Mat.BLUE) blue++;
        check(grid[idx(0, CampusPlan.BLOCK_HEIGHT - 1, 10)] == Mat.BLACK && blue > 150, "the campus is one big block with BLUE LOCK in blue on it (" + blue + " blue blocks)");

        // flood fill on foot (two blocks of clearance, no climbing) from the front of the building
        boolean[] seen = new boolean[grid.length];
        ArrayDeque<int[]> queue = new ArrayDeque<>();
        Place start = CampusPlan.place("entrance");
        queue.add(new int[] {start.x(), 1, start.z()});
        seen[idx(start.x(), 1, start.z())] = true;
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        while (!queue.isEmpty()) {
            int[] c = queue.poll();
            for (int[] d : dirs) {
                int x = c[0] + d[0];
                int z = c[2] + d[1];
                if (!inside(x, 2, z)) continue;
                if (grid[idx(x, 1, z)] != Mat.AIR || grid[idx(x, 2, z)] != Mat.AIR) continue;
                if (seen[idx(x, 1, z)]) continue;
                seen[idx(x, 1, z)] = true;
                queue.add(new int[] {x, 1, z});
            }
        }
        boolean reach = true;
        for (Place p : CampusPlan.places()) {
            boolean r = seen[idx(p.x(), 1, p.z())];
            if (!r) System.out.println("  cannot walk to " + p.id());
            reach &= r;
        }
        check(reach, "every place can be walked to from the entrance");
        int crowd = 0;
        for (int x = -90; x <= -35; x++) {
            for (int z = 1; z <= 35; z++) {
                if (grid[idx(x, 3, z)] == Mat.SKIN) crowd++;
            }
        }
        check(crowd == CampusPlan.CROWD, "the Selection Hall holds exactly 300 candidates (" + crowd + ")");
        check(CampusPlan.PITCH_LENGTH == 105 && CampusPlan.PITCH_WIDTH == 69, "the stadium pitch is full size for 11v11");
        check(CampusPlan.place("stadium_gate") != null && CampusPlan.place("training_room") != null && CampusPlan.place("team_z_room") != null,
                "the places the story needs exist");
        System.out.println("  campus volume " + CampusPlan.totalVolume() + " blocks in " + CampusPlan.fills().size() + " fills");
        System.out.println(failures == 0 ? "ALL CAMPUS TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
