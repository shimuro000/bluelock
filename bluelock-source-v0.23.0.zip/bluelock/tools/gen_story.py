#!/usr/bin/env python3
"""Generates the story chapter: common/story/StoryChapter1.java (structure) and the bluelock.story.* keys of en_us.json
(the text) from ONE script, so they cannot disagree.   Run:  python3 tools/gen_story.py

All dialogue is original writing that follows the shape of Season 1's First Selection. The player is a new member of
Team Z (not Isagi), so this is "your" version of the story. %s in a line is the player's name.
Speakers: narrator, ego, player, or a character id from the roster.
Arabic falls back to English for the story text (Minecraft does this itself when a key is missing in ar_sa).
"""
import json
import os

ROOT = os.path.join(os.path.dirname(__file__), "..")
JAVA = os.path.join(ROOT, "src/main/java/com/bluelock/common/story/StoryChapter1.java")
LANG = os.path.join(ROOT, "src/main/resources/assets/bluelock/lang/en_us.json")

# Beat tuple: ("scene", id, title, [(speaker, text), ...])
#             ("match", id, title, opponent team id, minutes, objective, xp, skill points, dev points, briefing)
CHAPTER = [
    ("scene", "arrival", "A hall of three hundred", [
        ("narrator", "A letter, a bus, a locked gate. Now a hall so large that three hundred voices bounce off its walls."),
        ("player", "Three hundred of us, and every one is here for the same reason."),
        ("narrator", "A giant screen lights up. A man's face fills it, two gold lenses burning where his eyes should be."),
        ("ego", "Welcome to Blue Lock. Japan has never won a World Cup, and I know why: it has never had a striker hungry enough."),
        ("ego", "A team does not need eleven polite players. It needs one man who ends the game. Here, three hundred of you will fight to become him."),
        ("ego", "I am Jinpachi Ego. I will teach you, and I will not be kind about it."),
        ("narrator", "Row after row, the candidates stare up at the screen. %s stands somewhere near the back."),
    ]),
    ("scene", "team_z", "Team Z", [
        ("narrator", "The wall lists three hundred names. %s is down in the last block of eleven: Team Z."),
        ("narrator", "Team Z's room is a bare white box with twelve bunks. It smells of fresh paint and nerves. Eleven of the lowest ranked players in the building."),
        ("isagi", "You are in Z too? Then we are in the same boat. I am Isagi. Eleven of us and not one chance on paper, so we should play like we have one."),
        ("bachira", "Finally, somebody new! Do you dribble? I dribble. There is a monster in me and it wants to play."),
        ("chigiri", "Last place, and I still outrun every one of them. When it matters, give me the ball and a gap."),
        ("kunigami", "I am not here to be friends. I am here to score. Put the ball in the box and I will do the rest."),
        ("raichi", "Do not let them see you shake. A hungry team has the sharpest teeth."),
        ("gagamaru", "I am big. I am very big. Please call me whenever you need somebody to stand in the way."),
        ("player", "Then let us give this building something to look at."),
    ]),
    ("scene", "trial_rules", "The first lesson", [
        ("narrator", "A hush falls. Ego's voice fills Team Z's room from a speaker above the door. A single ball sits on the floor."),
        ("ego", "Twelve of you in this room, and one ball. The lowest ranked player starts with it. That is you, %s."),
        ("ego", "Pass it, hold it, steal it. When the timer reaches zero, the last player to touch the ball loses. He loses his place in Blue Lock, forever."),
        ("isagi", "One ball and twelve players. Someone is leaving this room tonight."),
        ("bachira", "Then let us make sure it is not us!"),
        ("player", "Then I will make sure the ball is never in my feet when the clock hits zero."),
    ]),
    ("trial", "oni", "Trial: the last touch", 45, 120, 1, 1,
     "Twelve players, one ball, starting with you. When the timer hits zero the last one to touch the ball is eliminated. Do not be him."),
    ("scene", "after_trial", "Who is left", [
        ("narrator", "The ball rolls to a stop. One player stands very still, then walks out through the door without a word."),
        ("ego", "One of you is gone. The rest are still hungry. Good."),
        ("ego", "Your rank is on the wall. Learn to read it, because it will not stay the same. Tomorrow the First Selection begins."),
    ]),
    ("scene", "rules", "The First Selection", [
        ("ego", "The First Selection is five teams in one league: Z, V, W, X and Y. Everyone plays everyone. The weakest results go home."),
        ("ego", "Your rank decides what you eat. Win, and the cafeteria serves you better. Lose, and you eat what is left."),
        ("isagi", "Eleven players, one pitch, a few minutes. We fight for the spot together."),
        ("narrator", "The stadium is ready. Team X is first."),
    ]),
    ("match", "x", "Match 1: Team X", "team_x", 3, "SCORE", 150, 2, 1, "Team X is built around one striker. Beating them is a lot to ask. Score at least one goal to show Blue Lock that Team Z can bite."),
    ("scene", "after_x", "A loss that taught something", [
        ("narrator", "The final whistle is not kind. Team X's striker walks through the box like it belongs to him."),
        ("baro", "I am the king of this pitch. Everyone who wants the ball has to go through me first."),
        ("kunigami", "We got one in. I want more next time."),
        ("isagi", "He never once looked at where we were. That is a weakness. If we read the pitch faster than he does, there is a crack."),
        ("bachira", "Cracks are my favourite thing! Let us find one."),
    ]),
    ("match", "y", "Match 2: Team Y", "team_y", 3, "WIN", 200, 2, 1, "Team Y wants to hold you off. Play quicker than they can mark you and win."),
    ("scene", "after_y", "First win", [
        ("narrator", "A win. It is small and loud and it feels like the first window opening in a closed room."),
        ("chigiri", "That was only speed and a gap. Imagine what we do with a plan."),
        ("gagamaru", "My knees were shaking the whole time. But I kept standing."),
        ("isagi", "Good. Now we are a team that has something to lose, and that is when people get dangerous."),
    ]),
    ("match", "v", "Match 3: Team V", "team_v", 3, "WIN", 250, 2, 1, "Team V has three of the best players in the building. Win and Z's record starts to look dangerous."),
    ("scene", "before_w", "A crack in the team", [
        ("narrator", "Two matches left. The building feels quieter than before."),
        ("kuon", "Do you ever wonder if we are good enough? I have been counting the points. They are not on our side."),
        ("isagi", "Do not count. Move. If we win this one we are still alive."),
        ("raichi", "If you are scared, say it to the pitch. It listens better than we do."),
        ("narrator", "Not everyone on Team Z is in the same place. Tonight, someone is thinking about a different way out."),
    ]),
    ("match", "w", "Match 4: Team W", "team_w", 3, "NOT_LOSE", 300, 3, 2, "Team W knows more about Z than it should. Do not lose."),
    ("scene", "finale", "What comes next", [
        ("narrator", "The scoreboard shows the end of the First Selection. Team Z is still standing, which nobody in the building expected."),
        ("ego", "Interesting. The weakest team in the building is still here. Now we find out whether it was luck or hunger."),
        ("isagi", "It was hunger. And we are only getting started."),
        ("player", "The wall still says Z. For now. The next list will not."),
    ]),
    ("end", "end", "Chapter 1 complete"),
]

# Where in the campus (CampusPlan place ids) each beat happens.
PLACES = {"arrival": "selection_hall", "trial_rules": "team_z_room", "oni": "team_z_room", "after_trial": "team_z_room",
          "team_z": "team_z_room", "rules": "briefing", "x": "stadium_gate", "after_x": "locker_room",
          "y": "stadium_gate", "after_y": "cafeteria", "v": "stadium_gate", "before_w": "team_z_room", "w": "stadium_gate",
          "finale": "rank_wall"}

OBJECTIVES = {"SCORE": "Score a goal", "WIN": "Win the match", "NOT_LOSE": "Do not lose"}


def esc(s):
    return s.replace("\\", "\\\\").replace('"', '\\"')


def main():
    lang = json.load(open(LANG))
    for k in [k for k in lang if k.startswith("bluelock.story.")]:
        del lang[k]
    beats = []
    for b in CHAPTER:
        kind = b[0]
        bid = b[1]
        lang[f"bluelock.story.{bid}.title"] = b[2]
        if kind == "scene":
            lines = []
            for i, (spk, text) in enumerate(b[3], 1):
                key = f"bluelock.story.{bid}.{i}"
                lang[key] = text
                lines.append(f'new StoryBook.Line("{spk}", "{key}")')
            beats.append(f'        beats.add(StoryBook.scene("{bid}", "{PLACES[bid]}", List.of({", ".join(lines)})));')
        elif kind == "match":
            _, _, _, opp, minutes, obj, xp, sp, dp, brief = b
            lang[f"bluelock.story.{bid}.brief"] = brief
            beats.append(f'        beats.add(StoryBook.match("{bid}", "{PLACES[bid]}", "{opp}", {minutes}, StoryBook.Objective.{obj}, {xp}, {sp}, {dp}));')
        elif kind == "trial":
            _, _, _, seconds, xp, sp, dp, brief = b
            lang[f"bluelock.story.{bid}.brief"] = brief
            beats.append(f'        beats.add(StoryBook.trial("{bid}", "{PLACES[bid]}", {seconds}, {xp}, {sp}, {dp}));')
        else:
            beats.append(f'        beats.add(StoryBook.end("{bid}"));')
    for obj, text in OBJECTIVES.items():
        lang[f"bluelock.story.objective.{obj.lower()}"] = text
    json.dump(lang, open(LANG, "w"), indent=2, ensure_ascii=False)
    os.makedirs(os.path.dirname(JAVA), exist_ok=True)
    open(JAVA, "w").write('''package com.bluelock.common.story;

import java.util.ArrayList;
import java.util.List;

/** Chapter 1, the First Selection. Generated by tools/gen_story.py: edit the script, not this file. */
final class StoryChapter1 {
    private StoryChapter1() {
    }

    static List<StoryBook.Beat> build() {
        List<StoryBook.Beat> beats = new ArrayList<>();
''' + "\n".join(beats) + '''
        return beats;
    }
}
''')
    print(len(CHAPTER), "beats")


if __name__ == "__main__":
    main()
