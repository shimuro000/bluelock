#!/usr/bin/env python3
"""Synthesises the Blue Lock voice sounds (shouts, grunts, laughs; not speech) with a simple formant synthesiser.

6 voice types x 10 events = 60 files, written to src/main/resources/assets/bluelock/sounds/voice_<type>_<event>.ogg.
Run:  python3 tools/make_voices.py     (needs numpy, scipy and ffmpeg with libvorbis)
To use your own recordings instead, just replace any of those .ogg files (same name).
"""
import os
import subprocess
import tempfile
import wave

import numpy as np
from scipy.signal import lfilter

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "bluelock", "sounds")

TYPES = {
    #                f0   formant  rough breath vibrato
    "deep_calm":    (98,  0.88, 0.10, 0.05, 0.010),
    "deep_fierce":  (112, 0.90, 0.55, 0.06, 0.006),
    "mid_calm":     (142, 1.00, 0.10, 0.06, 0.012),
    "mid_bold":     (152, 1.02, 0.35, 0.05, 0.008),
    "high_playful": (215, 1.14, 0.08, 0.05, 0.020),
    "high_sharp":   (238, 1.16, 0.30, 0.05, 0.010),
}

VOWELS = {
    "a": (730, 1090, 2440),
    "o": (570, 840, 2410),
    "e": (530, 1840, 2480),
    "u": (640, 1190, 2390),
    "i": (270, 2290, 3010),
}


def resonator(x, freq, bw):
    c = -np.exp(-2 * np.pi * bw / SR)
    b = 2 * np.exp(-np.pi * bw / SR) * np.cos(2 * np.pi * freq / SR)
    a = 1 - b - c
    return lfilter([a], [1, -b, -c], x)


def formant(x, vowel, scale):
    f = VOWELS[vowel]
    y = x
    for freq, bw in zip(f, (80, 90, 120)):
        y = resonator(y, min(freq * scale, SR / 2 - 200), bw)
    return y


def source(f0_curve, rough, breath, vib, rng):
    n = len(f0_curve)
    t = np.arange(n) / SR
    f = f0_curve * (1 + vib * np.sin(2 * np.pi * 5.5 * t)) * (1 + rng.normal(0, 0.002 + rough * 0.01, n).cumsum() * 0.0 + rng.normal(0, 0.003 + rough * 0.012, n))
    phase = np.cumsum(f) / SR
    saw = 2 * (phase % 1.0) - 1
    glottal = saw - np.roll(saw, 1)           # a little brightness, like a glottal pulse
    glottal = glottal * 0.5 + 0.5 * np.sin(2 * np.pi * phase)
    noise = rng.normal(0, 1, n)
    return glottal * (1 - breath) + noise * breath * 0.7


def env(n, attack, release, hold_curve=None):
    e = np.ones(n)
    a = min(n, max(1, int(attack * SR)))
    r = min(n, max(1, int(release * SR)))
    e[:a] = np.linspace(0, 1, a)
    e[-r:] = np.minimum(e[-r:], np.linspace(1, 0, r))
    if hold_curve is not None:
        e *= hold_curve
    return e


def glide(n, start, end, bend=1.0):
    u = np.linspace(0, 1, n) ** bend
    return start + (end - start) * u


def voiced(dur, f0a, f0b, v1, v2, p, rng, attack=0.01, release=0.08, drive=1.0, bend=1.0):
    f0, scale, rough, breath, vib = p
    n = int(dur * SR)
    curve = glide(n, f0 * f0a, f0 * f0b, bend)
    src = source(curve, rough, breath, vib, rng)
    y1 = formant(src, v1, scale)
    y2 = formant(src, v2, scale)
    mix = np.linspace(0, 1, n)
    y = y1 * (1 - mix) + y2 * mix
    y /= max(1e-6, np.max(np.abs(y)))
    if rough > 0.2 or drive > 1.0:
        y = np.tanh(y * (1.5 + rough * 3.0) * drive) / np.tanh(1.5 + rough * 3.0)
    return y * env(n, attack, release)


def air(dur, p, rng, attack=0.005, release=0.05, vowel="u"):
    n = int(dur * SR)
    n_ = rng.normal(0, 1, n)
    return formant(n_, vowel, p[1]) * env(n, attack, release) * 0.25


def make(event, p, rng):
    f0, scale, rough, breath, vib = p
    if event == "effort":
        y = np.concatenate([air(0.06, p, rng, 0.01, 0.03), voiced(0.14, 1.05, 0.85, "u", "u", p, rng, 0.01, 0.07) * 0.5])
    elif event == "shot":
        y = voiced(0.5, 0.95, 1.25, "a", "o", p, rng, 0.015, 0.2, bend=0.6)
        y = np.concatenate([air(0.04, p, rng, 0.005, 0.02, "a") * 3, y])
    elif event == "power":
        a = voiced(0.35, 0.85, 1.3, "u", "a", p, rng, 0.04, 0.05, drive=1.4)
        b = voiced(0.85, 1.3, 1.05, "a", "o", p, rng, 0.02, 0.4, drive=1.6)
        y = np.concatenate([a, b])
    elif event == "skill":
        y = voiced(0.34, 1.1, 0.95, "o", "a", p, rng, 0.01, 0.12)
    elif event == "tackle":
        y = voiced(0.3, 1.0, 0.7, "u", "o", p, rng, 0.01, 0.12, drive=1.3)
        y = np.concatenate([air(0.04, p, rng) * 2, y])
    elif event == "goal":
        a = voiced(0.28, 0.95, 1.25, "e", "a", p, rng, 0.02, 0.03)
        b = voiced(1.0, 1.25, 1.1, "a", "e", p, rng, 0.02, 0.4, drive=1.2)
        y = np.concatenate([a, b])
    elif event == "hurt":
        y = voiced(0.5, 1.15, 0.75, "a", "u", p, rng, 0.02, 0.25)
        y = y * (0.8 + 0.2 * np.sin(2 * np.pi * 7 * np.arange(len(y)) / SR))
    elif event == "taunt":
        parts = []
        for i in range(4):
            parts.append(air(0.03, p, rng, 0.003, 0.02, "a") * 2)
            parts.append(voiced(0.12, 1.15 - i * 0.05, 1.0 - i * 0.05, "a", "a", p, rng, 0.005, 0.06))
            parts.append(np.zeros(int(0.06 * SR)))
        y = np.concatenate(parts)
    elif event == "talk":
        y = np.concatenate([voiced(0.07, 1.0, 1.08, "a", "e", p, rng, 0.006, 0.03), np.zeros(int(0.015 * SR)),
                            voiced(0.08, 1.05, 0.92, "o", "a", p, rng, 0.006, 0.04)]) * 0.7
    elif event == "cheer":
        a = voiced(0.22, 0.95, 1.2, "e", "a", p, rng, 0.012, 0.03)
        b = voiced(0.38, 1.2, 1.3, "a", "o", p, rng, 0.012, 0.18, drive=1.1)
        y = np.concatenate([a, np.zeros(int(0.03 * SR)), b])
    else:
        raise ValueError(event)
    y = y / max(1e-6, np.max(np.abs(y))) * 0.8
    return y


def write_ogg(y, path):
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, "v.wav")
        with wave.open(wav, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(SR)
            w.writeframes((np.clip(y, -1, 1) * 32767).astype(np.int16).tobytes())
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "3", path], check=True)


def main():
    os.makedirs(OUT, exist_ok=True)
    events = ["effort", "shot", "power", "skill", "tackle", "goal", "hurt", "taunt", "talk", "cheer"]
    for name, p in TYPES.items():
        for ev in events:
            rng = np.random.default_rng(abs(hash((name, ev))) % (2 ** 32) if False else sum(map(ord, name + ev)))
            write_ogg(make(ev, p, rng), os.path.join(OUT, f"voice_{name}_{ev}.ogg"))
    print("wrote", len(TYPES) * len(events), "voice files")


if __name__ == "__main__":
    main()
