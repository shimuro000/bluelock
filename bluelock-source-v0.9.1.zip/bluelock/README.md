# Blue Lock (Minecraft Java 1.20.1, Forge 47.4.0)

Football RPG mod inspired by Blue Lock. See `BUILDING.md` to build and run it.

Status: stats, data, character creation, ball, pitch, match rules, teams and formations, plus the gameplay update (ball carry, tackles, skills, bots, HUD, sound). See docs/TESTING.md.

## Layout
- `src/main/java/com/bluelock/common`  loader-independent game logic (no Forge imports allowed here)
- `src/main/java/com/bluelock/forge`   Forge entry point, events, commands, registration
- `src/main/resources/assets/bluelock` language files (en_us, ar_sa), later textures/models/sounds
- `src/test/java`                       unit tests for common logic (later)
- `docs/`                               design docs (ARCHITECTURE.md, ...)
