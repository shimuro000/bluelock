# Building and running

## One-time setup
1. Install JDK 17 (Temurin 17 from adoptium.net). Make sure `java -version` says 17.
2. Install IntelliJ IDEA Community.

## Run the game from the project folder
Open a terminal in this folder, then:
- Windows: `gradlew.bat runClient`
- Mac/Linux: `./gradlew runClient`

First run downloads Minecraft and Forge and can take 10-20 minutes. When the game opens, create a creative world and type `/bluelock`. You should see: "Blue Lock is loaded. Phase 1 bootstrap works!"

## Build the mod jar
`gradlew build` -> the jar appears in `build/libs/`.

## IntelliJ
File > Open > select this folder. Wait for Gradle to finish syncing. Then in the Gradle panel run Tasks > forgegradle runs > runClient.

## Getting the .jar without installing anything (GitHub)
1. Create a free GitHub account and a new repository, then upload all files of this project (Add file > Upload files; the hidden `.github` folder must be included).
2. Open the repository's Actions tab. The `build` workflow runs by itself (about 5-10 minutes).
3. Open the finished run and download the artifact `bluelock-jar`. Inside is `bluelock-0.9.1.jar`.
4. Put the jar in the `mods` folder of a Minecraft 1.20.1 Forge installation (Forge 47.x).
