package com.bluelock.common;

import com.bluelock.common.match.*;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.pitch.PitchPlacement;
import java.util.List;
import java.util.UUID;

public final class MatchSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    private static BallSnapshot ball(double u, double v, double h, int touches, UUID who) {
        return new BallSnapshot(u, v, h, touches, who);
    }

    public static void main(String[] args) {
        PitchLayout l = PitchLayout.standard();
        UUID home = UUID.randomUUID(), away = UUID.randomUUID(), nobody = UUID.randomUUID();
        double cu = l.centreU() + 0.5, cv = l.centreV() + 0.5;

        // --- placement round trip, both orientations ---
        for (boolean alongX : new boolean[] {true, false}) {
            PitchPlacement p = new PitchPlacement(100, 64, -40, alongX, l);
            boolean ok = true;
            for (int u = 0; u < l.length(); u += 7) for (int w = 0; w < l.width(); w += 5) {
                double x = p.blockX(u, w) + 0.5, z = p.blockZ(u, w) + 0.5;
                ok &= Math.abs(p.localU(x, z) - (u + 0.5)) < 1e-9 && Math.abs(p.localV(x, z) - (w + 0.5)) < 1e-9;
                ok &= Math.abs(p.worldX(u + 0.5, w + 0.5) - x) < 1e-9 && Math.abs(p.worldZ(u + 0.5, w + 0.5) - z) < 1e-9;
            }
            check(ok, "placement converts world <-> pitch (alongX=" + alongX + ")");
            check(Math.abs(p.localHeight(65.0)) < 1e-9 && Math.abs(p.worldY(0) - 65.0) < 1e-9, "height 0 is the top of the grass");
        }

        // --- goal detection areas ---
        check(GoalDetector.classify(l, cu, cv, 0.2) == GoalDetector.Area.IN_PLAY, "centre of the pitch is in play");
        check(GoalDetector.classify(l, -1.5, cv, 0.5) == GoalDetector.Area.NEAR_GOAL, "behind u=0 between the posts is the near goal");
        check(GoalDetector.classify(l, l.length() + 1.5, cv, 0.5) == GoalDetector.Area.FAR_GOAL, "behind the far line is the far goal");
        check(GoalDetector.classify(l, -1.5, cv, 3.5) == GoalDetector.Area.OUT, "over the crossbar is not a goal");
        check(GoalDetector.classify(l, -1.5, cv + 6, 0.5) == GoalDetector.Area.OUT, "beside the post is not a goal");
        check(GoalDetector.classify(l, 10, -1, 0.5) == GoalDetector.Area.OUT, "behind the touchline is out");
        check(GoalDetector.classify(l, 10, 10, -10) == GoalDetector.Area.OUT, "ball in the void is out");
        var spot = GoalDetector.restartSpot(l, -3, 40);
        check(spot[0] == 1.5 && spot[1] == l.width() - 1.5, "restart spot is clamped inside the pitch");

        // --- full match flow ---
        MatchSession m = new MatchSession(l, new MatchRules(200, 5));
        m.join(home, Side.HOME);
        m.join(away, Side.AWAY);
        check(m.phase() == MatchPhase.IDLE && m.tick(ball(cu, cv, 0.2, 0, null)).isEmpty(), "idle match does nothing");
        m.start();
        check(m.tick(ball(cu, cv, 0.2, 0, null)).isEmpty() && m.phase() == MatchPhase.WAITING_KICKOFF, "waits for kick-off");
        for (int i = 0; i < 50; i++) m.tick(ball(cu, cv, 0.2, 0, null));
        check(m.elapsedTicks() == 0, "clock does not run before the first touch");
        var ev = m.tick(ball(cu, cv, 0.2, 1, home));
        check(ev.size() == 1 && ev.get(0) instanceof MatchEvent.PlayStarted && m.phase() == MatchPhase.IN_PLAY, "first touch starts play");
        check(m.possession() == Side.HOME, "possession follows the last toucher");
        m.tick(ball(cu, cv, 0.2, 2, away));
        check(m.possession() == Side.AWAY, "possession changes when the other team touches");

        // HOME attacks the far goal: a HOME player's shot into the far goal scores for HOME and credits the player
        m.tick(ball(cu, cv, 0.2, 3, home));
        ev = m.tick(ball(l.length() + 1.5, cv, 0.5, 3, home));
        var g = ev.size() == 1 && ev.get(0) instanceof MatchEvent.GoalScored gs ? gs : null;
        check(g != null && g.scoringSide() == Side.HOME && !g.ownGoal() && home.equals(g.scorer()) && g.homeGoals() == 1, "HOME scores in the far goal and the scorer is credited");
        check(m.tick(ball(l.length() + 1.5, cv, 0.5, 3, home)).isEmpty() && m.homeGoals() == 1, "no second goal during the pause");
        for (int i = 0; i < 5; i++) ev = m.tick(ball(l.length() + 1.5, cv, 0.5, 3, home));
        check(m.phase() == MatchPhase.WAITING_KICKOFF, "after the pause the match waits for a new kick-off");
        check(m.tick(ball(cu, cv, 0.2, 3, home)).isEmpty(), "ball reset to centre, still waiting");
        ev = m.tick(ball(cu, cv, 0.2, 4, away));
        check(ev.size() == 1 && ev.get(0) instanceof MatchEvent.PlayStarted, "next touch restarts play");

        // own goal: AWAY player puts it into the near goal (which AWAY attacks) = goal for AWAY... AWAY scoring in near goal is normal
        ev = m.tick(ball(-1.5, cv, 0.5, 4, away));
        g = ev.size() == 1 && ev.get(0) instanceof MatchEvent.GoalScored gs2 ? gs2 : null;
        check(g != null && g.scoringSide() == Side.AWAY && !g.ownGoal() && away.equals(g.scorer()), "AWAY scores in the near goal");
        // finish pause
        for (int i = 0; i < 6; i++) m.tick(ball(cu, cv, 0.2, 4, away));
        m.tick(ball(cu, cv, 0.2, 4, away));
        m.tick(ball(cu, cv, 0.2, 5, home));
        // HOME player sends the ball into HOME's own goal (near goal) => own goal for AWAY
        ev = m.tick(ball(-1.5, cv, 0.5, 5, home));
        g = ev.size() == 1 && ev.get(0) instanceof MatchEvent.GoalScored gs3 ? gs3 : null;
        check(g != null && g.ownGoal() && g.scoringSide() == Side.AWAY && g.scorer() == null && m.awayGoals() == 2, "own goal counts for the other side, no scorer");

        // unknown player (not in a team) scores: credited to the side, no player
        MatchSession s = new MatchSession(l, new MatchRules(1000, 3));
        s.start();
        s.tick(ball(cu, cv, 0.2, 0, null));
        s.tick(ball(cu, cv, 0.2, 1, nobody));
        ev = s.tick(ball(l.length() + 1.5, cv, 0.5, 1, nobody));
        g = ev.size() == 1 && ev.get(0) instanceof MatchEvent.GoalScored gs4 ? gs4 : null;
        check(g != null && g.scoringSide() == Side.HOME && g.scorer() == null && !g.ownGoal(), "player without a team: goal counts, no scorer");

        // out of play
        MatchSession o = new MatchSession(l, new MatchRules(1000, 3));
        o.start();
        o.tick(ball(cu, cv, 0.2, 0, null));
        o.tick(ball(cu, cv, 0.2, 1, home));
        ev = o.tick(ball(15, -2, 0.2, 1, home));
        check(ev.size() == 1 && ev.get(0) instanceof MatchEvent.BallOut bo && bo.restartV() == 1.5 && bo.restartU() == 15 && o.phase() == MatchPhase.WAITING_RESTART, "ball out of play is put back on the line");
        int before = o.elapsedTicks();
        o.tick(ball(15, 1.5, 0.2, 1, home));
        o.tick(ball(15, 1.5, 0.2, 1, home));
        check(o.elapsedTicks() == before, "clock is stopped while waiting for a restart");
        o.tick(ball(15, 1.5, 0.2, 2, away));
        check(o.phase() == MatchPhase.IN_PLAY, "a touch resumes play after a restart");

        // time up
        MatchSession t = new MatchSession(l, new MatchRules(30, 3));
        t.join(home, Side.HOME);
        t.start();
        t.tick(ball(cu, cv, 0.2, 0, null));
        t.tick(ball(cu, cv, 0.2, 1, home));
        List<MatchEvent> last = List.of();
        for (int i = 0; i < 40 && t.isActive(); i++) last = t.tick(ball(cu, cv, 0.2, 1, home));
        check(t.phase() == MatchPhase.FINISHED && last.size() == 1 && last.get(0) instanceof MatchEvent.MatchFinished mf && mf.winner() == null, "time up with no goals is a draw");
        check(t.tick(ball(cu, cv, 0.2, 1, home)).isEmpty(), "finished match ignores the ball");

        // a replaced ball (touch counter back to zero) must not look like a touch
        MatchSession r = new MatchSession(l, new MatchRules(1000, 3));
        r.start();
        r.tick(ball(cu, cv, 0.2, 7, home));
        r.ballReplaced();
        r.tick(ball(cu, cv, 0.2, 0, null));
        check(r.phase() == MatchPhase.WAITING_KICKOFF, "replacing the ball does not start play by itself");
        check(r.tick(ball(cu, cv, 0.2, 1, home)).size() == 1 && r.phase() == MatchPhase.IN_PLAY, "touching the new ball starts play");

        System.out.println(failures == 0 ? "ALL MATCH TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
