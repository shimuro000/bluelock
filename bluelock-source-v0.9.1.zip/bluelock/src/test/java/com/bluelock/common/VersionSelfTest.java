package com.bluelock.common;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** The version shown in game must match the version in gradle.properties (which names the jar). */
public final class VersionSelfTest {
    public static void main(String[] args) throws IOException {
        String line = Files.readAllLines(Path.of("gradle.properties")).stream()
                .filter(l -> l.startsWith("mod_version=")).findFirst().orElse("");
        String gradle = line.substring("mod_version=".length()).trim();
        boolean ok = gradle.equals(BlueLockConstants.VERSION);
        System.out.println((ok ? "PASS " : "FAIL ") + "in-game version " + BlueLockConstants.VERSION + " matches gradle.properties " + gradle);
        System.out.println(ok ? "ALL VERSION TESTS PASSED" : "1 FAILURE(S)");
        if (!ok) System.exit(1);
    }
}
