package com.bluelock.common;

import com.bluelock.common.content.*;
import com.bluelock.common.stats.Stat;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/** Loads the REAL shipped data files through the real parser. Run with the project root as working directory. */
public final class ContentSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    @SuppressWarnings("unchecked")
    private static List<RawDefinition> readAll(Path root) throws IOException {
        List<RawDefinition> out = new ArrayList<>();
        for (String type : List.of("skills", "formations", "teams", "archetypes", "personalities")) {
            try (Stream<Path> files = Files.list(root.resolve(type))) {
                for (Path f : files.filter(p -> p.toString().endsWith(".json")).sorted().toList()) {
                    String name = f.getFileName().toString().replace(".json", "");
                    out.add(new RawDefinition(type, name, (Map<String, Object>) MiniJson.parse(Files.readString(f, StandardCharsets.UTF_8))));
                }
            }
        }
        return out;
    }

    private static RawDefinition raw(String type, String id, String json) {
        @SuppressWarnings("unchecked")
        Map<String, Object> m = (Map<String, Object>) MiniJson.parse(json);
        return new RawDefinition(type, id, m);
    }

    public static void main(String[] args) throws IOException {
        Path root = Path.of("src/main/resources/data/bluelock/definitions");
        DefinitionPack pack = DefinitionPack.build(readAll(root));
        pack.problems().forEach(p -> System.out.println("  problem: " + p));
        check(pack.problems().isEmpty(), "shipped data has no problems");
        check(pack.skills().size() == 19, "19 skills loaded (" + pack.skills().size() + ")");
        check(pack.formations().size() == 11, "11 formations loaded (" + pack.formations().size() + ")");
        check(pack.teams().size() == 5, "5 teams loaded");
        check(pack.formations().values().stream().map(f -> f.slots().size()).collect(java.util.stream.Collectors.toSet()).equals(java.util.Set.of(1, 2, 3, 4, 5, 7, 11)), "formations exist for every match size 1,2,3,4,5,7,11");
        check(pack.formations().values().stream().allMatch(f -> f.slots().stream().filter(s -> s.position() == Position.GK).count() <= 1), "no formation has two goalkeepers");
        SkillDefinition d = pack.skills().get("direct_shot").orElseThrow();
        check(d.requires().equals(List.of("finishing")) && d.requirements().get(Stat.SHOOTING) == 45, "direct_shot parsed correctly");

        // every language key used by content exists in both language files
        for (String lang : List.of("en_us", "ar_sa")) {
            @SuppressWarnings("unchecked")
            Map<String, Object> keys = (Map<String, Object>) MiniJson.parse(Files.readString(Path.of("src/main/resources/assets/bluelock/lang/" + lang + ".json"), StandardCharsets.UTF_8));
            boolean ok = true;
            for (SkillDefinition s : pack.skills().values()) ok &= keys.containsKey(s.nameKey()) && keys.containsKey(s.descriptionKey());
            for (FormationDefinition f : pack.formations().values()) ok &= keys.containsKey(f.nameKey());
            for (TeamDefinition t : pack.teams().values()) ok &= keys.containsKey(t.nameKey());
            for (Stat s : Stat.values()) ok &= keys.containsKey(s.langKey());
            check(ok, lang + " has every content language key");
        }

        // bad data must be skipped and reported, never crash
        DefinitionPack bad = DefinitionPack.build(List.of(
                raw("skills", "ok_skill", "{\"category\":\"SHOOTING\",\"cooldown_ticks\":10,\"stamina_cost\":5}"),
                raw("skills", "bad_stat", "{\"category\":\"SHOOTING\",\"cooldown_ticks\":10,\"stamina_cost\":5,\"requirements\":{\"flying\":10}}"),
                raw("skills", "orphan", "{\"category\":\"SHOOTING\",\"cooldown_ticks\":10,\"stamina_cost\":5,\"requires\":[\"nope\"]}"),
                raw("skills", "loop_a", "{\"category\":\"SHOOTING\",\"cooldown_ticks\":1,\"stamina_cost\":1,\"requires\":[\"loop_b\"]}"),
                raw("skills", "loop_b", "{\"category\":\"SHOOTING\",\"cooldown_ticks\":1,\"stamina_cost\":1,\"requires\":[\"loop_a\"]}"),
                raw("skills", "Bad-Name", "{}"),
                raw("teams", "lonely", "{\"color\":\"#FFFFFF\",\"formation\":\"missing\",\"playstyle\":\"DIRECT\",\"rating\":50}"),
                raw("teams", "badcolor", "{\"color\":\"red\",\"formation\":\"x\",\"playstyle\":\"DIRECT\",\"rating\":50}"),
                raw("formations", "tiny", "{\"slots\":[]}"),
                raw("formations", "two_keepers", "{\"slots\":[{\"position\":\"GK\",\"x\":0.1,\"y\":0.1},{\"position\":\"GK\",\"x\":0.5,\"y\":0.1},{\"position\":\"ST\",\"x\":0.5,\"y\":0.9}]}"),
                raw("monsters", "x", "{}")));
        check(bad.skills().size() == 1 && bad.skills().contains("ok_skill"), "only the valid skill survives");
        check(bad.teams().size() == 0 && bad.formations().size() == 0, "bad teams/formations skipped");
        check(bad.problems().size() == 10, "10 problems reported (" + bad.problems().size() + ")");

        // ---- Phase 4: character creation ----
        check(pack.archetypes().size() == 7 && pack.personalities().size() == 6, "7 archetypes and 6 personalities loaded");
        check(pack.archetypes().values().stream().allMatch(b -> b.totalDelta() == 0)
                && pack.personalities().values().stream().allMatch(b -> b.totalDelta() == 0), "every build shift adds up to zero (equal power)");
        int[] totals = new int[1];
        int minOwn = 1000, maxOwn = 0;
        boolean allOk = true, boundsOk = true, hasWeakness = true;
        for (com.bluelock.common.profile.Archetype a : com.bluelock.common.profile.Archetype.values()) {
            for (com.bluelock.common.profile.Personality pe : com.bluelock.common.profile.Personality.values()) {
                var r = com.bluelock.common.profile.CharacterCreator.create(pack, UUID.randomUUID(), "Roy", "", com.bluelock.common.profile.DominantFoot.RIGHT, a, pe);
                allOk &= r.isOk();
                if (!r.isOk()) continue;
                var st = r.value().stats();
                int sum = 0, min = 100;
                for (Stat stat : Stat.values()) { sum += st.base(stat); min = Math.min(min, st.base(stat)); boundsOk &= st.base(stat) >= 15 && st.base(stat) <= 70; }
                if (totals[0] == 0) totals[0] = sum;
                allOk &= sum == totals[0];
                hasWeakness &= min < com.bluelock.common.profile.CharacterCreator.BASELINE;
                int own = com.bluelock.common.stats.OverallRating.compute(st, com.bluelock.common.stats.StatModifiers.NONE, com.bluelock.common.stats.RoleWeights.forArchetype(a));
                minOwn = Math.min(minOwn, own); maxOwn = Math.max(maxOwn, own);
            }
        }
        check(allOk, "all 42 archetype/personality combinations create a profile with identical total stat points (" + totals[0] + ")");
        check(boundsOk, "all starting stats stay within 15..70");
        check(hasWeakness, "every build starts with at least one weak stat");
        System.out.println("  own-role overall across all builds: " + minOwn + ".." + maxOwn);
        check(maxOwn - minOwn <= 6, "no build is far stronger in its own role (spread " + (maxOwn - minOwn) + ")");
        var badName = com.bluelock.common.profile.CharacterCreator.create(pack, UUID.randomUUID(), "x", "", com.bluelock.common.profile.DominantFoot.LEFT, com.bluelock.common.profile.Archetype.STRIKER, com.bluelock.common.profile.Personality.CREATIVE);
        check(!badName.isOk() && badName.errorKey().orElse("").equals("bluelock.error.name_too_short"), "bad name rejected with a language key");
        var noData = com.bluelock.common.profile.CharacterCreator.create(DefinitionPack.empty(), UUID.randomUUID(), "Roy", "", com.bluelock.common.profile.DominantFoot.LEFT, com.bluelock.common.profile.Archetype.STRIKER, com.bluelock.common.profile.Personality.CREATIVE);
        check(!noData.isOk() && noData.errorKey().orElse("").equals("bluelock.error.content_missing"), "missing game data fails safely");
        var made = com.bluelock.common.profile.CharacterCreator.create(pack, UUID.randomUUID(), "  رؤى  ", "Ace", com.bluelock.common.profile.DominantFoot.BOTH, com.bluelock.common.profile.Archetype.PLAYMAKER, com.bluelock.common.profile.Personality.ANALYTICAL).value();
        var reloaded = com.bluelock.common.persistence.ProfileCodec.fromMap(com.bluelock.common.persistence.ProfileCodec.toMap(made));
        check(reloaded.name().equals("رؤى") && reloaded.nickname().equals("Ace") && reloaded.stats().base(Stat.VISION) == made.stats().base(Stat.VISION), "created profile survives save/load");

        System.out.println(failures == 0 ? "ALL CONTENT TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
