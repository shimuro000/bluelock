package com.bluelock.common;

import com.bluelock.common.action.*;
import com.bluelock.common.ball.BallCarry;
import com.bluelock.common.ball.Velocity;
import com.bluelock.common.content.*;
import com.bluelock.common.persistence.ProfileCodec;
import com.bluelock.common.profile.*;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.progression.SkillRules;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

public final class GameplaySelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    @SuppressWarnings("unchecked")
    private static DefinitionPack load() throws IOException {
        Path root = Path.of("src/main/resources/data/bluelock/definitions");
        List<RawDefinition> raws = new ArrayList<>();
        for (String type : List.of("skills", "formations", "teams", "archetypes", "personalities")) {
            try (Stream<Path> files = Files.list(root.resolve(type))) {
                for (Path f : files.filter(p -> p.toString().endsWith(".json")).sorted().toList()) {
                    raws.add(new RawDefinition(type, f.getFileName().toString().replace(".json", ""),
                            (Map<String, Object>) MiniJson.parse(Files.readString(f, StandardCharsets.UTF_8))));
                }
            }
        }
        return DefinitionPack.build(raws);
    }

    public static void main(String[] args) throws IOException {
        DefinitionPack pack = load();

        // ---- ball carry ----
        double[] t = BallCarry.target(10, 20, 3, 0, 0.8);
        check(Math.abs(t[0] - 10.8) < 1e-9 && Math.abs(t[1] - 20) < 1e-9, "ball sits in front of the feet along the heading");
        double[] still = BallCarry.target(0, 0, 0, 0, 1.0);
        check(still[0] == 0 && still[1] == 1.0, "zero heading puts the ball straight ahead");
        double min = 9, max = 0;
        for (int i = 0; i < 200; i++) { double d = BallCarry.distanceAt(i, 0.25); min = Math.min(min, d); max = Math.max(max, d); }
        check(min >= 0.74 && max <= 1.2 && max - min > 0.2, "carry distance swings with each step (" + String.format("%.2f", min) + ".." + String.format("%.2f", max) + ")");
        check(BallCarry.lossChancePerTick(60, 60, 0.08, false) == 0, "walking never loses the ball");
        double lowSkill = BallCarry.lossChancePerTick(30, 30, 0.28, false), highSkill = BallCarry.lossChancePerTick(90, 90, 0.28, false);
        check(lowSkill > highSkill * 3 && lowSkill < 0.03, "better dribblers lose the ball less often");
        check(BallCarry.lossChancePerTick(50, 50, 0.1, true) > 0, "pressure can cause a lost touch even when slow");
        check(BallCarry.canControl(0.3, 20, 20) && !BallCarry.canControl(0.9, 20, 20), "fast balls cannot be settled by weak players");
        check(BallCarry.canControl(0.6, 90, 90) && !BallCarry.canControl(0.6, 20, 20), "good first touch tames faster balls");

        // ---- tackles ----
        var strongT = new TackleResolver.Tackler(80, 70, 70, false);
        var weakT = new TackleResolver.Tackler(25, 25, 25, false);
        var strongC = new TackleResolver.Carrier(80, 80, 70, false, false);
        var weakC = new TackleResolver.Carrier(25, 25, 25, false, false);
        check(TackleResolver.winChance(strongT, weakC) > TackleResolver.winChance(weakT, weakC), "stronger tackler has a better chance");
        check(TackleResolver.winChance(weakT, strongC) < TackleResolver.winChance(weakT, weakC), "better dribbler is harder to tackle");
        check(TackleResolver.winChance(new TackleResolver.Tackler(50, 50, 50, true), weakC) > TackleResolver.winChance(new TackleResolver.Tackler(50, 50, 50, false), weakC), "slide tackle is more likely to work");
        check(TackleResolver.winChance(strongT, new TackleResolver.Carrier(25, 25, 25, false, true)) == 0, "a protecting skill makes the carrier untouchable");
        check(TackleResolver.resolve(strongT, new TackleResolver.Carrier(25, 25, 25, false, true), () -> 0.0) == TackleResolver.Outcome.FAILED, "protected carrier: tackle always fails");
        check(TackleResolver.resolve(strongT, weakC, () -> 0.01) == TackleResolver.Outcome.WON_BALL, "low roll wins the ball");
        double p = TackleResolver.winChance(strongT, weakC);
        check(TackleResolver.resolve(strongT, weakC, () -> p * 0.8) == TackleResolver.Outcome.DEFLECTED, "middle roll knocks the ball loose");
        check(TackleResolver.resolve(strongT, weakC, () -> 0.999) == TackleResolver.Outcome.FAILED, "high roll fails");
        Random rnd = new Random(7);
        int wins = 0;
        for (int i = 0; i < 10000; i++) if (TackleResolver.resolve(new TackleResolver.Tackler(50, 50, 50, false), new TackleResolver.Carrier(50, 50, 50, false, false), rnd::nextDouble) == TackleResolver.Outcome.WON_BALL) wins++;
        check(wins > 2200 && wins < 3300, "equal players: tackle wins the ball about 29% of the time (" + wins / 100.0 + "%)");

        // ---- stamina ----
        StaminaPool sp = new StaminaPool(50);
        check(Math.abs(sp.max() - 100) < 1e-9 && sp.percent() == 100, "stamina max grows with the stat");
        for (int i = 0; i < 200; i++) sp.tick(true, 50);
        check(sp.percent() < 85 && sp.percent() > 0, "sprinting drains stamina (" + sp.percent() + "%)");
        for (int i = 0; i < 2000; i++) sp.tick(false, 50);
        check(sp.percent() == 100, "resting refills stamina");
        check(sp.spend(30) && sp.percent() == 70 && !sp.spend(500), "skills cost stamina and cannot be used without it");
        StaminaPool fit = new StaminaPool(90), unfit = new StaminaPool(20);
        for (int i = 0; i < 300; i++) { fit.tick(true, 90); unfit.tick(true, 20); }
        check(fit.percent() > unfit.percent(), "a higher stamina stat lasts longer");

        // ---- kicks ----
        Random r = new Random(1);
        double worstWeak = 0, worstGood = 0;
        for (int i = 0; i < 2000; i++) {
            Velocity a = KickModel.pass(0, 1, 20, 20, r::nextDouble), b = KickModel.pass(0, 1, 20, 95, r::nextDouble);
            worstWeak = Math.max(worstWeak, Math.abs(Math.atan2(a.x(), a.z())));
            worstGood = Math.max(worstGood, Math.abs(Math.atan2(b.x(), b.z())));
        }
        check(worstWeak > worstGood * 3 && Math.toDegrees(worstWeak) <= 8.1, "weak passers miss by more (" + String.format("%.1f", Math.toDegrees(worstWeak)) + " vs " + String.format("%.1f", Math.toDegrees(worstGood)) + " degrees)");
        check(KickModel.pass(0, 1, 30, 50, () -> 0.5).z() > KickModel.pass(0, 1, 8, 50, () -> 0.5).z(), "longer passes are hit harder");
        check(KickModel.pass(0, 0, 10, 50, () -> 0.5).equals(Velocity.ZERO), "no direction, no pass");
        double slowShot = KickModel.shot(0, 0, 1, 50, 50, 20, 1.0, 0.1, () -> 0.5).z();
        double fastShot = KickModel.shot(0, 0, 1, 50, 50, 90, 1.0, 0.1, () -> 0.5).z();
        check(fastShot > slowShot * 1.3, "shot power makes the ball faster (" + String.format("%.2f", slowShot) + " vs " + String.format("%.2f", fastShot) + ")");
        check(KickModel.shot(0, 0, 1, 50, 50, 50, 1.0, 0.12, () -> 0.5).y() >= 0.12, "shots always get a little lift");
        double errBad = 0, errGood = 0;
        for (int i = 0; i < 2000; i++) {
            errBad = Math.max(errBad, Math.abs(KickModel.shot(0, 0, 1, 20, 20, 50, 1, 0.1, r::nextDouble).x()));
            errGood = Math.max(errGood, Math.abs(KickModel.shot(0, 0, 1, 95, 95, 50, 1, 0.1, r::nextDouble).x()));
        }
        check(errBad > errGood * 3, "better shooters are more accurate");

        // ---- shot aim assist ----
        double[] near = KickModel.aimToward(new double[] {0.05, 0.1, 1}, new double[] {0.2, 0.1, 1}, 18, 0.7);
        double[] toGoal = KickModel.aimToward(new double[] {0.2, 0.1, 1}, new double[] {0.2, 0.1, 1}, 18, 0.7);
        check(Math.abs(near[0]) > 0.1 && Math.abs(near[0]) < 0.2 + 0.02 && Math.abs(Math.sqrt(near[0] * near[0] + near[1] * near[1] + near[2] * near[2]) - 1) < 1e-9, "aim assist nudges a shot toward the goal and returns a unit vector");
        double[] wide = KickModel.aimToward(new double[] {1, 0, 0.2}, new double[] {0, 0, 1}, 18, 0.7);
        check(wide[0] > 0.97, "aim assist leaves shots that are aimed far away from the goal alone");
        check(Math.abs(toGoal[0] - 0.2 / Math.sqrt(0.2 * 0.2 + 0.01 + 1)) < 1e-9, "a shot already on target stays on target");

        // ---- pass assist ----
        List<double[]> mates = List.of(new double[] {10, 0}, new double[] {10, 5}, new double[] {0, 2}, new double[] {-10, 0});
        check(PassAssist.pick(0, 0, 1, 0.1, mates, 25, 3, 40) == 0, "assist picks the teammate closest to where you look");
        check(PassAssist.pick(0, 0, 0, 1, mates, 10, 3, 40) == -1, "no teammate in the cone gives no assist");
        check(PassAssist.pick(0, 0, -1, 0, mates, 25, 3, 40) == 3, "assist works backwards too");
        check(PassAssist.pick(0, 0, 1, 0, mates, 25, 15, 40) == -1, "too close or too far is ignored");

        // ---- progression ----
        PlayerProfile pl = new PlayerProfile(UUID.randomUUID(), "Roy", "", DominantFoot.RIGHT, Archetype.STRIKER, Personality.RELENTLESS, StatBlock.uniform(35));
        var lu = Progression.award(pl, Progression.XpAction.GOAL);
        check(!lu.happened() && pl.xp() == 40 && pl.level() == 1, "40 XP for a goal, no level yet");
        lu = Progression.award(pl, 70);
        check(lu.levelsGained() == 1 && pl.level() == 2 && pl.xp() == 10 && pl.skillPoints() == 1 && pl.developmentPoints() == 3, "level up grants 1 skill point and 3 development points");
        lu = Progression.award(pl, 2000);
        check(lu.levelsGained() >= 3 && pl.level() == lu.newLevel() && pl.skillPoints() == pl.level() - 1, "big XP gain gives several levels at once (level " + pl.level() + ")");
        PlayerProfile maxed = new PlayerProfile(UUID.randomUUID(), "Max", "", DominantFoot.LEFT, Archetype.DEFENDER, Personality.CREATIVE, StatBlock.uniform(35));
        Progression.award(maxed, 10_000_000L);
        check(maxed.level() == Progression.MAX_LEVEL && !Progression.award(maxed, 500).happened(), "level cap is respected");
        check(pl.spendDevelopment(Stat.PASSING, new DefaultGrowthCurveHolder().curve(), 2) <= 2, "partial development spending respects the limit");

        // ---- skills ----
        StatBlock dribblerStats = StatBlock.uniform(35);
        dribblerStats.setBase(Stat.DRIBBLING, 52); dribblerStats.setBase(Stat.AGILITY, 45); dribblerStats.setBase(Stat.BALL_CONTROL, 41); dribblerStats.setBase(Stat.CLOSE_CONTROL, 50);
        PlayerProfile dr = new PlayerProfile(UUID.randomUUID(), "Dri", "", DominantFoot.RIGHT, Archetype.DRIBBLER, Personality.CREATIVE, dribblerStats);
        List<String> roots = SkillRules.autoUnlockRoots(dr, pack);
        check(roots.contains("control") && !roots.contains("feint") && dr.isUnlocked("control"), "root skill 'control' unlocks by itself");
        check(roots.stream().allMatch(id -> pack.skills().get(id).orElseThrow().requires().isEmpty()), "only root skills auto-unlock");
        check("bluelock.skill.error.points".equals(SkillRules.check(dr, pack.skills().get("feint").orElseThrow())), "feint needs a skill point");
        dr.setProgression(2, 0, 1, 0);
        check(SkillRules.unlock(dr, pack.skills().get("feint").orElseThrow()) == null && dr.isUnlocked("feint") && dr.skillPoints() == 0, "unlocking feint costs one skill point");
        check("bluelock.skill.error.already".equals(SkillRules.check(dr, pack.skills().get("feint").orElseThrow())), "cannot unlock twice");
        dr.setProgression(3, 0, 5, 0);
        check("bluelock.skill.error.stats".equals(SkillRules.check(dr, pack.skills().get("burst_dribble").orElseThrow())), "burst dribble needs higher stats");
        check("bluelock.skill.error.parent".equals(SkillRules.check(dr, pack.skills().get("chain_dribble").orElseThrow())), "chain dribble needs its parent skill");

        // ---- save/load with skills and counters ----
        dr.addGoal(); dr.addGoal();
        PlayerProfile back = ProfileCodec.fromMap(ProfileCodec.toMap(dr));
        check(back.isUnlocked("feint") && back.isUnlocked("control") && back.goals() == 2 && back.level() == 3 && back.skillPoints() == 5, "skills, goals and level survive save/load");
        check(ProfileCodec.fromMap(new HashMap<>(Map.of("name", "Old"))).unlockedSkills().isEmpty(), "old saves without skills still load");

        System.out.println(failures == 0 ? "ALL GAMEPLAY TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }

    /** tiny helper so the test does not depend on how the default curve is constructed */
    private static final class DefaultGrowthCurveHolder {
        com.bluelock.common.stats.GrowthCurve curve() { return new com.bluelock.common.stats.DefaultGrowthCurve(); }
    }
}
