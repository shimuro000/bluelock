package com.bluelock.common;

import com.bluelock.common.ai.*;
import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import com.bluelock.common.team.TeamTactics;
import java.util.List;

public final class BotSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    private static final PitchLayout L = PitchLayout.standard();
    private static final TeamTactics T = TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED);

    private static BotView view(Side side, Position pos, Pos self, Pos ball, boolean has, Side poss, Pos carrier, int rank,
                                Pos base, List<Pos> mates, List<Pos> opps) {
        return new BotView(side, pos, self, ball, has, poss, carrier, rank, 60, T, base, mates, opps, L);
    }

    public static void main(String[] args) {
        double cv = L.centreV() + 0.5, cu = L.centreU() + 0.5;

        // goalkeeper
        var k = BotBrain.decide(view(Side.HOME, Position.GK, new Pos(2, cv), new Pos(40, cv + 10), false, Side.AWAY, new Pos(40, cv + 10), 3, new Pos(3, cv), List.of(), List.of()));
        check(k.intent() == Intent.MOVE && k.target().u() == 2.0 && k.target().v() > cv && k.target().v() <= cv + 3.0, "HOME keeper stays on his line and shades toward the ball");
        var ka = BotBrain.decide(view(Side.AWAY, Position.GK, new Pos(L.length() - 2, cv), new Pos(10, cv), false, Side.HOME, new Pos(10, cv), 3, new Pos(L.length() - 3, cv), List.of(), List.of()));
        check(ka.intent() == Intent.MOVE && ka.target().u() == L.length() - 2.0, "AWAY keeper defends the far goal line");
        var kc = BotBrain.decide(view(Side.HOME, Position.GK, new Pos(2, cv), new Pos(7, cv), false, null, null, 1, new Pos(3, cv), List.of(), List.of()));
        check(kc.intent() == Intent.CHASE_BALL, "keeper comes out for a loose ball in his box");
        var kp = BotBrain.decide(view(Side.HOME, Position.GK, new Pos(2, cv), new Pos(2.5, cv), true, Side.HOME, new Pos(2.5, cv), 0, new Pos(3, cv), List.of(new Pos(20, cv + 8)), List.of(new Pos(30, cv))));
        check(kp.intent() == Intent.PASS && kp.passIndex() == 0, "keeper with the ball passes to an open teammate");
        var kcl = BotBrain.decide(view(Side.HOME, Position.GK, new Pos(2, cv), new Pos(2.5, cv), true, Side.HOME, new Pos(2.5, cv), 0, new Pos(3, cv), List.of(), List.of()));
        check(kcl.intent() == Intent.CLEAR, "keeper with nobody to pass to clears the ball upfield");

        // shooting
        var s = BotBrain.decide(view(Side.HOME, Position.ST, new Pos(L.length() - 14, cv), new Pos(L.length() - 13, cv), true, Side.HOME, new Pos(L.length() - 14, cv), 0, new Pos(50, cv), List.of(), List.of(new Pos(L.length() - 2, cv + 1))));
        check(s.intent() == Intent.SHOOT && s.target().u() == L.length() && s.target().v() < cv, "striker in range shoots at the corner away from the keeper");
        var sa = BotBrain.decide(view(Side.AWAY, Position.ST, new Pos(14, cv), new Pos(13, cv), true, Side.AWAY, new Pos(14, cv), 0, new Pos(10, cv), List.of(), List.of()));
        check(sa.intent() == Intent.SHOOT && sa.target().u() == 0, "AWAY striker shoots at the near goal");

        // dribble vs pass
        var d = BotBrain.decide(view(Side.HOME, Position.ST, new Pos(25, cv), new Pos(26, cv), true, Side.HOME, new Pos(25, cv), 0, new Pos(50, cv), List.of(new Pos(33, cv + 6)), List.of(new Pos(40, cv - 15))));
        check(d.intent() == Intent.DRIBBLE && d.target().u() > 25, "free striker dribbles toward goal");
        var dp = BotBrain.decide(view(Side.HOME, Position.ST, new Pos(25, cv), new Pos(26, cv), true, Side.HOME, new Pos(25, cv), 0, new Pos(50, cv), List.of(new Pos(34, cv + 8)), List.of(new Pos(26, cv - 2.5))));
        check(dp.intent() == Intent.PASS && dp.passIndex() == 0, "pressured striker passes to the open teammate");
        var blocked = BotBrain.decide(view(Side.HOME, Position.CM, new Pos(25, cv), new Pos(26, cv), true, Side.HOME, new Pos(25, cv), 0, new Pos(30, cv), List.of(new Pos(36, cv)), List.of(new Pos(30.5, cv))));
        check(blocked.intent() != Intent.PASS, "no pass through an opponent standing in the lane");
        var marked = BotBrain.decide(view(Side.HOME, Position.CM, new Pos(25, cv), new Pos(26, cv), true, Side.HOME, new Pos(25, cv), 0, new Pos(30, cv), List.of(new Pos(36, cv + 8)), List.of(new Pos(36, cv + 9.5))));
        check(marked.intent() != Intent.PASS, "no pass to a heavily marked teammate");
        var mid = BotBrain.decide(view(Side.HOME, Position.CM, new Pos(25, cv), new Pos(26, cv), true, Side.HOME, new Pos(25, cv), 0, new Pos(30, cv), List.of(new Pos(35, cv + 7)), List.of()));
        check(mid.intent() == Intent.PASS, "a midfielder with a good option passes instead of running");
        var back = BotBrain.decide(view(Side.HOME, Position.CB, new Pos(6, cv), new Pos(7, cv), true, Side.HOME, new Pos(6, cv), 0, new Pos(10, cv), List.of(), List.of(new Pos(8, cv + 1.5))));
        check(back.intent() == Intent.CLEAR, "pressured defender in his own third clears the ball");
        var around = BotBrain.decide(view(Side.HOME, Position.ST, new Pos(20, cv), new Pos(21, cv), true, Side.HOME, new Pos(20, cv), 0, new Pos(50, cv), List.of(), List.of(new Pos(24, cv + 1))));
        check(around.intent() == Intent.DRIBBLE && around.target().v() < cv, "dribbler sidesteps a defender in front of him");

        // defending
        var press = BotBrain.decide(view(Side.HOME, Position.CM, new Pos(30, cv), new Pos(34, cv), false, Side.AWAY, new Pos(34, cv), 0, new Pos(30, cv), List.of(), List.of()));
        check(press.intent() == Intent.PRESS && press.target().u() == 34, "closest defender presses the carrier");
        var tackle = BotBrain.decide(view(Side.HOME, Position.CM, new Pos(33, cv), new Pos(34, cv), false, Side.AWAY, new Pos(34, cv), 0, new Pos(30, cv), List.of(), List.of()));
        check(tackle.intent() == Intent.TACKLE, "a defender within reach tackles");
        var hold = BotBrain.decide(view(Side.HOME, Position.CB, new Pos(20, cv), new Pos(34, cv), false, Side.AWAY, new Pos(34, cv), 3, new Pos(15, cv + 5), List.of(), List.of()));
        check(hold.intent() == Intent.HOLD && hold.target().u() > 15, "other defenders hold their shape and move up with the ball");
        var second = BotBrain.decide(view(Side.HOME, Position.CM, new Pos(30, cv), new Pos(34, cv), false, Side.AWAY, new Pos(34, cv), 1, new Pos(30, cv), List.of(), List.of()));
        check(second.intent() == Intent.HOLD, "second defender holds when pressing is only average");
        var secondPress = BotBrain.decide(new BotView(Side.HOME, Position.CM, new Pos(30, cv), new Pos(34, cv), false, Side.AWAY, new Pos(34, cv), 1, 60,
                TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.HIGH_PRESS), new Pos(30, cv), List.of(), List.of(), L));
        check(secondPress.intent() == Intent.PRESS, "a high-pressing team sends a second player");

        // loose ball and support
        var chase = BotBrain.decide(view(Side.HOME, Position.CM, new Pos(30, cv), new Pos(34, cv), false, null, null, 0, new Pos(30, cv), List.of(), List.of()));
        check(chase.intent() == Intent.CHASE_BALL, "closest player chases a loose ball");
        var wait = BotBrain.decide(view(Side.HOME, Position.CM, new Pos(30, cv), new Pos(34, cv), false, null, null, 2, new Pos(30, cv), List.of(), List.of()));
        check(wait.intent() == Intent.MOVE, "others keep their shape");
        var runner = BotBrain.decide(view(Side.HOME, Position.ST, new Pos(40, cv), new Pos(30, cv), false, Side.HOME, new Pos(30, cv), 1, new Pos(50, cv + 4), List.of(), List.of()));
        check(runner.intent() == Intent.MOVE && runner.target().u() > 35 && runner.target().v() == cv + 4, "striker runs ahead of the carrier");
        var runnerAway = BotBrain.decide(view(Side.AWAY, Position.ST, new Pos(20, cv), new Pos(30, cv), false, Side.AWAY, new Pos(30, cv), 1, new Pos(10, cv + 4), List.of(), List.of()));
        check(runnerAway.target().u() < 25, "AWAY striker runs the other way");
        boolean inside = true;
        for (Side side : Side.values()) for (Position pos : Position.values()) for (double bu = 0; bu <= L.length(); bu += 10) {
            var dec = BotBrain.decide(view(side, pos, new Pos(30, cv), new Pos(bu, 2), false, Side.AWAY, new Pos(bu, 2), 2, new Pos(30, cv), List.of(), List.of()));
            inside &= dec.target().u() >= 0 && dec.target().u() <= L.length() && dec.target().v() >= 0 && dec.target().v() <= L.width();
            inside &= dec.speed() > 0 && dec.speed() <= 1.0;
        }
        check(inside, "every decision for every role stays inside the pitch with a valid speed");

        // bot stats
        StatBlock gk = BotStats.forRating(50, Position.GK), st = BotStats.forRating(50, Position.ST), cb = BotStats.forRating(50, Position.CB);
        check(gk.base(Stat.REACTION) > st.base(Stat.REACTION) && st.base(Stat.FINISHING) > cb.base(Stat.FINISHING) && cb.base(Stat.TACKLING) > st.base(Stat.TACKLING), "bot stats follow the role");
        check(BotStats.forRating(200, Position.ST).base(Stat.SHOOTING) <= 100 && BotStats.forRating(-5, Position.CB).base(Stat.PASSING) >= 20, "bot stats stay in range");

        System.out.println(failures == 0 ? "ALL BOT TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
