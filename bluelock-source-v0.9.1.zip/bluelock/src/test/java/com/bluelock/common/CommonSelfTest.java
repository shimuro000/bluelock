package com.bluelock.common;

import com.bluelock.common.persistence.ProfileCodec;
import com.bluelock.common.profile.*;
import com.bluelock.common.stats.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Dependency-free checks for the common module. Run: java -cp <classes> com.bluelock.common.CommonSelfTest */
public final class CommonSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    public static void main(String[] args) {
        GrowthCurve curve = new DefaultGrowthCurve();
        StatBlock b = StatBlock.uniform(40);
        check(b.spendOn(Stat.PASSING, 5, curve) == 5 && b.permanent(Stat.PASSING) == 43, "band change: 5 points at 40 cost 1+2+2 -> 43");
        StatBlock b2 = StatBlock.uniform(60);
        check(b2.spendOn(Stat.DRIBBLING, 3, curve) == 2 && b2.permanent(Stat.DRIBBLING) == 61, "band edge: 3 points at 60 buy one level (2), 1 left over");
        StatBlock b3 = StatBlock.uniform(98);
        b3.spendOn(Stat.SHOOTING, 10_000, curve);
        check(b3.permanent(Stat.SHOOTING) == 99, "soft cap stops at 99");
        b3.grantMilestoneToMax(Stat.SHOOTING);
        check(b3.permanent(Stat.SHOOTING) == 100, "milestone reaches 100");
        check(b.spendOn(Stat.PASSING, -5, curve) == 0, "negative budget spends nothing");

        StatBlock e = StatBlock.uniform(95);
        StatModifiers mods = new StatModifiers().equipment(Stat.TOP_SPEED, 4).flow(Stat.TOP_SPEED, 4).temporary(Stat.STAMINA, -200);
        check(StatCalculator.effective(e, mods, Stat.TOP_SPEED) == 100, "effective clamps at 100");
        check(StatCalculator.effective(e, mods, Stat.STAMINA) == 0, "effective clamps at 0");

        StatBlock st = StatBlock.uniform(50);
        st.setBase(Stat.FINISHING, 90);
        int strikerOvr = OverallRating.compute(st, StatModifiers.NONE, RoleWeights.forArchetype(Archetype.STRIKER));
        int defenderOvr = OverallRating.compute(st, StatModifiers.NONE, RoleWeights.forArchetype(Archetype.DEFENDER));
        check(strikerOvr > defenderOvr, "overall is role-weighted (striker " + strikerOvr + " > defender " + defenderOvr + ")");

        check(PlayerProfile.validateName("Roy") == null, "name ok");
        check(PlayerProfile.validateName("رؤى") == null, "Arabic name ok");
        check(PlayerProfile.validateName("A") != null, "short name rejected");
        check(PlayerProfile.validateName("x".repeat(40)) != null, "long name rejected");
        check(PlayerProfile.validateName("bad<>name") != null, "bad chars rejected");

        PlayerProfile p = new PlayerProfile(UUID.randomUUID(), "Roy", "Ace", DominantFoot.LEFT,
                Archetype.STRIKER, Personality.RELENTLESS, StatBlock.uniform(45));
        p.setProgression(3, 1200, 2, 7);
        Map<String, Object> saved = ProfileCodec.toMap(p);
        PlayerProfile q = ProfileCodec.fromMap(saved);
        check(q.id().equals(p.id()) && q.name().equals("Roy") && q.foot() == DominantFoot.LEFT
                && q.archetype() == Archetype.STRIKER && q.level() == 3 && q.xp() == 1200
                && q.developmentPoints() == 7 && q.stats().base(Stat.VISION) == 45, "save/load round trip");

        Map<String, Object> broken = new HashMap<>();
        broken.put("name", "<<>>");
        broken.put("archetype", "NOT_REAL");
        PlayerProfile r = ProfileCodec.fromMap(broken);
        check(r.name().equals("Player") && r.archetype() == Archetype.ALL_ROUNDER && r.level() == 1, "partially missing save falls back to defaults");

        int spent = p.spendDevelopment(Stat.SHOOTING, curve);
        check(spent == 6 && p.developmentPoints() == 1 && p.stats().growth(Stat.SHOOTING) == 3, "7 dev points at 45 buy 3 levels (6), 1 left");

        System.out.println(failures == 0 ? "ALL TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
