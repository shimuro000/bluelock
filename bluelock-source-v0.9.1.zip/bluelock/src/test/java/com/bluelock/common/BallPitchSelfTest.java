package com.bluelock.common;

import com.bluelock.common.ball.BallPhysics;
import com.bluelock.common.ball.Velocity;
import com.bluelock.common.pitch.PitchLayout;
import java.util.List;

/** Simulates the ball against a flat floor and a wall, and checks the pitch geometry. */
public final class BallPitchSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    public static void main(String[] args) {
        BallPhysics.Config c = BallPhysics.defaults();

        // drop from 3 blocks above a floor at y=0
        double y = 3, x = 0;
        Velocity v = Velocity.ZERO;
        int bounces = 0;
        int settledAt = -1;
        double maxAfterFirstBounce = 0;
        for (int tick = 0; tick < 600; tick++) {
            v = BallPhysics.applyForces(v, c, false);
            double ny = y + v.y();
            boolean hitY = ny < 0;
            if (hitY) ny = 0;
            var r = BallPhysics.resolve(v, false, hitY, false, c);
            if (r.bounced()) bounces++;
            if (bounces >= 1 && y > maxAfterFirstBounce) maxAfterFirstBounce = y;
            y = ny;
            v = r.velocity();
            if (settledAt < 0 && r.grounded() && v.y() == 0 && Math.abs(v.horizontalSpeed()) < 1e-9 && tick > 10) { settledAt = tick; break; }
        }
        check(bounces >= 2, "dropped ball bounces several times (" + bounces + ")");
        check(maxAfterFirstBounce < 3, "bounces lose height");
        check(settledAt > 0 && settledAt < 300, "ball settles on the floor (tick " + settledAt + ")");

        // roll along the ground, must slow down and stop
        v = new Velocity(0.5, 0, 0);
        double travelled = 0;
        boolean stopped = false;
        for (int tick = 0; tick < 400; tick++) {
            v = BallPhysics.applyForces(v, c, false);
            travelled += v.x();
            var r = BallPhysics.resolve(v, false, true, false, c); // floor contact every tick (gravity pushes down)
            v = r.velocity();
            if (v.x() == 0 && v.z() == 0) { stopped = true; break; }
        }
        check(stopped && travelled > 3 && travelled < 40, "rolling ball stops after a sensible distance (" + String.format("%.1f", travelled) + " blocks)");

        // wall bounce reverses direction and loses speed
        var wall = BallPhysics.resolve(new Velocity(0.5, 0, 0.1), true, false, false, c);
        check(wall.velocity().x() < 0 && Math.abs(wall.velocity().x()) < 0.5 && wall.velocity().z() == 0.1, "wall bounce reverses x and keeps z");

        // kicks
        var pass = BallPhysics.kick(1, 0, 0, c.passSpeed(), 0);
        check(Math.abs(pass.x() - c.passSpeed()) < 1e-9 && pass.y() == 0, "pass keeps the aimed direction and speed");
        var shot = BallPhysics.kick(0, 0, 3, c.shotSpeed(), c.shotLift());
        check(Math.abs(shot.z() - c.shotSpeed()) < 1e-9 && shot.y() >= c.shotLift(), "shot gets a little lift");
        check(BallPhysics.kick(0, 0, 0, 1, 0).equals(Velocity.ZERO), "zero direction gives no kick");
        check(BallPhysics.dribble(0.001, 0, c).equals(Velocity.ZERO), "standing still gives no dribble push");
        check(BallPhysics.dribble(0.2, 0, c).x() > 0.2, "running player pushes the ball ahead of them");
        check(BallPhysics.dribble(5, 0, c).x() <= 0.61, "dribble push is capped");

        // pitch geometry
        PitchLayout p = PitchLayout.standard();
        check(p.length() == 61 && p.width() == 37 && p.centreU() == 30 && p.centreV() == 18, "standard pitch is 61x37 with a single-block centre");
        check(p.surfaceAt(30, 18) == PitchLayout.Surface.LINE, "centre spot is a line");
        check(p.surfaceAt(0, 5) == PitchLayout.Surface.LINE && p.surfaceAt(60, 5) == PitchLayout.Surface.LINE, "goal lines are lines");
        check(p.surfaceAt(30, 3) == PitchLayout.Surface.LINE, "halfway line is a line");
        check(p.surfaceAt(7, 18) == PitchLayout.Surface.LINE && p.surfaceAt(53, 18) == PitchLayout.Surface.LINE, "both penalty spots exist");
        check(p.surfaceAt(5, 10) != PitchLayout.Surface.LINE, "open grass between the boxes is not a line");
        int lines = 0, light = 0, dark = 0;
        for (int u = 0; u < p.length(); u++) for (int w = 0; w < p.width(); w++) {
            switch (p.surfaceAt(u, w)) { case LINE -> lines++; case LIGHT_GRASS -> light++; case DARK_GRASS -> dark++; }
        }
        System.out.println("  lines=" + lines + " light=" + light + " dark=" + dark);
        check(lines > 300 && light > 500 && dark > 500, "pitch has lines and both grass stripes");
        // symmetry of lines left/right and top/bottom
        boolean sym = true;
        for (int u = 0; u < p.length(); u++) for (int w = 0; w < p.width(); w++) {
            boolean a = p.surfaceAt(u, w) == PitchLayout.Surface.LINE;
            sym &= a == (p.surfaceAt(p.length() - 1 - u, w) == PitchLayout.Surface.LINE);
            sym &= a == (p.surfaceAt(u, p.width() - 1 - w) == PitchLayout.Surface.LINE);
        }
        check(sym, "line markings are mirror-symmetric");

        List<PitchLayout.GoalCell> near = p.goalCells(false), far = p.goalCells(true);
        check(near.size() == far.size() && near.size() > 40, "both goals have the same blocks (" + near.size() + ")");
        check(near.stream().allMatch(g -> g.u() <= 0) && far.stream().allMatch(g -> g.u() >= p.length() - 1), "goals sit on or behind the goal lines");
        // the goal mouth must be open: no block in front of the line, and the inside is free
        int cv = p.centreV();
        boolean openInside = near.stream().noneMatch(g -> g.u() >= -2 && g.u() <= -1 && g.v() >= cv - 3 && g.v() <= cv + 3 && g.dy() <= 2);
        check(openInside, "space inside the goal is empty so the ball can enter");
        boolean mouthOpen = near.stream().noneMatch(g -> g.u() == 0 && g.v() >= cv - 3 && g.v() <= cv + 3 && g.dy() <= 2);
        check(mouthOpen, "goal mouth is open below the crossbar");
        check(near.stream().anyMatch(g -> g.part() == PitchLayout.GoalPart.NET) && near.stream().anyMatch(g -> g.part() == PitchLayout.GoalPart.POST), "goal has posts and net");

        boolean badRejected = false;
        try { new PitchLayout(60, 37); } catch (IllegalArgumentException e) { badRejected = true; }
        check(badRejected, "even pitch size is rejected");

        System.out.println(failures == 0 ? "ALL BALL/PITCH TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
