package com.bluelock.common;

import com.bluelock.common.content.*;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.pitch.PitchPlacement;
import com.bluelock.common.profile.Archetype;
import com.bluelock.common.team.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

public final class TeamSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    @SuppressWarnings("unchecked")
    private static DefinitionPack load() throws IOException {
        Path root = Path.of("src/main/resources/data/bluelock/definitions");
        List<RawDefinition> raws = new ArrayList<>();
        for (String type : List.of("skills", "formations", "teams", "archetypes", "personalities")) {
            try (Stream<Path> files = Files.list(root.resolve(type))) {
                for (Path f : files.filter(p -> p.toString().endsWith(".json")).sorted().toList()) {
                    raws.add(new RawDefinition(type, f.getFileName().toString().replace(".json", ""),
                            (Map<String, Object>) MiniJson.parse(Files.readString(f, StandardCharsets.UTF_8))));
                }
            }
        }
        return DefinitionPack.build(raws);
    }

    public static void main(String[] args) throws IOException {
        DefinitionPack pack = load();
        check(pack.problems().isEmpty(), "data loads without problems");

        // modes
        check(MatchMode.parse("5v5").orElseThrow() == MatchMode.FIVE_V_FIVE && MatchMode.parse("11V11").isPresent(), "match modes parse (5v5, 11V11)");
        check(MatchMode.parse("6v6").isEmpty() && MatchMode.parse(null).isEmpty(), "unknown mode is rejected");

        // formation selection for every mode
        for (MatchMode mode : MatchMode.values()) {
            var f = FormationSelector.choose(pack.formations(), mode.size(), null, null);
            check(f.isPresent() && f.get().slots().size() == mode.size(), "a formation exists for " + mode.label() + " (" + f.map(FormationDefinition::id).orElse("none") + ")");
        }
        check(FormationSelector.choose(pack.formations(), 11, null, null).orElseThrow().id().equals("4_3_3"), "default 11v11 formation is 4-3-3");
        check(FormationSelector.choose(pack.formations(), 11, null, "3_5_2").orElseThrow().id().equals("3_5_2"), "team formation is used when the size fits");
        check(FormationSelector.choose(pack.formations(), 5, null, "3_5_2").orElseThrow().id().equals("1_2_1"), "team formation of the wrong size is ignored");
        check(FormationSelector.choose(pack.formations(), 11, "5_3_2", "3_5_2").orElseThrow().id().equals("5_3_2"), "explicit choice wins");
        check(FormationSelector.choose(pack.formations(), 9, null, null).isEmpty(), "no formation for 9 players");

        // seating in 4-3-3
        FormationDefinition f433 = pack.formations().get("4_3_3").orElseThrow();
        UUID striker = UUID.randomUUID(), defender = UUID.randomUUID(), maker = UUID.randomUUID(), allr = UUID.randomUUID();
        TeamSetup t = TeamSetup.seat(f433, List.of(
                new TeamSetup.Candidate(striker, Archetype.STRIKER, null),
                new TeamSetup.Candidate(defender, Archetype.DEFENDER, null),
                new TeamSetup.Candidate(maker, Archetype.PLAYMAKER, null)));
        check(f433.slots().get(t.slotOf(striker)).position() == Position.ST, "striker is seated at ST");
        Position dp = f433.slots().get(t.slotOf(defender)).position();
        check(dp == Position.CB || dp == Position.LB || dp == Position.RB, "defender is seated in defence (" + dp + ")");
        Position mp = f433.slots().get(t.slotOf(maker)).position();
        check(mp == Position.CM || mp == Position.CAM, "playmaker is seated in midfield (" + mp + ")");
        check(t.humanCount() == 3 && t.size() == 11 && t.bench().isEmpty(), "3 humans, 8 empty bot slots");
        check(f433.slots().get(t.slotOf(striker)).position() != Position.GK && t.occupant(0) == null, "nobody is forced into goal");

        // determinism and preferred slot
        TeamSetup again = TeamSetup.seat(f433, List.of(
                new TeamSetup.Candidate(striker, Archetype.STRIKER, null),
                new TeamSetup.Candidate(defender, Archetype.DEFENDER, null),
                new TeamSetup.Candidate(maker, Archetype.PLAYMAKER, null)));
        boolean same = true;
        for (int i = 0; i < 11; i++) same &= Objects.equals(t.occupant(i), again.occupant(i));
        check(same, "same input gives the same seating");
        TeamSetup pref = TeamSetup.seat(f433, List.of(
                new TeamSetup.Candidate(striker, Archetype.STRIKER, 0),
                new TeamSetup.Candidate(defender, Archetype.DEFENDER, 0)));
        check(pref.slotOf(striker) == 0 && pref.slotOf(defender) > 0, "preferred slot is honoured; a clash falls back to auto seating");
        TeamSetup badPref = TeamSetup.seat(f433, List.of(new TeamSetup.Candidate(striker, Archetype.STRIKER, 99)));
        check(f433.slots().get(badPref.slotOf(striker)).position() == Position.ST, "invalid preferred slot is ignored");

        // bench
        FormationDefinition solo = pack.formations().get("solo").orElseThrow();
        TeamSetup crowded = TeamSetup.seat(solo, List.of(
                new TeamSetup.Candidate(striker, Archetype.STRIKER, null),
                new TeamSetup.Candidate(defender, Archetype.DEFENDER, null)));
        check(crowded.humanCount() == 1 && crowded.bench().equals(List.of(defender)), "extra player goes to the bench when the team is full");

        // chemistry and rating
        Map<UUID, Archetype> arch = Map.of(striker, Archetype.STRIKER, defender, Archetype.DEFENDER, maker, Archetype.PLAYMAKER);
        Map<UUID, Integer> overall = Map.of(striker, 60, defender, 60, maker, 60);
        check(t.chemistry(arch) >= 90, "players in natural positions give high chemistry (" + t.chemistry(arch) + ")");
        TeamSetup wrong = TeamSetup.seat(f433, List.of(new TeamSetup.Candidate(striker, Archetype.STRIKER, 1))); // slot 1 = LB
        check(wrong.chemistry(Map.of(striker, Archetype.STRIKER)) < 50, "a striker at left-back has low chemistry (" + wrong.chemistry(Map.of(striker, Archetype.STRIKER)) + ")");
        int good = t.rating(overall, arch, 40);
        int bad = wrong.rating(Map.of(striker, 60), Map.of(striker, Archetype.STRIKER), 40);
        check(good > 40 && good < 60, "team rating mixes humans (60) and bots (40): " + good);
        check(TeamSetup.seat(f433, List.of()).rating(Map.of(), Map.of(), 55) == 55, "all-bot team has exactly the bot rating");
        check(TeamSetup.seat(f433, List.of()).chemistry(Map.of()) == 0, "no humans means chemistry 0");
        System.out.println("  good seating rating " + good + ", out of position " + bad);

        // kickoff positions
        PitchLayout layout = PitchLayout.standard();
        boolean homeHalf = true, awayHalf = true, inside = true, apart = true, outsideCircle = true;
        for (String id : pack.formations().asMap().keySet()) {
            FormationDefinition fd = pack.formations().get(id).orElseThrow();
            List<double[]> homeSpots = new ArrayList<>();
            for (FormationDefinition.Slot s : fd.slots()) {
                double[] h = KickoffPositions.spot(layout, Side.HOME, s);
                double[] a = KickoffPositions.spot(layout, Side.AWAY, s);
                homeHalf &= h[0] < layout.centreU();
                awayHalf &= a[0] > layout.centreU() + 1;
                inside &= h[0] > 1 && h[0] < layout.length() - 1 && h[1] > 1 && h[1] < layout.width() - 1 && a[0] > 1 && a[0] < layout.length() - 1;
                outsideCircle &= Math.hypot(h[0] - layout.centreU() - 0.5, h[1] - layout.centreV() - 0.5) > 5.0;
                homeSpots.add(h);
            }
            for (int i = 0; i < homeSpots.size(); i++) for (int j = i + 1; j < homeSpots.size(); j++) {
                apart &= Math.hypot(homeSpots.get(i)[0] - homeSpots.get(j)[0], homeSpots.get(i)[1] - homeSpots.get(j)[1]) >= 2.0;
            }
        }
        check(homeHalf && awayHalf, "kick-off spots are in each team's own half");
        check(inside && outsideCircle, "kick-off spots are inside the pitch and outside the centre circle");
        check(apart, "no two players start closer than 2 blocks (all formations)");
        var s0 = f433.slots().get(0);
        double[] hs = KickoffPositions.spot(layout, Side.HOME, s0), as = KickoffPositions.spot(layout, Side.AWAY, s0);
        check(Math.abs(hs[0] + as[0] - layout.length()) < 1e-9 && Math.abs(hs[1] + as[1] - layout.width()) < 1e-9, "away spots mirror home spots");

        // yaw
        PitchPlacement px = new PitchPlacement(0, 64, 0, true, layout), pz = new PitchPlacement(0, 64, 0, false, layout);
        check(px.yawAlongPitch(true) == -90f && px.yawAlongPitch(false) == 90f && pz.yawAlongPitch(true) == 0f && pz.yawAlongPitch(false) == 180f, "yaw faces along the pitch");

        // tactics
        TeamTactics hp = TeamTactics.forPlaystyle(Playstyle.HIGH_PRESS), cn = TeamTactics.forPlaystyle(Playstyle.COUNTER);
        check(hp.pressing() > cn.pressing() && hp.defensiveLine() > cn.defensiveLine() && new TeamTactics(500, -5, 50).pressing() == 0, "tactics follow the playstyle and stay within 0..100");

        System.out.println(failures == 0 ? "ALL TEAM TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }
}
