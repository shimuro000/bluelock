package com.bluelock.forge;

/** Numbers that identify a player action sent from the keyboard to the server. */
public final class ActionIds {
    public static final int PASS = 0;
    public static final int SHOT = 1;
    public static final int SLIDE = 2;
    public static final int FEINT = 3;
    public static final int BURST = 4;
    public static final int CHAIN = 5;
    public static final int SPRINT = 6;
    public static final int SHOULDER = 7;
    public static final int COUNT = 8;

    private ActionIds() {
    }
}
