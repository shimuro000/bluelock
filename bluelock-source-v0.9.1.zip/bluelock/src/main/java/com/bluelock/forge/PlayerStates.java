package com.bluelock.forge;

import com.bluelock.common.stats.Stat;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/** Holds the PlayerState of every player who takes part in the game, and updates them every tick. */
final class PlayerStates {
    private static final Map<UUID, PlayerState> STATES = new HashMap<>();

    private PlayerStates() {
    }

    static PlayerState get(ServerPlayer player) {
        return STATES.computeIfAbsent(player.getUUID(), id -> new PlayerState(staminaStat(player)));
    }

    static PlayerState peek(UUID id) {
        return STATES.get(id);
    }

    static int staminaStat(ServerPlayer player) {
        return ActorStats.of(player.getServer(), player).permanent(Stat.STAMINA);
    }

    static void clear() {
        STATES.clear();
    }

    static void tick(MinecraftServer server) {
        long now = server.overworld().getGameTime();
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (!STATES.containsKey(player.getUUID()) && !MatchManager.isMember(player.getUUID())) {
                continue;
            }
            PlayerState state = get(player);
            int stat = staminaStat(player);
            if (now % 100 == 0) {
                state.stamina.refreshMax(stat);
            }
            state.stamina.tick(player.isSprinting(), stat);
            if (state.stamina.exhausted() && player.isSprinting()) {
                player.setSprinting(false);
            }
            if (now < state.slideUntil) {
                player.setDeltaMovement(state.slideX * 0.75, player.getDeltaMovement().y, state.slideZ * 0.75);
                player.hurtMarked = true;
                if (TackleActions.slideContact(server, player)) {
                    state.slideUntil = 0;
                }
            }
        }
    }
}
