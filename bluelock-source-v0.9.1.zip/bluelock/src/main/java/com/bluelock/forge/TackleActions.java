package com.bluelock.forge;

import com.bluelock.common.action.TackleResolver;
import com.bluelock.common.match.Side;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Winning the ball from the player who carries it: standing tackle, slide tackle and shoulder charge. */
public final class TackleActions {
    public enum Mode { STAND, SLIDE, SHOULDER }

    private static final double STAND_REACH = 2.1;
    private static final double SLIDE_REACH = 2.6;
    private static final double SLIDE_CONTACT = 1.7;
    private static final int STAND_COOLDOWN = 20;

    private TackleActions() {
    }

    /** Tries to take the ball from a nearby opponent. Returns true if a tackle was attempted. */
    public static boolean attempt(MinecraftServer server, LivingEntity tackler, Mode mode) {
        long now = tackler.level().getGameTime();
        if (now < readyAt(tackler)) {
            return false;
        }
        double reach = mode == Mode.SLIDE ? SLIDE_REACH : STAND_REACH;
        BallEntity ball = carriedBallNear(tackler, reach);
        if (ball == null) {
            return false;
        }
        setReadyAt(tackler, now + STAND_COOLDOWN);
        resolve(server, tackler, ball, mode, now);
        return true;
    }

    /** Called every tick while a player slides: tackles the first carrier they touch. */
    static boolean slideContact(MinecraftServer server, ServerPlayer player) {
        BallEntity ball = carriedBallNear(player, SLIDE_CONTACT);
        if (ball == null) {
            return false;
        }
        resolve(server, player, ball, Mode.SLIDE, player.level().getGameTime());
        return true;
    }

    private static void resolve(MinecraftServer server, LivingEntity tackler, BallEntity ball, Mode mode, long now) {
        LivingEntity carrier = ball.carrier();
        StatBlock tacklerStats = ActorStats.of(server, tackler);
        StatBlock carrierStats = ActorStats.of(server, carrier);
        boolean protectedByMove = PlayerActions.isImmune(carrier, now);
        boolean sprinting = Math.hypot(carrier.getX() - carrier.xo, carrier.getZ() - carrier.zo) > 0.2;

        TackleResolver.Tackler t = new TackleResolver.Tackler(
                tacklerStats.permanent(Stat.TACKLING),
                tacklerStats.permanent(Stat.STRENGTH) + (mode == Mode.SHOULDER ? 25 : 0),
                tacklerStats.permanent(Stat.ANTICIPATION),
                mode == Mode.SLIDE);
        TackleResolver.Carrier c = new TackleResolver.Carrier(
                carrierStats.permanent(Stat.DRIBBLING), carrierStats.permanent(Stat.CLOSE_CONTROL),
                carrierStats.permanent(Stat.BALANCE), sprinting, protectedByMove);

        TackleResolver.Outcome outcome = TackleResolver.resolve(t, c, ThreadLocalRandom.current()::nextDouble);
        double dx = carrier.getX() - tackler.getX();
        double dz = carrier.getZ() - tackler.getZ();

        switch (outcome) {
            case WON_BALL -> {
                ball.takeBy(tackler);
                ball.playSound(ModSounds.TACKLE.get(), 1.0F, 1.0F);
                if (tackler instanceof ServerPlayer player) {
                    Rewards.give(server, player.getUUID(), Progression.XpAction.TACKLE_WON);
                }
            }
            case DEFLECTED -> {
                ball.knockLoose(dx, dz, 0.35 + ThreadLocalRandom.current().nextDouble() * 0.2);
                ball.playSound(ModSounds.TACKLE.get(), 0.8F, 1.2F);
            }
            case FAILED -> {
                if (tackler instanceof Player) {
                    tackler.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 1, false, false));
                }
                setReadyAt(tackler, now + STAND_COOLDOWN + 20);
            }
        }
        if (mode == Mode.SHOULDER && outcome != TackleResolver.Outcome.FAILED) {
            double len = Math.max(1.0E-6, Math.sqrt(dx * dx + dz * dz));
            carrier.push(dx / len * 0.45, 0.1, dz / len * 0.45);
            carrier.hurtMarked = true;
        }
    }

    /** The nearest ball that an opponent of {@code tackler} carries within reach, or null. */
    private static BallEntity carriedBallNear(LivingEntity tackler, double reach) {
        List<BallEntity> balls = tackler.level().getEntitiesOfClass(BallEntity.class,
                tackler.getBoundingBox().inflate(reach + 1.0), b -> b.carrier() != null && b.carrier() != tackler);
        BallEntity best = null;
        double bestDist = reach;
        for (BallEntity ball : balls) {
            LivingEntity carrier = ball.carrier();
            double d = tackler.distanceTo(carrier);
            if (d <= bestDist && isOpponent(tackler, carrier)) {
                bestDist = d;
                best = ball;
            }
        }
        return best;
    }

    /** In a match only players of the other side can be tackled; outside a match everybody can. */
    static boolean isOpponent(LivingEntity a, LivingEntity b) {
        Side sa = MatchManager.sideOfEntity(a);
        Side sb = MatchManager.sideOfEntity(b);
        return sa == null || sb == null || sa != sb;
    }

    private static long readyAt(LivingEntity e) {
        if (e instanceof BotEntity bot) {
            return bot.tackleReadyAt;
        }
        if (e instanceof ServerPlayer player) {
            return PlayerStates.get(player).tackleReadyAt;
        }
        return 0;
    }

    private static void setReadyAt(LivingEntity e, long value) {
        if (e instanceof BotEntity bot) {
            bot.tackleReadyAt = value;
        } else if (e instanceof ServerPlayer player) {
            PlayerStates.get(player).tackleReadyAt = value;
        }
    }
}
