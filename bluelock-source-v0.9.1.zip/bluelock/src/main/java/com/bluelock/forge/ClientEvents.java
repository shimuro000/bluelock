package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client-only game events: turns key presses into messages to the server and advances the HUD clock. */
@Mod.EventBusSubscriber(modid = BlueLockConstants.MOD_ID, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        ClientHudState.tick();
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return;
        }
        for (int action = 0; action < ClientKeys.BY_ACTION.length; action++) {
            while (ClientKeys.BY_ACTION[action].consumeClick()) {
                if (minecraft.screen == null) {
                    BlueLockNetwork.CHANNEL.sendToServer(new ActionPacket(action));
                }
            }
        }
    }
}
