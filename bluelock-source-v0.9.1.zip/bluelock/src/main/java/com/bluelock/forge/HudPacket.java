package com.bluelock.forge;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

/**
 * Server to client: everything the on-screen display needs (score, clock, possession, stamina, cooldowns, banner).
 * cooldowns holds, per action, how much of the cooldown is left as a percentage (0 = ready).
 */
public record HudPacket(boolean active, int home, int away, int elapsed, int duration, int phase, int possession,
                        int homeColor, int awayColor, String bannerKey, String bannerArg, int bannerTicks,
                        int stamina, int[] cooldowns) {

    public static HudPacket inactive() {
        return new HudPacket(false, 0, 0, 0, 0, 0, -1, 0, 0, "", "", 0, 100, new int[ActionIds.COUNT]);
    }

    public static void encode(HudPacket m, FriendlyByteBuf buf) {
        buf.writeBoolean(m.active());
        buf.writeVarInt(m.home());
        buf.writeVarInt(m.away());
        buf.writeVarInt(m.elapsed());
        buf.writeVarInt(m.duration());
        buf.writeVarInt(m.phase());
        buf.writeVarInt(m.possession() + 1);
        buf.writeInt(m.homeColor());
        buf.writeInt(m.awayColor());
        buf.writeUtf(m.bannerKey());
        buf.writeUtf(m.bannerArg());
        buf.writeVarInt(m.bannerTicks());
        buf.writeVarInt(m.stamina());
        buf.writeVarIntArray(m.cooldowns());
    }

    public static HudPacket decode(FriendlyByteBuf buf) {
        boolean active = buf.readBoolean();
        int home = buf.readVarInt();
        int away = buf.readVarInt();
        int elapsed = buf.readVarInt();
        int duration = buf.readVarInt();
        int phase = buf.readVarInt();
        int possession = buf.readVarInt() - 1;
        int homeColor = buf.readInt();
        int awayColor = buf.readInt();
        String bannerKey = buf.readUtf();
        String bannerArg = buf.readUtf();
        int bannerTicks = buf.readVarInt();
        int stamina = buf.readVarInt();
        int[] cooldowns = buf.readVarIntArray();
        return new HudPacket(active, home, away, elapsed, duration, phase, possession, homeColor, awayColor,
                bannerKey, bannerArg, bannerTicks, stamina, cooldowns);
    }

    public static void handle(HudPacket message, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> ClientHudState.update(message));
        context.setPacketHandled(true);
    }
}
