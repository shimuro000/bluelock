package com.bluelock.forge;

import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.progression.SkillRules;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/** Gives XP for football actions, handles level-ups and newly unlocked skills, and saves the profile. */
public final class Rewards {
    private Rewards() {
    }

    public static void give(MinecraftServer server, UUID playerId, Progression.XpAction action) {
        ProfileSavedData store = ProfileSavedData.get(server);
        Optional<PlayerProfile> found = store.load(playerId);
        if (found.isEmpty()) {
            return;
        }
        PlayerProfile profile = found.get();
        Progression.LevelUp levelUp = Progression.award(profile, action);
        if (action == Progression.XpAction.GOAL) {
            profile.addGoal();
        }
        List<String> unlocked = levelUp.happened() ? SkillRules.autoUnlockRoots(profile, BlueLockData.get()) : List.of();
        store.save(profile);

        ServerPlayer player = server.getPlayerList().getPlayer(playerId);
        if (player != null && levelUp.happened()) {
            player.sendSystemMessage(Component.translatable("bluelock.progress.levelup", levelUp.newLevel(),
                    Progression.SKILL_POINTS_PER_LEVEL * levelUp.levelsGained(),
                    Progression.DEVELOPMENT_POINTS_PER_LEVEL * levelUp.levelsGained()));
            for (String skill : unlocked) {
                player.sendSystemMessage(Component.translatable("bluelock.progress.skill_unlocked",
                        Component.translatable("bluelock.skill." + skill + ".name")));
            }
        }
    }
}
