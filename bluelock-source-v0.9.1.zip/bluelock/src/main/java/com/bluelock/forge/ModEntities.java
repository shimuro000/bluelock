package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, BlueLockConstants.MOD_ID);

    public static final RegistryObject<EntityType<BallEntity>> BALL = ENTITY_TYPES.register("ball",
            () -> EntityType.Builder.<BallEntity>of(BallEntity::new, MobCategory.MISC)
                    .sized(0.4F, 0.4F)
                    .clientTrackingRange(10)
                    .updateInterval(1)
                    .build("ball"));

    public static final RegistryObject<EntityType<BotEntity>> BOT = ENTITY_TYPES.register("bot",
            () -> EntityType.Builder.<BotEntity>of(BotEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .updateInterval(2)
                    .build("bot"));

    private ModEntities() {
    }
}
