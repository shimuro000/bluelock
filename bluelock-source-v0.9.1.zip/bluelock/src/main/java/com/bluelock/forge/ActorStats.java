package com.bluelock.forge;

import com.bluelock.common.profile.CharacterCreator;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.stats.StatBlock;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/** Stats of whoever is on the pitch: a player's career stats, or a bot's stats from its rating. */
public final class ActorStats {
    private static final StatBlock BASELINE = StatBlock.uniform(CharacterCreator.BASELINE);

    private ActorStats() {
    }

    public static StatBlock of(MinecraftServer server, Entity entity) {
        if (entity instanceof BotEntity bot) {
            return bot.stats();
        }
        if (entity instanceof Player player && server != null) {
            return ProfileSavedData.get(server).load(player.getUUID()).map(PlayerProfile::stats).orElse(BASELINE);
        }
        return BASELINE;
    }
}
