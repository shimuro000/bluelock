package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import com.bluelock.common.match.Side;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Draws a bot as a footballer in the home (blue) or away (red) kit. Client only. */
public class BotRenderer extends HumanoidMobRenderer<BotEntity, HumanoidModel<BotEntity>> {
    private static final ResourceLocation HOME = new ResourceLocation(BlueLockConstants.MOD_ID, "textures/entity/bot_home.png");
    private static final ResourceLocation AWAY = new ResourceLocation(BlueLockConstants.MOD_ID, "textures/entity/bot_away.png");

    public BotRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(BotEntity bot) {
        return bot.side() == Side.HOME ? HOME : AWAY;
    }
}
