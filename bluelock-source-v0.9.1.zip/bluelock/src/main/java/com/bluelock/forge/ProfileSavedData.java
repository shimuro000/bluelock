package com.bluelock.forge;

import com.bluelock.common.persistence.ProfileCodec;
import com.bluelock.common.persistence.ProfileRepository;
import com.bluelock.common.profile.PlayerProfile;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * All career profiles of this world, saved by Minecraft together with the world (file: data/bluelock_profiles.dat).
 * Minecraft writes it when the world saves, never every tick. A broken entry is skipped, not fatal.
 */
public final class ProfileSavedData extends SavedData implements ProfileRepository {
    public static final String NAME = "bluelock_profiles";

    private final Map<UUID, PlayerProfile> profiles = new HashMap<>();

    public static ProfileSavedData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(ProfileSavedData::loadFromTag, ProfileSavedData::new, NAME);
    }

    public static ProfileSavedData loadFromTag(CompoundTag root) {
        ProfileSavedData data = new ProfileSavedData();
        CompoundTag all = root.getCompound("profiles");
        for (String key : all.getAllKeys()) {
            try {
                PlayerProfile profile = ProfileCodec.fromMap(NbtMapConverter.fromTag(all.getCompound(key)));
                data.profiles.put(profile.id(), profile);
            } catch (RuntimeException e) {
                BlueLockMod.LOGGER.warn("Skipping unreadable Blue Lock profile '{}': {}", key, e.toString());
            }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag root) {
        CompoundTag all = new CompoundTag();
        for (PlayerProfile profile : profiles.values()) {
            all.put(profile.id().toString(), NbtMapConverter.toTag(ProfileCodec.toMap(profile)));
        }
        root.put("profiles", all);
        return root;
    }

    @Override
    public Optional<PlayerProfile> load(UUID playerId) {
        return Optional.ofNullable(profiles.get(playerId));
    }

    @Override
    public void save(PlayerProfile profile) {
        profiles.put(profile.id(), profile);
        setDirty();
    }

    @Override
    public void delete(UUID playerId) {
        if (profiles.remove(playerId) != null) {
            setDirty();
        }
    }
}
