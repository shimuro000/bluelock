package com.bluelock.forge;

import com.bluelock.common.action.KickModel;
import com.bluelock.common.ai.BotBrain;
import com.bluelock.common.ai.BotDecision;
import com.bluelock.common.ai.BotView;
import com.bluelock.common.ai.Pos;
import com.bluelock.common.ball.Velocity;
import com.bluelock.common.content.DefinitionPack;
import com.bluelock.common.content.FormationDefinition;
import com.bluelock.common.content.Playstyle;
import com.bluelock.common.content.Position;
import com.bluelock.common.content.TeamDefinition;
import com.bluelock.common.match.BallSnapshot;
import com.bluelock.common.match.MatchEvent;
import com.bluelock.common.match.MatchPhase;
import com.bluelock.common.match.MatchRules;
import com.bluelock.common.match.MatchSession;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchPlacement;
import com.bluelock.common.profile.Archetype;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.stats.OverallRating;
import com.bluelock.common.stats.RoleWeights;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import com.bluelock.common.stats.StatModifiers;
import com.bluelock.common.team.FormationSelector;
import com.bluelock.common.team.FormationSpots;
import com.bluelock.common.team.KickoffPositions;
import com.bluelock.common.team.MatchMode;
import com.bluelock.common.team.TeamSetup;
import com.bluelock.common.team.TeamTactics;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Runs the one active match of this server session: teams, formations, bots, kick-off positions, the match clock,
 * the on-screen display, sounds and XP. It finds the ball each tick, feeds the common MatchSession, and turns
 * its events into messages and resets. Everything is kept in memory only: after a server restart build the
 * pitch again with /bluelock pitch.
 */
public final class MatchManager {
    private static final double BALL_REST_HEIGHT = 0.05;
    private static final int DEFAULT_BOT_RATING = 40;
    private static final int DEFAULT_PLAYER_OVERALL = 35;
    private static final int KICKOFF_WAIT_BEFORE_BOTS = 80;
    private static final int FINISHED_CLEANUP_TICKS = 240;

    private record Member(UUID id, Side side, Archetype archetype, Integer preferredSlot) {
    }

    private record Actor(LivingEntity entity, Side side, boolean keeper) {
    }

    private static ServerLevel level;
    private static PitchPlacement pitch;
    private static MatchSession session;
    private static UUID ballId;
    private static MatchMode mode = MatchMode.FIVE_V_FIVE;
    private static final Map<Side, String> TEAM_IDS = new EnumMap<>(Side.class);
    private static final Map<Side, String> FORMATION_OVERRIDES = new EnumMap<>(Side.class);
    private static final Map<UUID, Member> MEMBERS = new LinkedHashMap<>();

    private static boolean botsEnabled = true;
    private static int botRatingOffset = 0;
    private static final List<BotEntity> BOTS = new ArrayList<>();
    private static final Map<Side, TeamSetup> ACTIVE_SETUPS = new EnumMap<>(Side.class);
    private static int kickoffWait;

    private static String bannerKey = "";
    private static String bannerArg = "";
    private static long bannerUntil;
    private static long finishedAt = -1;

    private MatchManager() {
    }

    // ---------- pitch and match lifecycle ----------

    public static boolean hasPitch() {
        return pitch != null;
    }

    public static MatchSession session() {
        return session;
    }

    public static void setPitch(ServerLevel pitchLevel, PitchPlacement placement) {
        stopMatch();
        level = pitchLevel;
        pitch = placement;
    }

    public static void startMatch(MinecraftServer server, int minutes) {
        despawnBots();
        removeBall();
        session = new MatchSession(pitch.layout(), MatchRules.ofMinutes(minutes));
        MEMBERS.values().forEach(m -> session.join(m.id(), m.side()));
        finishedAt = -1;
        kickoffWait = 0;
        ACTIVE_SETUPS.clear();
        for (Side side : Side.values()) {
            setup(side).ifPresent(s -> ACTIVE_SETUPS.put(side, s));
        }
        spawnBallAtCentre();
        session.start();
        if (botsEnabled) {
            spawnBots();
        }
        positionPlayers(server);
        banner("bluelock.banner.ready", "", 60);
        playToAll(server, ModSounds.WHISTLE.get(), 0.6F);
    }

    public static void stopMatch() {
        MinecraftServer server = level == null ? null : level.getServer();
        if (session != null) {
            session.stop();
        }
        session = null;
        despawnBots();
        removeBall();
        ACTIVE_SETUPS.clear();
        if (server != null) {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                BlueLockNetwork.sendToPlayer(player, HudPacket.inactive());
            }
        }
    }

    public static void clear() {
        session = null;
        pitch = null;
        level = null;
        ballId = null;
        BOTS.clear();
        ACTIVE_SETUPS.clear();
        PlayerStates.clear();
    }

    // ---------- teams ----------

    public static MatchMode mode() {
        return mode;
    }

    public static void setMode(MatchMode newMode) {
        mode = newMode;
        MEMBERS.replaceAll((id, m) -> new Member(m.id(), m.side(), m.archetype(), null));
        FORMATION_OVERRIDES.entrySet().removeIf(e -> {
            Optional<FormationDefinition> f = BlueLockData.get().formations().get(e.getValue());
            return f.isEmpty() || f.get().slots().size() != mode.size();
        });
    }

    public static void setBotsEnabled(boolean enabled) {
        botsEnabled = enabled;
    }

    public static boolean botsEnabled() {
        return botsEnabled;
    }

    public static void setBotRatingOffset(int offset) {
        botRatingOffset = offset;
    }

    public static void join(UUID player, Side side, Archetype archetype) {
        Member old = MEMBERS.get(player);
        Integer keep = old != null && old.side() == side ? old.preferredSlot() : null;
        MEMBERS.put(player, new Member(player, side, archetype, keep));
        if (session != null) {
            session.join(player, side);
        }
    }

    public static boolean isMember(UUID player) {
        return MEMBERS.containsKey(player);
    }

    public static Side sideOf(UUID player) {
        Member m = MEMBERS.get(player);
        return m == null ? null : m.side();
    }

    public static Side sideOfEntity(LivingEntity entity) {
        if (entity instanceof BotEntity bot) {
            return bot.side();
        }
        return sideOf(entity.getUUID());
    }

    /** slotIndex is 0-based. Returns false when the player has not joined a side or the slot does not exist. */
    public static boolean setSlot(UUID player, int slotIndex) {
        Member m = MEMBERS.get(player);
        if (m == null || slotIndex < 0 || slotIndex >= mode.size()) {
            return false;
        }
        MEMBERS.put(player, new Member(m.id(), m.side(), m.archetype(), slotIndex));
        return true;
    }

    public static void setTeam(Side side, String teamId) {
        TEAM_IDS.put(side, teamId);
    }

    /** Returns a language key describing the problem, or null when the formation was accepted. */
    public static String setFormation(Side side, String formationId) {
        Optional<FormationDefinition> f = BlueLockData.get().formations().get(formationId);
        if (f.isEmpty()) {
            return "bluelock.error.unknown_choice";
        }
        if (f.get().slots().size() != mode.size()) {
            return "bluelock.team.wrong_size";
        }
        FORMATION_OVERRIDES.put(side, formationId);
        return null;
    }

    public static Optional<TeamDefinition> teamDefinition(Side side) {
        String id = TEAM_IDS.get(side);
        return id == null ? Optional.empty() : BlueLockData.get().teams().get(id);
    }

    public static Component teamName(Side side) {
        String id = TEAM_IDS.get(side);
        return id == null || teamDefinition(side).isEmpty()
                ? Component.translatable("bluelock.team.custom")
                : Component.translatable("bluelock.team." + id + ".name");
    }

    public static Optional<TeamSetup> setup(Side side) {
        DefinitionPack pack = BlueLockData.get();
        String teamFormation = teamDefinition(side).map(TeamDefinition::formationId).orElse(null);
        Optional<FormationDefinition> formation =
                FormationSelector.choose(pack.formations(), mode.size(), FORMATION_OVERRIDES.get(side), teamFormation);
        if (formation.isEmpty()) {
            return Optional.empty();
        }
        List<TeamSetup.Candidate> candidates = new ArrayList<>();
        for (Member m : MEMBERS.values()) {
            if (m.side() == side) {
                candidates.add(new TeamSetup.Candidate(m.id(), m.archetype(), m.preferredSlot()));
            }
        }
        return Optional.of(TeamSetup.seat(formation.get(), candidates));
    }

    public static int chemistry(Side side) {
        return setup(side).map(s -> s.chemistry(archetypes(side))).orElse(0);
    }

    public static int rating(MinecraftServer server, Side side) {
        int bot = botBaseRating(side);
        Map<UUID, Integer> overalls = new HashMap<>();
        for (Member m : MEMBERS.values()) {
            if (m.side() == side) {
                overalls.put(m.id(), overallOf(server, m.id()));
            }
        }
        return setup(side).map(s -> s.rating(overalls, archetypes(side), bot)).orElse(bot);
    }

    private static int botBaseRating(Side side) {
        return teamDefinition(side).map(TeamDefinition::rating).orElse(DEFAULT_BOT_RATING);
    }

    private static Map<UUID, Archetype> archetypes(Side side) {
        Map<UUID, Archetype> map = new HashMap<>();
        for (Member m : MEMBERS.values()) {
            if (m.side() == side) {
                map.put(m.id(), m.archetype());
            }
        }
        return map;
    }

    private static int overallOf(MinecraftServer server, UUID player) {
        Optional<PlayerProfile> profile = ProfileSavedData.get(server).load(player);
        return profile
                .map(p -> OverallRating.compute(p.stats(), StatModifiers.NONE, RoleWeights.forArchetype(p.archetype())))
                .orElse(DEFAULT_PLAYER_OVERALL);
    }

    /** Team-mates of a player (other players and bots on the same side), used for pass aiming. */
    public static List<LivingEntity> teammatesOf(LivingEntity who) {
        List<LivingEntity> mates = new ArrayList<>();
        Side side = sideOfEntity(who);
        if (side == null || level == null) {
            return mates;
        }
        MinecraftServer server = level.getServer();
        for (Member m : MEMBERS.values()) {
            ServerPlayer p = server.getPlayerList().getPlayer(m.id());
            if (m.side() == side && p != null && p != who && p.level() == level) {
                mates.add(p);
            }
        }
        for (BotEntity bot : BOTS) {
            if (bot.side() == side && bot != who && bot.isAlive()) {
                mates.add(bot);
            }
        }
        return mates;
    }

    /** The point in the goal this player attacks, for shot aim assist. Null outside a match. */
    public static Vec3 attackTarget(ServerPlayer player) {
        Side side = sideOf(player.getUUID());
        if (side == null || pitch == null || session == null) {
            return null;
        }
        double u = side == Side.HOME ? pitch.layout().length() + 0.5 : -0.5;
        double v = pitch.layout().centreV() + 0.5;
        return new Vec3(pitch.worldX(u, v), pitch.worldY(1.2), pitch.worldZ(u, v));
    }

    /** Moves every seated human to their formation spot, facing the opponent's goal. */
    private static void positionPlayers(MinecraftServer server) {
        if (pitch == null || level == null) {
            return;
        }
        for (Side side : Side.values()) {
            TeamSetup setup = ACTIVE_SETUPS.get(side);
            if (setup == null) {
                continue;
            }
            for (int i = 0; i < setup.size(); i++) {
                UUID occupant = setup.occupant(i);
                if (occupant == null) {
                    continue;
                }
                ServerPlayer player = server.getPlayerList().getPlayer(occupant);
                if (player == null || player.level() != level) {
                    continue;
                }
                double[] spot = KickoffPositions.spot(pitch.layout(), side, setup.formation().slots().get(i));
                player.connection.teleport(pitch.worldX(spot[0], spot[1]), pitch.worldY(0.0), pitch.worldZ(spot[0], spot[1]),
                        pitch.yawAlongPitch(side == Side.HOME), 0.0F);
            }
        }
    }

    /** World position (x, z) of the centre of the goal each side defends. */
    public static String goalPosition(Side defending) {
        double u = defending == Side.HOME ? -1.0 : pitch.layout().length() + 1.0;
        double v = pitch.layout().centreV() + 0.5;
        return Math.round(pitch.worldX(u, v)) + ", " + Math.round(pitch.worldZ(u, v));
    }

    // ---------- bots ----------

    private static void spawnBots() {
        for (Side side : Side.values()) {
            TeamSetup setup = ACTIVE_SETUPS.get(side);
            if (setup == null) {
                continue;
            }
            int rating = Math.max(20, Math.min(95, botBaseRating(side) + botRatingOffset));
            for (int i = 0; i < setup.size(); i++) {
                if (setup.occupant(i) != null) {
                    continue;
                }
                FormationDefinition.Slot slot = setup.formation().slots().get(i);
                BotEntity bot = new BotEntity(ModEntities.BOT.get(), level);
                bot.configure(side, i, slot.position(), rating);
                double[] spot = KickoffPositions.spot(pitch.layout(), side, slot);
                bot.moveTo(pitch.worldX(spot[0], spot[1]), pitch.worldY(0.0), pitch.worldZ(spot[0], spot[1]),
                        pitch.yawAlongPitch(side == Side.HOME), 0.0F);
                level.addFreshEntity(bot);
                BOTS.add(bot);
            }
        }
    }

    private static void despawnBots() {
        for (BotEntity bot : BOTS) {
            if (!bot.isRemoved()) {
                bot.discard();
            }
        }
        BOTS.clear();
    }

    private static void repositionBots() {
        for (BotEntity bot : BOTS) {
            TeamSetup setup = ACTIVE_SETUPS.get(bot.side());
            if (setup == null || bot.slotIndex() >= setup.size() || bot.isRemoved()) {
                continue;
            }
            double[] spot = KickoffPositions.spot(pitch.layout(), bot.side(), setup.formation().slots().get(bot.slotIndex()));
            bot.stopRunning();
            bot.setDeltaMovement(0, 0, 0);
            bot.moveTo(pitch.worldX(spot[0], spot[1]), pitch.worldY(0.0), pitch.worldZ(spot[0], spot[1]),
                    pitch.yawAlongPitch(bot.side() == Side.HOME), 0.0F);
        }
    }

    private static List<Actor> actors(MinecraftServer server) {
        List<Actor> list = new ArrayList<>();
        for (Member m : MEMBERS.values()) {
            ServerPlayer p = server.getPlayerList().getPlayer(m.id());
            if (p != null && p.level() == level) {
                list.add(new Actor(p, m.side(), false));
            }
        }
        for (BotEntity bot : BOTS) {
            if (bot.isAlive() && !bot.isRemoved()) {
                list.add(new Actor(bot, bot.side(), bot.botPosition() == Position.GK));
            }
        }
        return list;
    }

    private static Pos posOf(Entity e) {
        return new Pos(pitch.localU(e.getX(), e.getZ()), pitch.localV(e.getX(), e.getZ()));
    }

    private static void tickBots(MinecraftServer server, BallEntity ball) {
        MatchPhase phase = session.phase();
        if (phase == MatchPhase.WAITING_KICKOFF) {
            kickoffWait++;
        } else {
            kickoffWait = 0;
        }
        boolean live = phase == MatchPhase.IN_PLAY || phase == MatchPhase.WAITING_RESTART
                || (phase == MatchPhase.WAITING_KICKOFF && kickoffWait > KICKOFF_WAIT_BEFORE_BOTS);
        if (!live || BOTS.isEmpty()) {
            return;
        }
        List<Actor> actors = actors(server);
        long now = level.getGameTime();
        for (int i = 0; i < BOTS.size(); i++) {
            BotEntity bot = BOTS.get(i);
            if (bot.isRemoved() || !bot.isAlive() || (now + i) % 3 != 0) {
                continue;
            }
            runBot(server, ball, bot, actors);
        }
    }

    private static void runBot(MinecraftServer server, BallEntity ball, BotEntity bot, List<Actor> actors) {
        Side side = bot.side();
        TeamSetup setup = ACTIVE_SETUPS.get(side);
        if (setup == null || bot.slotIndex() >= setup.size()) {
            return;
        }
        List<Actor> mates = new ArrayList<>();
        List<Actor> foes = new ArrayList<>();
        for (Actor a : actors) {
            if (a.entity() == bot) {
                continue;
            }
            (a.side() == side ? mates : foes).add(a);
        }
        List<Pos> matePositions = new ArrayList<>();
        for (Actor a : mates) {
            matePositions.add(posOf(a.entity()));
        }
        List<Pos> foePositions = new ArrayList<>();
        for (Actor a : foes) {
            foePositions.add(posOf(a.entity()));
        }
        Pos self = posOf(bot);
        Pos ballPos = posOf(ball);
        LivingEntity carrier = ball.carrier();
        Side possession = carrier == null ? null : sideOfEntity(carrier);
        Pos carrierPos = carrier == null ? null : posOf(carrier);

        int rank = 0;
        double myDistance = self.dist(ballPos);
        for (Actor a : mates) {
            if (!a.keeper() && posOf(a.entity()).dist(ballPos) < myDistance) {
                rank++;
            }
        }
        if (bot.botPosition() == Position.GK) {
            rank = 3;
        }
        double[] base = FormationSpots.baseSpot(pitch.layout(), side, setup.formation().slots().get(bot.slotIndex()));
        TeamTactics tactics = TeamTactics.forPlaystyle(teamDefinition(side).map(TeamDefinition::playstyle).orElse(Playstyle.BALANCED));
        BotView view = new BotView(side, bot.botPosition(), self, ballPos, carrier == bot, possession, carrierPos, rank,
                bot.rating(), tactics, new Pos(base[0], base[1]), matePositions, foePositions, pitch.layout());
        execute(server, ball, bot, BotBrain.decide(view), mates);
    }

    private static void execute(MinecraftServer server, BallEntity ball, BotEntity bot, BotDecision d, List<Actor> mates) {
        boolean carrying = ball.carrier() == bot;
        double speed = d.speed() * (carrying ? 0.9 : 1.0);
        StatBlock stats = bot.stats();
        switch (d.intent()) {
            case HOLD, MOVE, DRIBBLE -> bot.runTo(pitch.worldX(d.target().u(), d.target().v()), pitch.worldZ(d.target().u(), d.target().v()), speed);
            case CHASE_BALL -> {
                Vec3 motion = ball.getDeltaMovement();
                bot.runTo(ball.getX() + motion.x * 5, ball.getZ() + motion.z * 5, speed);
            }
            case PRESS -> {
                LivingEntity carrier = ball.carrier();
                if (carrier != null) {
                    bot.runTo(carrier.getX(), carrier.getZ(), speed);
                }
            }
            case TACKLE -> {
                LivingEntity carrier = ball.carrier();
                if (carrier != null) {
                    bot.runTo(carrier.getX(), carrier.getZ(), speed);
                    TackleActions.attempt(server, bot, TackleActions.Mode.STAND);
                }
            }
            case PASS -> {
                if (carrying && ball.carriedTicks() >= 10 && d.passIndex() >= 0 && d.passIndex() < mates.size()) {
                    LivingEntity mate = mates.get(d.passIndex()).entity();
                    double lx = mate.getX() + (mate.getX() - mate.xo) * 6;
                    double lz = mate.getZ() + (mate.getZ() - mate.zo) * 6;
                    double dx = lx - ball.getX();
                    double dz = lz - ball.getZ();
                    ball.kickBy(bot, BallEntity.passVelocity(dx, dz, Math.sqrt(dx * dx + dz * dz), stats), false);
                } else {
                    bot.runTo(pitch.worldX(d.target().u(), d.target().v()), pitch.worldZ(d.target().u(), d.target().v()), speed);
                }
            }
            case SHOOT -> {
                if (carrying && ball.carriedTicks() >= 6) {
                    double tx = pitch.worldX(d.target().u(), d.target().v());
                    double tz = pitch.worldZ(d.target().u(), d.target().v());
                    Velocity v = KickModel.shot(tx - ball.getX(), pitch.worldY(0.9) - ball.getY(), tz - ball.getZ(),
                            stats.permanent(Stat.SHOOTING), stats.permanent(Stat.FINISHING), stats.permanent(Stat.SHOT_POWER),
                            1.0, 0.1, ThreadLocalRandom.current()::nextDouble);
                    ball.kickBy(bot, v, true);
                }
            }
            case CLEAR -> {
                if (carrying && ball.carriedTicks() >= (bot.botPosition() == Position.GK ? 15 : 6)) {
                    double tx = pitch.worldX(d.target().u(), d.target().v());
                    double tz = pitch.worldZ(d.target().u(), d.target().v());
                    Velocity flat = KickModel.pass(tx - ball.getX(), tz - ball.getZ(), 32.0,
                            stats.permanent(Stat.PASSING), ThreadLocalRandom.current()::nextDouble);
                    ball.kickBy(bot, new Velocity(flat.x(), 0.28, flat.z()), true);
                }
            }
        }
    }

    // ---------- every tick ----------

    public static void tick(MinecraftServer server) {
        if (session == null || pitch == null || level == null) {
            return;
        }
        long now = level.getGameTime();
        if (server.getTickCount() % 5 == 0) {
            sendHud(server, now);
        }
        if (session.phase() == MatchPhase.FINISHED) {
            if (finishedAt < 0) {
                finishedAt = now;
            } else if (now - finishedAt > FINISHED_CLEANUP_TICKS) {
                stopMatch();
            }
            return;
        }
        if (!session.isActive()) {
            return;
        }
        BallEntity ball = findBall();
        if (ball == null) {
            ball = spawnBallAtCentre();
            session.ballReplaced();
        }
        BallSnapshot snapshot = new BallSnapshot(
                pitch.localU(ball.getX(), ball.getZ()),
                pitch.localV(ball.getX(), ball.getZ()),
                pitch.localHeight(ball.getY() + 0.2),
                ball.touchCount(),
                ball.lastToucher());
        List<MatchEvent> events = session.tick(snapshot);
        for (MatchEvent event : events) {
            handle(server, ball, event);
        }
        if (session.isActive()) {
            tickBots(server, ball);
        }
    }

    private static void handle(MinecraftServer server, BallEntity ball, MatchEvent event) {
        if (event instanceof MatchEvent.PlayStarted) {
            broadcast(server, Component.translatable("bluelock.match.kickoff"));
            banner("bluelock.banner.kickoff", "", 40);
            playToAll(server, ModSounds.WHISTLE.get(), 0.7F);
        } else if (event instanceof MatchEvent.GoalScored goal) {
            Component side = sideName(goal.scoringSide());
            String name = goal.scorer() != null ? playerName(server, goal.scorer()) : "";
            if (goal.ownGoal()) {
                broadcast(server, Component.translatable("bluelock.match.own_goal", side, goal.homeGoals(), goal.awayGoals()));
            } else if (goal.scorer() != null) {
                broadcast(server, Component.translatable("bluelock.match.goal_by", side, name, goal.homeGoals(), goal.awayGoals()));
                Rewards.give(server, goal.scorer(), Progression.XpAction.GOAL);
            } else {
                broadcast(server, Component.translatable("bluelock.match.goal", side, goal.homeGoals(), goal.awayGoals()));
            }
            if (name.isEmpty()) {
                banner(goal.scoringSide() == Side.HOME ? "bluelock.banner.goal_home" : "bluelock.banner.goal_away", "", 80);
            } else {
                banner("bluelock.banner.goal", name, 80);
            }
            playToAll(server, ModSounds.GOAL.get(), 1.0F);
        } else if (event instanceof MatchEvent.BallOut out) {
            ball.placeAt(pitch.worldX(out.restartU(), out.restartV()), pitch.worldY(BALL_REST_HEIGHT),
                    pitch.worldZ(out.restartU(), out.restartV()));
            broadcast(server, Component.translatable("bluelock.match.out"));
            banner("bluelock.banner.out", "", 30);
            playToAll(server, ModSounds.WHISTLE.get(), 0.4F);
        } else if (event instanceof MatchEvent.KickoffReset) {
            placeAtCentre(ball);
            repositionBots();
            positionPlayers(server);
            broadcast(server, Component.translatable("bluelock.match.kickoff_ready"));
            banner("bluelock.banner.ready", "", 50);
            playToAll(server, ModSounds.WHISTLE.get(), 0.5F);
        } else if (event instanceof MatchEvent.MatchFinished finished) {
            if (finished.winner() == null) {
                broadcast(server, Component.translatable("bluelock.match.finished_draw", finished.homeGoals(), finished.awayGoals()));
            } else {
                broadcast(server, Component.translatable("bluelock.match.finished", finished.homeGoals(), finished.awayGoals(),
                        sideName(finished.winner())));
            }
            banner("bluelock.banner.fulltime", "", 100);
            playToAll(server, ModSounds.WHISTLE.get(), 1.0F);
            for (Member m : MEMBERS.values()) {
                Rewards.give(server, m.id(), Progression.XpAction.MATCH_PLAYED);
                if (finished.winner() == m.side()) {
                    Rewards.give(server, m.id(), Progression.XpAction.MATCH_WON);
                }
            }
        }
    }

    // ---------- display, sounds, messages ----------

    private static void banner(String key, String arg, int ticks) {
        bannerKey = key;
        bannerArg = arg;
        bannerUntil = level == null ? 0 : level.getGameTime() + ticks;
    }

    private static void sendHud(MinecraftServer server, long now) {
        int possession = session.possession() == null ? -1 : session.possession().ordinal();
        int homeColor = teamDefinition(Side.HOME).map(TeamDefinition::colorRgb).orElse(0x2F6BFF);
        int awayColor = teamDefinition(Side.AWAY).map(TeamDefinition::colorRgb).orElse(0xC0392B);
        int bannerTicks = (int) Math.max(0, bannerUntil - now);
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            PlayerState state = PlayerStates.get(player);
            int[] cooldowns = new int[ActionIds.COUNT];
            for (int i = 0; i < cooldowns.length; i++) {
                long left = Math.max(0, state.readyAt[i] - now);
                cooldowns[i] = state.cooldownLength[i] <= 0 ? 0 : (int) Math.min(100, Math.round(100.0 * left / state.cooldownLength[i]));
            }
            BlueLockNetwork.sendToPlayer(player, new HudPacket(true, session.homeGoals(), session.awayGoals(),
                    session.elapsedTicks(), session.durationTicks(), session.phase().ordinal(), possession,
                    homeColor, awayColor, bannerTicks > 0 ? bannerKey : "", bannerArg, bannerTicks,
                    state.stamina.percent(), cooldowns));
        }
    }

    private static void playToAll(MinecraftServer server, SoundEvent sound, float volume) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.playNotifySound(sound, SoundSource.PLAYERS, volume, 1.0F);
        }
    }

    public static Component sideName(Side side) {
        return Component.translatable("bluelock.side." + side.name().toLowerCase(Locale.ROOT));
    }

    public static String playerName(MinecraftServer server, UUID id) {
        ServerPlayer player = server.getPlayerList().getPlayer(id);
        return player == null ? "?" : player.getGameProfile().getName();
    }

    private static void broadcast(MinecraftServer server, Component message) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.sendSystemMessage(message);
        }
    }

    // ---------- the ball ----------

    private static BallEntity findBall() {
        if (ballId == null) {
            return null;
        }
        Entity entity = level.getEntity(ballId);
        if (entity instanceof BallEntity ball && !ball.isRemoved()) {
            return ball;
        }
        return null;
    }

    private static void removeBall() {
        BallEntity ball = findBall();
        if (ball != null) {
            ball.discard();
        }
        ballId = null;
    }

    private static BallEntity spawnBallAtCentre() {
        BallEntity ball = BallEntity.spawn(level, 0, 0, 0);
        placeAtCentre(ball);
        ballId = ball.getUUID();
        return ball;
    }

    private static void placeAtCentre(BallEntity ball) {
        double u = pitch.layout().centreU() + 0.5;
        double v = pitch.layout().centreV() + 0.5;
        ball.placeAt(pitch.worldX(u, v), pitch.worldY(BALL_REST_HEIGHT), pitch.worldZ(u, v));
    }
}
