package com.bluelock.forge;

import java.util.Locale;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * The on-screen display (client only): scoreboard with clock and possession, stamina bar,
 * a row of key icons with cooldowns, and big banners for goals, kick-off and full time.
 */
public final class ClientHud implements IGuiOverlay {
    private static final String[] SHORT_NAME_KEYS = {
            "bluelock.hud.pass", "bluelock.hud.shot", "bluelock.hud.slide", "bluelock.hud.feint",
            "bluelock.hud.burst", "bluelock.hud.chain", "bluelock.hud.sprint", "bluelock.hud.shoulder"};

    @Override
    public void render(ForgeGui gui, GuiGraphics graphics, float partialTick, int width, int height) {
        if (!ClientHudState.active) {
            return;
        }
        Font font = gui.getFont();
        drawScoreboard(graphics, font, width);
        drawStamina(graphics, font, height);
        drawKeys(graphics, font, height);
        drawBanner(graphics, font, width, height);
    }

    private static String clock(int ticks) {
        int seconds = Math.max(0, ticks / 20);
        return String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60);
    }

    private void drawScoreboard(GuiGraphics g, Font font, int width) {
        int cx = width / 2;
        int half = 80;
        g.fill(cx - half, 4, cx + half, 26, 0xB0000000);
        g.fill(cx - half, 4, cx - half + 5, 26, 0xFF000000 | ClientHudState.homeColor);
        g.fill(cx + half - 5, 4, cx + half, 26, 0xFF000000 | ClientHudState.awayColor);
        g.drawCenteredString(font, ClientHudState.home + "  -  " + ClientHudState.away, cx, 8, 0xFFFFFFFF);
        g.drawCenteredString(font, clock(ClientHudState.elapsed) + " / " + clock(ClientHudState.duration), cx, 28, 0xFFDDDDDD);
        g.drawString(font, Component.translatable("bluelock.side.home"), cx - half + 9, 8, 0xFFFFFFFF, true);
        Component away = Component.translatable("bluelock.side.away");
        g.drawString(font, away, cx + half - 9 - font.width(away), 8, 0xFFFFFFFF, true);
        // possession: a bright strip under the side that has the ball
        if (ClientHudState.possession == 0) {
            g.fill(cx - half, 26, cx, 28, 0xFF000000 | ClientHudState.homeColor);
        } else if (ClientHudState.possession == 1) {
            g.fill(cx, 26, cx + half, 28, 0xFF000000 | ClientHudState.awayColor);
        }
    }

    private void drawStamina(GuiGraphics g, Font font, int height) {
        int x = 10;
        int y = height - 14;
        int w = 100;
        int pct = Math.max(0, Math.min(100, ClientHudState.stamina));
        int color = pct > 50 ? 0xFF44CC44 : pct > 20 ? 0xFFDDBB33 : 0xFFDD3333;
        g.fill(x - 1, y - 1, x + w + 1, y + 7, 0xB0000000);
        g.fill(x, y, x + pct * w / 100, y + 6, color);
        g.drawString(font, Component.translatable("bluelock.hud.stamina"), x, y - 11, 0xFFFFFFFF, true);
    }

    private void drawKeys(GuiGraphics g, Font font, int height) {
        int size = 20;
        int gap = 3;
        int x0 = 10;
        int y0 = height - 14 - 11 - size - 14;
        for (int i = 0; i < ActionIds.COUNT; i++) {
            int x = x0 + i * (size + gap);
            g.fill(x, y0, x + size, y0 + size, 0xB0000000);
            int cooldown = i < ClientHudState.cooldowns.length ? ClientHudState.cooldowns[i] : 0;
            if (cooldown > 0) {
                int h = size * cooldown / 100;
                g.fill(x, y0 + size - h, x + size, y0 + size, 0xC0888888);
            }
            Component key = ClientKeys.BY_ACTION[i].getTranslatedKeyMessage();
            g.drawString(font, key, x + (size - font.width(key)) / 2, y0 + 6, 0xFFFFFFFF, true);
            g.pose().pushPose();
            g.pose().translate(x + 1, y0 + size + 2, 0);
            g.pose().scale(0.6F, 0.6F, 1.0F);
            g.drawString(font, Component.translatable(SHORT_NAME_KEYS[i]), 0, 0, 0xFFCCCCCC, false);
            g.pose().popPose();
        }
    }

    private void drawBanner(GuiGraphics g, Font font, int width, int height) {
        if (ClientHudState.bannerTicks <= 0 || ClientHudState.bannerKey.isEmpty()) {
            return;
        }
        int fade = Math.min(20, ClientHudState.bannerTicks);
        int alpha = Math.max(8, 255 * fade / 20);
        Component text = ClientHudState.bannerArg.isEmpty()
                ? Component.translatable(ClientHudState.bannerKey)
                : Component.translatable(ClientHudState.bannerKey, ClientHudState.bannerArg);
        g.pose().pushPose();
        g.pose().translate(width / 2.0F, height / 3.0F, 0);
        g.pose().scale(2.5F, 2.5F, 1.0F);
        g.drawCenteredString(font, text, 0, 0, (alpha << 24) | 0xFFD040);
        g.pose().popPose();
    }
}
