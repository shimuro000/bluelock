package com.bluelock.forge;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

/** The football key bindings (client only). Players can change them in Options > Controls > Blue Lock. */
public final class ClientKeys {
    private static final String CATEGORY = "key.categories.bluelock";

    public static final KeyMapping PASS = new KeyMapping("key.bluelock.pass", InputConstants.KEY_R, CATEGORY);
    public static final KeyMapping SHOT = new KeyMapping("key.bluelock.shot", InputConstants.KEY_F, CATEGORY);
    public static final KeyMapping SLIDE = new KeyMapping("key.bluelock.slide", InputConstants.KEY_V, CATEGORY);
    public static final KeyMapping FEINT = new KeyMapping("key.bluelock.feint", InputConstants.KEY_Z, CATEGORY);
    public static final KeyMapping BURST = new KeyMapping("key.bluelock.burst", InputConstants.KEY_X, CATEGORY);
    public static final KeyMapping CHAIN = new KeyMapping("key.bluelock.chain", InputConstants.KEY_C, CATEGORY);
    public static final KeyMapping SPRINT = new KeyMapping("key.bluelock.sprint", InputConstants.KEY_B, CATEGORY);
    public static final KeyMapping SHOULDER = new KeyMapping("key.bluelock.shoulder", InputConstants.KEY_G, CATEGORY);

    /** Index = action id (see ActionIds). */
    public static final KeyMapping[] BY_ACTION = {PASS, SHOT, SLIDE, FEINT, BURST, CHAIN, SPRINT, SHOULDER};

    private ClientKeys() {
    }
}
