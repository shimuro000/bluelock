package com.bluelock.forge;

import com.bluelock.common.action.KickModel;
import com.bluelock.common.action.PassAssist;
import com.bluelock.common.ball.Velocity;
import com.bluelock.common.content.SkillDefinition;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** What happens on the server when a player presses a football key (pass, shot, slide tackle, dribble skills). */
public final class PlayerActions {
    private static final String[] SKILL_FOR_ACTION = new String[ActionIds.COUNT];
    private static final int SLIDE_COST = 15;
    private static final int SLIDE_COOLDOWN = 50;

    static {
        SKILL_FOR_ACTION[ActionIds.FEINT] = "feint";
        SKILL_FOR_ACTION[ActionIds.BURST] = "burst_dribble";
        SKILL_FOR_ACTION[ActionIds.CHAIN] = "chain_dribble";
        SKILL_FOR_ACTION[ActionIds.SPRINT] = "sprint_burst";
        SKILL_FOR_ACTION[ActionIds.SHOULDER] = "shoulder_charge";
    }

    private PlayerActions() {
    }

    public static void handle(ServerPlayer player, int action) {
        switch (action) {
            case ActionIds.PASS -> pass(player);
            case ActionIds.SHOT -> shot(player);
            case ActionIds.SLIDE -> slide(player);
            case ActionIds.FEINT, ActionIds.BURST, ActionIds.CHAIN, ActionIds.SPRINT, ActionIds.SHOULDER -> skill(player, action);
            default -> { }
        }
    }

    // ---------- state checks used by other classes ----------

    static boolean isImmune(LivingEntity entity, long now) {
        if (entity instanceof ServerPlayer player) {
            PlayerState state = PlayerStates.peek(player.getUUID());
            return state != null && now < state.immuneUntil;
        }
        return false;
    }

    static boolean hasNoLoss(LivingEntity entity, long now) {
        if (entity instanceof ServerPlayer player) {
            PlayerState state = PlayerStates.peek(player.getUUID());
            return state != null && now < state.noLossUntil;
        }
        return false;
    }

    // ---------- kicks ----------

    /** The ball this player carries, or a loose ball right at their feet. */
    private static BallEntity ballFor(ServerPlayer player) {
        List<BallEntity> balls = player.level().getEntitiesOfClass(BallEntity.class, player.getBoundingBox().inflate(3.0));
        BallEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (BallEntity ball : balls) {
            if (ball.carrier() == player) {
                return ball;
            }
            double d = ball.distanceTo(player);
            if (ball.carrier() == null && d < 2.6 && d < bestDist) {
                bestDist = d;
                best = ball;
            }
        }
        return best;
    }

    public static void pass(ServerPlayer player) {
        BallEntity ball = ballFor(player);
        if (ball == null) {
            return;
        }
        MinecraftServer server = player.getServer();
        StatBlock stats = ActorStats.of(server, player);
        Vec3 look = player.getLookAngle();
        List<LivingEntity> mates = MatchManager.teammatesOf(player);
        List<double[]> positions = new ArrayList<>();
        for (LivingEntity mate : mates) {
            positions.add(new double[] {mate.getX(), mate.getZ()});
        }
        int target = PassAssist.pick(player.getX(), player.getZ(), look.x, look.z, positions, 28.0, 3.0, 45.0);
        double dx = look.x;
        double dz = look.z;
        double distance = 0;
        if (target >= 0) {
            LivingEntity mate = mates.get(target);
            double leadX = mate.getX() + (mate.getX() - mate.xo) * 6;
            double leadZ = mate.getZ() + (mate.getZ() - mate.zo) * 6;
            dx = leadX - ball.getX();
            dz = leadZ - ball.getZ();
            distance = Math.sqrt(dx * dx + dz * dz);
        }
        Velocity v = KickModel.pass(dx, dz, distance, stats.permanent(Stat.PASSING), ThreadLocalRandom.current()::nextDouble);
        ball.kickBy(player, v, false);
        Rewards.give(server, player.getUUID(), Progression.XpAction.PASS);
    }

    public static void shot(ServerPlayer player) {
        BallEntity ball = ballFor(player);
        if (ball == null) {
            return;
        }
        MinecraftServer server = player.getServer();
        StatBlock stats = ActorStats.of(server, player);
        Vec3 look = player.getLookAngle();
        double[] dir = {look.x, look.y, look.z};
        Vec3 goal = MatchManager.attackTarget(player);
        if (goal != null) {
            double[] toGoal = {goal.x - ball.getX(), goal.y - ball.getY(), goal.z - ball.getZ()};
            dir = KickModel.aimToward(dir, toGoal, 18.0, 0.7);
        }
        Velocity v = KickModel.shot(dir[0], Math.max(dir[1], 0.0), dir[2],
                stats.permanent(Stat.SHOOTING), stats.permanent(Stat.FINISHING), stats.permanent(Stat.SHOT_POWER),
                1.0, 0.12, ThreadLocalRandom.current()::nextDouble);
        ball.kickBy(player, v, true);
        Rewards.give(server, player.getUUID(), Progression.XpAction.SHOT);
    }

    // ---------- slide tackle ----------

    private static void slide(ServerPlayer player) {
        PlayerState state = PlayerStates.get(player);
        long now = player.level().getGameTime();
        if (now < state.readyAt[ActionIds.SLIDE]) {
            return;
        }
        if (!state.stamina.spend(SLIDE_COST)) {
            player.displayClientMessage(Component.translatable("bluelock.action.tired"), true);
            return;
        }
        state.startCooldown(ActionIds.SLIDE, now, SLIDE_COOLDOWN);
        Vec3 heading = heading(player);
        state.slideX = heading.x;
        state.slideZ = heading.z;
        state.slideUntil = now + 10;
        player.playNotifySound(ModSounds.SKILL.get(), net.minecraft.sounds.SoundSource.PLAYERS, 0.8F, 0.8F);
    }

    // ---------- dribble skills and abilities ----------

    private static void skill(ServerPlayer player, int action) {
        String skillId = SKILL_FOR_ACTION[action];
        MinecraftServer server = player.getServer();
        Optional<SkillDefinition> def = BlueLockData.get().skills().get(skillId);
        Optional<PlayerProfile> profile = ProfileSavedData.get(server).load(player.getUUID());
        if (def.isEmpty()) {
            return;
        }
        if (profile.isEmpty()) {
            player.displayClientMessage(Component.translatable("bluelock.error.no_profile"), true);
            return;
        }
        if (!profile.get().isUnlocked(skillId)) {
            player.displayClientMessage(Component.translatable("bluelock.skill.locked",
                    Component.translatable(def.get().nameKey())), true);
            return;
        }
        PlayerState state = PlayerStates.get(player);
        long now = player.level().getGameTime();
        if (now < state.readyAt[action]) {
            return;
        }
        if (!state.stamina.spend(def.get().staminaCost())) {
            player.displayClientMessage(Component.translatable("bluelock.action.tired"), true);
            return;
        }
        state.startCooldown(action, now, def.get().cooldownTicks());

        Vec3 h = heading(player);
        Vec3 side = new Vec3(-h.z, 0, h.x);
        switch (skillId) {
            case "feint" -> {
                push(player, side.scale(0.55 * state.feintSide).add(h.scale(0.15)));
                state.feintSide = -state.feintSide;
                state.immuneUntil = now + 12;
            }
            case "burst_dribble" -> {
                push(player, h.scale(0.8));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 25, 1, false, false));
                state.immuneUntil = now + 14;
            }
            case "chain_dribble" -> {
                push(player, side.scale(0.4 * state.feintSide).add(h.scale(0.5)));
                state.feintSide = -state.feintSide;
                state.immuneUntil = now + 30;
                state.noLossUntil = now + 40;
            }
            case "sprint_burst" -> player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 50, 2, false, false));
            case "shoulder_charge" -> TackleActions.attempt(server, player, TackleActions.Mode.SHOULDER);
            default -> { }
        }
        player.playNotifySound(ModSounds.SKILL.get(), net.minecraft.sounds.SoundSource.PLAYERS, 0.7F, 1.0F);
        boolean carrying = isCarryingBall(player);
        Rewards.give(server, player.getUUID(), carrying ? Progression.XpAction.DRIBBLE_MOVE : Progression.XpAction.SKILL_USED);
    }

    private static boolean isCarryingBall(ServerPlayer player) {
        for (BallEntity ball : player.level().getEntitiesOfClass(BallEntity.class, player.getBoundingBox().inflate(4.0))) {
            if (ball.carrier() == player) {
                return true;
            }
        }
        return false;
    }

    private static void push(ServerPlayer player, Vec3 velocity) {
        player.setDeltaMovement(player.getDeltaMovement().add(velocity));
        player.hurtMarked = true;
    }

    /** Direction the player is running in, or the way they look when standing still. Unit vector, horizontal. */
    private static Vec3 heading(ServerPlayer player) {
        double dx = player.getX() - player.xo;
        double dz = player.getZ() - player.zo;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len > 0.03) {
            return new Vec3(dx / len, 0, dz / len);
        }
        Vec3 look = player.getLookAngle();
        double l = Math.sqrt(look.x * look.x + look.z * look.z);
        return l < 1.0E-3 ? new Vec3(0, 0, 1) : new Vec3(look.x / l, 0, look.z / l);
    }
}
