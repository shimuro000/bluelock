package com.bluelock.forge;

import com.bluelock.common.action.StaminaPool;

/** Short-lived, server-side state of one player: stamina, cooldowns and move effects. Not saved. */
final class PlayerState {
    final StaminaPool stamina;
    final long[] readyAt = new long[ActionIds.COUNT];
    final int[] cooldownLength = new int[ActionIds.COUNT];
    long tackleReadyAt;
    long immuneUntil;
    long noLossUntil;
    long slideUntil;
    double slideX;
    double slideZ;
    int feintSide = 1;

    void startCooldown(int action, long now, int ticks) {
        readyAt[action] = now + ticks;
        cooldownLength[action] = Math.max(1, ticks);
    }

    PlayerState(int staminaStat) {
        this.stamina = new StaminaPool(staminaStat);
    }
}
