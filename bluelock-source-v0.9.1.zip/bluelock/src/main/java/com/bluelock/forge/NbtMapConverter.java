package com.bluelock.forge;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NumericTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;

/** Converts the plain Maps used by the common module to and from Minecraft NBT. */
final class NbtMapConverter {
    private NbtMapConverter() {
    }

    static CompoundTag toTag(Map<String, Object> map) {
        CompoundTag tag = new CompoundTag();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (value instanceof String s) {
                tag.putString(key, s);
            } else if (value instanceof Integer i) {
                tag.putInt(key, i);
            } else if (value instanceof Long l) {
                tag.putLong(key, l);
            } else if (value instanceof Double d) {
                tag.putDouble(key, d);
            } else if (value instanceof Map<?, ?> nested) {
                @SuppressWarnings("unchecked")
                Map<String, Object> typed = (Map<String, Object>) nested;
                tag.put(key, toTag(typed));
            }
        }
        return tag;
    }

    static Map<String, Object> fromTag(CompoundTag tag) {
        Map<String, Object> map = new LinkedHashMap<>();
        for (String key : tag.getAllKeys()) {
            Tag value = tag.get(key);
            if (value instanceof CompoundTag nested) {
                map.put(key, fromTag(nested));
            } else if (value instanceof StringTag s) {
                map.put(key, s.getAsString());
            } else if (value instanceof NumericTag n) {
                map.put(key, n.getAsNumber());
            }
        }
        return map;
    }
}
