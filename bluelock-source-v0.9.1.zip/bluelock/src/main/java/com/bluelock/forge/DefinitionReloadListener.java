package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import com.bluelock.common.content.DefinitionPack;
import com.bluelock.common.content.RawDefinition;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/**
 * Reads every file under data/bluelock/definitions/<type>/<id>.json whenever data packs load or /reload runs,
 * and swaps the result into {@link BlueLockData}. Bad files are logged and skipped.
 */
public class DefinitionReloadListener extends SimpleJsonResourceReloadListener {

    public DefinitionReloadListener() {
        super(new Gson(), "definitions");
    }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> files, ResourceManager resourceManager, ProfilerFiller profiler) {
        List<RawDefinition> raws = new ArrayList<>();
        List<String> readProblems = new ArrayList<>();

        for (Map.Entry<ResourceLocation, JsonElement> file : files.entrySet()) {
            ResourceLocation location = file.getKey();
            if (!BlueLockConstants.MOD_ID.equals(location.getNamespace())) {
                continue;
            }
            String path = location.getPath(); // e.g. "skills/direct_shot"
            int slash = path.indexOf('/');
            if (slash <= 0 || slash == path.length() - 1) {
                readProblems.add(path + ": file must be inside a type folder (skills, formations or teams)");
                continue;
            }
            Object converted = JsonToJava.convert(file.getValue());
            if (!(converted instanceof Map<?, ?>)) {
                readProblems.add(path + ": file must contain a JSON object");
                continue;
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> data = (Map<String, Object>) converted;
            raws.add(new RawDefinition(path.substring(0, slash), path.substring(slash + 1), data));
        }

        DefinitionPack pack = DefinitionPack.build(raws);
        BlueLockData.set(pack);

        readProblems.forEach(p -> BlueLockMod.LOGGER.warn("Blue Lock data problem: {}", p));
        pack.problems().forEach(p -> BlueLockMod.LOGGER.warn("Blue Lock data problem: {}", p));
        BlueLockMod.LOGGER.info("Blue Lock data loaded: {} skills, {} formations, {} teams",
                pack.skills().size(), pack.formations().size(), pack.teams().size());
    }
}
