package com.bluelock.forge;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Converts Gson's tree into plain Maps/Lists so the common module can read data without knowing about Gson. */
final class JsonToJava {
    private JsonToJava() {
    }

    static Object convert(JsonElement e) {
        if (e == null || e.isJsonNull()) {
            return null;
        }
        if (e.isJsonObject()) {
            Map<String, Object> map = new LinkedHashMap<>();
            for (Map.Entry<String, JsonElement> entry : e.getAsJsonObject().entrySet()) {
                map.put(entry.getKey(), convert(entry.getValue()));
            }
            return map;
        }
        if (e.isJsonArray()) {
            List<Object> list = new ArrayList<>();
            for (JsonElement item : e.getAsJsonArray()) {
                list.add(convert(item));
            }
            return list;
        }
        JsonPrimitive p = e.getAsJsonPrimitive();
        if (p.isBoolean()) {
            return p.getAsBoolean();
        }
        if (p.isNumber()) {
            return p.getAsNumber();
        }
        return p.getAsString();
    }
}
