package com.bluelock.forge;

import com.bluelock.common.match.MatchPhase;

/** What the client currently knows about the match. Plain data: it contains no client-only classes. */
public final class ClientHudState {
    public static boolean active;
    public static int home;
    public static int away;
    public static int elapsed;
    public static int duration;
    public static int phase;
    public static int possession = -1;
    public static int homeColor = 0x2F6BFF;
    public static int awayColor = 0xC0392B;
    public static String bannerKey = "";
    public static String bannerArg = "";
    public static int bannerTicks;
    public static int bannerTotal = 1;
    public static int stamina = 100;
    public static int[] cooldowns = new int[ActionIds.COUNT];

    private ClientHudState() {
    }

    public static void update(HudPacket p) {
        active = p.active();
        home = p.home();
        away = p.away();
        elapsed = p.elapsed();
        duration = p.duration();
        phase = p.phase();
        possession = p.possession();
        homeColor = p.homeColor();
        awayColor = p.awayColor();
        stamina = p.stamina();
        cooldowns = p.cooldowns().length == ActionIds.COUNT ? p.cooldowns() : new int[ActionIds.COUNT];
        if (!p.bannerKey().isEmpty() && p.bannerTicks() > 0 && (!p.bannerKey().equals(bannerKey) || bannerTicks <= 0)) {
            bannerKey = p.bannerKey();
            bannerArg = p.bannerArg();
            bannerTicks = p.bannerTicks();
            bannerTotal = p.bannerTicks();
        }
    }

    /** Called once per client tick: keeps the clock running smoothly between packets. */
    public static void tick() {
        if (active && phase == MatchPhase.IN_PLAY.ordinal()) {
            elapsed++;
        }
        if (bannerTicks > 0) {
            bannerTicks--;
        }
    }
}
