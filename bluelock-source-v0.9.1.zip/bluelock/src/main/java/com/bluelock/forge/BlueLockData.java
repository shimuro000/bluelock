package com.bluelock.forge;

import com.bluelock.common.content.DefinitionPack;

/** Holds the currently loaded content. The whole pack is replaced at once on every data reload (never edited in place). */
public final class BlueLockData {
    private static volatile DefinitionPack current = DefinitionPack.empty();

    private BlueLockData() {
    }

    public static DefinitionPack get() {
        return current;
    }

    static void set(DefinitionPack pack) {
        current = pack;
    }
}
