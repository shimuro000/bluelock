package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import com.mojang.logging.LogUtils;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/** Forge entry point. Only loader wiring lives here (registration, events, commands). */
@Mod(BlueLockConstants.MOD_ID)
public class BlueLockMod {
    public static final Logger LOGGER = LogUtils.getLogger();

    public BlueLockMod(FMLJavaModLoadingContext context) {
        IEventBus modBus = context.getModEventBus();
        ModEntities.ENTITY_TYPES.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        modBus.addListener(this::onEntityAttributes);
        modBus.addListener(this::onCommonSetup);
        modBus.addListener(this::onBuildCreativeTabs);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void onEntityAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.BOT.get(), BotEntity.createAttributes().build());
    }

    private void onCommonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(BlueLockNetwork::register);
        LOGGER.info("{} common setup complete", BlueLockConstants.MOD_NAME);
    }

    private void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.FOOTBALL);
        }
    }

    @SubscribeEvent
    public void onAddReloadListeners(AddReloadListenerEvent event) {
        event.addListener(new DefinitionReloadListener());
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            PlayerStates.tick(event.getServer());
            MatchManager.tick(event.getServer());
        }
    }

    /** Left-click on a footballer: tackle them if they have the ball, and never hurt players or bots in a match. */
    @SubscribeEvent
    public void onAttackEntity(AttackEntityEvent event) {
        Player attacker = event.getEntity();
        if (attacker.level().isClientSide || !(attacker instanceof ServerPlayer player)) {
            return;
        }
        if (!(event.getTarget() instanceof LivingEntity target)) {
            return;
        }
        boolean carrying = BallEntity.carriesBall(target);
        boolean teammatesInMatch = target instanceof Player && MatchManager.isMember(target.getUUID())
                && MatchManager.isMember(player.getUUID());
        if (carrying || target instanceof BotEntity || teammatesInMatch) {
            if (carrying) {
                TackleActions.attempt(player.getServer(), player, TackleActions.Mode.STAND);
            }
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onServerStopped(ServerStoppedEvent event) {
        MatchManager.clear();
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        BlueLockCommands.register(event.getDispatcher());
    }
}
