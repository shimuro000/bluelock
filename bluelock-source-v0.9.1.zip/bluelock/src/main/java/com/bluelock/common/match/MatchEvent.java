package com.bluelock.common.match;

import java.util.UUID;

/** Things that happened during a tick. The Forge side turns them into messages and ball resets. */
public sealed interface MatchEvent {
    /** First touch after a kick-off: the clock starts. */
    record PlayStarted() implements MatchEvent {
    }

    /** scorer is the player credited, or null for an own goal / unknown scorer. */
    record GoalScored(Side scoringSide, UUID scorer, boolean ownGoal, int homeGoals, int awayGoals) implements MatchEvent {
    }

    /** The ball left the pitch: put it back at this spot (pitch coordinates). */
    record BallOut(double restartU, double restartV) implements MatchEvent {
    }

    /** After a goal: put the ball on the centre spot. */
    record KickoffReset() implements MatchEvent {
    }

    /** winner is null for a draw. */
    record MatchFinished(Side winner, int homeGoals, int awayGoals) implements MatchEvent {
    }
}
