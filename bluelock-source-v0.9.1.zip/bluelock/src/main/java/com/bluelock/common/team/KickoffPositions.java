package com.bluelock.common.team;

import com.bluelock.common.content.FormationDefinition;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;

/** Where a formation slot stands at kick-off, in pitch coordinates: always inside the team's own half. */
public final class KickoffPositions {
    private static final double GOAL_MARGIN = 2.5;
    private static final double CIRCLE_MARGIN = 6.0;   // keep out of the centre circle (radius 5)
    private static final double SIDE_MARGIN = 3.0;

    private KickoffPositions() {
    }

    /** Returns {u, v}. Formation y runs from own goal (0) to the opponent's goal (1), x from left to right. */
    public static double[] spot(PitchLayout layout, Side side, FormationDefinition.Slot slot) {
        double uMax = layout.centreU() - CIRCLE_MARGIN;
        double u = GOAL_MARGIN + slot.y() * (uMax - GOAL_MARGIN);
        double v = SIDE_MARGIN + slot.x() * (layout.width() - 2 * SIDE_MARGIN);
        if (side == Side.AWAY) {
            u = layout.length() - u;
            v = layout.width() - v;
        }
        return new double[] {u, v};
    }
}
