package com.bluelock.common.profile;

public enum Personality { COMPETITIVE, ANALYTICAL, INSTINCTIVE, OPPORTUNISTIC, CREATIVE, RELENTLESS }
