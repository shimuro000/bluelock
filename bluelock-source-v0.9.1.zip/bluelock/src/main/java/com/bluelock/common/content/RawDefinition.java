package com.bluelock.common.content;

import java.util.Map;

/** One data file after the loader converted its JSON into plain maps. type is "skills", "formations" or "teams". */
public record RawDefinition(String type, String id, Map<String, Object> data) {
}
