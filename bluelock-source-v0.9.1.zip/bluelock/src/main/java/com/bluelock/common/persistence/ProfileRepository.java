package com.bluelock.common.persistence;

import com.bluelock.common.profile.PlayerProfile;
import java.util.Optional;
import java.util.UUID;

/** Storage abstraction. The Forge module implements it on top of world data; never save every tick. */
public interface ProfileRepository {
    Optional<PlayerProfile> load(UUID playerId);

    void save(PlayerProfile profile);

    void delete(UUID playerId);
}
