package com.bluelock.common.content;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Formation layout: slots with a position and a normalised pitch spot (x: left 0..right 1, y: own goal 0..opponent goal 1). */
public record FormationDefinition(String id, List<Slot> slots) {
    public record Slot(Position position, double x, double y) {
    }

    public String nameKey() {
        return "bluelock.formation." + id + ".name";
    }

    static FormationDefinition parse(String id, Map<String, Object> m) {
        List<Slot> slots = new ArrayList<>();
        int keepers = 0;
        for (Map<String, Object> s : Fields.objectList(m, "slots")) {
            Position p = Fields.enumValue(s, "position", Position.class);
            if (p == Position.GK) keepers++;
            slots.add(new Slot(p, Fields.decimal(s, "x", 0, 1), Fields.decimal(s, "y", 0, 1)));
        }
        if (slots.isEmpty() || slots.size() > 11) throw new DefinitionException("a formation needs 1 to 11 slots");
        if (keepers > 1) throw new DefinitionException("a formation can have at most one goalkeeper");
        return new FormationDefinition(id, List.copyOf(slots));
    }
}
