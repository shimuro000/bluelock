package com.bluelock.common.stats;

import java.util.EnumMap;
import java.util.Map;

/**
 * Persistent stats of one player: base value + permanent growth per stat.
 * Server-owned: only server code may call the mutating methods.
 */
public final class StatBlock {
    public static final int MIN = 0;
    public static final int MAX = 100;

    private final EnumMap<Stat, Integer> base = new EnumMap<>(Stat.class);
    private final EnumMap<Stat, Integer> growth = new EnumMap<>(Stat.class);

    public StatBlock() {
        for (Stat s : Stat.values()) {
            base.put(s, 0);
            growth.put(s, 0);
        }
    }

    public static StatBlock uniform(int value) {
        StatBlock b = new StatBlock();
        for (Stat s : Stat.values()) {
            b.setBase(s, value);
        }
        return b;
    }

    public int base(Stat s) {
        return base.get(s);
    }

    public int growth(Stat s) {
        return growth.get(s);
    }

    /** Base + permanent growth, clamped to 0..100. */
    public int permanent(Stat s) {
        return clamp(base.get(s) + growth.get(s));
    }

    public void setBase(Stat s, int value) {
        base.put(s, clamp(value));
    }

    public void setGrowth(Stat s, int value) {
        growth.put(s, Math.max(0, value));
    }

    /**
     * Spends up to {@code budget} points raising {@code s}, one level at a time, using the curve.
     * Never exceeds the curve's soft cap. Returns the points actually spent.
     */
    public int spendOn(Stat s, int budget, GrowthCurve curve) {
        if (budget <= 0) return 0;
        int spent = 0;
        int remaining = budget;
        while (permanent(s) < curve.softCap()) {
            int cost = curve.costToRaise(permanent(s));
            if (cost > remaining) break;
            remaining -= cost;
            spent += cost;
            growth.put(s, growth.get(s) + 1);
        }
        return spent;
    }

    /** Rare milestone: allows raising a stat to the absolute cap of 100. */
    public void grantMilestoneToMax(Stat s) {
        growth.put(s, MAX - base.get(s));
    }

    public Map<Stat, Integer> baseView() {
        return new EnumMap<>(base);
    }

    public Map<Stat, Integer> growthView() {
        return new EnumMap<>(growth);
    }

    public static int clamp(int v) {
        return Math.max(MIN, Math.min(MAX, v));
    }
}
