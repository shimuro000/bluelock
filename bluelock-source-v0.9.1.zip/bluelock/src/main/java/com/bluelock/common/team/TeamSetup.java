package com.bluelock.common.team;

import com.bluelock.common.content.FormationDefinition;
import com.bluelock.common.profile.Archetype;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * A team on the pitch: a formation and who stands in each slot. Empty slots are for AI bots (a later phase).
 * Always rebuilt from the list of candidates, so the result never depends on earlier edits.
 */
public final class TeamSetup {
    /** A human who wants to play. preferredSlot is a 0-based slot index chosen by the player, or null. */
    public record Candidate(UUID id, Archetype archetype, Integer preferredSlot) {
    }

    private final FormationDefinition formation;
    private final UUID[] slots;
    private final List<UUID> bench;

    private TeamSetup(FormationDefinition formation, UUID[] slots, List<UUID> bench) {
        this.formation = formation;
        this.slots = slots;
        this.bench = List.copyOf(bench);
    }

    public FormationDefinition formation() { return formation; }
    public int size() { return slots.length; }
    public UUID occupant(int slot) { return slots[slot]; }
    public List<UUID> bench() { return bench; }

    public int slotOf(UUID player) {
        for (int i = 0; i < slots.length; i++) {
            if (player.equals(slots[i])) return i;
        }
        return -1;
    }

    public int humanCount() {
        return (int) Arrays.stream(slots).filter(java.util.Objects::nonNull).count();
    }

    /**
     * Players with a valid preferred slot get it (first come, first served). Everyone else takes the free slot
     * that suits their archetype best (ties: the lowest slot number). Players who do not fit go to the bench.
     */
    public static TeamSetup seat(FormationDefinition formation, List<Candidate> candidates) {
        int n = formation.slots().size();
        UUID[] seats = new UUID[n];
        Archetype[] seatArchetype = new Archetype[n];
        List<Candidate> unseated = new ArrayList<>();

        for (Candidate c : candidates) {
            Integer p = c.preferredSlot();
            if (p != null && p >= 0 && p < n && seats[p] == null && !contains(seats, c.id())) {
                seats[p] = c.id();
                seatArchetype[p] = c.archetype();
            } else {
                unseated.add(c);
            }
        }
        List<UUID> bench = new ArrayList<>();
        for (Candidate c : unseated) {
            if (contains(seats, c.id())) continue;
            int best = -1;
            int bestFit = -1;
            for (int i = 0; i < n; i++) {
                if (seats[i] != null) continue;
                int fit = PositionFit.fit(c.archetype(), formation.slots().get(i).position());
                if (fit > bestFit) {
                    bestFit = fit;
                    best = i;
                }
            }
            if (best < 0) {
                bench.add(c.id());
            } else {
                seats[best] = c.id();
                seatArchetype[best] = c.archetype();
            }
        }
        return new TeamSetup(formation, seats, bench);
    }

    /** Archetype-based chemistry (0..100): average position fit of the seated humans. 0 when nobody plays. */
    public int chemistry(java.util.Map<UUID, Archetype> archetypes) {
        int total = 0;
        int count = 0;
        for (int i = 0; i < slots.length; i++) {
            if (slots[i] == null) continue;
            Archetype a = archetypes.getOrDefault(slots[i], Archetype.ALL_ROUNDER);
            total += PositionFit.fit(a, formation.slots().get(i).position());
            count++;
        }
        return count == 0 ? 0 : Math.round((float) total / count);
    }

    /**
     * Team rating: average of every slot (a human uses their overall, an empty slot the bot rating),
     * lowered by up to 10% when humans play out of position.
     */
    public int rating(java.util.Map<UUID, Integer> overalls, java.util.Map<UUID, Archetype> archetypes, int botRating) {
        double sum = 0;
        for (UUID id : slots) {
            sum += id == null ? botRating : overalls.getOrDefault(id, botRating);
        }
        double average = sum / slots.length;
        double factor = humanCount() == 0 ? 1.0 : 0.9 + 0.1 * chemistry(archetypes) / 100.0;
        return (int) Math.round(average * factor);
    }

    private static boolean contains(UUID[] seats, UUID id) {
        for (UUID s : seats) {
            if (id.equals(s)) return true;
        }
        return false;
    }
}
