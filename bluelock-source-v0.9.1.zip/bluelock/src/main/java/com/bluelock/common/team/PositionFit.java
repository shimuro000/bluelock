package com.bluelock.common.team;

import com.bluelock.common.content.Position;
import com.bluelock.common.profile.Archetype;

/** How well an archetype suits a position, 0..100. Drives automatic seating and team chemistry. */
public final class PositionFit {
    private PositionFit() {
    }

    public static int fit(Archetype archetype, Position p) {
        if (p == Position.GK) return archetype == Archetype.ALL_ROUNDER ? 40 : 10;
        return switch (archetype) {
            case STRIKER -> switch (p) {
                case ST, CF -> 100;
                case LW, RW -> 70;
                case CAM -> 65;
                default -> 35;
            };
            case SPEEDSTER -> switch (p) {
                case LW, RW -> 100;
                case ST, LM, RM -> 85;
                case LWB, RWB -> 80;
                case CF -> 60;
                default -> 35;
            };
            case DRIBBLER -> switch (p) {
                case LW, RW -> 100;
                case CAM -> 90;
                case LM, RM -> 85;
                case CM -> 70;
                case ST -> 60;
                default -> 35;
            };
            case PLAYMAKER -> switch (p) {
                case CAM, CM -> 100;
                case CDM -> 80;
                case LM, RM -> 70;
                case CF -> 55;
                default -> 35;
            };
            case FINISHER -> switch (p) {
                case ST -> 100;
                case CF -> 95;
                case LW, RW -> 60;
                case CAM -> 55;
                default -> 30;
            };
            case DEFENDER -> switch (p) {
                case CB -> 100;
                case LB, RB -> 95;
                case CDM -> 90;
                case LWB, RWB -> 85;
                case CM -> 55;
                default -> 25;
            };
            case ALL_ROUNDER -> 70;
        };
    }
}
