package com.bluelock.common.content;

/** A single data file is invalid. The loader records it and skips that file instead of crashing. */
public final class DefinitionException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public DefinitionException(String message) {
        super(message);
    }
}
