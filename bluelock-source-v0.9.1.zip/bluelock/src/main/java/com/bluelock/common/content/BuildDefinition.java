package com.bluelock.common.content;

import com.bluelock.common.stats.Stat;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;

/**
 * Starting stat shifts for an archetype or personality (data/bluelock/definitions/archetypes|personalities).
 * Shifts add up to zero, so every choice has the same total starting power: strengths are paid for by tradeoffs.
 */
public record BuildDefinition(String id, Map<Stat, Integer> statDeltas) {

    public int totalDelta() {
        return statDeltas.values().stream().mapToInt(Integer::intValue).sum();
    }

    static BuildDefinition parse(String id, Map<String, Object> m) {
        EnumMap<Stat, Integer> deltas = new EnumMap<>(Stat.class);
        Map<String, Object> raw = Fields.objectOrEmpty(m, "stat_deltas");
        if (raw.isEmpty()) throw new DefinitionException("'stat_deltas' is missing or empty");
        for (Map.Entry<String, Object> e : raw.entrySet()) {
            Stat stat;
            try {
                stat = Stat.valueOf(e.getKey().toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ex) {
                throw new DefinitionException("unknown stat '" + e.getKey() + "'");
            }
            if (!(e.getValue() instanceof Number n)) throw new DefinitionException("shift for '" + e.getKey() + "' must be a number");
            deltas.put(stat, Fields.range("stat_deltas." + e.getKey(), n, -30, 30));
        }
        return new BuildDefinition(id, Map.copyOf(deltas));
    }
}
