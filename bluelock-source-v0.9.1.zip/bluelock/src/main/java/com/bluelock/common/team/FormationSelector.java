package com.bluelock.common.team;

import com.bluelock.common.content.FormationDefinition;
import com.bluelock.common.registry.Registry;
import java.util.Optional;
import java.util.TreeMap;

/** Picks the formation a team plays: explicit choice, then the team's own formation, then a default for the size. */
public final class FormationSelector {
    private FormationSelector() {
    }

    public static Optional<FormationDefinition> choose(Registry<FormationDefinition> formations, int size,
                                                       String explicitId, String teamFormationId) {
        for (String id : new String[] {explicitId, teamFormationId}) {
            if (id == null) continue;
            Optional<FormationDefinition> f = formations.get(id);
            if (f.isPresent() && f.get().slots().size() == size) return f;
        }
        Optional<FormationDefinition> classic = formations.get("4_3_3");
        if (classic.isPresent() && classic.get().slots().size() == size) return classic;
        TreeMap<String, FormationDefinition> sorted = new TreeMap<>(formations.asMap());
        for (FormationDefinition f : sorted.values()) {
            if (f.slots().size() == size) return Optional.of(f);
        }
        return Optional.empty();
    }
}
