package com.bluelock.common.ai;

import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.team.TeamTactics;
import java.util.List;

/**
 * Everything one bot knows when it makes a decision. possession is the side of the player who carries the ball
 * (null when the ball is loose). chaseRank is 0 for the outfield player of the bot's team closest to the ball.
 */
public record BotView(Side side, Position position, Pos self, Pos ball, boolean selfHasBall, Side possession,
                      Pos carrier, int chaseRank, int rating, TeamTactics tactics, Pos baseSpot,
                      List<Pos> mates, List<Pos> opponents, PitchLayout layout) {
}
