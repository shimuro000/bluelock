package com.bluelock.common.team;

import com.bluelock.common.content.FormationDefinition;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;

/** A slot's home spot over the whole pitch (not just the own half). AWAY is mirrored. */
public final class FormationSpots {
    private FormationSpots() {
    }

    public static double[] baseSpot(PitchLayout layout, Side side, FormationDefinition.Slot slot) {
        double u = 3 + slot.y() * (layout.length() - 6);
        double v = 3 + slot.x() * (layout.width() - 6);
        if (side == Side.AWAY) {
            u = layout.length() - u;
            v = layout.width() - v;
        }
        return new double[] {u, v};
    }
}
