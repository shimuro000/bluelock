package com.bluelock.common.ai;

import com.bluelock.common.content.Position;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatBlock;

/** Stats for a bot from its rating (a team rating plus the difficulty), shaped by its position. */
public final class BotStats {
    private BotStats() {
    }

    public static StatBlock forRating(int rating, Position position) {
        int base = Math.max(20, Math.min(95, rating));
        StatBlock b = StatBlock.uniform(base);
        switch (position) {
            case GK -> boost(b, 12, Stat.REACTION, Stat.JUMP, Stat.POSITIONING, Stat.BALANCE);
            case CB, LB, RB, LWB, RWB, CDM -> boost(b, 10, Stat.TACKLING, Stat.MARKING, Stat.INTERCEPTION, Stat.STRENGTH);
            case CM, CAM, LM, RM -> boost(b, 8, Stat.PASSING, Stat.VISION, Stat.STAMINA, Stat.DRIBBLING);
            case LW, RW, ST, CF -> boost(b, 10, Stat.SHOOTING, Stat.FINISHING, Stat.SHOT_POWER, Stat.ACCELERATION);
        }
        return b;
    }

    private static void boost(StatBlock b, int amount, Stat... stats) {
        for (Stat s : stats) {
            b.setBase(s, b.base(s) + amount);
        }
    }
}
