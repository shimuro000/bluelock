package com.bluelock.common.action;

import java.util.List;

/** Picks the teammate a pass is aimed at: the one closest to where the player is looking. */
public final class PassAssist {
    private PassAssist() {
    }

    /** mates are {x, z} positions. Returns the index of the best teammate, or -1 if nobody is inside the cone. */
    public static int pick(double px, double pz, double lookX, double lookZ, List<double[]> mates,
                           double maxAngleDegrees, double minDistance, double maxDistance) {
        double len = Math.sqrt(lookX * lookX + lookZ * lookZ);
        if (len < 1.0E-6) return -1;
        double lx = lookX / len, lz = lookZ / len;
        int best = -1;
        double bestAngle = Math.toRadians(maxAngleDegrees);
        for (int i = 0; i < mates.size(); i++) {
            double dx = mates.get(i)[0] - px, dz = mates.get(i)[1] - pz;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist < minDistance || dist > maxDistance) continue;
            double cos = (dx * lx + dz * lz) / dist;
            double angle = Math.acos(Math.max(-1, Math.min(1, cos)));
            if (angle <= bestAngle) {
                bestAngle = angle;
                best = i;
            }
        }
        return best;
    }
}
