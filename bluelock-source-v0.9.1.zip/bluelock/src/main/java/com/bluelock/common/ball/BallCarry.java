package com.bluelock.common.ball;

/** How the ball sticks to a dribbler's feet. Pure math; the Forge ball entity applies it every tick. */
public final class BallCarry {
    public static final double BASE_DISTANCE = 0.75;

    private BallCarry() {
    }

    /** Distance in front of the feet. It swings a little with every step, more when running fast. */
    public static double distanceAt(int tick, double speed) {
        double swing = Math.min(0.35, 0.10 + speed * 1.2);
        return BASE_DISTANCE + swing * 0.5 * (1 + Math.sin(tick * 0.9));
    }

    /** Ball spot (x, z) in front of the carrier along the heading. A zero heading puts it straight ahead (+z). */
    public static double[] target(double carrierX, double carrierZ, double headingX, double headingZ, double distance) {
        double len = Math.sqrt(headingX * headingX + headingZ * headingZ);
        double hx = len < 1.0E-6 ? 0 : headingX / len;
        double hz = len < 1.0E-6 ? 1 : headingZ / len;
        return new double[] {carrierX + hx * distance, carrierZ + hz * distance};
    }

    /** Chance per tick that a running carrier loses control. Zero while walking; grows with speed and pressure. */
    public static double lossChancePerTick(int dribbling, int closeControl, double speed, boolean pressured) {
        double control = (0.6 * closeControl + 0.4 * dribbling) / 100.0;
        double running = Math.max(0, speed - 0.12) * (1 - control) * 0.10;
        return running + (pressured ? 0.004 * (1 - control) : 0);
    }

    /** Can a player settle a ball arriving at this speed? Better first touch and ball control tame faster balls. */
    public static boolean canControl(double ballSpeed, int firstTouch, int ballControl) {
        double skill = (0.5 * firstTouch + 0.5 * ballControl) / 100.0;
        return ballSpeed <= 0.30 + 0.45 * skill;
    }
}
