package com.bluelock.common.stats;

public enum StatCategory {
    PHYSICAL, TECHNICAL, MENTAL, DEFENSIVE, SPECIAL
}
