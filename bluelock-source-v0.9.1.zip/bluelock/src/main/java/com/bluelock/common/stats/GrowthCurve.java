package com.bluelock.common.stats;

/** Cost of raising a stat by one point. Balance-sensitive, so it is an interface (config/data driven later). */
public interface GrowthCurve {
    /** Highest value reachable through normal growth. 100 is a rare milestone only. */
    int softCap();

    /** Points needed to raise a stat from {@code currentValue} to {@code currentValue + 1}. */
    int costToRaise(int currentValue);
}
