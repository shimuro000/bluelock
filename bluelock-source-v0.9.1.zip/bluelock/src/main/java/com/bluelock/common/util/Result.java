package com.bluelock.common.util;

import java.util.Optional;

/** Success-or-failure value. Failures carry a language key (never hardcoded UI text). */
public final class Result<T> {
    private final T value;
    private final String errorKey;

    private Result(T value, String errorKey) {
        this.value = value;
        this.errorKey = errorKey;
    }

    public static <T> Result<T> ok(T value) {
        return new Result<>(value, null);
    }

    public static <T> Result<T> fail(String errorKey) {
        return new Result<>(null, errorKey);
    }

    public boolean isOk() {
        return errorKey == null;
    }

    public T value() {
        if (!isOk()) {
            throw new IllegalStateException("Result failed: " + errorKey);
        }
        return value;
    }

    public Optional<String> errorKey() {
        return Optional.ofNullable(errorKey);
    }
}
