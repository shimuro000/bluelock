package com.bluelock.common.ai;

/** A spot on the pitch in pitch coordinates (u along the length, v across the width). */
public record Pos(double u, double v) {
    public double dist(Pos o) {
        return Math.hypot(u - o.u, v - o.v);
    }
}
