package com.bluelock.common.profile;

import com.bluelock.common.stats.StatBlock;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/** Persistent career data of one player (identity, progression, stats). Server-owned state. */
public final class PlayerProfile {
    public static final int NAME_MIN = 2;
    public static final int NAME_MAX = 16;

    private final UUID id;
    private String name;
    private String nickname;
    private DominantFoot foot;
    private Archetype archetype;
    private Personality personality;
    private int level = 1;
    private long xp = 0;
    private int skillPoints = 0;
    private int developmentPoints = 0;
    private int goals = 0;
    private int assists = 0;
    private final Set<String> unlockedSkills = new LinkedHashSet<>();
    private final StatBlock stats;

    public PlayerProfile(UUID id, String name, String nickname, DominantFoot foot,
                         Archetype archetype, Personality personality, StatBlock stats) {
        this.id = Objects.requireNonNull(id);
        this.name = name;
        this.nickname = nickname == null ? "" : nickname;
        this.foot = Objects.requireNonNull(foot);
        this.archetype = Objects.requireNonNull(archetype);
        this.personality = Objects.requireNonNull(personality);
        this.stats = Objects.requireNonNull(stats);
    }

    /** Letters (any language), digits, spaces, '_' and '-'; length 2-16. Returns a lang key on failure, else null. */
    public static String validateName(String name) {
        if (name == null) return "bluelock.error.name_empty";
        String trimmed = name.trim();
        if (trimmed.length() < NAME_MIN) return "bluelock.error.name_too_short";
        if (trimmed.length() > NAME_MAX) return "bluelock.error.name_too_long";
        for (int i = 0; i < trimmed.length(); i++) {
            char c = trimmed.charAt(i);
            if (!(Character.isLetterOrDigit(c) || c == ' ' || c == '_' || c == '-')) {
                return "bluelock.error.name_invalid_chars";
            }
        }
        return null;
    }

    public UUID id() { return id; }
    public String name() { return name; }
    public String nickname() { return nickname; }
    public DominantFoot foot() { return foot; }
    public Archetype archetype() { return archetype; }
    public Personality personality() { return personality; }
    public int level() { return level; }
    public long xp() { return xp; }
    public int skillPoints() { return skillPoints; }
    public int developmentPoints() { return developmentPoints; }
    public StatBlock stats() { return stats; }
    public int goals() { return goals; }
    public int assists() { return assists; }
    public Set<String> unlockedSkills() { return Collections.unmodifiableSet(unlockedSkills); }
    public boolean isUnlocked(String skillId) { return unlockedSkills.contains(skillId); }
    public void unlockSkill(String skillId) { unlockedSkills.add(skillId); }
    public void spendSkillPoints(int n) { skillPoints = Math.max(0, skillPoints - n); }
    public void setCareerCounters(int goals, int assists) { this.goals = Math.max(0, goals); this.assists = Math.max(0, assists); }
    public void addGoal() { goals++; }

    public void setProgression(int level, long xp, int skillPoints, int developmentPoints) {
        this.level = Math.max(1, level);
        this.xp = Math.max(0, xp);
        this.skillPoints = Math.max(0, skillPoints);
        this.developmentPoints = Math.max(0, developmentPoints);
    }

    /** Spends development points on a stat via the growth curve. Returns points spent. */
    public int spendDevelopment(com.bluelock.common.stats.Stat stat, com.bluelock.common.stats.GrowthCurve curve) {
        int spent = stats.spendOn(stat, developmentPoints, curve);
        developmentPoints -= spent;
        return spent;
    }

    /** Like {@link #spendDevelopment} but spends at most {@code maxPoints}. */
    public int spendDevelopment(com.bluelock.common.stats.Stat stat, com.bluelock.common.stats.GrowthCurve curve, int maxPoints) {
        int spent = stats.spendOn(stat, Math.min(developmentPoints, Math.max(0, maxPoints)), curve);
        developmentPoints -= spent;
        return spent;
    }
}
