package com.bluelock.common.stats;

import java.util.EnumMap;

/** Temporary modifier layers from spec section 10. Built fresh by the server whenever stats are evaluated. */
public final class StatModifiers {
    public static final StatModifiers NONE = new StatModifiers();

    private final EnumMap<Stat, Integer> equipment = new EnumMap<>(Stat.class);
    private final EnumMap<Stat, Integer> skill = new EnumMap<>(Stat.class);
    private final EnumMap<Stat, Integer> temporary = new EnumMap<>(Stat.class);
    private final EnumMap<Stat, Integer> flow = new EnumMap<>(Stat.class);
    private final EnumMap<Stat, Integer> context = new EnumMap<>(Stat.class);

    public StatModifiers equipment(Stat s, int v) { equipment.merge(s, v, Integer::sum); return this; }
    public StatModifiers skill(Stat s, int v) { skill.merge(s, v, Integer::sum); return this; }
    public StatModifiers temporary(Stat s, int v) { temporary.merge(s, v, Integer::sum); return this; }
    public StatModifiers flow(Stat s, int v) { flow.merge(s, v, Integer::sum); return this; }
    public StatModifiers context(Stat s, int v) { context.merge(s, v, Integer::sum); return this; }

    int total(Stat s) {
        return equipment.getOrDefault(s, 0) + skill.getOrDefault(s, 0) + temporary.getOrDefault(s, 0)
                + flow.getOrDefault(s, 0) + context.getOrDefault(s, 0);
    }
}
