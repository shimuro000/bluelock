package com.bluelock.common.stats;

public final class OverallRating {
    private OverallRating() {
    }

    /** Role-weighted average of effective stats, rounded to the nearest integer. */
    public static int compute(StatBlock block, StatModifiers mods, RoleWeights weights) {
        long total = 0;
        long weightSum = 0;
        for (Stat s : Stat.values()) {
            int w = weights.weight(s);
            total += (long) StatCalculator.effective(block, mods, s) * w;
            weightSum += w;
        }
        return (int) Math.round((double) total / weightSum);
    }
}
