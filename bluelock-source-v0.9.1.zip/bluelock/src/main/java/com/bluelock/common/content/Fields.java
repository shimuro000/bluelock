package com.bluelock.common.content;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Typed readers for the plain Map form of a JSON file. Every failure becomes a DefinitionException. */
final class Fields {
    private Fields() {
    }

    static String string(Map<String, Object> m, String key) {
        Object o = m.get(key);
        if (o instanceof String s && !s.isBlank()) return s;
        throw new DefinitionException("missing or empty text field '" + key + "'");
    }

    static int integer(Map<String, Object> m, String key, int min, int max) {
        Object o = m.get(key);
        if (!(o instanceof Number n)) throw new DefinitionException("missing number field '" + key + "'");
        return range(key, n, min, max);
    }

    static int integerOr(Map<String, Object> m, String key, int def, int min, int max) {
        return m.containsKey(key) ? integer(m, key, min, max) : def;
    }

    static double decimal(Map<String, Object> m, String key, double min, double max) {
        Object o = m.get(key);
        if (!(o instanceof Number n)) throw new DefinitionException("missing number field '" + key + "'");
        double d = n.doubleValue();
        if (d < min || d > max) throw new DefinitionException("'" + key + "' must be between " + min + " and " + max);
        return d;
    }

    static <E extends Enum<E>> E enumValue(Map<String, Object> m, String key, Class<E> type) {
        String s = string(m, key);
        try {
            return Enum.valueOf(type, s.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            throw new DefinitionException("unknown value '" + s + "' for '" + key + "'");
        }
    }

    static List<String> stringList(Map<String, Object> m, String key) {
        Object o = m.get(key);
        if (o == null) return List.of();
        if (!(o instanceof List<?> list)) throw new DefinitionException("'" + key + "' must be a list");
        List<String> out = new ArrayList<>();
        for (Object item : list) {
            if (!(item instanceof String s)) throw new DefinitionException("'" + key + "' must contain only text");
            out.add(s);
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    static List<Map<String, Object>> objectList(Map<String, Object> m, String key) {
        Object o = m.get(key);
        if (!(o instanceof List<?> list)) throw new DefinitionException("missing list field '" + key + "'");
        List<Map<String, Object>> out = new ArrayList<>();
        for (Object item : list) {
            if (!(item instanceof Map)) throw new DefinitionException("'" + key + "' must contain objects");
            out.add(new LinkedHashMap<>((Map<String, Object>) item));
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> objectOrEmpty(Map<String, Object> m, String key) {
        Object o = m.get(key);
        if (o == null) return Map.of();
        if (!(o instanceof Map)) throw new DefinitionException("'" + key + "' must be an object");
        return (Map<String, Object>) o;
    }

    static int range(String key, Number n, int min, int max) {
        double d = n.doubleValue();
        if (d != Math.rint(d)) throw new DefinitionException("'" + key + "' must be a whole number");
        if (d < min || d > max) throw new DefinitionException("'" + key + "' must be between " + min + " and " + max);
        return (int) d;
    }
}
