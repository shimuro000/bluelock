package com.bluelock.common.action;

import com.bluelock.common.ball.Velocity;
import java.util.function.DoubleSupplier;

/** Kick power and accuracy from stats. Better stats mean a faster ball and a smaller random error. */
public final class KickModel {
    private KickModel() {
    }

    /**
     * Pass along (dx, dz). targetDistance is the distance to the receiver in blocks, or 0 when there is none
     * (the ball then gets a default medium speed). rng returns a number in [0, 1).
     */
    public static Velocity pass(double dx, double dz, double targetDistance, int passing, DoubleSupplier rng) {
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0E-6) return Velocity.ZERO;
        double speed = targetDistance > 0 ? clamp(targetDistance / 26.0 + 0.10, 0.35, 1.05) : 0.55;
        speed *= 0.90 + 0.20 * passing / 100.0;
        double maxSpread = Math.toRadians((100 - passing) / 100.0 * 10.0);
        double angle = (rng.getAsDouble() * 2 - 1) * maxSpread;
        double nx = dx / len, nz = dz / len;
        double rx = nx * Math.cos(angle) - nz * Math.sin(angle);
        double rz = nx * Math.sin(angle) + nz * Math.cos(angle);
        return new Velocity(rx * speed, 0, rz * speed);
    }

    /** Shot along (dx, dy, dz). Uses Shot Power for speed and Shooting + Finishing for accuracy. */
    public static Velocity shot(double dx, double dy, double dz, int shooting, int finishing, int shotPower,
                                double baseSpeed, double minLift, DoubleSupplier rng) {
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-6) return Velocity.ZERO;
        double speed = baseSpeed * (0.72 + 0.60 * shotPower / 100.0);
        double accuracy = (0.5 * shooting + 0.5 * finishing) / 100.0;
        double maxSpread = Math.toRadians((1 - accuracy) * 9.0);
        double yaw = (rng.getAsDouble() * 2 - 1) * maxSpread;
        double pitch = (rng.getAsDouble() * 2 - 1) * maxSpread * 0.5;
        double nx = dx / len, ny = dy / len, nz = dz / len;
        double rx = nx * Math.cos(yaw) - nz * Math.sin(yaw);
        double rz = nx * Math.sin(yaw) + nz * Math.cos(yaw);
        double ry = ny + Math.tan(pitch);
        return new Velocity(rx * speed, Math.max(ry * speed, minLift), rz * speed);
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /**
     * Aim assist: if the player looks within maxAngleDegrees of the target direction, nudge the shot toward it.
     * Both directions are 3D vectors. Returns a unit vector.
     */
    public static double[] aimToward(double[] look, double[] toTarget, double maxAngleDegrees, double blend) {
        double[] l = unit(look);
        double[] t = unit(toTarget);
        double cos = l[0] * t[0] + l[1] * t[1] + l[2] * t[2];
        double angle = Math.acos(Math.max(-1, Math.min(1, cos)));
        if (angle > Math.toRadians(maxAngleDegrees)) return l;
        return unit(new double[] {l[0] * (1 - blend) + t[0] * blend, l[1] * (1 - blend) + t[1] * blend, l[2] * (1 - blend) + t[2] * blend});
    }

    private static double[] unit(double[] v) {
        double len = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        return len < 1.0E-9 ? new double[] {0, 0, 1} : new double[] {v[0] / len, v[1] / len, v[2] / len};
    }
}
