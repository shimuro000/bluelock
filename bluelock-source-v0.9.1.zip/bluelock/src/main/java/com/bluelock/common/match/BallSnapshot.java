package com.bluelock.common.match;

import java.util.UUID;

/** What the match needs to know about the ball each tick, in pitch coordinates. */
public record BallSnapshot(double u, double v, double height, int touchCount, UUID lastToucher) {
}
