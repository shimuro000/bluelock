package com.bluelock.common.content;

import com.bluelock.common.stats.Stat;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * One skill, loaded from data/bluelock/definitions/skills/<id>.json.
 * "requires" lists parent skills (the skill tree); "requirements" are minimum stat values.
 * Name and description come from language keys, never from the data file.
 */
public record SkillDefinition(String id, SkillCategory category, Map<Stat, Integer> requirements,
                              List<String> requires, int cooldownTicks, int staminaCost, int egoCost,
                              int maxMastery) {

    public String nameKey() {
        return "bluelock.skill." + id + ".name";
    }

    public String descriptionKey() {
        return "bluelock.skill." + id + ".desc";
    }

    static SkillDefinition parse(String id, Map<String, Object> m) {
        EnumMap<Stat, Integer> reqs = new EnumMap<>(Stat.class);
        for (Map.Entry<String, Object> e : Fields.objectOrEmpty(m, "requirements").entrySet()) {
            Stat stat;
            try {
                stat = Stat.valueOf(e.getKey().toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ex) {
                throw new DefinitionException("unknown stat '" + e.getKey() + "' in requirements");
            }
            if (!(e.getValue() instanceof Number n)) throw new DefinitionException("requirement for '" + e.getKey() + "' must be a number");
            reqs.put(stat, Fields.range("requirements." + e.getKey(), n, 0, 100));
        }
        return new SkillDefinition(id, Fields.enumValue(m, "category", SkillCategory.class), Map.copyOf(reqs),
                List.copyOf(Fields.stringList(m, "requires")),
                Fields.integer(m, "cooldown_ticks", 0, 20 * 600),
                Fields.integer(m, "stamina_cost", 0, 100),
                Fields.integerOr(m, "ego_cost", 0, 0, 100),
                Fields.integerOr(m, "max_mastery", 5, 1, 10));
    }
}
