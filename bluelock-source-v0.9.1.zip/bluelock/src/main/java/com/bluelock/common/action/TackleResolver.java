package com.bluelock.common.action;

import java.util.function.DoubleSupplier;

/** Decides a tackle from the stats of both players. */
public final class TackleResolver {
    public enum Outcome { WON_BALL, DEFLECTED, FAILED }

    public record Tackler(int tackling, int strength, int anticipation, boolean slide) {
    }

    public record Carrier(int dribbling, int closeControl, int balance, boolean sprinting, boolean protectedByMove) {
    }

    private TackleResolver() {
    }

    public static double winChance(Tackler t, Carrier c) {
        if (c.protectedByMove()) return 0;
        double attack = 0.5 * t.tackling() + 0.25 * t.strength() + 0.25 * t.anticipation();
        double defence = 0.5 * c.dribbling() + 0.3 * c.closeControl() + 0.2 * c.balance();
        double p = 0.45 + (attack - defence) / 100.0 * 0.9 + (t.slide() ? 0.15 : 0) - (c.sprinting() ? 0.08 : 0);
        return Math.max(0.08, Math.min(0.90, p));
    }

    /** roll is a random number in [0, 1). Low rolls win the ball outright, middle rolls knock it loose. */
    public static Outcome resolve(Tackler t, Carrier c, DoubleSupplier roll) {
        if (c.protectedByMove()) return Outcome.FAILED;
        double p = winChance(t, c);
        double r = roll.getAsDouble();
        if (r < p * 0.65) return Outcome.WON_BALL;
        if (r < p) return Outcome.DEFLECTED;
        return Outcome.FAILED;
    }
}
