package com.bluelock.common.stats;

import java.util.Locale;

/** Every player attribute from the design spec (section 8). Reaction appears once, under Physical. */
public enum Stat {
    // Physical
    TOP_SPEED(StatCategory.PHYSICAL), ACCELERATION(StatCategory.PHYSICAL), STAMINA(StatCategory.PHYSICAL),
    STRENGTH(StatCategory.PHYSICAL), BALANCE(StatCategory.PHYSICAL), AGILITY(StatCategory.PHYSICAL),
    JUMP(StatCategory.PHYSICAL), REACTION(StatCategory.PHYSICAL),
    // Technical
    BALL_CONTROL(StatCategory.TECHNICAL), DRIBBLING(StatCategory.TECHNICAL), CLOSE_CONTROL(StatCategory.TECHNICAL),
    PASSING(StatCategory.TECHNICAL), LONG_PASSING(StatCategory.TECHNICAL), CROSSING(StatCategory.TECHNICAL),
    SHOOTING(StatCategory.TECHNICAL), FINISHING(StatCategory.TECHNICAL), SHOT_POWER(StatCategory.TECHNICAL),
    CURVE(StatCategory.TECHNICAL), VOLLEY(StatCategory.TECHNICAL), FIRST_TOUCH(StatCategory.TECHNICAL),
    // Mental
    VISION(StatCategory.MENTAL), SPATIAL_AWARENESS(StatCategory.MENTAL), POSITIONING(StatCategory.MENTAL),
    COMPOSURE(StatCategory.MENTAL), DECISION_MAKING(StatCategory.MENTAL), ANTICIPATION(StatCategory.MENTAL),
    CONFIDENCE(StatCategory.MENTAL),
    // Defensive
    TACKLING(StatCategory.DEFENSIVE), INTERCEPTION(StatCategory.DEFENSIVE), MARKING(StatCategory.DEFENSIVE),
    DEFENSIVE_POSITIONING(StatCategory.DEFENSIVE), BLOCKING(StatCategory.DEFENSIVE),
    // Special
    EGO_AFFINITY(StatCategory.SPECIAL), FLOW_AFFINITY(StatCategory.SPECIAL), AWAKENING_POTENTIAL(StatCategory.SPECIAL);

    private final StatCategory category;

    Stat(StatCategory category) {
        this.category = category;
    }

    public StatCategory category() {
        return category;
    }

    /** Language key used by the client UI, e.g. "bluelock.stat.top_speed". */
    public String langKey() {
        return "bluelock.stat." + name().toLowerCase(Locale.ROOT);
    }
}
