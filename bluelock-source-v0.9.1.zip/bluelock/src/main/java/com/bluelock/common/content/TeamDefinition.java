package com.bluelock.common.content;

import java.util.Map;

/** A team. Rosters are added in a later phase; for now a team has a look, a formation, a style and a strength tier. */
public record TeamDefinition(String id, int colorRgb, String formationId, Playstyle playstyle, int rating) {

    public String nameKey() {
        return "bluelock.team." + id + ".name";
    }

    static TeamDefinition parse(String id, Map<String, Object> m) {
        String color = Fields.string(m, "color");
        int rgb;
        try {
            if (!color.matches("#[0-9a-fA-F]{6}")) throw new NumberFormatException();
            rgb = Integer.parseInt(color.substring(1), 16);
        } catch (NumberFormatException e) {
            throw new DefinitionException("'color' must look like #RRGGBB");
        }
        return new TeamDefinition(id, rgb, Fields.string(m, "formation"),
                Fields.enumValue(m, "playstyle", Playstyle.class), Fields.integer(m, "rating", 1, 100));
    }
}
