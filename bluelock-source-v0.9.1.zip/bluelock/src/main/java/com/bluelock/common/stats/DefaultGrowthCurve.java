package com.bluelock.common.stats;

/** Default progression bands from spec section 9: fast early, expensive when elite. */
public final class DefaultGrowthCurve implements GrowthCurve {
    @Override
    public int softCap() {
        return 99;
    }

    @Override
    public int costToRaise(int v) {
        if (v <= 40) return 1;   // 0-40 fast growth
        if (v <= 60) return 2;   // 41-60 normal
        if (v <= 75) return 4;   // 61-75 slower
        if (v <= 90) return 8;   // 76-90 high cost
        return 16;               // 91-99 elite cost
    }
}
