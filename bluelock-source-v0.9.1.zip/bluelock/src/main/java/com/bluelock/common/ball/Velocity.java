package com.bluelock.common.ball;

/** Ball velocity in blocks per tick. */
public record Velocity(double x, double y, double z) {
    public static final Velocity ZERO = new Velocity(0, 0, 0);

    public double horizontalSpeed() {
        return Math.sqrt(x * x + z * z);
    }
}
