package com.bluelock.common.pitch;

/**
 * Where a pitch stands in the world, and how to convert between world coordinates and pitch coordinates.
 * Pitch coordinates are continuous: block (u, v) covers u..u+1 and v..v+1; height 0 is the top of the grass.
 * Used both to build the pitch and to find out where the ball is on it, so the two always agree.
 */
public record PitchPlacement(int centreX, int floorY, int centreZ, boolean alongX, PitchLayout layout) {

    public double localU(double worldX, double worldZ) {
        return (alongX ? worldX - centreX : worldZ - centreZ) + layout.centreU();
    }

    public double localV(double worldX, double worldZ) {
        return (alongX ? worldZ - centreZ : worldX - centreX) + layout.centreV();
    }

    /** Height above the top of the grass surface for a world y. */
    public double localHeight(double worldY) {
        return worldY - (floorY + 1.0);
    }

    public double worldX(double u, double v) {
        return alongX ? centreX + (u - layout.centreU()) : centreX + (v - layout.centreV());
    }

    public double worldZ(double u, double v) {
        return alongX ? centreZ + (v - layout.centreV()) : centreZ + (u - layout.centreU());
    }

    public double worldY(double height) {
        return floorY + 1.0 + height;
    }

    public int blockX(int u, int v) {
        return (int) Math.round(worldX(u, v));
    }

    public int blockZ(int u, int v) {
        return (int) Math.round(worldZ(u, v));
    }

    /**
     * Minecraft yaw for looking along the pitch. Yaw 0 looks toward +Z, -90 toward +X, 90 toward -X, 180 toward -Z.
     * towardPositiveU = true looks from the u = 0 end toward the far end.
     */
    public float yawAlongPitch(boolean towardPositiveU) {
        if (alongX) return towardPositiveU ? -90f : 90f;
        return towardPositiveU ? 0f : 180f;
    }
}
