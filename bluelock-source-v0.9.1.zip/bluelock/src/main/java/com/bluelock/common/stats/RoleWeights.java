package com.bluelock.common.stats;

import com.bluelock.common.profile.Archetype;
import java.util.EnumMap;

/** Per-role stat importance. Overall rating is a weighted average, never a plain average (spec section 8). */
public final class RoleWeights {
    private final EnumMap<Stat, Integer> weights = new EnumMap<>(Stat.class);

    private RoleWeights() {
        for (Stat s : Stat.values()) {
            weights.put(s, 1);
        }
    }

    private RoleWeights with(int weight, Stat... stats) {
        for (Stat s : stats) {
            weights.put(s, weight);
        }
        return this;
    }

    public int weight(Stat s) {
        return weights.get(s);
    }

    public static RoleWeights forArchetype(Archetype a) {
        RoleWeights w = new RoleWeights();
        switch (a) {
            case STRIKER -> w.with(4, Stat.SHOOTING, Stat.FINISHING, Stat.POSITIONING).with(3, Stat.SHOT_POWER, Stat.COMPOSURE);
            case SPEEDSTER -> w.with(4, Stat.TOP_SPEED, Stat.ACCELERATION).with(3, Stat.AGILITY, Stat.STAMINA);
            case DRIBBLER -> w.with(4, Stat.DRIBBLING, Stat.CLOSE_CONTROL, Stat.AGILITY).with(3, Stat.BALL_CONTROL, Stat.BALANCE);
            case PLAYMAKER -> w.with(4, Stat.VISION, Stat.PASSING, Stat.DECISION_MAKING).with(3, Stat.LONG_PASSING, Stat.FIRST_TOUCH);
            case FINISHER -> w.with(4, Stat.FINISHING, Stat.COMPOSURE, Stat.SHOOTING).with(3, Stat.VOLLEY, Stat.CURVE);
            case DEFENDER -> w.with(4, Stat.TACKLING, Stat.MARKING, Stat.DEFENSIVE_POSITIONING).with(3, Stat.INTERCEPTION, Stat.BLOCKING, Stat.STRENGTH);
            case ALL_ROUNDER -> { /* all weights equal on purpose */ }
        }
        return w;
    }
}
