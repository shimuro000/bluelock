package com.bluelock.common.match;

import com.bluelock.common.pitch.PitchLayout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * One match: score, clock, phase, teams and possession. Pure logic, driven by {@link #tick}.
 * Flow: start -> WAITING_KICKOFF -> (first touch) IN_PLAY -> goal -> GOAL_PAUSE -> WAITING_KICKOFF ...
 * Ball out of play -> WAITING_RESTART -> (touch) IN_PLAY. Clock runs only while IN_PLAY. At time up: FINISHED.
 */
public final class MatchSession {
    private final PitchLayout layout;
    private final MatchRules rules;
    private final Map<UUID, Side> roster = new HashMap<>();

    private MatchPhase phase = MatchPhase.IDLE;
    private int homeGoals;
    private int awayGoals;
    private int elapsedTicks;
    private int pauseTicksLeft;
    private boolean needBaseline;
    private int touchBaseline;
    private int lastSeenTouch;
    private UUID lastToucher;
    private Side lastToucherSide;

    public MatchSession(PitchLayout layout, MatchRules rules) {
        this.layout = layout;
        this.rules = rules;
    }

    public void start() {
        phase = MatchPhase.WAITING_KICKOFF;
        homeGoals = 0;
        awayGoals = 0;
        elapsedTicks = 0;
        needBaseline = true;
        lastToucher = null;
        lastToucherSide = null;
    }

    public void stop() {
        phase = MatchPhase.IDLE;
    }

    /** The ball entity was replaced (it was lost). Its touch counter starts again from zero. */
    public void ballReplaced() {
        needBaseline = true;
        lastSeenTouch = 0;
    }

    public void join(UUID player, Side side) {
        roster.put(player, side);
    }

    public Side sideOf(UUID player) {
        return roster.get(player);
    }

    public MatchPhase phase() { return phase; }
    public int homeGoals() { return homeGoals; }
    public int awayGoals() { return awayGoals; }
    public int elapsedTicks() { return elapsedTicks; }
    public int durationTicks() { return rules.durationTicks(); }
    public Side possession() { return lastToucherSide; }
    public boolean isActive() { return phase != MatchPhase.IDLE && phase != MatchPhase.FINISHED; }

    public List<MatchEvent> tick(BallSnapshot ball) {
        List<MatchEvent> events = new ArrayList<>();
        switch (phase) {
            case IDLE, FINISHED -> { }
            case WAITING_KICKOFF, WAITING_RESTART -> {
                if (needBaseline) {
                    touchBaseline = ball.touchCount();
                    needBaseline = false;
                } else if (ball.touchCount() != touchBaseline) {
                    boolean kickoff = phase == MatchPhase.WAITING_KICKOFF;
                    phase = MatchPhase.IN_PLAY;
                    trackTouch(ball);
                    if (kickoff) events.add(new MatchEvent.PlayStarted());
                }
            }
            case GOAL_PAUSE -> {
                if (--pauseTicksLeft <= 0) {
                    if (elapsedTicks >= rules.durationTicks()) {
                        finish(events);
                    } else {
                        phase = MatchPhase.WAITING_KICKOFF;
                        needBaseline = true;
                        events.add(new MatchEvent.KickoffReset());
                    }
                }
            }
            case IN_PLAY -> inPlay(ball, events);
        }
        return events;
    }

    private void inPlay(BallSnapshot ball, List<MatchEvent> events) {
        trackTouch(ball);
        elapsedTicks++;

        GoalDetector.Area area = GoalDetector.classify(layout, ball.u(), ball.v(), ball.height());
        if (area == GoalDetector.Area.NEAR_GOAL || area == GoalDetector.Area.FAR_GOAL) {
            Side defending = area == GoalDetector.Area.NEAR_GOAL ? Side.HOME : Side.AWAY;
            Side scoring = defending.opposite();
            if (scoring == Side.HOME) homeGoals++; else awayGoals++;
            boolean own = lastToucherSide == defending;
            UUID scorer = (!own && lastToucherSide == scoring) ? lastToucher : null;
            events.add(new MatchEvent.GoalScored(scoring, scorer, own, homeGoals, awayGoals));
            phase = MatchPhase.GOAL_PAUSE;
            pauseTicksLeft = rules.goalPauseTicks();
            return;
        }
        if (area == GoalDetector.Area.OUT) {
            double[] spot = GoalDetector.restartSpot(layout, ball.u(), ball.v());
            events.add(new MatchEvent.BallOut(spot[0], spot[1]));
            phase = MatchPhase.WAITING_RESTART;
            needBaseline = true;
            return;
        }
        if (elapsedTicks >= rules.durationTicks()) {
            finish(events);
        }
    }

    private void finish(List<MatchEvent> events) {
        phase = MatchPhase.FINISHED;
        Side winner = homeGoals > awayGoals ? Side.HOME : awayGoals > homeGoals ? Side.AWAY : null;
        events.add(new MatchEvent.MatchFinished(winner, homeGoals, awayGoals));
    }

    private void trackTouch(BallSnapshot ball) {
        if (ball.touchCount() != lastSeenTouch) {
            lastSeenTouch = ball.touchCount();
            lastToucher = ball.lastToucher();
            lastToucherSide = lastToucher == null ? null : roster.get(lastToucher);
        }
    }
}
