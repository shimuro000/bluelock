package com.bluelock.common.profile;

public enum DominantFoot { LEFT, RIGHT, BOTH }
