package com.bluelock.common.team;

import com.bluelock.common.content.Playstyle;

/** Team behaviour settings, 0..100 each. The AI (a later phase) reads these. */
public record TeamTactics(int defensiveLine, int pressing, int tempo) {
    public TeamTactics {
        defensiveLine = clamp(defensiveLine);
        pressing = clamp(pressing);
        tempo = clamp(tempo);
    }

    public static TeamTactics forPlaystyle(Playstyle style) {
        return switch (style) {
            case BALANCED -> new TeamTactics(50, 50, 50);
            case POSSESSION -> new TeamTactics(65, 55, 40);
            case COUNTER -> new TeamTactics(30, 35, 80);
            case HIGH_PRESS -> new TeamTactics(75, 90, 70);
            case DIRECT -> new TeamTactics(50, 40, 85);
        };
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(100, v));
    }
}
