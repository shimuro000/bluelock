package com.bluelock.common.progression;

import com.bluelock.common.profile.PlayerProfile;

/** XP, levels, skill points and development points (spec sections 9 and 13). */
public final class Progression {
    public static final int MAX_LEVEL = 50;
    public static final int SKILL_POINTS_PER_LEVEL = 1;
    public static final int DEVELOPMENT_POINTS_PER_LEVEL = 3;

    public enum XpAction {
        PASS(1), SHOT(3), SKILL_USED(2), DRIBBLE_MOVE(4), TACKLE_WON(8), GOAL(40), MATCH_PLAYED(25), MATCH_WON(35);

        private final int xp;

        XpAction(int xp) {
            this.xp = xp;
        }

        public int xp() {
            return xp;
        }
    }

    public record LevelUp(int levelsGained, int newLevel) {
        public boolean happened() {
            return levelsGained > 0;
        }
    }

    private Progression() {
    }

    /** XP needed to go from {@code level} to the next one. */
    public static long xpToNext(int level) {
        return 100L + 40L * (level - 1);
    }

    public static LevelUp award(PlayerProfile p, XpAction action) {
        return award(p, action.xp());
    }

    /** Adds XP, applies level-ups (skill points + development points) and returns what happened. */
    public static LevelUp award(PlayerProfile p, long amount) {
        if (amount <= 0 || p.level() >= MAX_LEVEL) return new LevelUp(0, p.level());
        int level = p.level();
        long xp = p.xp() + amount;
        int skillPoints = p.skillPoints();
        int devPoints = p.developmentPoints();
        int gained = 0;
        while (level < MAX_LEVEL && xp >= xpToNext(level)) {
            xp -= xpToNext(level);
            level++;
            gained++;
            skillPoints += SKILL_POINTS_PER_LEVEL;
            devPoints += DEVELOPMENT_POINTS_PER_LEVEL;
        }
        if (level >= MAX_LEVEL) xp = 0;
        p.setProgression(level, xp, skillPoints, devPoints);
        return new LevelUp(gained, level);
    }
}
