package com.bluelock.common.content;

import com.bluelock.common.registry.Registry;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * All loaded game content, built from raw data files. A broken file is skipped and reported in
 * {@link #problems()} so one typo never stops the whole mod from loading.
 */
public final class DefinitionPack {
    public static final String SKILLS = "skills";
    public static final String FORMATIONS = "formations";
    public static final String TEAMS = "teams";
    public static final String ARCHETYPES = "archetypes";
    public static final String PERSONALITIES = "personalities";

    private final Registry<SkillDefinition> skills;
    private final Registry<FormationDefinition> formations;
    private final Registry<TeamDefinition> teams;
    private final Registry<BuildDefinition> archetypes;
    private final Registry<BuildDefinition> personalities;
    private final List<String> problems;

    private DefinitionPack(Registry<SkillDefinition> skills, Registry<FormationDefinition> formations,
                           Registry<TeamDefinition> teams, Registry<BuildDefinition> archetypes,
                           Registry<BuildDefinition> personalities, List<String> problems) {
        this.skills = skills;
        this.formations = formations;
        this.teams = teams;
        this.archetypes = archetypes;
        this.personalities = personalities;
        this.problems = List.copyOf(problems);
    }

    public static DefinitionPack empty() {
        return build(List.of());
    }

    public static DefinitionPack build(List<RawDefinition> raws) {
        List<String> problems = new ArrayList<>();
        Registry<SkillDefinition> skills = new Registry<>("skills");
        Registry<FormationDefinition> formations = new Registry<>("formations");
        Registry<TeamDefinition> teams = new Registry<>("teams");
        Registry<BuildDefinition> archetypes = new Registry<>("archetypes");
        Registry<BuildDefinition> personalities = new Registry<>("personalities");

        Map<String, SkillDefinition> parsedSkills = new LinkedHashMap<>();
        List<RawDefinition> teamRaws = new ArrayList<>();

        for (RawDefinition raw : raws) {
            String where = raw.type() + "/" + raw.id();
            try {
                if (!Registry.isValidId(raw.id())) throw new DefinitionException("invalid file name (use a-z, 0-9, _)");
                switch (raw.type()) {
                    case SKILLS -> parsedSkills.put(raw.id(), SkillDefinition.parse(raw.id(), raw.data()));
                    case FORMATIONS -> formations.register(raw.id(), FormationDefinition.parse(raw.id(), raw.data()));
                    case TEAMS -> teamRaws.add(raw);
                    case ARCHETYPES -> {
                        requireEnumName(raw.id(), com.bluelock.common.profile.Archetype.class);
                        archetypes.register(raw.id(), BuildDefinition.parse(raw.id(), raw.data()));
                    }
                    case PERSONALITIES -> {
                        requireEnumName(raw.id(), com.bluelock.common.profile.Personality.class);
                        personalities.register(raw.id(), BuildDefinition.parse(raw.id(), raw.data()));
                    }
                    default -> throw new DefinitionException("unknown content type '" + raw.type() + "'");
                }
            } catch (DefinitionException | IllegalArgumentException e) {
                problems.add(where + ": " + e.getMessage());
            }
        }

        // Skill tree: accept a skill only after all of its parents were accepted (rejects missing parents and cycles).
        Map<String, SkillDefinition> pending = new LinkedHashMap<>(parsedSkills);
        boolean progress = true;
        while (progress) {
            progress = false;
            for (SkillDefinition s : new ArrayList<>(pending.values())) {
                if (s.requires().stream().allMatch(skills::contains)) {
                    skills.register(s.id(), s);
                    pending.remove(s.id());
                    progress = true;
                }
            }
        }
        for (SkillDefinition s : pending.values()) {
            problems.add("skills/" + s.id() + ": parent skill missing or skill tree loops back on itself");
        }

        for (RawDefinition raw : teamRaws) {
            try {
                TeamDefinition t = TeamDefinition.parse(raw.id(), raw.data());
                if (!formations.contains(t.formationId())) {
                    throw new DefinitionException("unknown formation '" + t.formationId() + "'");
                }
                teams.register(raw.id(), t);
            } catch (DefinitionException | IllegalArgumentException e) {
                problems.add("teams/" + raw.id() + ": " + e.getMessage());
            }
        }

        return new DefinitionPack(skills.freeze(), formations.freeze(), teams.freeze(),
                archetypes.freeze(), personalities.freeze(), problems);
    }

    /** The file name must match a choice the game knows (e.g. striker.json for Archetype.STRIKER). */
    private static <E extends Enum<E>> void requireEnumName(String id, Class<E> type) {
        for (E e : type.getEnumConstants()) {
            if (e.name().equalsIgnoreCase(id)) return;
        }
        throw new DefinitionException("'" + id + "' is not a known " + type.getSimpleName().toLowerCase());
    }

    public Registry<SkillDefinition> skills() { return skills; }
    public Registry<FormationDefinition> formations() { return formations; }
    public Registry<TeamDefinition> teams() { return teams; }
    public Registry<BuildDefinition> archetypes() { return archetypes; }
    public Registry<BuildDefinition> personalities() { return personalities; }
    public List<String> problems() { return problems; }
}
