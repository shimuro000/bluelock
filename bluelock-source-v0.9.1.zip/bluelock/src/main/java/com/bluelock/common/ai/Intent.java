package com.bluelock.common.ai;

public enum Intent { HOLD, MOVE, CHASE_BALL, PRESS, TACKLE, PASS, SHOOT, DRIBBLE, CLEAR }
