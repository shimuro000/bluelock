package com.bluelock.common.ai;

import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;

/**
 * Decision making of a football bot. Pure and deterministic: the same view always gives the same decision,
 * so it can be tested without Minecraft. The Forge entity turns the decision into movement and kicks.
 */
public final class BotBrain {
    public static final double TACKLE_RANGE = 1.8;
    private static final double PRESSURE_DISTANCE = 3.0;

    private BotBrain() {
    }

    public static BotDecision decide(BotView v) {
        if (v.position() == Position.GK) return keeper(v);
        if (v.selfHasBall()) return withBall(v);
        if (v.possession() == v.side()) return support(v);
        if (v.possession() != null) return defend(v);
        return looseBall(v);
    }

    // ---------- helpers ----------

    private static boolean attacksFar(BotView v) {
        return v.side() == Side.HOME;
    }

    private static double dir(BotView v) {
        return attacksFar(v) ? 1.0 : -1.0;
    }

    private static Pos goal(BotView v) {
        PitchLayout l = v.layout();
        return new Pos(attacksFar(v) ? l.length() : 0, l.centreV() + 0.5);
    }

    private static boolean isForward(Position p) {
        return switch (p) {
            case ST, CF, LW, RW, CAM, LM, RM -> true;
            default -> false;
        };
    }

    private static Pos clamp(PitchLayout l, double u, double v) {
        return new Pos(Math.max(2, Math.min(l.length() - 2, u)), Math.max(2, Math.min(l.width() - 2, v)));
    }

    private static double nearestDistance(Pos p, java.util.List<Pos> others) {
        double best = Double.MAX_VALUE;
        for (Pos o : others) best = Math.min(best, p.dist(o));
        return best;
    }

    /** Where this bot stands when it has nothing special to do: its formation spot, moved with the ball. */
    private static Pos shape(BotView v) {
        PitchLayout l = v.layout();
        double cu = l.centreU() + 0.5;
        double cv = l.centreV() + 0.5;
        double k = 0.30 + 0.30 * v.tactics().defensiveLine() / 100.0;
        return clamp(l, v.baseSpot().u() + (v.ball().u() - cu) * k, v.baseSpot().v() + (v.ball().v() - cv) * 0.25);
    }

    // ---------- roles ----------

    private static BotDecision keeper(BotView v) {
        PitchLayout l = v.layout();
        double cv = l.centreV() + 0.5;
        double lineU = attacksFar(v) ? 2.0 : l.length() - 2.0;
        double fromOwnGoal = attacksFar(v) ? v.ball().u() : l.length() - v.ball().u();

        if (v.selfHasBall()) {
            int pass = bestPass(v, true);
            if (pass >= 0) return new BotDecision(Intent.PASS, v.mates().get(pass), 1.0, pass);
            return BotDecision.of(Intent.CLEAR, new Pos(l.centreU() + 0.5, v.self().v()), 1.0);
        }
        if (v.possession() == null && fromOwnGoal < 14 && v.self().dist(v.ball()) < 7.0) {
            return BotDecision.of(Intent.CHASE_BALL, v.ball(), 1.0);
        }
        double targetV = Math.max(cv - 3.0, Math.min(cv + 3.0, cv + (v.ball().v() - cv) * 0.35));
        return BotDecision.of(Intent.MOVE, new Pos(lineU, targetV), 0.8);
    }

    private static BotDecision withBall(BotView v) {
        PitchLayout l = v.layout();
        Pos goal = goal(v);
        double dGoal = v.self().dist(goal);
        double nearest = nearestDistance(v.self(), v.opponents());
        boolean pressured = nearest < PRESSURE_DISTANCE;
        double depth = attacksFar(v) ? v.self().u() : l.length() - v.self().u();
        double shootRange = 14 + 10 * v.rating() / 100.0;

        if (dGoal <= shootRange) {
            // aim at the far corner from the goalkeeper (the opponent closest to the goal)
            double keeperV = l.centreV() + 0.5;
            double bestKeeperDist = Double.MAX_VALUE;
            for (Pos o : v.opponents()) {
                double d = o.dist(goal);
                if (d < bestKeeperDist) {
                    bestKeeperDist = d;
                    keeperV = o.v();
                }
            }
            double aimV = l.centreV() + 0.5 + (keeperV >= l.centreV() + 0.5 ? -2.4 : 2.4);
            return BotDecision.of(Intent.SHOOT, new Pos(goal.u(), aimV), 1.0);
        }
        if (depth < 10 && pressured) {
            return BotDecision.of(Intent.CLEAR, new Pos(l.centreU() + 0.5, v.self().v()), 1.0);
        }
        int pass = bestPass(v, false);
        if (pass >= 0 && (pressured || !isForward(v.position()))) {
            return new BotDecision(Intent.PASS, v.mates().get(pass), 1.0, pass);
        }
        // dribble toward goal, sidestepping the closest opponent that is in front
        double stepV = v.self().v();
        for (Pos o : v.opponents()) {
            boolean inFront = (o.u() - v.self().u()) * dir(v) > 0 && o.dist(v.self()) < 6.0;
            if (inFront) {
                stepV += o.v() >= v.self().v() ? -4.0 : 4.0;
                break;
            }
        }
        return BotDecision.of(Intent.DRIBBLE, clamp(l, v.self().u() + dir(v) * 7.0, stepV), 0.95);
    }

    private static BotDecision support(BotView v) {
        PitchLayout l = v.layout();
        double ahead = dir(v);
        Position pos = v.position();
        boolean forward = pos == Position.ST || pos == Position.CF || pos == Position.LW || pos == Position.RW;
        boolean mid = pos == Position.CAM || pos == Position.CM || pos == Position.CDM || pos == Position.LM || pos == Position.RM;
        if (forward) {
            Pos base = v.baseSpot();
            return BotDecision.of(Intent.MOVE, clamp(l, v.ball().u() + ahead * 9.0, base.v()), 0.95);
        }
        if (mid) {
            Pos base = v.baseSpot();
            return BotDecision.of(Intent.MOVE, clamp(l, v.ball().u() + ahead * 2.5, base.v()), 0.85);
        }
        return BotDecision.of(Intent.MOVE, shape(v), 0.75);
    }

    private static BotDecision defend(BotView v) {
        if (v.carrier() != null && (v.chaseRank() == 0 || (v.chaseRank() == 1 && v.tactics().pressing() >= 60))) {
            double d = v.self().dist(v.carrier());
            if (v.chaseRank() == 0 && d <= TACKLE_RANGE) {
                return BotDecision.of(Intent.TACKLE, v.carrier(), 1.0);
            }
            return BotDecision.of(Intent.PRESS, v.carrier(), v.chaseRank() == 0 ? 1.0 : 0.9);
        }
        return BotDecision.of(Intent.HOLD, shape(v), 0.7);
    }

    private static BotDecision looseBall(BotView v) {
        if (v.chaseRank() == 0) return BotDecision.of(Intent.CHASE_BALL, v.ball(), 1.0);
        return BotDecision.of(Intent.MOVE, shape(v), 0.8);
    }

    // ---------- passing ----------

    /** Index of the best open teammate ahead of the ball carrier, or -1. */
    private static int bestPass(BotView v, boolean allowBackwards) {
        int best = -1;
        double bestScore = -Double.MAX_VALUE;
        for (int i = 0; i < v.mates().size(); i++) {
            Pos m = v.mates().get(i);
            double dist = v.self().dist(m);
            double progress = (m.u() - v.self().u()) * dir(v);
            if (dist < 4 || dist > 26) continue;
            if (!allowBackwards && progress < 2) continue;
            if (nearestDistance(m, v.opponents()) < 2.5) continue;
            if (laneBlocked(v.self(), m, v.opponents())) continue;
            double score = progress - dist * 0.1;
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        return best;
    }

    private static boolean laneBlocked(Pos from, Pos to, java.util.List<Pos> opponents) {
        double dx = to.u() - from.u(), dv = to.v() - from.v();
        double len2 = dx * dx + dv * dv;
        for (Pos o : opponents) {
            double t = len2 == 0 ? 0 : ((o.u() - from.u()) * dx + (o.v() - from.v()) * dv) / len2;
            if (t <= 0 || t >= 1) continue;
            double px = from.u() + t * dx, pv = from.v() + t * dv;
            if (Math.hypot(o.u() - px, o.v() - pv) < 2.2) return true;
        }
        return false;
    }
}
