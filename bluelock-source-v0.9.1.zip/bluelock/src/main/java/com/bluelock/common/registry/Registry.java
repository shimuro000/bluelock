package com.bluelock.common.registry;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

/** Simple id -> definition table. Filled once while loading data, then frozen (read-only). */
public final class Registry<T> {
    private static final Pattern VALID_ID = Pattern.compile("[a-z0-9_]{1,64}");

    private final String name;
    private final Map<String, T> entries = new LinkedHashMap<>();
    private boolean frozen = false;

    public Registry(String name) {
        this.name = name;
    }

    public static boolean isValidId(String id) {
        return id != null && VALID_ID.matcher(id).matches();
    }

    public void register(String id, T value) {
        if (frozen) throw new IllegalStateException(name + " registry is frozen");
        if (!isValidId(id)) throw new IllegalArgumentException(name + ": invalid id '" + id + "' (use a-z, 0-9, _)");
        if (value == null) throw new IllegalArgumentException(name + ": null value for '" + id + "'");
        if (entries.containsKey(id)) throw new IllegalArgumentException(name + ": duplicate id '" + id + "'");
        entries.put(id, value);
    }

    public Registry<T> freeze() {
        frozen = true;
        return this;
    }

    public Optional<T> get(String id) {
        return Optional.ofNullable(entries.get(id));
    }

    public boolean contains(String id) {
        return entries.containsKey(id);
    }

    public Collection<T> values() {
        return Collections.unmodifiableCollection(entries.values());
    }

    public Map<String, T> asMap() {
        return Collections.unmodifiableMap(entries);
    }

    public int size() {
        return entries.size();
    }

    public String name() {
        return name;
    }
}
