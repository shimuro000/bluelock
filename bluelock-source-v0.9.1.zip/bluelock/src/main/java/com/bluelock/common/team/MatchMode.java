package com.bluelock.common.team;

import java.util.Locale;
import java.util.Optional;

/** Players per team (spec section 33). */
public enum MatchMode {
    ONE_V_ONE(1), TWO_V_TWO(2), THREE_V_THREE(3), FOUR_V_FOUR(4), FIVE_V_FIVE(5), SEVEN_V_SEVEN(7), ELEVEN_V_ELEVEN(11);

    private final int size;

    MatchMode(int size) {
        this.size = size;
    }

    public int size() {
        return size;
    }

    /** Text such as "5v5". */
    public String label() {
        return size + "v" + size;
    }

    public static Optional<MatchMode> parse(String text) {
        if (text == null) return Optional.empty();
        String t = text.trim().toLowerCase(Locale.ROOT);
        for (MatchMode m : values()) {
            if (m.label().equals(t)) return Optional.of(m);
        }
        return Optional.empty();
    }
}
