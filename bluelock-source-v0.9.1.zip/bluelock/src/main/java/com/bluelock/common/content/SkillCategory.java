package com.bluelock.common.content;

public enum SkillCategory { SHOOTING, PASSING, DRIBBLING, MOVEMENT, DEFENSE, VISION, PHYSICAL, MENTAL, SPECIAL }
