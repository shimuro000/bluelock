package com.bluelock.common.profile;

/** Football background (spec section 5, stage C). Modifies starting tendencies, never locks the build. */
public enum Archetype { STRIKER, SPEEDSTER, DRIBBLER, PLAYMAKER, FINISHER, DEFENDER, ALL_ROUNDER }
