package com.bluelock.common.match;

import com.bluelock.common.pitch.PitchLayout;

/** Decides where the ball is: on the pitch, in a goal, or out of play. */
public final class GoalDetector {
    public enum Area { IN_PLAY, NEAR_GOAL, FAR_GOAL, OUT }

    private static final double VOID_HEIGHT = -6.0;

    private GoalDetector() {
    }

    /**
     * NEAR_GOAL is the goal behind u = 0 (HOME defends it), FAR_GOAL the one behind u = length.
     * A ball is in a goal when it is between the posts, under the crossbar, and behind the goal line.
     */
    public static Area classify(PitchLayout layout, double u, double v, double height) {
        if (height < VOID_HEIGHT) return Area.OUT;
        int cv = layout.centreV();
        boolean betweenPosts = v >= cv - PitchLayout.GOAL_HALF_WIDTH && v < cv + PitchLayout.GOAL_HALF_WIDTH + 1;
        boolean underBar = height < PitchLayout.GOAL_HEIGHT;
        if (betweenPosts && underBar) {
            if (u < 0 && u > -PitchLayout.GOAL_DEPTH) return Area.NEAR_GOAL;
            if (u >= layout.length() && u < layout.length() + PitchLayout.GOAL_DEPTH) return Area.FAR_GOAL;
        }
        boolean inside = u >= 0 && u < layout.length() && v >= 0 && v < layout.width();
        return inside ? Area.IN_PLAY : Area.OUT;
    }

    /** Closest spot just inside the touchlines/goal lines, used to put the ball back. */
    public static double[] restartSpot(PitchLayout layout, double u, double v) {
        double ru = Math.max(1.5, Math.min(layout.length() - 1.5, u));
        double rv = Math.max(1.5, Math.min(layout.width() - 1.5, v));
        return new double[] {ru, rv};
    }
}
