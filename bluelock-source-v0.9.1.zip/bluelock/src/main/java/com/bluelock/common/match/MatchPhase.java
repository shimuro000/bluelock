package com.bluelock.common.match;

public enum MatchPhase { IDLE, WAITING_KICKOFF, IN_PLAY, WAITING_RESTART, GOAL_PAUSE, FINISHED }
