package com.bluelock.common.match;

/** Match settings. Ticks: 20 per second. */
public record MatchRules(int durationTicks, int goalPauseTicks) {
    public static MatchRules ofMinutes(int minutes) {
        return new MatchRules(minutes * 60 * 20, 3 * 20);
    }
}
