package com.bluelock.common.match;

/** HOME defends the goal behind the u = 0 line and attacks the far one; AWAY is the opposite. */
public enum Side {
    HOME, AWAY;

    public Side opposite() {
        return this == HOME ? AWAY : HOME;
    }
}
