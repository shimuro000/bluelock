package com.bluelock.common.stats;

/** EffectiveStat = Base + PermanentGrowth + Equipment + Skill + Temporary + Flow + Context, clamped. */
public final class StatCalculator {
    private StatCalculator() {
    }

    public static int effective(StatBlock block, StatModifiers mods, Stat s) {
        return StatBlock.clamp(block.base(s) + block.growth(s) + mods.total(s));
    }
}
