package com.bluelock.common.progression;

import com.bluelock.common.content.DefinitionPack;
import com.bluelock.common.content.SkillDefinition;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.stats.Stat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Skill unlocking. Root skills (no parents) unlock by themselves once your stats are high enough.
 * Every other skill needs all its parent skills, the stat requirements, and one skill point.
 */
public final class SkillRules {
    public static final int SKILL_POINT_COST = 1;

    private SkillRules() {
    }

    /** Returns null when the skill can be unlocked, otherwise a language key explaining why not. */
    public static String check(PlayerProfile p, SkillDefinition s) {
        if (p.isUnlocked(s.id())) return "bluelock.skill.error.already";
        for (String parent : s.requires()) {
            if (!p.isUnlocked(parent)) return "bluelock.skill.error.parent";
        }
        for (Map.Entry<Stat, Integer> req : s.requirements().entrySet()) {
            if (p.stats().permanent(req.getKey()) < req.getValue()) return "bluelock.skill.error.stats";
        }
        if (!s.requires().isEmpty() && p.skillPoints() < SKILL_POINT_COST) return "bluelock.skill.error.points";
        return null;
    }

    /** Unlocks a skill if allowed. Returns null on success or the error key. */
    public static String unlock(PlayerProfile p, SkillDefinition s) {
        String error = check(p, s);
        if (error != null) return error;
        if (!s.requires().isEmpty()) p.spendSkillPoints(SKILL_POINT_COST);
        p.unlockSkill(s.id());
        return null;
    }

    /** Unlocks every root skill whose stat requirements are met. Returns the ids that were newly unlocked. */
    public static List<String> autoUnlockRoots(PlayerProfile p, DefinitionPack pack) {
        List<String> unlocked = new ArrayList<>();
        for (SkillDefinition s : pack.skills().values()) {
            if (s.requires().isEmpty() && check(p, s) == null) {
                p.unlockSkill(s.id());
                unlocked.add(s.id());
            }
        }
        return unlocked;
    }
}
