package com.bluelock.common.pitch;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Pure geometry of a football pitch (no Minecraft code). Coordinates: u runs along the length (0 .. length-1),
 * v runs across the width (0 .. width-1). Length and width are odd so the centre is a single block.
 * The Forge side turns Surfaces and GoalParts into real blocks.
 */
public final class PitchLayout {
    public enum Surface { LIGHT_GRASS, DARK_GRASS, LINE }

    public enum GoalPart { POST, NET }

    /** One goal block, placed above the pitch surface: dy = 1 is the block on top of the grass. */
    public record GoalCell(int u, int dy, int v, GoalPart part) {
    }

    public static final int DEFAULT_LENGTH = 61;
    public static final int DEFAULT_WIDTH = 37;
    public static final int GOAL_HALF_WIDTH = 3;   // goal opening is 7 blocks wide
    public static final int GOAL_HEIGHT = 3;
    public static final int GOAL_DEPTH = 3;
    private static final int PENALTY_DEPTH = 9;
    private static final int PENALTY_HALF_WIDTH = 10;
    private static final int GOAL_AREA_DEPTH = 4;
    private static final int GOAL_AREA_HALF_WIDTH = 5;
    private static final int PENALTY_SPOT = 7;
    private static final double CENTRE_CIRCLE_RADIUS = 5.0;

    private final int length;
    private final int width;

    public PitchLayout(int length, int width) {
        if (length < 41 || length > 121 || width < 25 || width > 81) {
            throw new IllegalArgumentException("pitch size out of range (length 41-121, width 25-81)");
        }
        if (length % 2 == 0 || width % 2 == 0) {
            throw new IllegalArgumentException("length and width must be odd numbers");
        }
        this.length = length;
        this.width = width;
    }

    public static PitchLayout standard() {
        return new PitchLayout(DEFAULT_LENGTH, DEFAULT_WIDTH);
    }

    public int length() { return length; }
    public int width() { return width; }
    public int centreU() { return (length - 1) / 2; }
    public int centreV() { return (width - 1) / 2; }

    public boolean inside(int u, int v) {
        return u >= 0 && u < length && v >= 0 && v < width;
    }

    /** What the surface block at (u, v) should be. Only call for cells that are inside the pitch. */
    public Surface surfaceAt(int u, int v) {
        if (!inside(u, v)) throw new IllegalArgumentException("outside the pitch: " + u + "," + v);
        int du = Math.min(u, length - 1 - u);      // distance from the nearest goal line
        int dv = Math.abs(v - centreV());          // distance from the long centre axis

        boolean line = u == 0 || u == length - 1 || v == 0 || v == width - 1;          // outline
        line |= u == centreU();                                                          // halfway line
        line |= (du == PENALTY_DEPTH && dv <= PENALTY_HALF_WIDTH) || (dv == PENALTY_HALF_WIDTH && du <= PENALTY_DEPTH);
        line |= (du == GOAL_AREA_DEPTH && dv <= GOAL_AREA_HALF_WIDTH) || (dv == GOAL_AREA_HALF_WIDTH && du <= GOAL_AREA_DEPTH);
        line |= du == PENALTY_SPOT && dv == 0;                                           // penalty spots
        double dist = Math.hypot(u - centreU(), v - centreV());
        line |= Math.abs(dist - CENTRE_CIRCLE_RADIUS) <= 0.5 || dist < 0.5;              // centre circle and spot

        if (line) return Surface.LINE;
        return (u / 4) % 2 == 0 ? Surface.LIGHT_GRASS : Surface.DARK_GRASS;
    }

    /**
     * Blocks of one goal. {@code farEnd == false}: the goal behind the u = 0 line; true: behind u = length-1.
     * Cells outside the pitch have u < 0 (or u > length-1 for the far end).
     */
    public List<GoalCell> goalCells(boolean farEnd) {
        Map<String, GoalCell> cells = new LinkedHashMap<>();
        int cv = centreV();
        int left = cv - GOAL_HALF_WIDTH - 1;
        int right = cv + GOAL_HALF_WIDTH + 1;

        for (int dy = 1; dy <= GOAL_HEIGHT; dy++) {
            put(cells, 0, dy, left, GoalPart.POST, farEnd);
            put(cells, 0, dy, right, GoalPart.POST, farEnd);
            put(cells, -GOAL_DEPTH, dy, left, GoalPart.POST, farEnd);
            put(cells, -GOAL_DEPTH, dy, right, GoalPart.POST, farEnd);
        }
        for (int v = left; v <= right; v++) {
            put(cells, 0, GOAL_HEIGHT, v, GoalPart.POST, farEnd);                     // crossbar
            for (int d = 1; d <= GOAL_DEPTH; d++) {
                put(cells, -d, GOAL_HEIGHT, v, GoalPart.NET, farEnd);                 // roof net
            }
            for (int dy = 1; dy <= GOAL_HEIGHT; dy++) {
                put(cells, -GOAL_DEPTH, dy, v, GoalPart.NET, farEnd);                 // back net
            }
        }
        for (int d = 1; d < GOAL_DEPTH; d++) {
            for (int dy = 1; dy <= GOAL_HEIGHT; dy++) {
                put(cells, -d, dy, left, GoalPart.NET, farEnd);                       // side nets
                put(cells, -d, dy, right, GoalPart.NET, farEnd);
            }
        }
        // posts and crossbar win over nets where they overlap
        for (int dy = 1; dy <= GOAL_HEIGHT; dy++) {
            put(cells, -GOAL_DEPTH, dy, left, GoalPart.POST, farEnd);
            put(cells, -GOAL_DEPTH, dy, right, GoalPart.POST, farEnd);
        }
        for (int v = left; v <= right; v++) {
            put(cells, 0, GOAL_HEIGHT, v, GoalPart.POST, farEnd);
        }
        return new ArrayList<>(cells.values());
    }

    private void put(Map<String, GoalCell> cells, int u, int dy, int v, GoalPart part, boolean farEnd) {
        int uu = farEnd ? length - 1 - u : u;
        cells.put(uu + "," + dy + "," + v, new GoalCell(uu, dy, v, part));
    }
}
