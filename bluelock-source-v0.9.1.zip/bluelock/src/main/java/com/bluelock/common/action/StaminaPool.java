package com.bluelock.common.action;

/** Stamina of one player. Sprinting drains it, standing and walking refill it, skills and tackles cost some. */
public final class StaminaPool {
    private double current;
    private double max;

    public StaminaPool(int staminaStat) {
        this.max = maxFor(staminaStat);
        this.current = max;
    }

    public static double maxFor(int staminaStat) {
        return 60 + 0.8 * staminaStat;
    }

    public void refreshMax(int staminaStat) {
        double ratio = max <= 0 ? 1 : current / max;
        max = maxFor(staminaStat);
        current = max * ratio;
    }

    public boolean spend(double cost) {
        if (current < cost) return false;
        current -= cost;
        return true;
    }

    /** Call once per tick. */
    public void tick(boolean sprinting, int staminaStat) {
        if (sprinting) {
            current -= 0.14 * (1.4 - 0.6 * staminaStat / 100.0);
        } else {
            current += 0.12 + 0.001 * staminaStat;
        }
        current = Math.max(0, Math.min(max, current));
    }

    public double current() { return current; }
    public double max() { return max; }
    public int percent() { return (int) Math.round(100.0 * current / max); }
    public boolean exhausted() { return current < 5; }
}
