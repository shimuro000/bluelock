package com.bluelock.common.content;

public enum Playstyle { BALANCED, POSSESSION, COUNTER, HIGH_PRESS, DIRECT }
