package com.bluelock.common.ball;

/**
 * Ball movement rules, with no Minecraft code. The Forge entity moves the ball, tells us what it hit,
 * and we return the new velocity. Units: blocks and ticks (20 ticks = 1 second).
 */
public final class BallPhysics {
    /** Tunable physics numbers. Later phases can load these from a config file. */
    public record Config(double gravity, double airDrag, double waterDrag, double groundFriction,
                         double bounciness, double wallBounciness, double ceilingBounciness,
                         double minBounceSpeed, double stopSpeed,
                         double dribbleSpeedFactor, double passSpeed, double shotSpeed, double shotLift) {
    }

    public static Config defaults() {
        return new Config(0.03, 0.995, 0.8, 0.965, 0.65, 0.55, 0.3, 0.08, 0.005, 1.5, 0.55, 1.0, 0.12);
    }

    /** Result of resolving a move: the new velocity and whether the ball is resting on/rolling along the ground. */
    public record Resolved(Velocity velocity, boolean grounded, boolean bounced) {
    }

    private BallPhysics() {
    }

    /** Gravity and drag, applied before the ball moves each tick. */
    public static Velocity applyForces(Velocity v, Config c, boolean inWater) {
        double drag = inWater ? c.waterDrag() : c.airDrag();
        double gravity = inWater ? c.gravity() * 0.3 : c.gravity();
        return new Velocity(v.x() * drag, v.y() * drag - gravity, v.z() * drag);
    }

    /**
     * After moving by {@code intended}, the entity reports which axes were blocked.
     * Bounce off walls and ceilings, bounce or settle on the ground, and roll with friction.
     */
    public static Resolved resolve(Velocity intended, boolean hitX, boolean hitY, boolean hitZ, Config c) {
        double vx = intended.x();
        double vy = intended.y();
        double vz = intended.z();
        boolean grounded = false;
        boolean bounced = false;

        if (hitX) {
            vx = -vx * c.wallBounciness();
            bounced |= Math.abs(intended.x()) > c.minBounceSpeed();
        }
        if (hitZ) {
            vz = -vz * c.wallBounciness();
            bounced |= Math.abs(intended.z()) > c.minBounceSpeed();
        }
        if (hitY) {
            if (intended.y() < 0) {
                grounded = true;
                if (-intended.y() >= c.minBounceSpeed()) {
                    vy = -vy * c.bounciness();
                    bounced = true;
                    grounded = false;
                } else {
                    vy = 0;
                }
            } else {
                vy = -vy * c.ceilingBounciness();
            }
        }
        if (grounded) {
            vx *= c.groundFriction();
            vz *= c.groundFriction();
            if (Math.sqrt(vx * vx + vz * vz) < c.stopSpeed()) {
                vx = 0;
                vz = 0;
            }
        }
        return new Resolved(new Velocity(vx, vy, vz), grounded, bounced);
    }

    /** Velocity for a kick in direction (dx, dy, dz) at the given speed, with at least {@code minLift} upward. */
    public static Velocity kick(double dx, double dy, double dz, double speed, double minLift) {
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-6 || speed <= 0) return Velocity.ZERO;
        double nx = dx / len;
        double ny = dy / len;
        double nz = dz / len;
        return new Velocity(nx * speed, Math.max(ny * speed, minLift), nz * speed);
    }

    /** Gentle push when a player runs into the ball: it rolls ahead of the player's per-tick movement. */
    public static Velocity dribble(double playerDx, double playerDz, Config c) {
        double speed = Math.sqrt(playerDx * playerDx + playerDz * playerDz);
        if (speed < 0.02) return Velocity.ZERO;
        double factor = Math.min(c.dribbleSpeedFactor(), 0.6 / speed);
        return new Velocity(playerDx * factor, 0, playerDz * factor);
    }
}
