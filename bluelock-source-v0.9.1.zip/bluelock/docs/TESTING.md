# Testing the mod (Phase 5)

1. Get `bluelock-0.9.1.jar` (see BUILDING.md, "Getting the .jar without installing anything").
2. Install Minecraft Java 1.20.1 and Forge 47.4.0 (or newer 47.x), put the jar in the `mods` folder, start the game.
3. Create a Creative world (flat world is best), then:
   - `/bluelock pitch` builds a 61x37 pitch where you stand (grass stripes, white lines, two goals) and puts a ball at the centre. Stand on flat ground first; blocks above the pitch area are removed.
   - `/bluelock ball` puts a ball in front of you. The Football item is in the Tools & Utilities creative tab.
4. Play: run into the ball to dribble, right-click it to pass, left-click it to shoot.
5. Career commands: `/bluelock create striker competitive right Roy`, `/bluelock profile`, `/bluelock data`.

6. Play a match (Phase 6):
   - `/bluelock pitch` first, then `/bluelock match join home` (or `away`), then `/bluelock match start 3` (3 minutes; default 3).
   - The chat tells you where each goal is (X, Z). Home defends one goal and attacks the other.
   - Touch the ball to kick off; the clock runs only while the ball is in play.
   - Goals, own goals, ball out of play (put back on the line), kick-off after goals and full time are announced in chat.
   - `/bluelock match status` shows score, time and possession; `/bluelock match stop` ends it.
   - Alone? Join one side and shoot at the other goal. With a friend, join opposite sides.

7. Teams and formations (Phase 8):
   - `/bluelock match mode 5v5` picks the size (1v1, 2v2, 3v3, 4v4, 5v5, 7v7, 11v11). Default is 5v5.
   - `/bluelock team set home team_v` gives a side one of the five teams (V, W, X, Y, Z): their formation, style and rating.
   - `/bluelock team formation away 1_2_1` picks a formation that fits the mode; `/bluelock team show home` lists every slot (your name, or "(bot)" for slots the AI will fill later), plus rating and chemistry.
   - `/bluelock team slot 3` moves you to slot 3. Without it you are seated automatically by your archetype (a Striker gets ST, a Defender gets CB/LB/RB...).
   - At the start of a match and after every goal, joined players are moved to their formation spot, facing the other goal.

8. Gameplay update (carry, tackles, skills, bots, HUD, sound):
   - Walk into the ball and it sticks to your feet and travels with you. Run faster and it swings further ahead; weak dribblers can lose it when sprinting.
   - Keys (change them in Options > Controls > Blue Lock): R pass (auto-aims at the team-mate you look at), F shot (aim assist toward the goal), V slide tackle, Z feint, X burst dribble, C chain dribble, B sprint burst, G shoulder charge.
   - Tackle: left-click the player or bot who has the ball (standing tackle), or press V and slide into them. Better Tackling beats better Dribbling.
   - Skills: `/bluelock skills` lists them. Root skills (like Control) unlock by themselves when your stats allow it; others cost 1 skill point: `/bluelock skills unlock feint`. Skill points and development points come from levelling up (goals, tackles, passes, matches give XP). `/bluelock train passing` spends development points.
   - Bots: `/bluelock match start` fills every empty slot with a bot. `/bluelock match bots off` turns them off, `/bluelock match difficulty easy|normal|hard` changes their strength. Join a side first: `/bluelock match join home`.
   - The screen shows the score, clock, possession, your stamina, the key icons with cooldowns, and big GOAL / KICK-OFF / FULL TIME banners. Referee whistle, crowd cheer, kick, shot and tackle sounds are included.

Remove balls with `/kill @e[type=bluelock:ball]` and bots with `/kill @e[type=bluelock:bot]`.
