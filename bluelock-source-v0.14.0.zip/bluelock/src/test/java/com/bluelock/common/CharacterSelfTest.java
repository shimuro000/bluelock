package com.bluelock.common;

import com.bluelock.common.ai.*;
import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.team.TeamTactics;
import java.util.*;

/** Phase 5: Blue Lock characters, traits, sprint energy and speed. */
public final class CharacterSelfTest {
    private static int failures = 0;

    private static void check(boolean ok, String what) {
        System.out.println((ok ? "PASS " : "FAIL ") + what);
        if (!ok) failures++;
    }

    private static BotView view(Pos self, boolean hasBall, Pos ball, CharacterTraits t, Position pos, List<Pos> opp) {
        return new BotView(Side.HOME, pos, self, ball, hasBall, hasBall ? Side.HOME : null, hasBall ? self : null, 0, 60,
                TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED), new Pos(30, 18), List.of(new Pos(40, 10)), opp,
                PitchLayout.standard(), BallMotion.STILL, 0.2, 50, 50, t);
    }

    public static void main(String[] args) {
        roster();
        energy();
        speed();
        behaviour();
        System.out.println(failures == 0 ? "ALL CHARACTER TESTS PASSED" : failures + " FAILURE(S)");
        if (failures > 0) System.exit(1);
    }

    private static void roster() {
        check(Roster.all().size() >= 20, "roster has 20+ characters (" + Roster.all().size() + ")");
        Set<String> ids = new HashSet<>();
        boolean uniq = true;
        for (FootballCharacter c : Roster.all()) uniq &= ids.add(c.id());
        check(uniq, "character ids are unique");
        check(Roster.byId("isagi") != null && Roster.byId("isagi").teamId().equals("team_z"), "Isagi is on team Z");
        check(Roster.byId("chigiri").traits().speed() > Roster.byId("kunigami").traits().speed(), "Chigiri is faster than Kunigami");
        check(Roster.byId("baro").traits().ego() > Roster.byId("isagi").traits().ego(), "Baro has more ego than Isagi");
        Set<String> taken = new HashSet<>();
        FootballCharacter st = Roster.assign("team_z", Position.ST, taken);
        check(st != null && st.position() == Position.ST, "an ST slot gets the ST character");
        taken.add(st.id());
        FootballCharacter again = Roster.assign("team_z", Position.ST, taken);
        check(again == null || !again.id().equals(st.id()), "a character is not given out twice");
        check(Roster.assign("team_z", Position.GK, new HashSet<>()).position() == Position.GK, "a GK slot gets the keeper");
        check(Roster.assign("nope", Position.ST, new HashSet<>()) == null, "unknown team gives no character");
        FootballCharacter isagi = Roster.byId("isagi");
        int look = Roster.lookOf(isagi, 0);
        check(Roster.byLook(look) == isagi && Roster.hairForLook(look).equals(isagi.hair()), "look code leads back to the character and his hair");
        check(Roster.hairForLook(-5).equals(Roster.hairForLook(-5)) && Roster.byLook(-5) == null, "nameless bots get the same hair on every client");
        check(BotStats.forCharacter(60, Roster.byId("chigiri")).base(Stat.TOP_SPEED) > BotStats.forRating(60, Position.RW).base(Stat.TOP_SPEED), "fast characters get speed stats");
    }

    private static void energy() {
        BotEnergy e = new BotEnergy(10);
        check(e.percent() == 100 && !e.isTired(), "energy starts full");
        int ticks = 0;
        while (!e.isTired() && ticks < 1000) { e.update(true, 2); ticks += 2; }
        check(ticks >= 190 && ticks <= 210, "10 s of sprint empties it (" + ticks + " ticks)");
        check(!e.update(true, 2), "a tired bot cannot sprint");
        check(e.speedFactor() < 1.0, "a tired bot jogs slower");
        for (int i = 0; i < 400 && e.isTired(); i++) e.update(false, 2);
        check(!e.isTired() && e.percent() >= BotEnergy.RECOVER_FROM_TIRED, "rest brings it back");
        check(e.update(true, 2), "after resting it can sprint again");
        BotEnergy big = new BotEnergy(20), small = new BotEnergy(5);
        int bigTicks = 0, smallTicks = 0;
        while (!big.isTired() && bigTicks < 2000) { big.update(true, 2); bigTicks += 2; }
        while (!small.isTired() && smallTicks < 2000) { small.update(true, 2); smallTicks += 2; }
        check(smallTicks < bigTicks, "stamina decides how long a sprint lasts");
    }

    private static void speed() {
        double jog = BotSpeed.jog(60, BotDifficulty.NORMAL.speedFactor(), CharacterTraits.NEUTRAL);
        check(jog > 0.13, "a jogging bot is faster than a sprinting player (" + String.format("%.3f", jog) + ")");
        double mult = BotSpeed.sprintMultiplier(jog, CharacterTraits.NEUTRAL);
        check(jog * mult > jog * 1.2 && jog * mult <= BotSpeed.SPRINT_CAP + 1e-9, "sprint is much faster but capped");
        CharacterTraits chigiri = Roster.byId("chigiri").traits();
        double j2 = BotSpeed.jog(90, BotDifficulty.PRO.speedFactor(), chigiri);
        check(j2 * BotSpeed.sprintMultiplier(j2, chigiri) <= BotSpeed.SPRINT_CAP + 1e-9, "even the fastest bot respects the cap");
        check(j2 > jog, "a fast character on PRO outruns a normal bot");
        check(AnimLogicProbe.sprintShownOnlyWhenFast(), "bots show the sprint animation only at sprint speed");
    }

    private static void behaviour() {
        PitchLayout l = PitchLayout.standard();
        // chasing a far ball: sprint
        BotView chase = new BotView(Side.HOME, Position.CM, new Pos(10, 18), new Pos(30, 18), false, null, null, 0, 60,
                TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED), new Pos(20, 18), List.of(), List.of(), l);
        BotDecision d = BotBrain.decide(chase);
        check(d.intent() == Intent.CHASE_BALL && d.sprint(), "chasing a far ball means sprinting");
        BotView close = new BotView(Side.HOME, Position.CM, new Pos(29, 18), new Pos(30, 18), false, null, null, 0, 60,
                TeamTactics.forPlaystyle(com.bluelock.common.content.Playstyle.BALANCED), new Pos(20, 18), List.of(), List.of(), l);
        check(!BotBrain.decide(close).sprint(), "a close ball needs no sprint");
        // ego: same spot, only the traits differ
        CharacterTraits egoist = new CharacterTraits(1, 1.35, 10, 100, 50, 50, 50);
        CharacterTraits team = new CharacterTraits(1, 1.35, 10, 10, 50, 50, 50);
        Pos self = new Pos(34, 18);   // 27 from the goal at u = 61
        BotDecision a = BotBrain.decide(view(self, true, self, egoist, Position.ST, List.of()));
        BotDecision b = BotBrain.decide(view(self, true, self, team, Position.ST, List.of()));
        Pos nearShot = new Pos(45, 18);
        boolean egoShoots = BotBrain.decide(view(nearShot, true, nearShot, egoist, Position.ST, List.of())).intent() == Intent.SHOOT;
        check(a.intent() != Intent.SHOOT && b.intent() != Intent.SHOOT && egoShoots, "an egoist shoots from range (sanity)");
        Pos mid = new Pos(40, 18);   // 21 from goal: only the egoist is in range at rating 60
        boolean egoMid = BotBrain.decide(view(mid, true, mid, egoist, Position.ST, List.of())).intent() == Intent.SHOOT;
        boolean teamMid = BotBrain.decide(view(mid, true, mid, team, Position.ST, List.of())).intent() == Intent.SHOOT;
        check(egoMid && !teamMid, "high ego shoots from further out than low ego");
        // old constructors still work
        check(CharacterTraits.forPosition(Position.GK).speed() < CharacterTraits.forPosition(Position.RW).speed(), "wingers are faster than keepers");
        check(new CharacterTraits(9, 9, 99, 500, -5, 0, 0).speed() <= 1.3, "traits are clamped");
    }

    /** Small helper so the test does not need the anim package imports above. */
    private static final class AnimLogicProbe {
        static boolean sprintShownOnlyWhenFast() {
            return com.bluelock.common.anim.AnimLogic.botLocomotion(0.30, false, false).equals("run")
                    && com.bluelock.common.anim.AnimLogic.botLocomotion(0.45, false, false).equals("sprint")
                    && com.bluelock.common.anim.AnimLogic.botLocomotion(0.45, true, false).equals("dribble_sprint")
                    && com.bluelock.common.anim.AnimLogic.botLocomotion(0.10, false, false).equals("walk");
        }
    }
}
