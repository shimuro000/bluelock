package com.bluelock.forge.anim;

import com.bluelock.common.ai.Roster;
import com.bluelock.forge.HairDraw;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.GeoRenderLayer;

/**
 * Puts the 3D hair on the head bone of the animated bot, so it follows every animation. Client only.
 * renderForBone is deliberately declared without @Override: if a GeckoLib version changed its signature the hair
 * would just not show, instead of the whole build failing.
 */
public class HairGeoLayer extends GeoRenderLayer<GeoBotEntity> {
    /** Head-model pixels start at the neck; the geo head cube starts 24 pixels above the feet. */
    private static final float NECK_HEIGHT = 24.0F;

    public HairGeoLayer(GeoRenderer<GeoBotEntity> renderer) {
        super(renderer);
    }

    public void renderForBone(PoseStack poseStack, GeoBotEntity bot, GeoBone bone, RenderType renderType,
                              MultiBufferSource bufferSource, VertexConsumer buffer, float partialTick,
                              int packedLight, int packedOverlay) {
        if (!"head".equals(bone.getName()) || bot.isInvisible()) {
            return;
        }
        poseStack.pushPose();
        poseStack.translate(0.0F, NECK_HEIGHT / 16.0F, 0.0F);
        poseStack.scale(1.0F / 16.0F, -1.0F / 16.0F, 1.0F / 16.0F);
        HairDraw.draw(poseStack, bufferSource, Roster.hairForLook(bot.look()), packedLight);
        poseStack.popPose();
    }
}
