package com.bluelock.forge.anim;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Draws the animated bot. Client only. */
public class GeoBotRenderer extends GeoEntityRenderer<GeoBotEntity> {
    public GeoBotRenderer(EntityRendererProvider.Context context) {
        super(context, new GeoBotModel());
        this.shadowRadius = 0.5F;
        addRenderLayer(new HairGeoLayer(this));
    }
}
