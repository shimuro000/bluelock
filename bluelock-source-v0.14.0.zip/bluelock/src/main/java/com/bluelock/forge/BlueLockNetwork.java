package com.bluelock.forge;

import com.bluelock.common.BlueLockConstants;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** The channel the mod uses to talk between client and server. */
public final class BlueLockNetwork {
    private static final String PROTOCOL = "3";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(BlueLockConstants.MOD_ID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private BlueLockNetwork() {
    }

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, ActionPacket.class, ActionPacket::encode, ActionPacket::decode, ActionPacket::handle);
        CHANNEL.registerMessage(id++, HudPacket.class, HudPacket::encode, HudPacket::decode, HudPacket::handle);
        CHANNEL.registerMessage(id++, MenuRequestPacket.class, MenuRequestPacket::encode, MenuRequestPacket::decode, MenuRequestPacket::handle);
        CHANNEL.registerMessage(id++, MenuCommandPacket.class, MenuCommandPacket::encode, MenuCommandPacket::decode, MenuCommandPacket::handle);
        CHANNEL.registerMessage(id++, CreatePacket.class, CreatePacket::encode, CreatePacket::decode, CreatePacket::handle);
        CHANNEL.registerMessage(id++, PlayerAnimPacket.class, PlayerAnimPacket::encode, PlayerAnimPacket::decode, PlayerAnimPacket::handle);
        CHANNEL.registerMessage(id++, MenuStatePacket.class, MenuStatePacket::encode, MenuStatePacket::decode, MenuStatePacket::handle);
        CHANNEL.registerMessage(id++, SkillFxPacket.class, SkillFxPacket::encode, SkillFxPacket::decode, SkillFxPacket::handle);
        CHANNEL.registerMessage(id++, HairSyncPacket.class, HairSyncPacket::encode, HairSyncPacket::decode, HairSyncPacket::handle);
        CHANNEL.registerMessage(id++, HairUpdatePacket.class, HairUpdatePacket::encode, HairUpdatePacket::decode, HairUpdatePacket::handle);
    }

    public static void sendToPlayer(ServerPlayer player, Object message) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), message);
    }
}
