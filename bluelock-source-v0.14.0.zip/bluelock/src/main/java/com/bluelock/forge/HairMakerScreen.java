package com.bluelock.forge;

import com.bluelock.common.appearance.HairDesign;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;

/**
 * The 3D hair maker (client only): pick one of the style presets, shape it with sliders (top volume, fringe, sides,
 * back, spikes, fluff, ponytail), colour the hair and its tips, and watch the result on your own character, which you
 * can turn by dragging. The look is built from the numbers in {@link HairDesign}; nothing here touches the world.
 */
public class HairMakerScreen extends Screen {
    private static final String[] SLIDER_KEYS = {"top", "front", "sides", "back", "spikes", "fluff", "tail"};

    private final Screen parent;
    private final Consumer<HairDesign> onDone;
    private HairDesign design;
    private boolean editingTip;
    private int scroll;
    private int contentBottom;
    private final List<AbstractWidget> scrolling = new ArrayList<>();
    private final List<Integer> originalY = new ArrayList<>();
    private int ticks;

    public HairMakerScreen(Screen parent, HairDesign start, Consumer<HairDesign> onDone) {
        super(Component.translatable("bluelock.hair.title"));
        this.parent = parent;
        this.design = start == null ? HairDesign.standard() : start;
        this.onDone = onDone;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void tick() {
        ticks++;
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);   // leaving without "done" keeps the old hair
    }

    @Override
    public void removed() {
        ClientHair.preview = null;
        ClientHair.previewSpin = 0.0F;
    }

    private <T extends AbstractWidget> T scrolled(T widget) {
        scrolling.add(widget);
        originalY.add(widget.getY());
        return addRenderableWidget(widget);
    }

    private int viewTop() {
        return 56;
    }

    private int viewBottom() {
        return height - 30;
    }

    private int maxScroll() {
        return Math.max(0, contentBottom - viewBottom() + 6);
    }

    private void applyScroll() {
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
        for (int i = 0; i < scrolling.size(); i++) {
            AbstractWidget w = scrolling.get(i);
            int y = originalY.get(i) - scroll;
            w.setY(y);
            w.visible = y >= viewTop() && y + w.getHeight() <= viewBottom();
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (maxScroll() > 0 && mouseX > width / 2.0) {
            scroll -= (int) (delta * 24);
            applyScroll();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    /** Dragging on the left half turns the character. */
    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (button == 0 && mouseX < width / 2.0 && mouseY > viewTop() && mouseY < height - 30) {
            ClientHair.previewSpin += (float) dragX * 1.6F;
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    private void change(HairDesign newDesign) {
        design = newDesign;
        ClientHair.preview = design;
    }

    private int[] sliderValues() {
        return new int[] {design.top(), design.front(), design.sides(), design.back(), design.spikes(), design.fluff(), design.tail()};
    }

    @Override
    protected void init() {
        scrolling.clear();
        originalY.clear();
        ClientHair.preview = design;
        int rightX = width / 2 + 10;
        int w = Math.min(width / 2 - 30, 230);
        int y = viewTop() + 4;

        // style: previous / name (click = next) / next
        scrolled(new BlueButton(rightX, y, 24, 20, Component.literal("<"), b -> {
            change(design.withStyle(design.style() - 1));
            rebuildWidgets();
        }, BlueUi.CYAN));
        scrolled(new BlueButton(rightX + 26, y, w - 52, 20,
                Component.translatable("bluelock.hair.style", Component.translatable("bluelock.hair.style." + HairDesign.STYLE_NAMES[design.style()])),
                b -> {
                    change(design.withStyle(design.style() + 1));
                    rebuildWidgets();
                }, BlueUi.GOLD));
        scrolled(new BlueButton(rightX + w - 24, y, 24, 20, Component.literal(">"), b -> {
            change(design.withStyle(design.style() + 1));
            rebuildWidgets();
        }, BlueUi.CYAN));
        y += 26;

        int[] values = sliderValues();
        for (int i = 0; i < SLIDER_KEYS.length; i++) {
            int index = i;
            scrolled(new ValueSlider(rightX, y, w, "bluelock.hair." + SLIDER_KEYS[i], values[i], 100, v -> {
                int[] n = sliderValues();
                n[index] = v;
                change(design.withSliders(n[0], n[1], n[2], n[3], n[4], n[5], n[6]));
            }));
            y += 21;
        }
        y += 2;

        int third = (w - 4) / 3;
        scrolled(new BlueButton(rightX, y, third, 18, Component.translatable("bluelock.hair.reshuffle"),
                b -> change(design.withSeed(new Random().nextInt(HairDesign.SEED_MAX + 1))), BlueUi.CYAN));
        scrolled(new BlueButton(rightX + third + 2, y, third, 18, Component.translatable("bluelock.hair.random"), b -> {
            change(HairDesign.random(new Random()));
            rebuildWidgets();
        }, BlueUi.CYAN));
        scrolled(new BlueButton(rightX + 2 * (third + 2), y, third, 18, Component.translatable("bluelock.hair.reset"), b -> {
            change(design.withStyle(design.style()).withSeed(0));
            rebuildWidgets();
        }, BlueUi.RED));
        y += 26;

        // colours
        scrolled(new BlueButton(rightX, y, w, 20,
                Component.translatable(editingTip ? "bluelock.hair.editing_tip" : "bluelock.hair.editing_main"),
                b -> {
                    editingTip = !editingTip;
                    rebuildWidgets();
                }, editingTip ? BlueUi.GOLD : BlueUi.CYAN));
        y += 24;
        int columns = 8;
        int cell = Math.min(26, w / columns);
        int target = editingTip ? design.tipColor() : design.color();
        for (int i = 0; i < HairDesign.SWATCHES.length; i++) {
            int rgb = HairDesign.SWATCHES[i];
            scrolled(new Swatch(rightX + (i % columns) * cell, y + (i / columns) * cell, cell - 2, rgb, rgb == target, () -> {
                pickColor(rgb);
                rebuildWidgets();
            }));
        }
        y += ((HairDesign.SWATCHES.length + columns - 1) / columns) * cell + 4;

        String[] channel = {"red", "green", "blue"};
        int[] shift = {16, 8, 0};
        for (int i = 0; i < 3; i++) {
            int sh = shift[i];
            scrolled(new ValueSlider(rightX, y, w, "bluelock.hair." + channel[i], (target >> sh) & 255, 255, v -> {
                int current = editingTip ? design.tipColor() : design.color();
                int next = (current & ~(255 << sh)) | (v << sh);
                setColor(next);
            }));
            y += 21;
        }
        scrolled(new ValueSlider(rightX, y, w, "bluelock.hair.tip_amount", design.tipAmount(), 100, v -> {
            int tipColor = v > 0 && design.tipAmount() == 0 && design.tipColor() == design.color()
                    ? HairDesign.SWATCHES[14] : design.tipColor();   // first time tips are switched on: start with the Blue Lock cyan
            change(design.withColors(design.color(), tipColor, v));
        }));
        y += 24;
        contentBottom = y;
        applyScroll();

        // fixed buttons
        addRenderableWidget(new BlueButton(rightX, height - 24, w / 2 - 2, 18, Component.translatable("bluelock.hair.done"), b -> {
            onDone.accept(design);
            minecraft.setScreen(parent);
        }, BlueUi.GREEN));
        addRenderableWidget(new BlueButton(rightX + w / 2 + 2, height - 24, w / 2 - 2, 18, Component.translatable("bluelock.hair.cancel"),
                b -> minecraft.setScreen(parent), BlueUi.RED));
        int px = width / 4;
        addRenderableWidget(new BlueButton(px - 66, height - 24, 40, 18, Component.translatable("bluelock.hair.view_front"),
                b -> ClientHair.previewSpin = 0.0F, BlueUi.BLUE));
        addRenderableWidget(new BlueButton(px - 20, height - 24, 40, 18, Component.translatable("bluelock.hair.view_side"),
                b -> ClientHair.previewSpin = 90.0F, BlueUi.BLUE));
        addRenderableWidget(new BlueButton(px + 26, height - 24, 40, 18, Component.translatable("bluelock.hair.view_back"),
                b -> ClientHair.previewSpin = 180.0F, BlueUi.BLUE));
    }

    /** A swatch was clicked: it becomes the main colour or the tip colour. */
    private void pickColor(int rgb) {
        setColor(rgb);
    }

    private void setColor(int rgb) {
        if (editingTip) {
            change(design.withColors(design.color(), rgb, design.tipAmount() == 0 ? 40 : design.tipAmount()));
        } else {
            int tip = design.tipAmount() == 0 ? rgb : design.tipColor();
            change(design.withColors(rgb, tip, design.tipAmount()));
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        BlueUi.background(g, width, height);
        BlueUi.title(g, font, width / 2 - 70, 12, 2.5F, Component.translatable("bluelock.hair.title"), BlueUi.WHITE);
        BlueUi.slogan(g, font, width / 2, 40, ticks);

        BlueUi.panel(g, 20, 52, width / 2 - 30, height - 82);
        int px = width / 4;
        if (minecraft != null && minecraft.player != null) {
            int scale = Math.max(30, Math.min(70, (height - 140) / 2));
            g.pose().pushPose();
            g.pose().translate(px, 0.0F, 50.0F);
            g.pose().mulPose(Axis.YP.rotationDegrees(ClientHair.previewSpin));   // turn the character around the vertical line through it
            g.pose().translate(-px, 0.0F, -50.0F);
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, px, height - 52, scale, 0.0F, 0.0F, minecraft.player);
            g.pose().popPose();
        }
        g.drawCenteredString(font, Component.translatable("bluelock.hair.drag_hint"), px, 60, BlueUi.GREY);

        if (maxScroll() > 0) {
            int trackH = viewBottom() - viewTop();
            int thumbH = Math.max(14, trackH * trackH / (trackH + maxScroll()));
            int thumbY = viewTop() + (trackH - thumbH) * scroll / maxScroll();
            g.fill(width - 8, viewTop(), width - 5, viewBottom(), 0x55000000);
            g.fill(width - 8, thumbY, width - 5, thumbY + thumbH, BlueUi.CYAN);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    // ---------- small widgets ----------

    /** A slider from 0 to max that calls onChange with the new whole number while it is dragged. */
    private static final class ValueSlider extends AbstractSliderButton {
        private final String labelKey;
        private final int max;
        private final IntConsumer onChange;

        ValueSlider(int x, int y, int w, String labelKey, int start, int max, IntConsumer onChange) {
            super(x, y, w, 18, Component.empty(), max == 0 ? 0.0 : (double) start / max);
            this.labelKey = labelKey;
            this.max = max;
            this.onChange = onChange;
            updateMessage();
        }

        private int current() {
            return (int) Math.round(value * max);
        }

        @Override
        protected void updateMessage() {
            setMessage(Component.translatable(labelKey).append(": " + current()));
        }

        @Override
        protected void applyValue() {
            onChange.accept(current());
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            int x = getX();
            int y = getY();
            g.fill(x, y, x + width, y + height, 0xDD0F2A5C);
            int filled = (int) Math.round(value * (width - 3));
            g.fill(x + 1, y + 1, x + 1 + filled, y + height - 1, isHoveredOrFocused() ? 0xCC3CC8FF : 0xAA1E6BFF);
            g.fill(x + 1 + filled, y, x + 3 + filled, y + height, BlueUi.WHITE);
            g.drawCenteredString(Minecraft.getInstance().font, getMessage(), x + width / 2, y + (height - 8) / 2, BlueUi.WHITE);
        }
    }

    /** A small square showing one colour. */
    private static final class Swatch extends AbstractWidget {
        private final int rgb;
        private final boolean selected;
        private final Runnable onPick;

        Swatch(int x, int y, int size, int rgb, boolean selected, Runnable onPick) {
            super(x, y, size, size, Component.empty());
            this.rgb = rgb;
            this.selected = selected;
            this.onPick = onPick;
        }

        @Override
        public void onClick(double mouseX, double mouseY) {
            onPick.run();
        }

        @Override
        protected void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            int border = selected ? BlueUi.WHITE : isHoveredOrFocused() ? BlueUi.CYAN : 0xFF0B1E45;
            g.fill(getX(), getY(), getX() + width, getY() + height, border);
            g.fill(getX() + 2, getY() + 2, getX() + width - 2, getY() + height - 2, 0xFF000000 | rgb);
        }

        @Override
        protected void updateWidgetNarration(NarrationElementOutput output) {
        }
    }
}
