package com.bluelock.forge;

import com.bluelock.common.content.QuestDefinition;
import com.bluelock.common.content.QuestType;
import com.bluelock.common.content.SkillCategory;
import com.bluelock.common.content.SkillDefinition;
import com.bluelock.common.persistence.ProfileCodec;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.stats.Stat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

/** What the menu knows. Plain data, no client-only classes, filled by MenuStatePacket. */
public final class ClientMenuState {
    public static int version;
    public static boolean received;
    public static boolean hasProfile;
    public static PlayerProfile profile;
    public static long xpNeeded = 100;
    public static String rollFoot = "RIGHT";
    public static String rollTalent = "NORMAL";
    public static final List<SkillDefinition> SKILLS = new ArrayList<>();
    public static final List<QuestDefinition> QUESTS = new ArrayList<>();
    public static String mode = "5v5";
    public static boolean bots = true;
    public static String difficulty = "normal";
    public static boolean pitch;
    public static boolean practice;
    public static String wantedSize = "standard";
    public static String pitchSize = "";
    public static boolean matchActive;
    public static int homeGoals;
    public static int awayGoals;
    public static int side = -1;
    public static String teamHome = "";
    public static String teamAway = "";
    private static boolean autoOpenPending;
    private static boolean autoOpenDone;

    private ClientMenuState() {
    }

    /** True once, when the server says there is no character yet: the creation screen should open by itself. */
    public static boolean consumeAutoOpen() {
        if (autoOpenPending) {
            autoOpenPending = false;
            return true;
        }
        return false;
    }

    public static void update(CompoundTag t) {
        hasProfile = t.getBoolean("hasProfile");
        profile = null;
        if (hasProfile && t.contains("profile")) {
            try {
                profile = ProfileCodec.fromMap(NbtMapConverter.fromTag(t.getCompound("profile")));
            } catch (RuntimeException e) {
                hasProfile = false;
            }
            xpNeeded = Math.max(1, t.getLong("xpNeeded"));
        } else {
            rollFoot = t.getString("rollFoot");
            rollTalent = t.getString("rollTalent");
        }
        SKILLS.clear();
        ListTag skills = t.getList("skills", Tag.TAG_COMPOUND);
        for (int i = 0; i < skills.size(); i++) {
            CompoundTag c = skills.getCompound(i);
            Map<Stat, Integer> req = new EnumMap<>(Stat.class);
            CompoundTag reqTag = c.getCompound("req");
            for (String key : reqTag.getAllKeys()) {
                try {
                    req.put(Stat.valueOf(key), reqTag.getInt(key));
                } catch (IllegalArgumentException ignored) {
                    // unknown stat name: skip it
                }
            }
            String requires = c.getString("requires");
            List<String> parents = requires.isEmpty() ? List.of() : Arrays.asList(requires.split(","));
            try {
                SKILLS.add(new SkillDefinition(c.getString("id"), SkillCategory.valueOf(c.getString("category")), Map.copyOf(req),
                        List.copyOf(parents), c.getInt("cooldown"), c.getInt("stamina"), 0, 5));
            } catch (IllegalArgumentException ignored) {
                // unknown category: skip the skill
            }
        }
        QUESTS.clear();
        ListTag quests = t.getList("quests", Tag.TAG_COMPOUND);
        for (int i = 0; i < quests.size(); i++) {
            CompoundTag c = quests.getCompound(i);
            try {
                QUESTS.add(new QuestDefinition(c.getString("id"), QuestType.valueOf(c.getString("type")), c.getInt("target"),
                        c.getInt("xp"), c.getInt("sp"), c.getInt("dp")));
            } catch (IllegalArgumentException ignored) {
                // unknown quest type: skip
            }
        }
        mode = t.getString("mode");
        bots = t.getBoolean("bots");
        difficulty = t.getString("difficulty");
        pitch = t.getBoolean("pitch");
        practice = t.getBoolean("practice");
        wantedSize = t.getString("wantedSize");
        pitchSize = t.getString("pitchSize");
        matchActive = t.getBoolean("active");
        homeGoals = t.getInt("home");
        awayGoals = t.getInt("away");
        side = t.getInt("side");
        teamHome = t.getString("teamHome");
        teamAway = t.getString("teamAway");
        received = true;
        if (!hasProfile && !autoOpenDone) {
            autoOpenDone = true;
            autoOpenPending = true;
        }
        version++;
    }
}
