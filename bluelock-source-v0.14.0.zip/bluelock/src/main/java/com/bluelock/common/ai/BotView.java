package com.bluelock.common.ai;

import com.bluelock.common.content.Position;
import com.bluelock.common.match.Side;
import com.bluelock.common.pitch.PitchLayout;
import com.bluelock.common.team.TeamTactics;
import java.util.List;

/**
 * Everything one bot knows when it makes a decision. possession is the side of the player who carries the ball
 * (null when the ball is loose). chaseRank is 0 for the outfield player of the bot's team closest to the ball.
 * traits is how this bot's character plays; the shorter constructors give an average player.
 */
public record BotView(Side side, Position position, Pos self, Pos ball, boolean selfHasBall, Side possession,
                      Pos carrier, int chaseRank, int rating, TeamTactics tactics, Pos baseSpot,
                      List<Pos> mates, List<Pos> opponents, PitchLayout layout,
                      BallMotion ballMotion, double ballHeight, int reaction, int jump, CharacterTraits traits) {

    /** Without character traits: an average player. */
    public BotView(Side side, Position position, Pos self, Pos ball, boolean selfHasBall, Side possession,
                   Pos carrier, int chaseRank, int rating, TeamTactics tactics, Pos baseSpot,
                   List<Pos> mates, List<Pos> opponents, PitchLayout layout,
                   BallMotion ballMotion, double ballHeight, int reaction, int jump) {
        this(side, position, self, ball, selfHasBall, possession, carrier, chaseRank, rating, tactics, baseSpot,
                mates, opponents, layout, ballMotion, ballHeight, reaction, jump, CharacterTraits.NEUTRAL);
    }

    /** For callers that do not know the ball's motion (the ball counts as standing still). */
    public BotView(Side side, Position position, Pos self, Pos ball, boolean selfHasBall, Side possession,
                   Pos carrier, int chaseRank, int rating, TeamTactics tactics, Pos baseSpot,
                   List<Pos> mates, List<Pos> opponents, PitchLayout layout) {
        this(side, position, self, ball, selfHasBall, possession, carrier, chaseRank, rating, tactics, baseSpot,
                mates, opponents, layout, BallMotion.STILL, 0.2, 50, 50, CharacterTraits.NEUTRAL);
    }
}
