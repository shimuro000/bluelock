package com.bluelock.common.ai;

import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.content.Position;

/**
 * A named Blue Lock footballer that a bot can play as: a position, a rating bonus, how he plays and his hair.
 * Squads are a first version; they are meant to be refined in the story phase.
 */
public record FootballCharacter(String id, String name, String teamId, Position position, int ratingBonus,
                                CharacterTraits traits, HairDesign hair) {

    /** Language key of the display name is not needed: names are proper names and shown as they are. */
    public String displayName() {
        return name;
    }
}
