package com.bluelock.common.ai;

import com.bluelock.common.appearance.HairDesign;
import com.bluelock.common.content.Position;
import java.util.ArrayList;
import java.util.List;

/**
 * The Blue Lock characters bots can play as, grouped by team (team_v, team_w, team_x, team_y, team_z).
 * Pure data and a small assignment rule, so it can be tested without Minecraft.
 */
public final class Roster {
    private static final List<FootballCharacter> ALL = new ArrayList<>();

    private static CharacterTraits t(double speed, double boost, double secs, int ego, int cre, int agg, int work) {
        return new CharacterTraits(speed, boost, secs, ego, cre, agg, work);
    }

    private static void add(String id, String name, String team, Position pos, int bonus, CharacterTraits tr, int style, int color) {
        ALL.add(new FootballCharacter(id, name, team, pos, bonus, tr, HairDesign.preset(style, color)));
    }

    static {
        // Team Z
        add("isagi", "Yoichi Isagi", "team_z", Position.CAM, 6, t(1.00, 1.38, 12, 55, 70, 50, 85), 1, 0x1B1B1F);
        add("bachira", "Meguru Bachira", "team_z", Position.LW, 8, t(1.06, 1.40, 10, 55, 100, 35, 55), 3, 0x3B2A1E);
        add("kunigami", "Rensuke Kunigami", "team_z", Position.ST, 6, t(1.03, 1.38, 12, 50, 35, 70, 70), 2, 0x1B1B1F);
        add("chigiri", "Hyoma Chigiri", "team_z", Position.RW, 8, t(1.25, 1.55, 8, 40, 45, 35, 65), 7, 0xB3261E);
        add("raichi", "Jingo Raichi", "team_z", Position.CF, 3, t(1.00, 1.36, 9, 80, 30, 60, 50), 2, 0x1B1B1F);
        add("gagamaru", "Gagamaru", "team_z", Position.GK, 5, t(0.97, 1.28, 8, 25, 15, 45, 40), 0, 0x3B2A1E);
        add("kuon", "Kuon Wataru", "team_z", Position.CDM, 3, t(1.00, 1.34, 14, 30, 35, 60, 80), 4, 0xF0E8C8);
        add("igarashi", "Gurimu Igarashi", "team_z", Position.CB, 2, t(0.98, 1.32, 12, 25, 25, 75, 70), 0, 0x3B2A1E);
        // Team V
        add("baro", "Shoei Baro", "team_v", Position.ST, 9, t(1.10, 1.45, 11, 100, 40, 85, 65), 2, 0x1B1B1F);
        add("nagi", "Seishiro Nagi", "team_v", Position.CF, 9, t(1.02, 1.38, 8, 60, 90, 20, 25), 5, 0xF4F4F4);
        add("reo", "Reo Mikage", "team_v", Position.RW, 8, t(1.02, 1.38, 11, 55, 75, 45, 75), 6, 0x7B3FBF);
        add("hiori", "Yo Hiori", "team_v", Position.CM, 6, t(1.00, 1.36, 12, 35, 55, 50, 85), 1, 0x1B1B1F);
        add("aryu", "Jyubei Aryu", "team_v", Position.CAM, 6, t(1.02, 1.38, 11, 70, 60, 50, 70), 6, 0x5E3BE0);
        add("nanase", "Nanase Nijiro", "team_v", Position.LW, 5, t(1.03, 1.40, 10, 50, 60, 40, 65), 3, 0xD9B45A);
        // Team W
        add("rin", "Rin Itoshi", "team_w", Position.CM, 11, t(1.05, 1.42, 13, 85, 85, 65, 75), 6, 0x1B1B1F);
        add("shidou", "Ryusei Shidou", "team_w", Position.ST, 10, t(1.10, 1.45, 10, 80, 100, 55, 60), 9, 0xB3261E);
        add("kaiser", "Michael Kaiser", "team_w", Position.CF, 12, t(1.04, 1.40, 10, 95, 75, 50, 55), 6, 0x8B5E3C);
        add("sae", "Sae Itoshi", "team_w", Position.CAM, 14, t(1.06, 1.42, 12, 75, 90, 55, 80), 6, 0x1B1B1F);
        add("noa", "Noel Noa", "team_w", Position.CM, 14, t(1.06, 1.42, 15, 55, 80, 70, 95), 1, 0xF0E8C8);
        // Team X
        add("otoya", "Eita Otoya", "team_x", Position.LM, 4, t(1.05, 1.40, 14, 40, 55, 50, 85), 3, 0x1FA89A);
        add("tokimitsu", "Aoshi Tokimitsu", "team_x", Position.CM, 4, t(1.00, 1.36, 13, 30, 50, 40, 85), 1, 0x1B1B1F);
        add("aiku", "Oliver Aiku", "team_x", Position.RB, 5, t(1.00, 1.36, 13, 30, 40, 65, 80), 1, 0x2F6BFF);
        // Team Y
        add("ikki", "Ikki Niko", "team_y", Position.CB, 8, t(1.00, 1.36, 13, 35, 45, 85, 75), 2, 0x8A8F98);
        add("zantetsu", "Zantetsu Tsurugi", "team_y", Position.LB, 3, t(1.00, 1.34, 12, 25, 30, 75, 70), 0, 0x1B1B1F);
    }

    private Roster() {
    }

    public static List<FootballCharacter> all() {
        return List.copyOf(ALL);
    }

    public static List<FootballCharacter> ofTeam(String teamId) {
        List<FootballCharacter> out = new ArrayList<>();
        for (FootballCharacter c : ALL) {
            if (c.teamId().equals(teamId)) out.add(c);
        }
        return out;
    }

    public static FootballCharacter byId(String id) {
        for (FootballCharacter c : ALL) {
            if (c.id().equals(id)) return c;
        }
        return null;
    }

    /**
     * Picks the character for one slot of a team. Characters are used at most once ({@code taken} holds the ids
     * already given out). A character who plays exactly this position goes first, then one in the same line
     * (goal, defence, midfield, attack). Returns null when the team has nobody fitting: the bot is then a nameless
     * player with traits from its position.
     */
    public static FootballCharacter assign(String teamId, Position slotPosition, java.util.Set<String> taken) {
        List<FootballCharacter> team = ofTeam(teamId);
        for (FootballCharacter c : team) {
            if (!taken.contains(c.id()) && c.position() == slotPosition) return c;
        }
        for (FootballCharacter c : team) {
            if (!taken.contains(c.id()) && line(c.position()) == line(slotPosition)) return c;
        }
        return null;
    }

    /** Look codes are synced to clients as one number: 0 or more = index in the roster, negative = a nameless bot. */
    public static int lookOf(FootballCharacter c, int fallbackSeed) {
        if (c == null) return -1 - Math.abs(fallbackSeed % 100000);
        return ALL.indexOf(c);
    }

    public static FootballCharacter byLook(int look) {
        return look >= 0 && look < ALL.size() ? ALL.get(look) : null;
    }

    /** The hair of a look: the character's own, or a made-up one from the seed (the same on every client). */
    public static HairDesign hairForLook(int look) {
        FootballCharacter c = byLook(look);
        if (c != null) return c.hair();
        return HairDesign.random(new java.util.Random(look * 7919L + 13));
    }

    private static int line(Position p) {
        return switch (p) {
            case GK -> 0;
            case CB, LB, RB, LWB, RWB, CDM -> 1;
            case CM, CAM, LM, RM -> 2;
            case LW, RW, ST, CF -> 3;
        };
    }
}
