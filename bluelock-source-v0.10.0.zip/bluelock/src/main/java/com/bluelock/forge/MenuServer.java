package com.bluelock.forge;

import com.bluelock.common.content.QuestDefinition;
import com.bluelock.common.content.SkillDefinition;
import com.bluelock.common.persistence.ProfileCodec;
import com.bluelock.common.profile.CharacterRoll;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.Progression;
import com.bluelock.common.stats.Stat;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerPlayer;

/** Server side of the menu: sends everything the screens need, and runs the menu's button presses as /bluelock commands. */
public final class MenuServer {
    /** Only these /bluelock commands may be sent from a menu button. */
    private static final Pattern ALLOWED = Pattern.compile(
            "^(pitch|ball|quests|profile|match [a-z0-9_ ]{1,40}|team [a-z0-9_ ]{1,40}|skills|skills unlock [a-z0-9_]{1,40}|train [a-z0-9_]{1,40}( up| [0-9]{1,3})?)$");

    private MenuServer() {
    }

    public static void runMenuCommand(ServerPlayer player, String command) {
        if (command == null || !ALLOWED.matcher(command).matches()) {
            return;
        }
        run(player, command);
    }

    /** Character creation from the menu. The name is cleaned up; the command itself validates it again. */
    public static void create(ServerPlayer player, String archetype, String personality, String position, String name) {
        String cleanName = name == null ? "" : name.replaceAll("[\\r\\n]", " ").trim();
        if (!archetype.matches("[a-z_]{1,20}") || !personality.matches("[a-z_]{1,20}") || !position.matches("[a-z]{1,4}")) {
            return;
        }
        run(player, "create " + archetype + " " + personality + " " + position + " " + cleanName);
    }

    private static void run(ServerPlayer player, String command) {
        player.getServer().getCommands().performPrefixedCommand(player.createCommandSourceStack(), "bluelock " + command);
        sendState(player);
    }

    public static void sendState(ServerPlayer player) {
        CompoundTag t = new CompoundTag();
        Optional<PlayerProfile> profile = ProfileSavedData.get(player.getServer()).load(player.getUUID());
        t.putBoolean("hasProfile", profile.isPresent());
        if (profile.isPresent()) {
            t.put("profile", NbtMapConverter.toTag(ProfileCodec.toMap(profile.get())));
            t.putLong("xpNeeded", Progression.xpToNext(profile.get().level()));
        } else {
            CharacterRoll.Result roll = CreationRolls.get(player.getUUID());
            t.putString("rollFoot", roll.foot().name());
            t.putString("rollTalent", roll.talent().name());
        }

        ListTag skills = new ListTag();
        for (SkillDefinition s : BlueLockData.get().skills().values()) {
            CompoundTag c = new CompoundTag();
            c.putString("id", s.id());
            c.putString("category", s.category().name());
            c.putString("requires", String.join(",", s.requires()));
            c.putInt("cooldown", s.cooldownTicks());
            c.putInt("stamina", s.staminaCost());
            CompoundTag reqs = new CompoundTag();
            for (Map.Entry<Stat, Integer> e : s.requirements().entrySet()) {
                reqs.putInt(e.getKey().name(), e.getValue());
            }
            c.put("req", reqs);
            skills.add(c);
        }
        t.put("skills", skills);

        ListTag quests = new ListTag();
        for (QuestDefinition q : BlueLockData.get().quests().values()) {
            CompoundTag c = new CompoundTag();
            c.putString("id", q.id());
            c.putString("type", q.type().name());
            c.putInt("target", q.target());
            c.putInt("xp", q.rewardXp());
            c.putInt("sp", q.rewardSkillPoints());
            c.putInt("dp", q.rewardDevelopmentPoints());
            quests.add(c);
        }
        t.put("quests", quests);

        t.putString("mode", MatchManager.mode().label());
        t.putBoolean("bots", MatchManager.botsEnabled());
        t.putString("difficulty", MatchManager.difficulty().label());
        t.putBoolean("pitch", MatchManager.hasPitch());
        var session = MatchManager.session();
        t.putBoolean("active", session != null && session.isActive());
        t.putInt("home", session == null ? 0 : session.homeGoals());
        t.putInt("away", session == null ? 0 : session.awayGoals());
        var side = MatchManager.sideOf(player.getUUID());
        t.putInt("side", side == null ? -1 : side.ordinal());
        var homeTeam = MatchManager.teamDefinition(com.bluelock.common.match.Side.HOME);
        var awayTeam = MatchManager.teamDefinition(com.bluelock.common.match.Side.AWAY);
        t.putString("teamHome", homeTeam.map(d -> d.id()).orElse(""));
        t.putString("teamAway", awayTeam.map(d -> d.id()).orElse(""));
        BlueLockNetwork.sendToPlayer(player, new MenuStatePacket(t));
    }
}
