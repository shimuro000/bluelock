package com.bluelock.forge;

import com.bluelock.common.content.SkillCategory;
import com.bluelock.common.content.SkillDefinition;
import com.bluelock.common.content.QuestDefinition;
import com.bluelock.common.profile.PlayerProfile;
import com.bluelock.common.progression.SkillRules;
import com.bluelock.common.stats.Stat;
import com.bluelock.common.stats.StatCategory;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** The Blue Lock menu (key M): Match, Stats, Skills and Quests (client only). */
public class MainMenuScreen extends Screen {
    private enum Tab { MATCH, STATS, SKILLS, QUESTS }

    private record Label(Component text, int x, int y, int color) {
    }

    private record Bar(int x, int y, int w, int h, int percent, int color) {
    }

    private static final List<String> MODES = List.of("1v1", "2v2", "3v3", "4v4", "5v5", "7v7", "11v11");
    private static final List<String> DIFFICULTIES = List.of("easy", "normal", "hard", "pro");
    private static final List<String> TEAMS = List.of("team_v", "team_w", "team_x", "team_y", "team_z");
    private static final int[] MINUTES = {3, 5, 10};
    private static final int ROW = 22;

    private static Tab tab = Tab.MATCH;
    private static int statCategory;
    private static int skillCategory;
    private static int questPage;
    private static int minutesIndex;

    private final List<Label> labels = new ArrayList<>();
    private final List<Bar> bars = new ArrayList<>();
    private int lastVersion = -1;
    private int ticks;
    private int left;
    private int width0;
    private int top;

    public MainMenuScreen() {
        super(Component.translatable("bluelock.menu.title"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ClientKeys.MENU.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void tick() {
        ticks++;
        if (ticks % 20 == 0) {
            BlueLockNetwork.CHANNEL.sendToServer(new MenuRequestPacket());
        }
        if (lastVersion != ClientMenuState.version) {
            lastVersion = ClientMenuState.version;
            rebuildWidgets();
        }
    }

    private void send(String command) {
        BlueLockNetwork.CHANNEL.sendToServer(new MenuCommandPacket(command));
    }

    private static String next(List<String> list, String current) {
        int i = list.indexOf(current);
        return list.get((i + 1) % list.size());
    }

    @Override
    protected void init() {
        labels.clear();
        bars.clear();
        width0 = Math.min(width - 24, 460);
        left = (width - width0) / 2;
        top = 72;
        Tab[] tabs = Tab.values();
        int tabWidth = width0 / tabs.length;
        for (int i = 0; i < tabs.length; i++) {
            Tab t = tabs[i];
            addRenderableWidget(new BlueButton(left + i * tabWidth, 46, tabWidth - 3, 20,
                    Component.translatable("bluelock.menu.tab." + t.name().toLowerCase(Locale.ROOT)),
                    b -> {
                        tab = t;
                        rebuildWidgets();
                    }, t == tab ? BlueUi.GOLD : BlueUi.CYAN));
        }
        addRenderableWidget(new BlueButton(left + width0 - 70, height - 26, 70, 18,
                Component.translatable("bluelock.menu.close"), b -> onClose(), BlueUi.RED));

        if (!ClientMenuState.hasProfile || ClientMenuState.profile == null) {
            labels.add(new Label(Component.translatable("bluelock.menu.no_character"), left + 8, top + 10, BlueUi.GOLD));
            addRenderableWidget(new BlueButton(left + 8, top + 30, 180, 20,
                    Component.translatable("bluelock.menu.create_character"),
                    b -> minecraft.setScreen(new CharacterCreationScreen()), BlueUi.GOLD));
            return;
        }
        switch (tab) {
            case MATCH -> buildMatch();
            case STATS -> buildStats();
            case SKILLS -> buildSkills();
            case QUESTS -> buildQuests();
        }
    }

    // ---------- MATCH ----------

    private void buildMatch() {
        int y = top + 8;
        int bw = 214;
        addRenderableWidget(new BlueButton(left + 6, y, bw, 20, Component.translatable("bluelock.menu.match.pitch"),
                b -> send("pitch"), BlueUi.CYAN));
        y += ROW;
        addRenderableWidget(new BlueButton(left + 6, y, bw, 20, Component.translatable("bluelock.menu.match.mode", ClientMenuState.mode),
                b -> send("match mode " + next(MODES, ClientMenuState.mode)), BlueUi.CYAN));
        y += ROW;
        addRenderableWidget(new BlueButton(left + 6, y, bw, 20, Component.translatable("bluelock.menu.match.minutes", MINUTES[minutesIndex]),
                b -> {
                    minutesIndex = (minutesIndex + 1) % MINUTES.length;
                    rebuildWidgets();
                }, BlueUi.CYAN));
        y += ROW;
        addRenderableWidget(new BlueButton(left + 6, y, bw, 20,
                Component.translatable("bluelock.menu.match.bots", Component.translatable(ClientMenuState.bots ? "bluelock.menu.on" : "bluelock.menu.off")),
                b -> send("match bots " + (ClientMenuState.bots ? "off" : "on")), BlueUi.CYAN));
        y += ROW;
        addRenderableWidget(new BlueButton(left + 6, y, bw, 20,
                Component.translatable("bluelock.menu.match.difficulty", Component.translatable("bluelock.menu.difficulty." + ClientMenuState.difficulty)),
                b -> send("match difficulty " + next(DIFFICULTIES, ClientMenuState.difficulty)), BlueUi.CYAN));
        y += ROW;
        addRenderableWidget(new BlueButton(left + 6, y, bw / 2 - 2, 20, Component.translatable("bluelock.menu.match.join_home"),
                b -> send("match join home"), ClientMenuState.side == 0 ? BlueUi.GOLD : BlueUi.BLUE));
        addRenderableWidget(new BlueButton(left + 6 + bw / 2 + 2, y, bw / 2 - 2, 20, Component.translatable("bluelock.menu.match.join_away"),
                b -> send("match join away"), ClientMenuState.side == 1 ? BlueUi.GOLD : BlueUi.RED));
        y += ROW;
        addRenderableWidget(new BlueButton(left + 6, y, bw, 20,
                Component.translatable("bluelock.menu.match.team_home", teamName(ClientMenuState.teamHome)),
                b -> send("team set home " + next(TEAMS, ClientMenuState.teamHome.isEmpty() ? TEAMS.get(TEAMS.size() - 1) : ClientMenuState.teamHome)), BlueUi.BLUE));
        y += ROW;
        addRenderableWidget(new BlueButton(left + 6, y, bw, 20,
                Component.translatable("bluelock.menu.match.team_away", teamName(ClientMenuState.teamAway)),
                b -> send("team set away " + next(TEAMS, ClientMenuState.teamAway.isEmpty() ? TEAMS.get(TEAMS.size() - 1) : ClientMenuState.teamAway)), BlueUi.RED));

        int rx = left + bw + 22;
        addRenderableWidget(new BlueButton(rx, top + 8, width0 - bw - 28, 30, Component.translatable("bluelock.menu.match.start"),
                b -> send("match start " + MINUTES[minutesIndex]), BlueUi.GREEN));
        addRenderableWidget(new BlueButton(rx, top + 8 + 34, width0 - bw - 28, 20, Component.translatable("bluelock.menu.match.stop"),
                b -> send("match stop"), BlueUi.RED));
        labels.add(new Label(Component.translatable(ClientMenuState.pitch ? "bluelock.menu.match.pitch_yes" : "bluelock.menu.match.pitch_no"),
                rx, top + 72, ClientMenuState.pitch ? BlueUi.GREEN : BlueUi.GREY));
        labels.add(new Label(Component.translatable(ClientMenuState.matchActive ? "bluelock.menu.match.running" : "bluelock.menu.match.idle"),
                rx, top + 86, ClientMenuState.matchActive ? BlueUi.GOLD : BlueUi.GREY));
        if (ClientMenuState.matchActive) {
            labels.add(new Label(Component.literal(ClientMenuState.homeGoals + "  -  " + ClientMenuState.awayGoals), rx, top + 100, BlueUi.WHITE));
        }
        labels.add(new Label(Component.translatable("bluelock.menu.match.hint"), rx, top + 122, BlueUi.GREY));
    }

    private static Component teamName(String id) {
        return id.isEmpty() ? Component.translatable("bluelock.team.custom") : Component.translatable("bluelock.team." + id + ".name");
    }

    // ---------- STATS ----------

    private void buildStats() {
        PlayerProfile p = ClientMenuState.profile;
        StatCategory[] cats = StatCategory.values();
        int cw = width0 / cats.length;
        for (int i = 0; i < cats.length; i++) {
            int index = i;
            addRenderableWidget(new BlueButton(left + i * cw, top + 4, cw - 3, 18,
                    Component.translatable("bluelock.menu.stats.cat." + cats[i].name().toLowerCase(Locale.ROOT)),
                    b -> {
                        statCategory = index;
                        rebuildWidgets();
                    }, i == statCategory ? BlueUi.GOLD : BlueUi.BLUE));
        }
        labels.add(new Label(Component.translatable("bluelock.menu.stats.points", p.developmentPoints()), left + 4, top + 28, BlueUi.GOLD));
        int y = top + 44;
        for (Stat stat : Stat.values()) {
            if (stat.category() != cats[statCategory]) {
                continue;
            }
            int value = p.stats().permanent(stat);
            labels.add(new Label(Component.translatable(stat.langKey()), left + 6, y + 6, BlueUi.WHITE));
            bars.add(new Bar(left + 170, y + 7, 150, 6, value, value >= 70 ? BlueUi.CYAN : BlueUi.BLUE));
            labels.add(new Label(Component.literal(String.valueOf(value)), left + 326, y + 6, BlueUi.WHITE));
            int cap = p.growthCurve().softCap();
            int cost = p.growthCurve().costToRaise(value);
            BlueButton up = new BlueButton(left + 352, y, 80, 18, Component.translatable("bluelock.menu.stats.up", cost),
                    b -> send("train " + stat.name().toLowerCase(Locale.ROOT) + " up"), BlueUi.GREEN);
            up.active = value < cap && p.developmentPoints() >= cost;
            addRenderableWidget(up);
            y += 19;
        }
    }

    // ---------- SKILLS ----------

    private void buildSkills() {
        PlayerProfile p = ClientMenuState.profile;
        List<SkillCategory> cats = new ArrayList<>();
        for (SkillCategory c : SkillCategory.values()) {
            for (SkillDefinition s : ClientMenuState.SKILLS) {
                if (s.category() == c) {
                    cats.add(c);
                    break;
                }
            }
        }
        if (cats.isEmpty()) {
            labels.add(new Label(Component.translatable("bluelock.menu.skills.none"), left + 6, top + 10, BlueUi.GREY));
            return;
        }
        skillCategory = Math.floorMod(skillCategory, cats.size());
        addRenderableWidget(new BlueButton(left, top + 4, 30, 18, Component.literal("<"), b -> {
            skillCategory--;
            rebuildWidgets();
        }, BlueUi.CYAN));
        addRenderableWidget(new BlueButton(left + width0 - 30, top + 4, 30, 18, Component.literal(">"), b -> {
            skillCategory++;
            rebuildWidgets();
        }, BlueUi.CYAN));
        SkillCategory category = cats.get(skillCategory);
        labels.add(new Label(Component.translatable("bluelock.menu.skills.cat." + category.name().toLowerCase(Locale.ROOT))
                .append(Component.literal("   ")).append(Component.translatable("bluelock.menu.skills.points", p.skillPoints())),
                left + 40, top + 9, BlueUi.GOLD));
        int y = top + 30;
        for (SkillDefinition skill : ClientMenuState.SKILLS) {
            if (skill.category() != category) {
                continue;
            }
            labels.add(new Label(Component.translatable(skill.nameKey()), left + 6, y + 2, BlueUi.WHITE));
            labels.add(new Label(Component.translatable(skill.descriptionKey()), left + 6, y + 13, BlueUi.GREY));
            String error = SkillRules.check(p, skill);
            Component status;
            int color;
            if (p.isUnlocked(skill.id())) {
                status = Component.translatable("bluelock.menu.skills.unlocked");
                color = BlueUi.GREEN;
            } else if (error == null) {
                status = Component.translatable("bluelock.menu.skills.ready");
                color = BlueUi.GOLD;
            } else {
                status = Component.translatable(error);
                color = BlueUi.RED;
            }
            labels.add(new Label(status, left + 250, y + 2, color));
            labels.add(new Label(requirementText(skill), left + 250, y + 13, BlueUi.GREY));
            BlueButton unlock = new BlueButton(left + width0 - 78, y + 2, 78, 18, Component.translatable("bluelock.menu.skills.unlock"),
                    b -> send("skills unlock " + skill.id()), BlueUi.GREEN);
            unlock.active = !p.isUnlocked(skill.id()) && error == null && !skill.requires().isEmpty();
            addRenderableWidget(unlock);
            y += 30;
        }
    }

    private static Component requirementText(SkillDefinition skill) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Stat, Integer> e : skill.requirements().entrySet()) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(Component.translatable(e.getKey().langKey()).getString()).append(' ').append(e.getValue());
        }
        return Component.literal(sb.toString());
    }

    // ---------- QUESTS ----------

    private void buildQuests() {
        PlayerProfile p = ClientMenuState.profile;
        List<QuestDefinition> quests = ClientMenuState.QUESTS;
        int perPage = 5;
        int pages = Math.max(1, (quests.size() + perPage - 1) / perPage);
        questPage = Math.floorMod(questPage, pages);
        addRenderableWidget(new BlueButton(left, top + 4, 30, 18, Component.literal("<"), b -> {
            questPage--;
            rebuildWidgets();
        }, BlueUi.CYAN));
        addRenderableWidget(new BlueButton(left + width0 - 30, top + 4, 30, 18, Component.literal(">"), b -> {
            questPage++;
            rebuildWidgets();
        }, BlueUi.CYAN));
        labels.add(new Label(Component.translatable("bluelock.menu.quests.page", questPage + 1, pages), left + 40, top + 9, BlueUi.GOLD));
        int y = top + 30;
        for (int i = questPage * perPage; i < Math.min(quests.size(), (questPage + 1) * perPage); i++) {
            QuestDefinition q = quests.get(i);
            boolean done = p.isQuestDone(q.id());
            int progress = done ? q.target() : p.questProgress(q.id());
            labels.add(new Label(Component.translatable(q.nameKey()), left + 6, y, done ? BlueUi.GREEN : BlueUi.WHITE));
            labels.add(new Label(Component.translatable(q.descriptionKey()), left + 6, y + 11, BlueUi.GREY));
            bars.add(new Bar(left + 6, y + 24, 200, 5, progress * 100 / q.target(), done ? BlueUi.GREEN : BlueUi.CYAN));
            labels.add(new Label(Component.literal(progress + "/" + q.target()), left + 212, y + 22, BlueUi.WHITE));
            labels.add(new Label(Component.translatable("bluelock.menu.quests.reward", q.rewardXp(), q.rewardSkillPoints(), q.rewardDevelopmentPoints()),
                    left + 260, y + 11, BlueUi.GOLD));
            y += 38;
        }
    }

    // ---------- drawing ----------

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        BlueUi.background(g, width, height);
        BlueUi.title(g, font, left, 8, 2.0F, Component.translatable("bluelock.menu.logo"), BlueUi.WHITE);
        BlueUi.slogan(g, font, width / 2 + width0 / 4, 14, ticks);
        PlayerProfile p = ClientMenuState.hasProfile ? ClientMenuState.profile : null;
        if (p != null) {
            Component who = Component.literal(p.name() + "  ").append(Component.translatable(p.talent().langKey()));
            g.drawString(font, who, left, 30, p.talent() == com.bluelock.common.profile.Talent.GENIUS ? BlueUi.GOLD : BlueUi.WHITE, true);
            Component lvl = Component.translatable("bluelock.menu.level", p.level());
            g.drawString(font, lvl, left + width0 - font.width(lvl), 30, BlueUi.WHITE, true);
            BlueUi.bar(g, left + width0 - 140, 38, 100, 4, (int) (100 * p.xp() / Math.max(1, ClientMenuState.xpNeeded)), BlueUi.CYAN);
        }
        BlueUi.panel(g, left - 4, top - 2, width0 + 8, height - top - 30);
        for (Bar b : bars) {
            BlueUi.bar(g, b.x(), b.y(), b.w(), b.h(), b.percent(), b.color());
        }
        for (Label l : labels) {
            g.drawString(font, l.text(), l.x(), l.y(), l.color(), true);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }
}
