package com.bluelock.common.progression;

import com.bluelock.common.content.DefinitionPack;
import com.bluelock.common.content.QuestDefinition;
import com.bluelock.common.content.QuestType;
import com.bluelock.common.profile.PlayerProfile;
import java.util.ArrayList;
import java.util.List;

/** Quest progress. Every counted action moves all unfinished quests of that type; finished quests pay out at once. */
public final class Quests {
    private Quests() {
    }

    /** Adds progress and returns the quests that were completed by it (rewards are already given). */
    public static List<QuestDefinition> record(PlayerProfile p, QuestType type, int amount, DefinitionPack pack) {
        List<QuestDefinition> completed = new ArrayList<>();
        if (amount <= 0) return completed;
        for (QuestDefinition q : pack.quests().values()) {
            if (q.type() != type || p.isQuestDone(q.id())) continue;
            int progress = Math.min(q.target(), p.questProgress(q.id()) + amount);
            p.setQuestProgress(q.id(), progress);
            if (progress >= q.target()) {
                p.markQuestDone(q.id());
                p.addPoints(q.rewardSkillPoints(), q.rewardDevelopmentPoints());
                Progression.award(p, q.rewardXp());
                completed.add(q);
            }
        }
        return completed;
    }

    public static int doneCount(PlayerProfile p, DefinitionPack pack) {
        int n = 0;
        for (QuestDefinition q : pack.quests().values()) {
            if (p.isQuestDone(q.id())) n++;
        }
        return n;
    }
}
